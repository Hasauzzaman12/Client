import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetAllocationLandReturnComponent } from './asset-allocation-land-return.component';

describe('AssetAllocationLandReturnComponent', () => {
  let component: AssetAllocationLandReturnComponent;
  let fixture: ComponentFixture<AssetAllocationLandReturnComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AssetAllocationLandReturnComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AssetAllocationLandReturnComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
