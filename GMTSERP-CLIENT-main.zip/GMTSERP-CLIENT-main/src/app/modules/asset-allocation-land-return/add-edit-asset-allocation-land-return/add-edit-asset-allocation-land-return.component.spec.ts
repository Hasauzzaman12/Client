import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditAssetAllocationLandReturnComponent } from './add-edit-asset-allocation-land-return.component';

describe('AddEditAssetAllocationLandReturnComponent', () => {
  let component: AddEditAssetAllocationLandReturnComponent;
  let fixture: ComponentFixture<AddEditAssetAllocationLandReturnComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddEditAssetAllocationLandReturnComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddEditAssetAllocationLandReturnComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
