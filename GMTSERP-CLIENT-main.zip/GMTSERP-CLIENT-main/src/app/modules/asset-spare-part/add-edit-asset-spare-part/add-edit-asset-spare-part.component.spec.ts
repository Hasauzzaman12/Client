import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditAssetSparePartComponent } from './add-edit-asset-spare-part.component';

describe('AddEditAssetSparePartComponent', () => {
  let component: AddEditAssetSparePartComponent;
  let fixture: ComponentFixture<AddEditAssetSparePartComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddEditAssetSparePartComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddEditAssetSparePartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
