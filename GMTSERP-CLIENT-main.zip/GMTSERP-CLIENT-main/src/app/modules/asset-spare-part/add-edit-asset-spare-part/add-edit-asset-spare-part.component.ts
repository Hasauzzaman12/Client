import { HttpClient, HttpEventType, HttpRequest } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable, of,startWith, debounceTime, distinctUntilChanged, switchMap, map } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';

@Component({
  selector: 'app-add-edit-asset-spare-part',
  templateUrl: './add-edit-asset-spare-part.component.html',
  styleUrls: ['./add-edit-asset-spare-part.component.scss']
})
export class AddEditAssetSparePartComponent implements OnInit {

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';

  constructor(public _apiService: ApiServiceService,
    private _snackBar: MatSnackBar,
    public router: Router,
    private authservice: AuthService,
    private currentRoute: ActivatedRoute) { 

    }

    newBlogForm!: FormGroup;
    id: number = 0;
    name= '';
    asset_Owner_Id: number = 0;
    user_Id: number = this.authservice.getUserId;
    display_Order: number = 0;
    is_active: boolean = true;

    assetOwnerList$!: Observable<any[]>;


  ngOnInit(): void {

    this.newBlogForm = new FormGroup({
      id: new FormControl(0),
      name: new FormControl(''),
      asset_Owner_Id: new FormControl(0),
      display_Order: new FormControl(0),
      is_active: new FormControl(true)
    });

    this.assetOwnerList$=this._apiService.getAssetOwnerList();

    let id = this.currentRoute.snapshot.paramMap.get('id');
    if (id != null) {
      this.getSparePartById(id);
      
    }
  }
  getSparePartById(id: number | string) {
   
    this._apiService.getSparePartById(id).subscribe((data: any) => {
      this.id=data.id;
      this.name=data.name;
      this.asset_Owner_Id=data.asset_Owner_Id;
      this.display_Order=data.display_Order;
      this.is_active=data.is_active;
    });
  
  }

  
  onSubmit(data: any) {
    data.id=this.id;
    if (data.name == ''||data.name == null) {
      alert("Name is Required")
      return;
    }

    if (data.asset_Owner_Id == 0||data.asset_Owner_Id == null) {
      alert("Asset Owner is Required")
      return;
    }

    const formData = new FormData();
    formData.append('id', data.id);
    formData.append('name', data.name == null ? '' : data.name);
    formData.append('asset_Owner_Id', data.asset_Owner_Id);
    formData.append('display_Order', data.display_Order);
    formData.append('is_active', data.is_active);
    formData.append('user_Id', this.user_Id.toString());
    
    if (this.newBlogForm.valid) {
      if (data.id != 0) {
  
        this._apiService.updateSparePart(formData).subscribe(res => {
  
          this._snackBar.open("Asset Spare Part Updated Successfully", "Update", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });
  
          this.router.navigate(['/asset-spare-part']);
  
  
        })
      }
      else {
        this._apiService.addSparePart(formData).subscribe(res => {
  
          this._snackBar.open("Asset Spare Part Saved Successfully", "Success", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });
  
          this.router.navigate(['/asset-spare-part']);
  
  
        })
      }
    }

  }

  gotoBack() {
    this.router.navigate(['/asset-spare-part']);
  }
  reset(): void {
    this.ngOnInit();
  }
}
