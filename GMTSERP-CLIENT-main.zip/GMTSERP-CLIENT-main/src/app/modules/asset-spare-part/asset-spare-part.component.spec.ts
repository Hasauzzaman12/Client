import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetSparePartComponent } from './asset-spare-part.component';

describe('AssetSparePartComponent', () => {
  let component: AssetSparePartComponent;
  let fixture: ComponentFixture<AssetSparePartComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AssetSparePartComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AssetSparePartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
