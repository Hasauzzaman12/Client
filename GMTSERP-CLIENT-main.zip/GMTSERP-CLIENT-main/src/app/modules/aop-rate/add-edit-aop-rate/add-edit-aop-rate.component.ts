

import { Component, Input, OnInit } from '@angular/core';
import { MatSnackBar , MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition} from '@angular/material/snack-bar';
import { ActivatedRoute ,Router} from '@angular/router';
import { Observable } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';

@Component({
  selector: 'app-add-edit-aop-rate',
  templateUrl: './add-edit-aop-rate.component.html',
  styleUrls: ['./add-edit-aop-rate.component.scss']
})
export class AddEditAopRateComponent implements OnInit {

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';

  constructor(public _apiService:ApiServiceService,
    private _snackBar: MatSnackBar,
    public router:Router,
    private currentRoute: ActivatedRoute) {}

  @Input() aopRate:any;
  id: number = 0;
  sl_No:number=0;
  aop_Type: string = "";
  mkt_Rate: number = 0;
  budget_Rate: number = 0;
  is_active: boolean=true;

  ngOnInit(): void {
    let id = this.currentRoute.snapshot.paramMap.get('id');
    if (id != null){
      this.getAOPRateById(id);

    }
  }


  //Add New Certification

  addNewAOPRate() {

    var aopRate = {
      sl_No:this.sl_No,
      aop_Type:this.aop_Type,
      mkt_Rate:this.mkt_Rate,
      budget_Rate:this.budget_Rate,
      is_active:this.is_active
     
    }
    this._apiService.addAOPRate(aopRate).subscribe(res => {

      this._snackBar.open("AOP Rate Added Successfully", "Success", {
        horizontalPosition: this.horizontalPosition,
        verticalPosition: this.verticalPosition,
        duration: 2000
      });

      this.router.navigate(['/aop-rate']);
      
    })
  }

  updateAOPRate() {

    var aopRate = {
      id:this.id,
      sl_No:this.sl_No,
      aop_Type:this.aop_Type,
      mkt_Rate:this.mkt_Rate,
      budget_Rate:this.budget_Rate,
      is_active:this.is_active
     
    }
    this._apiService.updateAOPRate(aopRate).subscribe(res => {
      this._snackBar.open("AOP Rate Updated Successfully", "Update", {
        horizontalPosition: this.horizontalPosition,
        verticalPosition: this.verticalPosition,
        duration: 2000
      });

      this.router.navigate(['/aop-rate']);
 
    })
  }

  gotoBack() {
    this.router.navigate(['/aop-rate']);
  }

  getAOPRateById(id:number|string){
    this._apiService.getAOPRateById(id)
    .subscribe((data: any) => {
      this.id=data.id;
      this.sl_No=data.sl_No;
      this.aop_Type=data.aop_Type;
      this.mkt_Rate=data.mkt_Rate;
      this.budget_Rate=data.budget_Rate;
      this.is_active =data.is_active;
    });
  
  }

}
