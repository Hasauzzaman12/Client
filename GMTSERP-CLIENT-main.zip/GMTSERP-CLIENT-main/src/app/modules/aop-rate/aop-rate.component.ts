
import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';

@Component({
  selector: 'app-aop-rate',
  templateUrl: './aop-rate.component.html',
  styleUrls: ['./aop-rate.component.scss']
})
export class AopRateComponent implements OnInit {


  displayedColumns: string[] = ['sl_No', 'aop_Type','mkt_Rate','budget_Rate','is_active','action'];
  dataSource!: MatTableDataSource<any>;

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';


  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(public _apiService:ApiServiceService,
     private _snackBar: MatSnackBar,
     public dialog: MatDialog,
     private router:Router) { }

  ngOnInit(): void {
    this.getAllAOPRateList();
  }

  getAllAOPRateList(){
    this._apiService.getAOPRateList()
    .subscribe({
      next:(res)=>{
        this.dataSource=new MatTableDataSource(res);
        this.dataSource.paginator=this.paginator;
        this.dataSource.sort=this.sort;
      },
      error:(err)=>{
        console.log("Error");
      }
      
    })
  }
  openForEdit(id: number) {
   
    this.router.navigate(['/aop-rate/edit/' + id]);
  }

  gotoNew() {
    this.router.navigate(['/addaoprate']);
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  deleteStyleMaster(id:number){
   
    if(confirm("Are you sure to delete?")){
      this._apiService.deleteCertification(id)
      .subscribe({
        next:(res)=>{
          this._snackBar.open("AOP Rate Deleted Successfully", "Delete", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 1000
          });
          this.getAllAOPRateList();
        },
        error:()=>{
          this._snackBar.open("Delete Failed", "Failed");
        }
      })
    }

   

  }

}


