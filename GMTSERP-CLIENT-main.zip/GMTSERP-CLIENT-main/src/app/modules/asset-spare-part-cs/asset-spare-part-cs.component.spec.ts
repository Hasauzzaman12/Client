import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetSparePartCsComponent } from './asset-spare-part-cs.component';

describe('AssetSparePartCsComponent', () => {
  let component: AssetSparePartCsComponent;
  let fixture: ComponentFixture<AssetSparePartCsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AssetSparePartCsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AssetSparePartCsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
