import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service'

@Component({
  selector: 'app-asset-spare-part-cs',
  templateUrl: './asset-spare-part-cs.component.html',
  styleUrls: ['./asset-spare-part-cs.component.scss']
})
export class AssetSparePartCsComponent implements OnInit {

  user_Id: number = this.authservice.getUserId;
  asset_Item_Name: string = '';
  company_Id: number = 0;
  asset_Owner_Id: number = 0;
  isFilterShow: boolean = false;

  companyList$!:Observable<any[]>;
  assetOwnerList$!:Observable<any[]>;

  displayedColumns: string[] = ['asset_Owner_Name','name','company_Name', 'current_Stock','status'];
  dataSource!: MatTableDataSource<any>;

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';


  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(public _apiService: ApiServiceService,
    private authservice: AuthService,
    private _snackBar: MatSnackBar,
    public dialog: MatDialog,
    private router: Router) { }

  ngOnInit(): void {
    this.getAssetSparePartsFiltered();
    if(this.user_Id>0){
      this.companyList$ = this._apiService.getCompanyListByUser(this.user_Id);
    }else{
      this.companyList$ = this._apiService.getCompanyList();
    }

    this.assetOwnerList$=this._apiService.getAssetOwnerList();
  }

  getAssetSparePartsFiltered() {
    const formData = new FormData();
    if (this.asset_Item_Name != ''||this.asset_Item_Name != null) {
      formData.append('asset_Item_Name', this.asset_Item_Name);
    }
    if (this.user_Id != 0||this.user_Id != null) {
      formData.append('user_Id', this.user_Id.toString());
    }
    if (this.company_Id != 0||this.company_Id != null) {
      formData.append('company_Id', this.company_Id.toString());
    }
    if (this.asset_Owner_Id != 0||this.asset_Owner_Id != null) {
      formData.append('asset_Owner_Id', this.asset_Owner_Id.toString());
    }
    this._apiService.getAssetSparePartsStock(formData)
      .subscribe({
        next: (res) => {
          this.dataSource = new MatTableDataSource(res);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
        },
        error: (err) => {
          console.log("Error");
        }

      })
  }
  SearchSummary() {
    this.getAssetSparePartsFiltered();
  }
  reset() {
    this.asset_Item_Name='';
    this.company_Id=0;
    this.asset_Owner_Id=0;
    this.getAssetSparePartsFiltered();
  }

  toggleFilter() {
    this.isFilterShow = !this.isFilterShow;
  }
  openForEdit(id: number) {

    this.router.navigate(['/asset-spare-part/edit/' + id]);
  }
  gotoNew() {
    this.router.navigate(['/add-asset-spare-part']);
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

 

}
