import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddAdminMenuComponent } from './add-admin-menu.component';

describe('AddAdminMenuComponent', () => {
  let component: AddAdminMenuComponent;
  let fixture: ComponentFixture<AddAdminMenuComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddAdminMenuComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddAdminMenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
