

import { HttpClient, HttpEventType, HttpRequest } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable, of, startWith, debounceTime, distinctUntilChanged, switchMap, map } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';
import { DatePipe } from '@angular/common';


@Component({
  selector: 'app-add-admin-menu',
  templateUrl: './add-admin-menu.component.html',
  styleUrls: ['./add-admin-menu.component.scss']
})
export class AddAdminMenuComponent implements OnInit {
  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';
  user_Id: number = this.authservice.getUserId;


  constructor(public _apiService: ApiServiceService,
    private _snackBar: MatSnackBar,
    public router: Router,
    private authservice: AuthService,
    private currentRoute: ActivatedRoute,
    private datepipe: DatePipe) {

  }

  newBlogForm!: FormGroup;

  id: number = 0;
  display_Name = '';
  position = '';
  link_Name = '';
  parent_Menu_Id: number = 0;
  module_Id: number = 0;
  display_Order: number = 0;
  is_Active: boolean = true;
  is_Menu: boolean = true;
  menu_Name: string = '';

  public isExist: boolean = false;
  public editMood: boolean = false;


  positionList$!: Observable<any[]>;
  parentmenuList$!: Observable<any[]>;
  moduleList$!: Observable<any[]>;
  employeeList$!: Observable<any[]>;

  ngOnInit(): void {

    this.newBlogForm = new FormGroup({
      id: new FormControl(0),
      display_Name: new FormControl(''),
      link_Name: new FormControl(''),
      position: new FormControl(''),
      parent_Menu_Id: new FormControl(0),
      module_Id: new FormControl(0),
      display_Order: new FormControl(0),
      is_Active: new FormControl(true),
      is_Menu: new FormControl(true)
    });


    this.parentmenuList$ = this._apiService.getmenuList();
    this.moduleList$ = this._apiService.getmoduleList();

    let id = this.currentRoute.snapshot.paramMap.get('id');
    if (id != null) {
      this.getAdminMenuById(id);

    }

    const pos_list = [
      { id: 'Top', name: 'Top' },
      { id: 'Left', name: 'Left' },
      { id: 'Right', name: 'Right' },
      { id: 'Bottom', name: 'Bottom' },
      { id: 'Footer', name: 'Footer' }
    ];

    this.positionList$ = of(pos_list);



  }


  getAdminMenuById(id: number | string) {
    this._apiService.getAdminMenuById(id).subscribe((data: any) => {
      console.log(data);

      this.id = data.id;
      this.display_Name = data.display_Name;
      this.link_Name = data.link_Name;
      this.position = data.position;
      this.parent_Menu_Id = data.parent_Menu_Id;
      this.module_Id = data.module_Id;
      this.display_Order = data.display_Order;
      this.is_Active = data.is_Active;
      this.is_Menu = data.is_Menu;


    });


  }

  isExistMenu(data: any) {

    this.menu_Name = data.display_Name;
    this._apiService.checkduplicateMenuName(this.menu_Name).subscribe(response => {
      this.isExist = response;

      if (this.isExist == true) {
        this._snackBar.open("This Menu already exist", "Please Update", {
          horizontalPosition: this.horizontalPosition,
          verticalPosition: this.verticalPosition,
          duration: 2000
        });
      }
    });
  }

  onSubmit(data: any) {
    data.id = this.id;
    data.menu_Name = data.display_Name;
    data.user_Id=this.user_Id;

    if (data.display_Name == '' || data.display_Name == null) {
      alert("Menu Name is Required")
      return;
    }
    if (data.position == 0 || data.position == null) {
      alert("Position is Required")
      return;
    }


    const formData = new FormData();

    formData.append('id', data.id);
    formData.append('display_Name', data.display_Name);
    formData.append('link_Name', data.link_Name);
    formData.append('position', data.position);
    formData.append('parent_Menu_Id', data.parent_Menu_Id);
    formData.append('module_Id', data.module_Id);
    formData.append('display_Order', data.display_Order);
    formData.append('is_Active', data.is_Active);
    formData.append('is_Menu', data.is_Menu);

    if (this.newBlogForm.valid) {
      if (data.id != 0) {

        this._apiService.updateAdminMenu(data).subscribe(res => {

          this._snackBar.open("Menu Updated Successfully", "Update", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });

          this.router.navigate(['/menu']);
        })
      }
      else {
        this._apiService.addAdminMenu(data).subscribe(res => {

          this._snackBar.open("Menu Saved Successfully", "Success", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });

          this.router.navigate(['/menu']);
        })
      }
    }

  }


  gotoBack() {
    this.router.navigate(['/menu']);
  }
  reset(): void {
    this.ngOnInit();
  }
}
