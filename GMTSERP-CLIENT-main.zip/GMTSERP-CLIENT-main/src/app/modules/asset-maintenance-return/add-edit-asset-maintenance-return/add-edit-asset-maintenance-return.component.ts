import { HttpClient, HttpEventType, HttpRequest } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable, of,startWith, debounceTime, distinctUntilChanged, switchMap, map } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-add-edit-asset-maintenance-return',
  templateUrl: './add-edit-asset-maintenance-return.component.html',
  styleUrls: ['./add-edit-asset-maintenance-return.component.scss']
})
export class AddEditAssetMaintenanceReturnComponent implements OnInit {

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';

  myControl = new FormControl();
  filteredOptions: Observable<any>;

  constructor(public _apiService: ApiServiceService,
    private _snackBar: MatSnackBar,
    public router: Router,
    private authservice: AuthService,
    private currentRoute: ActivatedRoute,
    private datepipe: DatePipe) {  this.filteredOptions = this.myControl.valueChanges.pipe(

      startWith(''),

      debounceTime(400),

      distinctUntilChanged(),

      switchMap(val => {

            return this.filter(val || '')

       }) 

    )}

    newBlogForm!: FormGroup;
    id: number = 0;
    maintenance_Date : any;
    maintenance_No= '';
    asset_Book_Id: number = 0;
    asset_No= '';
    supplier_Id: number = 0;
    supplier_Name= '';
    service_Amount: number = 0;
    reason_Of_Maintenance= '';
    aprrox_Return_Date : any;
    actual_Return_Date : any;
    remarks= '';
    is_active: boolean = true;

    attachment_Id: number = 0;
    attachment_File_Name= '';

    selectedFile!: File;
    user_Id: number = this.authservice.getUserId;

  ngOnInit(): void {

    let currentDateTime =this.datepipe.transform((new Date), 'MM/dd/yyyy h:mm:ss');
    this.newBlogForm = new FormGroup({
      id: new FormControl(0),
      maintenance_No: new FormControl(''),
      maintenance_Date: new FormControl(null),
      asset_Book_Id: new FormControl(0),
      supplier_Id: new FormControl(0),
      service_Amount: new FormControl(0),
      reason_Of_Maintenance: new FormControl(''),
      aprrox_Return_Date: new FormControl(null),
      actual_Return_Date: new FormControl(null),
      remarks: new FormControl(''),
      is_active: new FormControl(true)
    });

    let id = this.currentRoute.snapshot.paramMap.get('id');
    if (id != null) {
      this.getAssetMaintenanceReturnById(id);
     
    }else{
      this.actual_Return_Date=currentDateTime;
      
    }
  }
  getAssetMaintenanceReturnById(id: number | string) {
    this._apiService.getAssetMaintenanceById(id).subscribe((data: any) => {
      this.id=data.id;
      this.maintenance_Date=data.maintenance_Date;
      this.maintenance_No=data.maintenance_No;
      this.asset_Book_Id=data.asset_Book_Id;
      this.asset_No=data.asset_No;
      this.supplier_Id=data.supplier_Id;
      this.supplier_Name=data.supplier_Name;
      this.service_Amount=data.service_Amount;
      this.reason_Of_Maintenance=data.reason_Of_Maintenance;
      this.aprrox_Return_Date=data.aprrox_Return_Date;
      this.actual_Return_Date=data.actual_Return_Date;
      this.remarks=data.remarks;
      this.is_active=data.is_active;
      this.attachment_Id=data.attachment_Id;
      this.attachment_File_Name=data.attachment_File_Name;

    });
  }

  getAssetMaintenanceByAssetId(id: number | string) {
    this._apiService.getAssetMaintenanceByAssetId(id).subscribe((data: any) => {
      this.id=data.id;
      this.maintenance_Date=data.maintenance_Date;
      this.maintenance_No=data.maintenance_No;
      this.asset_Book_Id=data.asset_Book_Id;
      this.asset_No=data.asset_No;
      this.supplier_Id=data.supplier_Id;
      this.supplier_Name=data.supplier_Name;
      this.service_Amount=data.service_Amount;
      this.reason_Of_Maintenance=data.reason_Of_Maintenance;
      this.aprrox_Return_Date=data.aprrox_Return_Date;
      this.is_active=data.is_active;
      this.attachment_Id=data.attachment_Id;
      this.attachment_File_Name=data.attachment_File_Name;

    });
  }

  onSubmit(data: any){
    data.id=this.id;
    
    if(data.actual_Return_Date == ''||data.actual_Return_Date == null) {
      alert("Return Date is Required")
      return;
    }


    const formData = new FormData();

    formData.append('id', data.id);
    formData.append('actual_Return_Date', data.actual_Return_Date);
    formData.append('service_Amount', data.service_Amount);
    formData.append('remarks', data.remarks);
    formData.append('is_active', data.is_active);


    if (this.newBlogForm.valid) {
      if (data.id != 0) {
  
        this._apiService.updateAssetMaintenanceForReturn(formData).subscribe(res => {
  
          this._snackBar.open("Asset Maintenance Updated Successfully", "Update", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });
  
          this.router.navigate(['/asset-maintenance-return']);
  
  
        })
      }
      else {
        this._snackBar.open("Invalid", "Invalid", {
          horizontalPosition: this.horizontalPosition,
          verticalPosition: this.verticalPosition,
          duration: 2000
        });
      }
    }
   }
   filter(val: string): Observable <any>{

    const formData = new FormData();
    if (this.user_Id != 0||this.user_Id != null) {
      formData.append('user_Id', this.user_Id.toString());
    }
    formData.append('status', 'Maintenance Receive');

    return this._apiService.getAssetForDdlFiltered(formData)

      .pipe(
 
        map(response => response.filter((option: { asset_No: string; }) => { 
 
          return option.asset_No.toLowerCase().indexOf(val.toLowerCase()) !== -1
 
        }))
 
      )

    // if(this.id===0){
    //   return this._apiService.getMaintenanceReceiveAsset()

    //   .pipe(
 
    //     map(response => response.filter((option: { asset_No: string; }) => { 
 
    //       return option.asset_No.toLowerCase().indexOf(val.toLowerCase()) !== -1
 
    //     }))
 
    //   )
    // }else{

    //   return this._apiService.getMaintenanceReceiveAssetEdit(this.asset_Book_Id)

    //   .pipe(
 
    //     map(response => response.filter((option: { asset_No: string; }) => { 
 
    //       return option.asset_No.toLowerCase().indexOf(val.toLowerCase()) !== -1
 
    //     }))
 
    //   )
    // }
    

   } 
   gotoBack() {
    this.router.navigate(['/asset-maintenance-return']);
  }
  onSelFunc(option: any){
    if(option.id>0){
      this.asset_Book_Id=option.id;
        this.getAssetMaintenanceByAssetId(this.asset_Book_Id);
    }
  }
  reset(): void {
    this.ngOnInit();
  }
}
