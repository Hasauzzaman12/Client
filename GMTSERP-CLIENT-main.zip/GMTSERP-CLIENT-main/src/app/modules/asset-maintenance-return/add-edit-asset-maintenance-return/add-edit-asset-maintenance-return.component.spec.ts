import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditAssetMaintenanceReturnComponent } from './add-edit-asset-maintenance-return.component';

describe('AddEditAssetMaintenanceReturnComponent', () => {
  let component: AddEditAssetMaintenanceReturnComponent;
  let fixture: ComponentFixture<AddEditAssetMaintenanceReturnComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddEditAssetMaintenanceReturnComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddEditAssetMaintenanceReturnComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
