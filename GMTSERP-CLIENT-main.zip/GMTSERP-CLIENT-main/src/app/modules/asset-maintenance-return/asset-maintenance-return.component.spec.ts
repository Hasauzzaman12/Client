import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetMaintenanceReturnComponent } from './asset-maintenance-return.component';

describe('AssetMaintenanceReturnComponent', () => {
  let component: AssetMaintenanceReturnComponent;
  let fixture: ComponentFixture<AssetMaintenanceReturnComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AssetMaintenanceReturnComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AssetMaintenanceReturnComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
