import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetAllocationAdminReturnComponent } from './asset-allocation-admin-return.component';

describe('AssetAllocationAdminReturnComponent', () => {
  let component: AssetAllocationAdminReturnComponent;
  let fixture: ComponentFixture<AssetAllocationAdminReturnComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AssetAllocationAdminReturnComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AssetAllocationAdminReturnComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
