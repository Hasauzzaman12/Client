import { HttpClient, HttpEventType, HttpRequest } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable, of,startWith, debounceTime, distinctUntilChanged, switchMap, map } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';
import { DatePipe } from '@angular/common';
import { SD } from 'src/environments/sd';

@Component({
  selector: 'app-add-edit-asset-allocation-admin-return',
  templateUrl: './add-edit-asset-allocation-admin-return.component.html',
  styleUrls: ['./add-edit-asset-allocation-admin-return.component.scss']
})
export class AddEditAssetAllocationAdminReturnComponent implements OnInit {

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';

  myControl = new FormControl();
  options = [];
  filteredOptions: Observable<any>;

  constructor(public _apiService: ApiServiceService,
    private _snackBar: MatSnackBar,
    public router: Router,
    private authservice: AuthService,
    private currentRoute: ActivatedRoute,
    private datepipe: DatePipe) { 
      this.filteredOptions = this.myControl.valueChanges.pipe(

        startWith(''),
  
        debounceTime(400),
  
        distinctUntilChanged(),
  
        switchMap(val => {
  
          if(val!=''){
            return this.filter(val || '')
          }else{
            return '';
          }
  
         }) 
  
      )
    }

    newBlogForm!: FormGroup;
    id: number = 0;
    return_Date : any;
    asset_Book_Id: number = 0;
    asset_No= '';
    asset_Allocation_Id: number = 0;
    remarks= '';
    status= 'Maintenance';
    is_active: boolean = true;
    user_Id: number = this.authservice.getUserId;
    asset_Item_Category_Id: number = SD.asset_Item_Category_Id_admin;

    allocation_Date : any;
    allocation_Type= '';
    item_Description= '';
    company_Name= '';
    unit_Name= '';
    department_Name= '';
    employee_Name= '';
    custodia_Name= '';
    sub_Custodian_Name= '';

    assetBookList$!:Observable<any[]>;

  ngOnInit(): void {
    let currentDateTime =this.datepipe.transform((new Date), 'MM/dd/yyyy h:mm:ss');
    this.newBlogForm = new FormGroup({
      id: new FormControl(0),
      return_Date: new FormControl(null),
      asset_Book_Id: new FormControl(0),
      asset_Allocation_Id: new FormControl(0),
      remarks: new FormControl(''),
      status: new FormControl('Maintenance'),
      is_active: new FormControl(true)
    });

    let id = this.currentRoute.snapshot.paramMap.get('id');
    if (id != null) {
      this.getAssetAllocationReturnById(id);
     
    }else{
      this.return_Date=currentDateTime;
    }
  }

  getAssetAllocationReturnById(id: number | string) {
    this._apiService.getAssetAllocationReturnById(id).subscribe((data: any) => {
      this.id=data.id;
      this.return_Date=data.return_Date;
      this.asset_Book_Id=data.asset_Book_Id;
      this.asset_No=data.asset_No;
      this.asset_Allocation_Id=data.asset_Allocation_Id;
      this.remarks=data.remarks;
      this.status=data.status;
      this.is_active=data.is_active;

      this.allocation_Date=data.allocation_Date;
      this.allocation_Type=data.allocation_Type;
      this.item_Description=data.item_Description;
      this.company_Name=data.company_Name;
      this.unit_Name=data.unit_Name;
      this.department_Name=data.department_Name;
      this.employee_Name=data.employee_Name;
      this.custodia_Name=data.custodia_Name;
      this.sub_Custodian_Name=data.sub_Custodian_Name;
      // this.getAssetAllocationByAssetId(this.asset_Book_Id);
    });
  }


  getAssetAllocationByAssetId(id: number | string){
    this._apiService.getAssetAllocationByAssetId(id).subscribe((data: any) => {

      this.asset_Allocation_Id=data.id;
      this.allocation_Date=data.allocation_Date;
      this.allocation_Type=data.allocation_Type;
      this.item_Description=data.item_Description;
      this.company_Name=data.company_Name;
      this.unit_Name=data.unit_Name;
      this.department_Name=data.department_Name;
      this.employee_Name=data.employee_Name;
      this.custodia_Name=data.custodia_Name;
      this.sub_Custodian_Name=data.sub_Custodian_Name;
    });
  }
  onSubmit(data: any){
    if(data.return_Date == ''||data.return_Date == null) {
      alert("Return Date is Required")
      return;
    }
    if (data.asset_Book_Id == 0||data.asset_Book_Id == null) {
      alert("Asset Book is Required")
      return;
    }

    const formData = new FormData();
    data.id=this.id;
    data.asset_Allocation_Id=this.asset_Allocation_Id;
    
    formData.append('id', data.id);
    formData.append('return_Date', data.return_Date);
    formData.append('asset_Book_Id', data.asset_Book_Id);
    formData.append('asset_Allocation_Id', data.asset_Allocation_Id);
    formData.append('remarks', data.remarks);
    formData.append('status', data.status);
    formData.append('is_active', data.is_active);

    if (this.newBlogForm.valid) {
      if (data.id != 0) {
  
        this._apiService.updateAssetAllocationReturn(formData).subscribe(res => {
  
          this._snackBar.open("Asset Allocation Return Updated Successfully", "Update", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });
  
          this.router.navigate(['/asset-allocation-admin-return']);
  
  
        })
      }
      else {
        this._apiService.addAssetAllocationReturn(formData).subscribe(res => {
  
          this._snackBar.open("Asset Allocation Return Saved Successfully", "Success", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });
  
          this.router.navigate(['/asset-allocation-admin-return']);

        })
      }
    }

  }
  filter(val: string): Observable <any>{

    const formData = new FormData();
    formData.append('asset_No', val);
    if (this.user_Id != 0||this.user_Id != null) {
      formData.append('user_Id', this.user_Id.toString());
    }
    formData.append('status', 'INSTALLED');
    formData.append('asset_Item_Category_Id', this.asset_Item_Category_Id.toString());
    return this._apiService.getAssetBookingFiltered(formData)

    .pipe(

      map(response => response.filter((option: { asset_No: string; }) => { 

        return option.asset_No.toLowerCase().indexOf(val.toLowerCase()) !== -1

      }))

    )

   }  

   onSelFunc(option: any){
    if(option.id>0){
      this.asset_Book_Id=option.id;
        this.getAssetAllocationByAssetId(this.asset_Book_Id);
    }
  }
  gotoBack() {
    this.router.navigate(['/asset-allocation-admin-return']);
  }
  reset(): void {
    this.ngOnInit();
  }
}

