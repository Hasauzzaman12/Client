import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditAssetAllocationAdminReturnComponent } from './add-edit-asset-allocation-admin-return.component';

describe('AddEditAssetAllocationAdminReturnComponent', () => {
  let component: AddEditAssetAllocationAdminReturnComponent;
  let fixture: ComponentFixture<AddEditAssetAllocationAdminReturnComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddEditAssetAllocationAdminReturnComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddEditAssetAllocationAdminReturnComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
