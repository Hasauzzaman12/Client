import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetItemAssignMobileComponent } from './asset-item-assign-mobile.component';

describe('AssetItemAssignMobileComponent', () => {
  let component: AssetItemAssignMobileComponent;
  let fixture: ComponentFixture<AssetItemAssignMobileComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AssetItemAssignMobileComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AssetItemAssignMobileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
