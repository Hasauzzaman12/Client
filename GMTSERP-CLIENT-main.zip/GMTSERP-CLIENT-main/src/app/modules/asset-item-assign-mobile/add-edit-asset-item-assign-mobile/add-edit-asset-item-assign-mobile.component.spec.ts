import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditAssetItemAssignMobileComponent } from './add-edit-asset-item-assign-mobile.component';

describe('AddEditAssetItemAssignMobileComponent', () => {
  let component: AddEditAssetItemAssignMobileComponent;
  let fixture: ComponentFixture<AddEditAssetItemAssignMobileComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddEditAssetItemAssignMobileComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddEditAssetItemAssignMobileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
