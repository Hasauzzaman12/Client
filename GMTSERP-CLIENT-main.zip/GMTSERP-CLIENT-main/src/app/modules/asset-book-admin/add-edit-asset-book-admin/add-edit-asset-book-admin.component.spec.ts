import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditAssetBookAdminComponent } from './add-edit-asset-book-admin.component';

describe('AddEditAssetBookAdminComponent', () => {
  let component: AddEditAssetBookAdminComponent;
  let fixture: ComponentFixture<AddEditAssetBookAdminComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddEditAssetBookAdminComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddEditAssetBookAdminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
