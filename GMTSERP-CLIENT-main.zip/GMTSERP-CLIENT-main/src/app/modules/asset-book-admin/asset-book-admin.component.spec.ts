import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetBookAdminComponent } from './asset-book-admin.component';

describe('AssetBookAdminComponent', () => {
  let component: AssetBookAdminComponent;
  let fixture: ComponentFixture<AssetBookAdminComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AssetBookAdminComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AssetBookAdminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
