import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetOwnerComponent } from './asset-owner.component';

describe('AssetOwnerComponent', () => {
  let component: AssetOwnerComponent;
  let fixture: ComponentFixture<AssetOwnerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AssetOwnerComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AssetOwnerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
