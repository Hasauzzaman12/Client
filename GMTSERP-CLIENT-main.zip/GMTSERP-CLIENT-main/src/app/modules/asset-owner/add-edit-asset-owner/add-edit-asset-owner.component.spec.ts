import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditAssetOwnerComponent } from './add-edit-asset-owner.component';

describe('AddEditAssetOwnerComponent', () => {
  let component: AddEditAssetOwnerComponent;
  let fixture: ComponentFixture<AddEditAssetOwnerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddEditAssetOwnerComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddEditAssetOwnerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
