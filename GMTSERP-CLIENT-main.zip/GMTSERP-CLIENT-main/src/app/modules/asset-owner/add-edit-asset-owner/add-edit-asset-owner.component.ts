import { HttpClient, HttpEventType, HttpRequest } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable, of,startWith, debounceTime, distinctUntilChanged, switchMap, map } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';

@Component({
  selector: 'app-add-edit-asset-owner',
  templateUrl: './add-edit-asset-owner.component.html',
  styleUrls: ['./add-edit-asset-owner.component.scss']
})
export class AddEditAssetOwnerComponent implements OnInit {

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';

  constructor(public _apiService: ApiServiceService,
    private _snackBar: MatSnackBar,
    public router: Router,
    private authservice: AuthService,
    private currentRoute: ActivatedRoute) { 

    }

    newBlogForm!: FormGroup;
    id: number = 0;
    asset_Owner_Name= '';
    company_Id: number = 0;
    user_Id: number = this.authservice.getUserId;
    is_Active: boolean = true;

    companyList$!:Observable<any[]>;

  ngOnInit(): void {

    this.newBlogForm = new FormGroup({
      id: new FormControl(0),
      asset_Owner_Name: new FormControl(''),
      company_Id: new FormControl(0),
      is_Active: new FormControl(true)
    });

    if(this.user_Id>0){
      this.companyList$ = this._apiService.getCompanyListByUser(this.user_Id);
    }else{
      this.companyList$ = this._apiService.getCompanyList();
    }
    let id = this.currentRoute.snapshot.paramMap.get('id');
    if (id != null) {
      this.getAssetOwnerById(id);
      
    }
  }
getAssetOwnerById(id: number | string) {
   
    this._apiService.getAssetOwnerById(id).subscribe((data: any) => {
      this.id=data.id;
      this.asset_Owner_Name=data.asset_Owner_Name;
      this.company_Id=data.company_Id;
      this.is_Active=data.is_Active;
    });
  
  }

  
  onSubmit(data: any) {
    data.id=this.id;
    if (data.asset_Owner_Name == ''||data.asset_Owner_Name == null) {
      alert("Owner Name is Required")
      return;
    }

    if (data.company_Id == 0||data.company_Id == null) {
      alert("Company is Required")
      return;
    }

    const formData = new FormData();
    formData.append('id', data.id);
    formData.append('asset_Owner_Name', data.asset_Owner_Name == null ? '' : data.asset_Owner_Name);
    formData.append('company_Id', data.company_Id);
    formData.append('is_Active', data.is_Active);

    if (this.newBlogForm.valid) {
      if (data.id != 0) {
  
        this._apiService.updateAssetOwner(formData).subscribe(res => {
  
          this._snackBar.open("Asset Owner Updated Successfully", "Update", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });
  
          this.router.navigate(['/asset-owner']);
  
  
        })
      }
      else {
        this._apiService.addAssetOwner(formData).subscribe(res => {
  
          this._snackBar.open("Asset Owner Saved Successfully", "Success", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });
  
          this.router.navigate(['/asset-owner']);
  
  
        })
      }
    }

  }

  gotoBack() {
    this.router.navigate(['/asset-owner']);
  }
  reset(): void {
    this.ngOnInit();
  }
}
