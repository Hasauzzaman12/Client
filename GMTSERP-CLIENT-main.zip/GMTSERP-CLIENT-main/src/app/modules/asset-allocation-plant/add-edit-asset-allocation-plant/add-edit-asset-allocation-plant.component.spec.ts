import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditAssetAllocationPlantComponent } from './add-edit-asset-allocation-plant.component';

describe('AddEditAssetAllocationPlantComponent', () => {
  let component: AddEditAssetAllocationPlantComponent;
  let fixture: ComponentFixture<AddEditAssetAllocationPlantComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddEditAssetAllocationPlantComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddEditAssetAllocationPlantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
