import { HttpClient, HttpEventType, HttpRequest } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable, of,startWith, debounceTime, distinctUntilChanged, switchMap, map } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';
import { DatePipe } from '@angular/common';
import { SD } from 'src/environments/sd';

@Component({
  selector: 'app-add-edit-asset-allocation-plant',
  templateUrl: './add-edit-asset-allocation-plant.component.html',
  styleUrls: ['./add-edit-asset-allocation-plant.component.scss']
})
export class AddEditAssetAllocationPlantComponent implements OnInit {

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';

  myControl = new FormControl();
  myControl2 = new FormControl();
  options = [];
  filteredOptions: Observable<any>;
  filteredOptionsEmp: Observable<any>;

  constructor(public _apiService: ApiServiceService,
    private _snackBar: MatSnackBar,
    public router: Router,
    private authservice: AuthService,
    private currentRoute: ActivatedRoute,
    private datepipe: DatePipe) { 
      this.filteredOptions = this.myControl.valueChanges.pipe(

        startWith(''),
  
        debounceTime(400),
  
        distinctUntilChanged(),
  
        switchMap(val => {
  
              return this.filter(val || '')
  
         }) 
  
      )

      this.filteredOptionsEmp = this.myControl2.valueChanges.pipe(

        startWith(''),
  
        debounceTime(400),
  
        distinctUntilChanged(),
  
        switchMap(val => {
  
              return this.filter2(val || '')
  
         }) 
  
      )
    }

    newBlogForm!: FormGroup;
    id: number = 0;
    allocation_Date : any;
    asset_Book_Id: number = 0;
    asset_No= '';
    allocation_Type= '';
    company_Id: number = 0;
    unit_Id: number = 0;
    department_Id: number = 0;
    custodian_Id: number = 0;
    sub_Custodian_Id: number = 0;
    // employee_Id: number = 0;
    // employee_Code= '';
    // employee_Name= '';
    is_active: boolean = true;
    user_Id: number = this.authservice.getUserId;
    asset_Item_Category_Id: number = SD.asset_Item_Category_Id_Plant_Machinery;
    asset_Owner_Id: number = SD.asset_Owner_Id_Plant_Machinery;

    assetBookList$!:Observable<any[]>;
    companyList$!:Observable<any[]>;
    departmentList$!:Observable<any[]>;
    // employeeList$!:Observable<any[]>;
    unitListByComId$!: Observable<any[]>;
    custodianListByComId$!: Observable<any[]>;
    subcustodianListByCusId$!: Observable<any[]>;

  ngOnInit(): void {

    let currentDateTime =this.datepipe.transform((new Date), 'MM/dd/yyyy h:mm:ss');
    this.newBlogForm = new FormGroup({
      id: new FormControl(0),
      allocation_Date: new FormControl(null),
      asset_Book_Id: new FormControl(0),
      allocation_Type: new FormControl(''),
      company_Id: new FormControl(0),
      unit_Id: new FormControl(0),
      department_Id: new FormControl(0),
      custodian_Id: new FormControl(0),
      sub_Custodian_Id: new FormControl(0),
      employee_Id: new FormControl(0),
      is_active: new FormControl(true)
    });

   
    if(this.user_Id>0){
      this.companyList$ = this._apiService.getCompanyListByUser(this.user_Id);
    }else{
      this.companyList$ = this._apiService.getCompanyList();
    }
    this.departmentList$ = this._apiService.getDepartmentList();

    let id = this.currentRoute.snapshot.paramMap.get('id');
    if (id != null) {
      this.getAssetAllocationById(id);
     
    }else{
      this.allocation_Date=currentDateTime;
    }
  }


  getAssetAllocationById(id: number | string) {
    this._apiService.getAssetAllocationkById(id).subscribe((data: any) => {
      console.log(data);
      this.id=data.id;
      this.allocation_Date=data.allocation_Date;
      this.asset_Book_Id=data.asset_Book_Id;
      this.asset_No=data.asset_No;
      this.allocation_Type=data.allocation_Type;
      this.company_Id=data.company_Id;
      this.unit_Id=data.unit_Id;
      this.department_Id=data.department_Id;
      this.custodian_Id=data.custodian_Id;
      this.sub_Custodian_Id=data.sub_Custodian_Id;
      // this.employee_Id=data.employee_Id;
      // this.employee_Code=data.employee_Code;
      // this.employee_Name=data.employee_Name;
      this.is_active=data.is_active;

      this.unitListByComId$ = this._apiService.getUnitListByCompanyId(this.company_Id);
      this.custodianListByComId$ = this._apiService.getCustodianByCompanyId(this.company_Id);
      this.subcustodianListByCusId$ = this._apiService.getSubCustodianByCustodian(this.custodian_Id);
    });

  }

  onSubmit(data: any){
    data.id=this.id;
    // data.department_Id=this.department_Id;
    // data.company_Id=this.company_Id;

    console.log(data);
    
    if(data.allocation_Date == ''||data.allocation_Date == null) {
      alert("Allocation Date is Required")
      return;
    }
    if (data.allocation_Type == ''||data.allocation_Type == null) {
      alert("Allocation Type is Required")
      return;
    }
    if (data.asset_Book_Id == 0||data.asset_Book_Id == null) {
      alert("Asset Book is Required")
      return;
    }
    if (data.company_Id == 0||data.company_Id == null) {
      alert("Company is Required")
      return;
    }
    if (data.department_Id == 0||data.department_Id == null) {
      alert("Department is Required")
      return;
    }

    const formData = new FormData();

    
    formData.append('id', data.id);
    formData.append('allocation_Date', data.allocation_Date);
    formData.append('asset_Book_Id', data.asset_Book_Id);
    formData.append('allocation_Type', data.allocation_Type);
    formData.append('company_Id', data.company_Id);
    formData.append('unit_Id', data.unit_Id);
    formData.append('department_Id', data.department_Id);
    formData.append('custodian_Id', data.custodian_Id);
    formData.append('sub_Custodian_Id', data.sub_Custodian_Id);
    // formData.append('employee_Id', data.employee_Id);
    formData.append('user_Id', this.user_Id.toString());
    formData.append('is_active', data.is_active);

    if (this.newBlogForm.valid) {
      if (data.id != 0) {
  
        this._apiService.updateAssetAllocation(formData).subscribe(res => {
  
          this._snackBar.open("Asset Allocation Updated Successfully", "Update", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });
  
          this.router.navigate(['/asset-allocation-plant']);
  
  
        })
      }
      else {
        this._apiService.addAssetAllocation(formData).subscribe(res => {
  
          this._snackBar.open("Asset Allocation Saved Successfully", "Success", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });
  
          this.router.navigate(['/asset-allocation-plant']);
  
  
        })
      }
    }

  }

  filter(val: string): Observable <any>{

    const formData = new FormData();
    if (this.asset_Owner_Id != 0||this.asset_Owner_Id != null) {
      formData.append('asset_Owner_Id', this.asset_Owner_Id.toString());
    }
    if (this.user_Id != 0||this.user_Id != null) {
      formData.append('user_Id', this.user_Id.toString());
    }
    formData.append('status', 'STOCKED');
    formData.append('asset_Item_Category_Id', this.asset_Item_Category_Id.toString());
    

    return this._apiService.getAssetBookingFiltered(formData)

    .pipe(

      map(response => response.filter((option: { asset_No: string; }) => { 

        return option.asset_No.toLowerCase().indexOf(val.toLowerCase()) !== -1

      }))

    )

   }  

   filter2(val: string): Observable <any>{

    const formData = new FormData();
    if (this.user_Id != 0||this.user_Id != null) {
      formData.append('user_Id', this.user_Id.toString());
    }
    formData.append('emp_Status', 'Active');

    return this._apiService.getEmployeesFiltered(formData)

    .pipe(

      map(response => response.filter((option: { employee_Id: string; }) => { 

        return option.employee_Id.toLowerCase().indexOf(val.toLowerCase()) !== -1

      }))

    )

   }  

   onSelFunc(option: any){
    if(option.id>0){
      this.asset_Book_Id=option.id;
    }
  }

  onSelFunc2(option: any){
    if(option.id>0){
      // this.employee_Id=option.id;
      // this.employee_Name=option.employee_Name;
      this.department_Id=option.department_Id;
      this.company_Id=option.company_Id;
    }
  }
gotoBack() {
    this.router.navigate(['/asset-allocation-plant']);
  }
  reset(): void {
    this.ngOnInit();
  }

  changeCustodian(data: any) {
    if(data.custodian_Id>0){
      this.subcustodianListByCusId$ = this._apiService.getSubCustodianByCustodian(data.custodian_Id);
    }
  }
  changeCompany(data: any) {
    if(data.company_Id>0){
      this.unitListByComId$ = this._apiService.getUnitListByCompanyId(data.company_Id);
      this.custodianListByComId$ = this._apiService.getCustodianByCompanyId(data.company_Id);
    }
  }
}
