import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetAllocationPlantComponent } from './asset-allocation-plant.component';

describe('AssetAllocationPlantComponent', () => {
  let component: AssetAllocationPlantComponent;
  let fixture: ComponentFixture<AssetAllocationPlantComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AssetAllocationPlantComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AssetAllocationPlantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
