import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';
import { SD } from 'src/environments/sd';

@Component({
  selector: 'app-asset-item-software',
  templateUrl: './asset-item-software.component.html',
  styleUrls: ['./asset-item-software.component.scss']
})
export class AssetItemSoftwareComponent implements OnInit {

  user_Id: number = 0;
  asset_Item_Category_Id: number = SD.asset_Item_Category_Id_software;;
  company_Id: number = 0;
  isFilterShow: boolean = false;

  companyList$!:Observable<any[]>;

  displayedColumns: string[] = ['asset_Owner_Name','asset_Item_Category_Name','item_Name','software_Supplier_Name','price','software_AMC','software_AMC_Amount','software_No_Of_Users','company_Name','is_Active','action'];
  dataSource!: MatTableDataSource<any>;

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';


  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(public _apiService: ApiServiceService,
    private authservice: AuthService,
    private _snackBar: MatSnackBar,
    public dialog: MatDialog,
    private router: Router) { }

  ngOnInit(): void {
    this.getAssetSoftwareList();
    if(this.user_Id>0){
      this.companyList$ = this._apiService.getCompanyListByUser(this.user_Id);
    }else{
      this.companyList$ = this._apiService.getCompanyList();
    }
  }

  getAssetSoftwareList() {
    this.user_Id=this.authservice.getUserId;
    const formData = new FormData();

    if (this.user_Id != 0||this.user_Id != null) {
      formData.append('user_Id', this.user_Id.toString());
    }
    formData.append('asset_Item_Category_Id', this.asset_Item_Category_Id.toString());
    if (this.company_Id != 0||this.company_Id != null) {
      formData.append('company_Id', this.company_Id.toString());
    }

    this._apiService.getAssetItemListFiltered(formData)
      .subscribe({
        next: (res) => {
          this.dataSource = new MatTableDataSource(res);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
        },
        error: (err) => {
          console.log("Error");
        }

      })
  }
  toggleFilter() {
    this.isFilterShow = !this.isFilterShow;
  }
  SearchSummary() {
    this.getAssetSoftwareList();
  }
  reset() {
    this.company_Id=0;
    this.getAssetSoftwareList();
  }
  openForEdit(id: number) {

    this.router.navigate(['/asset-item-software/edit/' + id]);
  }
  gotoNew() {
    this.router.navigate(['/add-asset-item-software']);
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  deleteAssetItem(id: number) {

    if (confirm("Are you sure to delete?")) {
      this._apiService.deleteAssetItem(id)
        .subscribe({
          next: (res) => {
            this._snackBar.open("Asset Item Deleted Successfully", "Delete", {
              horizontalPosition: this.horizontalPosition,
              verticalPosition: this.verticalPosition,
              duration: 1000
            });
            this.getAssetSoftwareList();
          },
          error: () => {
            this._snackBar.open("Delete Failed", "Failed");
          }
        })
    }
  }

}


