import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditSoftwareComponent } from './add-edit-software.component';

describe('AddEditSoftwareComponent', () => {
  let component: AddEditSoftwareComponent;
  let fixture: ComponentFixture<AddEditSoftwareComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddEditSoftwareComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddEditSoftwareComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
