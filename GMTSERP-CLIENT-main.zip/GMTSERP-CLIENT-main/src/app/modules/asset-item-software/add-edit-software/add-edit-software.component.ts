import { HttpClient, HttpEventType, HttpRequest } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable, of,startWith, debounceTime, distinctUntilChanged, switchMap, map } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';
import { DatePipe } from '@angular/common';
import { SD } from 'src/environments/sd';

@Component({
  selector: 'app-add-edit-software',
  templateUrl: './add-edit-software.component.html',
  styleUrls: ['./add-edit-software.component.scss']
})
export class AddEditSoftwareComponent implements OnInit {
  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';

  constructor(public _apiService: ApiServiceService,
    private _snackBar: MatSnackBar,
    public router: Router,
    private authservice: AuthService,
    private currentRoute: ActivatedRoute,
    private datepipe: DatePipe) {  }

    newBlogForm!: FormGroup;
    id: number = 0;
    item_Name= '';
    asset_Owner_Id: number = 1;
    company_Id: number = 0;
    user_Id: number = this.authservice.getUserId;
    is_Active: boolean = true;
    asset_Item_Category_Id: number = SD.asset_Item_Category_Id_software;
    software_Name= '';
    software_Supplier_Id: number = 0;
    software_AMC: boolean = true;
    software_AMC_Start_Date : any;
    software_AMC_End_Date : any;
    software_No_Of_Users: number = 0;
    software_AMC_Amount: number = 0;
    price: number = 0;
    attachment_Id: number = 0;
    attachment_File_Name= '';
    selectedFile!: File;

    assetOwnerList$!: Observable<any[]>;
    supplierList$!: Observable<any[]>;
    companyList$!:Observable<any[]>;

    attchament_list: any[] = []

  ngOnInit(): void {

    this.newBlogForm = new FormGroup({
      id: new FormControl(0),
      item_Name: new FormControl(''),
      asset_Owner_Id: new FormControl({value: this.asset_Owner_Id, disabled: true}),
      company_Id: new FormControl(0),
      is_Active: new FormControl(true),
      asset_Item_Category_Id: new FormControl(0),
      software_Name: new FormControl(''),
      software_Supplier_Id: new FormControl(0),
      software_AMC: new FormControl(true),
      software_AMC_Start_Date: new FormControl(null),
      software_AMC_End_Date: new FormControl(null),
      software_No_Of_Users: new FormControl(0),
      software_AMC_Amount: new FormControl(0),
      price: new FormControl(0),

      attachment_Id: new FormControl(0),
    });

    this.assetOwnerList$=this._apiService.getAssetOwnerList();
    this.supplierList$=this._apiService.getSuulierList();
    if(this.user_Id>0){
      this.companyList$ = this._apiService.getCompanyListByUser(this.user_Id);
    }else{
      this.companyList$ = this._apiService.getCompanyList();
    }

    let id = this.currentRoute.snapshot.paramMap.get('id');
    if (id != null) {
      this.getAssetItemById(id);
      
    }
  }

  getAssetItemById(id: number | string) {
   
    this._apiService.getAssetItemnById(id).subscribe((data: any) => {
      this.attchament_list = data.attachmentList;

      this.id=data.id;
      this.item_Name=data.item_Name;
      this.asset_Owner_Id=data.asset_Owner_Id;
      this.company_Id=data.company_Id;
      this.is_Active=data.is_Active;
      this.asset_Item_Category_Id=data.asset_Item_Category_Id;
      this.software_Name=data.software_Name;
      this.software_Supplier_Id=data.software_Supplier_Id;
      this.software_AMC=data.software_AMC;
      this.software_AMC_Start_Date=data.software_AMC_Start_Date;
      this.software_AMC_End_Date=data.software_AMC_End_Date;
      this.software_No_Of_Users=data.software_No_Of_Users;
      this.software_AMC_Amount=data.software_AMC_Amount;
      this.price=data.price;
      this.attachment_Id=data.attachment_Id

    });
  
  }

  onSubmit(data: any) {
    data.id=this.id;
    data.asset_Owner_Id=this.asset_Owner_Id;
    data.asset_Item_Category_Id=this.asset_Item_Category_Id;

    const formData = new FormData();

    if (data.company_Id == 0||data.company_Id == null) {
      alert("Company is Required")
      return;
    }
    if (data.item_Name == ''||data.item_Name == null) {
      alert("SOftware Name is Required")
      return;
    }
    if (data.software_Supplier_Id == 0||data.software_Supplier_Id == null) {
      alert("Supplier is Required")
      return;
    }

    if (data.software_AMC_Start_Date == ''||data.software_AMC_Start_Date == null||data.software_AMC_End_Date == ''||data.software_AMC_End_Date == null) {
      alert("AMC Start & End Date is Required")
      return;
    }
    formData.append('id', data.id);
    formData.append('item_Name', data.item_Name == null ? '' : data.item_Name);
    formData.append('asset_Owner_Id', data.asset_Owner_Id);
    formData.append('company_Id', data.company_Id);
    formData.append('is_Active', data.is_Active);
    formData.append('asset_Item_Category_Id', data.asset_Item_Category_Id);
    formData.append('software_Name', data.item_Name == null ? '' : data.item_Name);
    formData.append('software_Supplier_Id', data.software_Supplier_Id);
    formData.append('software_AMC', data.software_AMC);
    formData.append('software_AMC_Start_Date', data.software_AMC_Start_Date);
    formData.append('software_AMC_End_Date', data.software_AMC_End_Date);
    formData.append('software_No_Of_Users', data.software_No_Of_Users);
    formData.append('software_AMC_Amount', data.software_AMC_Amount);
    formData.append('price', data.price);
    formData.append('attachment_Id', data.attachment_Id);
    formData.append('attachmentFile', this.selectedFile);

    for (let i = 0; i < this.attchament_list.length; i++) {

      if ((this.attchament_list[i].description == "" || this.attchament_list[i].description == null)) {
        alert("Invalid Input in Attchment Tab!");
        return;
      }

      const keyPrefix = "attachmentList[" + i.toString() + "].";
      formData.append(keyPrefix + "id", this.attchament_list[i].id);
      formData.append(keyPrefix + "description", this.attchament_list[i].description == null ? '' : this.attchament_list[i].description);
      formData.append(keyPrefix + "attachment_Id", this.attchament_list[i].attachment_Id);
      formData.append(keyPrefix + "attachmentFile", this.attchament_list[i].attachmentFile);

    }

    if (this.newBlogForm.valid) {
      if (data.id != 0) {
  
        this._apiService.updateAssetItem(formData).subscribe(res => {
  
          this._snackBar.open("Asset Item Updated Successfully", "Update", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });
  
          this.router.navigate(['/asset-item-software']);
  
  
        })
      }
      else {
        this._apiService.addAssetItem(formData).subscribe(res => {
  
          this._snackBar.open("Asset Item Saved Successfully", "Success", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });
  
          this.router.navigate(['/asset-item-software']);
  
  
        })
      }
    }
  }
  onSelectFile(fileInput: any) {
    this.selectedFile = <File>fileInput.target.files[0];
    this.attachment_Id = 0;
  }
 
  gotoBack() {
    this.router.navigate(['/asset-item-software']);
  }
  reset(): void {
    this.ngOnInit();
  }
addAttachmentRow() {
    this.attchament_list.push({ id: 0, description: '', attachment_Id: 0, attachmentFile: '' });
  }
  deleteAttachmentROw(index: any) {
    if (confirm("Are you sure want to delete?")) {
      this.attchament_list.splice(index, 1);
    }
  }
  onSelectChildFile(data: any, fileInput: any) {
    data.attachmentFile = <File>fileInput.target.files[0];
    data.attachment_Id = 0;
  }
}
