import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetItemSoftwareComponent } from './asset-item-software.component';

describe('AssetItemSoftwareComponent', () => {
  let component: AssetItemSoftwareComponent;
  let fixture: ComponentFixture<AssetItemSoftwareComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AssetItemSoftwareComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AssetItemSoftwareComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
