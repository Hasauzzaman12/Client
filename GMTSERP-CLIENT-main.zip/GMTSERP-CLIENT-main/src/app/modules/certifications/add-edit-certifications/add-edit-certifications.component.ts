import { Component, Input, OnInit } from '@angular/core';
import { MatSnackBar , MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition} from '@angular/material/snack-bar';
import { ActivatedRoute ,Router} from '@angular/router';
import { Observable } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';

@Component({
  selector: 'app-add-edit-certifications',
  templateUrl: './add-edit-certifications.component.html',
  styleUrls: ['./add-edit-certifications.component.scss']
})
export class AddEditCertificationsComponent implements OnInit {

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';

  constructor(public _apiService:ApiServiceService,
    private _snackBar: MatSnackBar,
    public router:Router,
    private currentRoute: ActivatedRoute) {}

  @Input() certificattion:any;
  id: number = 0;
  certification_Name: string = "";
  upcharges: number = 0;
  is_active: boolean=true;

  ngOnInit(): void {
    let id = this.currentRoute.snapshot.paramMap.get('id');
    if (id != null){
      this.getCertificationsById(id);

    }
  }

  gotoBack() {
    this.router.navigate(['/certification']);
  }


  //Add New Certification

  addNewCertifications() {

    var certificattion = {
      certification_Name:this.certification_Name,
      upcharges:this.upcharges,
      is_active:this.is_active
     
    }
    this._apiService.addCertification(certificattion).subscribe(res => {

      this._snackBar.open("Certification Added Successfully", "Success", {
        horizontalPosition: this.horizontalPosition,
        verticalPosition: this.verticalPosition,
        duration: 2000
      });

      this.router.navigate(['/certification']);
      
    })
  }

  updateCertifications() {

    var certificattion = {
      id:this.id,
      certification_Name:this.certification_Name,
      upcharges:this.upcharges,
      is_active:this.is_active
     
    }
    this._apiService.updateCertification(certificattion).subscribe(res => {
      this._snackBar.open("Certification Updated Successfully", "Update", {
        horizontalPosition: this.horizontalPosition,
        verticalPosition: this.verticalPosition,
        duration: 2000
      });

      this.router.navigate(['/certification']);
 
    })
  }


  getCertificationsById(id:number|string){
    this._apiService.getCertificationById(id)
    .subscribe((data: any) => {
      this.id=data.id;
      this.certification_Name=data.certification_Name;
      this.upcharges=data.upcharges;
      this.is_active =data.is_active;
    });
  
  }

}
