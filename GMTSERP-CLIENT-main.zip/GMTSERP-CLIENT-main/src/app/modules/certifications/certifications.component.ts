import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';

@Component({
  selector: 'app-certifications',
  templateUrl: './certifications.component.html',
  styleUrls: ['./certifications.component.scss']
})
export class CertificationsComponent implements OnInit {


  displayedColumns: string[] = ['certification_Name', 'upcharges','is_active','action'];
  dataSource!: MatTableDataSource<any>;

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';


  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(public _apiService:ApiServiceService,
     private _snackBar: MatSnackBar,
     public dialog: MatDialog,
     private router:Router) { }

  ngOnInit(): void {
    this.getAllCertification();
  }

  getAllCertification(){
    this._apiService.getCertificationList()
    .subscribe({
      next:(res)=>{
        this.dataSource=new MatTableDataSource(res);
        this.dataSource.paginator=this.paginator;
        this.dataSource.sort=this.sort;
      },
      error:(err)=>{
        console.log("Error");
      }
      
    })
  }
  openForEdit(id: number) {
   
    this.router.navigate(['/certification/edit/' + id]);
  }

  gotoNew() {
    this.router.navigate(['/addcertification']);
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  deleteStyleMaster(id:number){
   
    if(confirm("Are you sure to delete?")){
      this._apiService.deleteCertification(id)
      .subscribe({
        next:(res)=>{
          this._snackBar.open("Certification Deleted Successfully", "Delete", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 1000
          });
          this.getAllCertification();
        },
        error:()=>{
          this._snackBar.open("Delete Failed", "Failed");
        }
      })
    }

   

  }

}

