import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';
import { AdminUserPasswordResetDialogComponent } from './admin-user-password-reset-dialog/admin-user-password-reset-dialog.component';

@Component({
  selector: 'app-admin-user-registration',
  templateUrl: './admin-user-registration.component.html',
  styleUrls: ['./admin-user-registration.component.scss']
})
export class AdminUserRegistrationComponent implements OnInit {

  displayedColumns: string[] = ['username','userTypeId','employee_Code', 'email', 'phoneNumber','isActive','action'];
  dataSource!: MatTableDataSource<any>

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(public authservice:AuthService, private _snackBar: MatSnackBar,private router:Router, public dialog: MatDialog) { }


  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }


  gotoNew() {
    this.router.navigate(['/addadminUser']);
  }


  ngOnInit(): void {
    this.getAllExistingUserList();
  }

  getAllExistingUserList(){
    this.authservice.getUserList()
    .subscribe({
      next:(res)=>{
        this.dataSource=new MatTableDataSource(res);
        this.dataSource.paginator=this.paginator;
        this.dataSource.sort=this.sort;
      },
      error:(err)=>{
        console.log("Error");
      }
      
    })
  }

  openForEdit(itemId: number) {
   
    this.router.navigate(['/admin-user-registration/edit/' + itemId]);
  }


  gotoBack() {
    this.router.navigate(['/admin-user-registration']);
  }
  openDialog(newObj: any): void {

    const dialogRef = this.dialog.open(AdminUserPasswordResetDialogComponent, {
      height: '60%',
      autoFocus: false,
      width: '50%',
      backdropClass: 'custom-dialog-backdrop-class',
      panelClass: 'custom-dialog-panel-class',
      data: { pageValue: newObj }
    });


    dialogRef.afterClosed().subscribe(result => {
      this.getAllExistingUserList();
    });
  }
}
