import { HttpClient } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable, of } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';

@Component({
  selector: 'app-add-edit-admin-user-registration',
  templateUrl: './add-edit-admin-user-registration.component.html',
  styleUrls: ['./add-edit-admin-user-registration.component.scss']
})


export class AddEditAdminUserRegistrationComponent implements OnInit {

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';
  selectedFile!: File;
  newBlogForm!:FormGroup;
  submitted = false;
  UserType:any;
  selectedComId:any;
  selectedUnitId:any;


  form: any;

  companyList$!:Observable<any[]>;
  employeeList$!:Observable<any[]>;
  unitListByComId$!:Observable<any[]>;
  unitList$!:Observable<any[]>;
  UserTypeList$!:Observable<any[]>;
  
  UserRoleList$!:Observable<any[]>;

  @Input() stylemaster:any;
  userName: string = "";
  userCreationDate: any = "";
  userExpireDate: any = "";
  phoneNumber:string="";
  companyId: number = 0;
  userTypeId:string="";
  employee_Id:number=0;
  email:string="";
  userFullName:string="";
  unitId:number=0;
  profile_Image_Id:number=0;

  password:string="";
  departmentId:number=0;
  retyprPassword:string="";
  defaultUnitId:number=0;
  designationId:number=0;
  roleId:string="";
  isActive: boolean=true;

  userid: number = 0;
  companyid: number = 0;

  unit_array_list: any[] = []

  public editMood: boolean = false;
  constructor(
    public router:Router,
    public _apiService:ApiServiceService,
    public _authService:AuthService,
    private _snackBar: MatSnackBar,
    private authservice:AuthService,
    private currentRoute: ActivatedRoute,
    public http:HttpClient,
    public formBuilder:FormBuilder
    ){}

    get f(){
      return this.newBlogForm.controls;
    }

    changeUnit(event: any) {
      this.selectedComId = event.target.value;
      this.unitListByComId$=this._apiService.getUnitListByCompanyId(this.selectedComId);  
    }

    companies = <any>[];
    adminUnits = <any[]>[];

    newFrmArray = new FormArray([
      new FormControl()
    ]);

    onCheckboxChange(value:any,event:any) {

      if(event.target.checked){
        this.unit_array_list.push(value);
      }else{
        const index: number = this.unit_array_list.indexOf(value);
        if (index !== -1) {
        this.unit_array_list.splice(index, 1);
      }       
      }

      console.log(this.unit_array_list);
     
      
    }

    //bdfaruqe
  

  ngOnInit(): void {

    let id = this.currentRoute.snapshot.paramMap.get('id');
    if (id != null){
      this.editMood = true;
      this.getAdminUserById(id);

    }

    this.newBlogForm = this.formBuilder.group({
      phoneNumber: [
        '',
        [
          Validators.required,
          Validators.minLength(11),
          Validators.maxLength(11)
        ]
      ],
      userName: [
        '',
        [
          Validators.required
        ]
      ],
     
      password: [ ],
      retyprPassword: [],
      companyId: new FormControl(null),
      employee_Id: new FormControl(0),
      unitId: new FormControl(null),
      email: new FormControl(null),
      userTypeId: new FormControl(null),
      defaultUnitId: new FormControl(null),
      roleId:new FormControl(null),
      CustomUnitList:new FormControl(null),
      isActive: new FormControl(null),
      userid: new FormControl(this.authservice.getUserId),
      companyid: new FormControl(this.authservice.getCompanyId),

    });

    const userTypeData = [
      {id: 'Employee',name: 'Employee' },
      {id: 'Non-Employee',name: 'Non-Employee'},
      {id: 'Branch User',name: 'Branch User'},
      {id: 'Guest User',name: 'Guest User'}
    ];

    this.userid=this.authservice.getUserId;
    this.companyid=this.authservice.getCompanyId;
    this.companyList$ = this._apiService.getCompanyList();
    this.employeeList$=this._apiService.getActiveEmployeeList();
    this.unitList$=this._apiService.getUnitList();
    this.UserTypeList$= of(userTypeData);
    this.UserRoleList$=this.authservice.getUserRoleList();
  }

  gotoBack() {
    this.router.navigate(['/admin-user-registration']);
  }

  onReset(): void {
    this.submitted = false;
    this.newBlogForm.reset();
  }

  onSubmit(data: any) {

    this.submitted = true;
    if (this.newBlogForm.invalid) {
      return;
    }

    const formData = new FormData();
    formData.append('userName', data.userName);
    // formData.append('companyId', data.companyId);
    formData.append('employee_Id', data.employee_Id);
    formData.append('phoneNumber', data.phoneNumber);
    formData.append('userTypeId', data.userTypeId);
    formData.append('email', data.email);
    // formData.append('unitId', data.defaultUnitId);
    formData.append('password', data.password);
    // formData.append('defaultUnitId', data.defaultUnitId);
    // formData.append('roleId', data.roleId);
    formData.append('retyprPassword', data.retyprPassword);
    formData.append('isActive', data.isActive);
    formData.append('userid',this.authservice.getUserId);

    // for (let i = 0; i < this.unit_array_list.length; i++) {

    //   const keyPrefix = "selectedUnitList[" + i.toString() + "].";
    //   formData.append(keyPrefix + "id", this.unit_array_list[i].id);
    //   formData.append(keyPrefix + "companyName", this.unit_array_list[i].companyName);
    //   formData.append(keyPrefix + "unitName", this.unit_array_list[i].unitName);
    //   formData.append(keyPrefix + "isActive", this.unit_array_list[i].isActive);
    //   formData.append(keyPrefix + "isChecked", this.unit_array_list[i].isChecked);


    // }

   

    if(data.id>0){
      this._authService.updateUser(formData).subscribe(res => {

        this._snackBar.open("User Update Successfully", "Success", {
          horizontalPosition: this.horizontalPosition,
          verticalPosition: this.verticalPosition,
          duration: 2000
        });
  
        this.router.navigate(['/admin-user-registration']);
     
      })

    }else{
      this._authService.addUser(formData).subscribe(res => {

        this._snackBar.open("User Saved Successfully", "Success", {
          horizontalPosition: this.horizontalPosition,
          verticalPosition: this.verticalPosition,
          duration: 2000
        });
  
        this.router.navigate(['/admin-user-registration']);
     
      })
    }

    }

    

    getAdminUserById(id:number|string){
      this._authService.getExistUserById(id)
      .subscribe((data: any) => {

        // this.unit_array_list=data.selectedUnitList;
        // this.unitListByComId$=this._apiService.getAdminUnitsByUserId(id,data.companyid);

        this.newBlogForm = new FormGroup({
  
          id:new FormControl(id),
          userName: new FormControl(data.username),
          // companyId: new FormControl(data.companyid),
          employee_Id: new FormControl(data.employee_Id),
          phoneNumber: new FormControl(data.phoneNumber),
          userTypeId: new FormControl(data.userTypeId),
          email: new FormControl(data.email),
          // unitId: new FormControl(data.unitId),
          // defaultUnitId: new FormControl(data.defaultUnitId),
          // roleId: new FormControl(data.roleId),
          isActive: new FormControl(data.isActive),
          userid: new FormControl(data.userid),
          // companyid: new FormControl(data.companyid),
    
        });
    
  
  
      });
    
    }


}

class Custom {
  public id:number=0;

}
