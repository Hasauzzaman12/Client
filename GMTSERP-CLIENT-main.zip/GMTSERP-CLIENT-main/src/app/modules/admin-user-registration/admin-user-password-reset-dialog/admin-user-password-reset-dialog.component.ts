import { DatePipe } from '@angular/common';
import { Component, Inject, OnInit, Optional } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';

@Component({
  selector: 'app-admin-user-password-reset-dialog',
  templateUrl: './admin-user-password-reset-dialog.component.html',
  styleUrls: ['./admin-user-password-reset-dialog.component.scss']
})
export class AdminUserPasswordResetDialogComponent implements OnInit {

  formDialog: any;
  id: number = 0;
  username: string = '';
  newPassword: string = '';
  confirmPassword: string = '';
  constructor(
    public dialogRef: MatDialogRef<AdminUserPasswordResetDialogComponent>,
    private datepipe: DatePipe,
    public _apiService: ApiServiceService,
    private authservice: AuthService,
    @Optional() @Inject(MAT_DIALOG_DATA) public data: any
  )
  {

    this.formDialog = data.pageValue;
    this.id=this.formDialog.id;
    this.username=this.formDialog.username;
   }

  ngOnInit(): void {
  }
  submitDialog(){

    if (this.newPassword == ''||this.newPassword == null) {
      alert("New Password is Required")
      return;
    }
    if (this.confirmPassword == ''||this.confirmPassword == null) {
      alert("Confirm Password is Required")
      return;
    }

    if(this.newPassword!=this.confirmPassword){
      alert("Password not matched")
      return;
    }
    const formData = new FormData();
    formData.append('username', this.username);
    formData.append('newPassword', this.newPassword == null ? '' : this.newPassword);
    formData.append('confirmPassword', this.confirmPassword == null ? '' : this.confirmPassword);

    console.log(formData);

    if (this.id != 0) {
      this.authservice.resetPassword(formData);
      this.dialogRef.close({ event: 'close', data: this.formDialog });
    }
  

  }
  closeDialog() {
    this.dialogRef.close({ event: 'close', data: this.formDialog });
    
  }

  onNoClick(): void {
    this.dialogRef.close();
  }
}
