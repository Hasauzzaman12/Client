import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminUserPasswordResetDialogComponent } from './admin-user-password-reset-dialog.component';

describe('AdminUserPasswordResetDialogComponent', () => {
  let component: AdminUserPasswordResetDialogComponent;
  let fixture: ComponentFixture<AdminUserPasswordResetDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminUserPasswordResetDialogComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdminUserPasswordResetDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
