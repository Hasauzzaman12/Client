import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-user-registration-detail',
  templateUrl: './admin-user-registration-detail.component.html',
  styleUrls: ['./admin-user-registration-detail.component.scss']
})
export class AdminUserRegistrationDetailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
