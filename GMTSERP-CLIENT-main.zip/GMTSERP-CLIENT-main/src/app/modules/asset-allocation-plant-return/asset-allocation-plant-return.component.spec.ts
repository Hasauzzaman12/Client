import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetAllocationPlantReturnComponent } from './asset-allocation-plant-return.component';

describe('AssetAllocationPlantReturnComponent', () => {
  let component: AssetAllocationPlantReturnComponent;
  let fixture: ComponentFixture<AssetAllocationPlantReturnComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AssetAllocationPlantReturnComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AssetAllocationPlantReturnComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
