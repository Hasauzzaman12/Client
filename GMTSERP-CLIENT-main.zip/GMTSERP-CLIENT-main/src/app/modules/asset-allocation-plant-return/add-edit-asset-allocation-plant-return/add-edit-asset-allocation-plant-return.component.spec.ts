import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditAssetAllocationPlantReturnComponent } from './add-edit-asset-allocation-plant-return.component';

describe('AddEditAssetAllocationPlantReturnComponent', () => {
  let component: AddEditAssetAllocationPlantReturnComponent;
  let fixture: ComponentFixture<AddEditAssetAllocationPlantReturnComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddEditAssetAllocationPlantReturnComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddEditAssetAllocationPlantReturnComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
