import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditAssetGrnMasterComponent } from './add-edit-asset-grn-master.component';

describe('AddEditAssetGrnMasterComponent', () => {
  let component: AddEditAssetGrnMasterComponent;
  let fixture: ComponentFixture<AddEditAssetGrnMasterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddEditAssetGrnMasterComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddEditAssetGrnMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
