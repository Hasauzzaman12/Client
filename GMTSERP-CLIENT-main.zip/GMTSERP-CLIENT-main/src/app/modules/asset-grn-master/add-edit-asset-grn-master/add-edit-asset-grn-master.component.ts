import { HttpClient, HttpEventType, HttpRequest } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable, of,startWith, debounceTime, distinctUntilChanged, switchMap, map } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-add-edit-asset-grn-master',
  templateUrl: './add-edit-asset-grn-master.component.html',
  styleUrls: ['./add-edit-asset-grn-master.component.scss']
})
export class AddEditAssetGrnMasterComponent implements OnInit {

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';

  constructor(public _apiService: ApiServiceService,
    private _snackBar: MatSnackBar,
    public router: Router,
    private authservice: AuthService,
    private currentRoute: ActivatedRoute,
    private datepipe: DatePipe)  { }

    newBlogForm!: FormGroup;
    id: number = 0;
    grn_Date : any;
    grn_No= '';
    asset_Owner_Id: number = 0;
    req_No= '';
    req_Attachment_Id: number = 0;
    attachment_File_Name_Req= '';
    pO_No= '';
    pO_Amount: number = 0;
    pO_Attachment_Id: number = 0;
    attachment_File_Name_PO= '';
    vendor= '';
    company_Id: number = 0;
    unit_Id: number = 0;
    user_Id: number = this.authservice.getUserId;
    is_active: boolean = true;

    is_Edit : boolean = true;
    assetOwnerList$!: Observable<any[]>;
    companyList$!:Observable<any[]>;
    unitList$!:Observable<any[]>;
    sparePartList$!:Observable<any[]>;

    selectedFile_Req!: File;
    selectedFile_PO!: File;

    grn_detail_list: any[] = [];

  ngOnInit(): void {

    let currentDateTime =this.datepipe.transform((new Date), 'MM/dd/yyyy h:mm:ss');
    this.newBlogForm = new FormGroup({
      id: new FormControl(0),
      grn_Date: new FormControl(null),
      grn_No: new FormControl(''),
      asset_Owner_Id: new FormControl(0),
      req_No: new FormControl(''),
      req_Attachment_Id: new FormControl(0),
      pO_No: new FormControl(''),
      pO_Amount: new FormControl(0),
      pO_Attachment_Id: new FormControl(0),
      vendor: new FormControl(''),
      company_Id: new FormControl(0),
      unit_Id: new FormControl(0),
      is_active: new FormControl(true),

    });

    this.assetOwnerList$=this._apiService.getAssetOwnerList();
    if(this.user_Id>0){
      this.companyList$ = this._apiService.getCompanyListByUser(this.user_Id);
    }else{
      this.companyList$ = this._apiService.getCompanyList();
    }

    // this.sparePartList$=this._apiService.getAssetSparePartList();

    let id = this.currentRoute.snapshot.paramMap.get('id');
    if (id != null) {
      this.getAssetGrnMasterById(id);
     
    }else{
      this.grn_Date=currentDateTime;
      this.getGrnNo();
    }

    if(this.user_Id == 122){
      this.is_Edit = false;
    }
  }

  getAssetGrnMasterById(id: number | string) {
    this._apiService.getAssetGrnMasterById(id).subscribe((data: any) => {
      this.id=data.id;
      this.grn_Date=data.grn_Date;
      this.grn_No=data.grn_No;
      this.asset_Owner_Id=data.asset_Owner_Id;
      this.req_No=data.req_No;
      this.req_Attachment_Id=data.req_Attachment_Id;
      this.attachment_File_Name_Req=data.attachment_File_Name_Req;
      this.pO_No=data.pO_No;
      this.pO_Amount=data.pO_Amount;
      this.pO_Attachment_Id=data.pO_Attachment_Id;
      this.attachment_File_Name_PO=data.attachment_File_Name_PO;
      this.vendor=data.vendor;
      this.company_Id=data.company_Id;
      this.unit_Id=data.unit_Id;
      this.is_active=data.is_active;

      this.grn_detail_list = data.assetGrnDetailList;
      this.unitList$=this._apiService.getUnitListByCompanyId(this.company_Id);
      this.sparePartList$=this._apiService.getAssetSparePartsByOwner(this.asset_Owner_Id);
    });
  }

  addGrnDetailRow() {
    if(this.asset_Owner_Id>0){
      this.grn_detail_list.push({ id: 0,asset_Grn_Master_Id: 0,asset_Spare_Parts_Id: 0, purchase_Price: 0,  purchase_Qty: 0 ,warranty_Start_Date: '',warranty_End_Date: ''});
    }else{
      alert("Select Asset Owner")
    }
   
  }
  deletedGrnDetailROw(index: any) {
    if (confirm("Are you sure want to delete?")) {
      this.grn_detail_list.splice(index, 1);
    }
  }
  onSubmit(data: any){
    data.id=this.id;

    if(data.grn_Date == ''||data.grn_Date == null) {
      alert("GRN Date is Required")
      return;
    }

    if (data.asset_Owner_Id == 0||data.asset_Owner_Id == null) {
      alert("Asset Owner is Required")
      return;
    }
    if (data.company_Id == 0||data.company_Id == null) {
      alert("Company is Required")
      return;
    }

    const formData = new FormData();

    formData.append('id', data.id);
    formData.append('grn_Date', data.grn_Date);
    formData.append('grn_No', data.grn_No);
    formData.append('asset_Owner_Id', data.asset_Owner_Id);
    formData.append('req_No', data.req_No == null ? '' : data.req_No);
    formData.append('req_Attachment_Id', data.req_Attachment_Id);
    formData.append('attachmentFile_Req', this.selectedFile_Req);
    formData.append('pO_No', data.pO_No == null ? '' : data.pO_No);
    formData.append('pO_Amount', data.pO_Amount);
    formData.append('pO_Attachment_Id', data.pO_Attachment_Id);
    formData.append('attachmentFile_PO', this.selectedFile_PO);
    formData.append('vendor', data.vendor == null ? '' : data.vendor);
    formData.append('company_Id', data.company_Id);
    formData.append('unit_Id', data.unit_Id);
    formData.append('user_Id', this.user_Id.toString());
    formData.append('is_active', data.is_active);


    for (let i = 0; i < this.grn_detail_list.length; i++) {

      if ((this.grn_detail_list[i].asset_Spare_Parts_Id == 0 || this.grn_detail_list[i].asset_Spare_Parts_Id == null)) {
        alert("Spare Item is Required!");
        return;
      }
      if ((this.grn_detail_list[i].purchase_Price == 0 || this.grn_detail_list[i].purchase_Price == null)) {
        alert("Spare Item Price is Required!");
        return;
      }
      if ((this.grn_detail_list[i].purchase_Qty == 0 || this.grn_detail_list[i].purchase_Qty == null)) {
        alert("Spare Item Quantity is Required!");
        return;
      }

      const keyPrefix = "assetGrnDetailList[" + i.toString() + "].";
      formData.append(keyPrefix + "id", this.grn_detail_list[i].id);
      formData.append(keyPrefix + "asset_Spare_Parts_Id", this.grn_detail_list[i].asset_Spare_Parts_Id);
      formData.append(keyPrefix + "purchase_Price", this.grn_detail_list[i].purchase_Price);
      formData.append(keyPrefix + "purchase_Qty", this.grn_detail_list[i].purchase_Qty);
      if (this.grn_detail_list[i].warranty_Start_Date != null) {
        formData.append(keyPrefix + "warranty_Start_Date", this.grn_detail_list[i].warranty_Start_Date);
      }
      if (this.grn_detail_list[i].warranty_End_Date != null) {
        formData.append(keyPrefix + "warranty_End_Date", this.grn_detail_list[i].warranty_End_Date);
      }
      
     
    }

    if (this.newBlogForm.valid) {
      if (data.id != 0) {
  
        this._apiService.updateAssetGrnMaster(formData).subscribe(res => {
  
          this._snackBar.open("Asset GRN Master Updated Successfully", "Update", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });
  
          this.router.navigate(['/asset-grn-master']);
  
  
        })
      }
      else {
        this._apiService.addAssetGrnMaster(formData).subscribe(res => {
  
          this._snackBar.open("Asset GRN Master Saved Successfully", "Success", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });
  
          this.router.navigate(['/asset-grn-master']);
  
  
        })
      }
    }

  }
  getGrnNo() {
    this._apiService.getGrnNo()
    .subscribe((data: any) => {
      this.grn_No = data;
    })}

    gotoBack() {
      this.router.navigate(['/asset-grn-master']);
    }
    reset(): void {
      this.ngOnInit();
    }
    changeUnit(event: any) {
    
      this.unitList$=this._apiService.getUnitListByCompanyId(event.target.value);
     
    }
    onSelectFileReq(fileInput: any) {
      this.selectedFile_Req = <File>fileInput.target.files[0];
      this.req_Attachment_Id = 0;
    }

    onSelectFilePO(fileInput: any) {
      this.selectedFile_PO = <File>fileInput.target.files[0];
      this.pO_Attachment_Id = 0;
    }

    changeOwner(event: any) {
     if(event.target.value>0){
      this.asset_Owner_Id=event.target.value;
      this.sparePartList$=this._apiService.getAssetSparePartsByOwner(event.target.value);
     }
     
    }
}
