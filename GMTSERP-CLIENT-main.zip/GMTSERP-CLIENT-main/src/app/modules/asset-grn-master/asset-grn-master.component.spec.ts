import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetGrnMasterComponent } from './asset-grn-master.component';

describe('AssetGrnMasterComponent', () => {
  let component: AssetGrnMasterComponent;
  let fixture: ComponentFixture<AssetGrnMasterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AssetGrnMasterComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AssetGrnMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
