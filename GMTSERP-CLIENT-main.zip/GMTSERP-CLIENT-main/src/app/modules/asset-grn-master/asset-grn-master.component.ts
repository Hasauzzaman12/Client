import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';

@Component({
  selector: 'app-asset-grn-master',
  templateUrl: './asset-grn-master.component.html',
  styleUrls: ['./asset-grn-master.component.scss']
})
export class AssetGrnMasterComponent implements OnInit {

  grn_No: string = '';
  user_Id: number = this.authservice.getUserId;
  company_Id: number = 0;
  companyList$!:Observable<any[]>;
  isFilterShow: boolean = false;

  from_Date : any=null;
  to_Date : any=null;

  is_Edit : boolean = true;

  displayedColumns: string[] = ['grn_Date','grn_No','asset_Owner_Name','company_Name','pO_Amount', 'action'];
  dataSource!: MatTableDataSource<any>;

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';


  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(public _apiService: ApiServiceService,
    private authservice: AuthService,
    private _snackBar: MatSnackBar,
    public dialog: MatDialog,
    private router: Router) { }

  ngOnInit(): void {
    this.getAssetGrnMasterList();
    if(this.user_Id>0){
      this.companyList$ = this._apiService.getCompanyListByUser(this.user_Id);
    }else{
      this.companyList$ = this._apiService.getCompanyList();
    }

    if(this.user_Id==122){
      this.is_Edit = false;
    }
  }

  getAssetGrnMasterList() {
    const formData = new FormData();
    if (this.grn_No != ''||this.grn_No != null) {
      formData.append('grn_No', this.grn_No);
    }
    if (this.user_Id != 0||this.user_Id != null) {
      formData.append('user_Id', this.user_Id.toString());
    }
    if (this.company_Id != 0||this.company_Id != null) {
      formData.append('company_Id', this.company_Id.toString());
    }

    if(this.from_Date != null && this.to_Date != null){
      formData.append('from_Date', this.from_Date);
      formData.append('to_Date', this.to_Date);
    }
    
    this._apiService.getAssetGrnMastersFiltered(formData)
      .subscribe({
        next: (res) => {
          this.dataSource = new MatTableDataSource(res);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
        },
        error: (err) => {
          console.log("Error");
        }

      })
  }

  openForEdit(id: number) {

    this.router.navigate(['/asset-grn-master/edit/' + id]);
  }
  gotoNew() {
    this.router.navigate(['/add-asset-grn-master']);
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  SearchSummary() {
    this.getAssetGrnMasterList();
  }
  reset() {

    this.grn_No='';
    this.company_Id=0;
    this.from_Date=null;
    this.to_Date=null;
    
    this.getAssetGrnMasterList();
  }

  toggleFilter() {
    this.isFilterShow = !this.isFilterShow;
  }
}
