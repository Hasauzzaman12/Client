import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';

@Component({
  selector: 'app-asset-spare-part-book',
  templateUrl: './asset-spare-part-book.component.html',
  styleUrls: ['./asset-spare-part-book.component.scss']
})
export class AssetSparePartBookComponent implements OnInit {

  asset_No: string = '';
  asset_Item_Name: string = '';
  asset_Owner_Id: number = 0;
  employee_Name: string = '';
  user_Id: number = this.authservice.getUserId;
  company_Id: number = 0;
  isFilterShow: boolean = false;

  from_Date : any=null;
  to_Date : any=null;

  assetOwnerList$!:Observable<any[]>;
  companyList$!:Observable<any[]>;

  displayedColumns: string[] = ['allocation_Date','asset_Owner_Name','company_Name','allocation_Type','asset_No','asset_Spare_Parts_Name','purchase_Qty','purchase_Price','action'];
  dataSource!: MatTableDataSource<any>;

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';


  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(public _apiService: ApiServiceService,
    private authservice: AuthService,
    private _snackBar: MatSnackBar,
    public dialog: MatDialog,
    private router: Router) { }

  ngOnInit(): void {
    this.geAssetSparePartBookList();
    if(this.user_Id>0){
      this.companyList$ = this._apiService.getCompanyListByUser(this.user_Id);
    }else{
      this.companyList$ = this._apiService.getCompanyList();
    }

    this.assetOwnerList$=this._apiService.getAssetOwnerList();
  }

  geAssetSparePartBookList() {
    const formData = new FormData();
    if (this.asset_Owner_Id != 0||this.asset_Owner_Id != null) {
      formData.append('asset_Owner_Id', this.asset_Owner_Id.toString());
    }
    if (this.asset_Item_Name != ''||this.asset_Item_Name != null) {
      formData.append('asset_Item_Name', this.asset_Item_Name);
    }
    if (this.asset_No != ''||this.asset_No != null) {
      formData.append('asset_No', this.asset_No);
    }
    if (this.employee_Name != ''||this.employee_Name != null) {
      formData.append('employee_Name', this.employee_Name);
    }
    if (this.user_Id != 0||this.user_Id != null) {
      formData.append('user_Id', this.user_Id.toString());
    }
    if (this.company_Id != 0||this.company_Id != null) {
      formData.append('company_Id', this.company_Id.toString());
    }

    if(this.from_Date != null && this.to_Date != null){
      formData.append('from_Date', this.from_Date);
      formData.append('to_Date', this.to_Date);
    }
    
    this._apiService.getAssetSparePartBookFiltered(formData)
      .subscribe({
        next: (res) => {
          this.dataSource = new MatTableDataSource(res);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
        },
        error: (err) => {
          console.log("Error");
        }

      })
  }
  openForEdit(id: number) {

    this.router.navigate(['/asset-spare-part-book/edit/' + id]);
  }
  gotoNew() {
    this.router.navigate(['/add-asset-spare-part-book']);
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  SearchSummary() {
    this.geAssetSparePartBookList();
  }
  reset() {
    this.asset_No='';
    this.employee_Name='';
    this.asset_Item_Name='';
    this.company_Id=0;
    this.asset_Owner_Id=0;
    this.from_Date=null;
    this.to_Date=null;
    
    this.geAssetSparePartBookList();
  }

  toggleFilter() {
    this.isFilterShow = !this.isFilterShow;
  }
  openAssetForView(id: number) {
    this.router.navigate([]).then((result) => {
      window.open('/#/asset-book/detail/' + id, '_blank');
    });
  }
}
