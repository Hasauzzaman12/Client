import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditAssetSparePartBookComponent } from './add-edit-asset-spare-part-book.component';

describe('AddEditAssetSparePartBookComponent', () => {
  let component: AddEditAssetSparePartBookComponent;
  let fixture: ComponentFixture<AddEditAssetSparePartBookComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddEditAssetSparePartBookComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddEditAssetSparePartBookComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
