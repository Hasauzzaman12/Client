import { HttpClient, HttpEventType, HttpRequest } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable, of,startWith, debounceTime, distinctUntilChanged, switchMap, map } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-add-edit-asset-spare-part-book',
  templateUrl: './add-edit-asset-spare-part-book.component.html',
  styleUrls: ['./add-edit-asset-spare-part-book.component.scss']
})
export class AddEditAssetSparePartBookComponent implements OnInit {

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';

  myControl = new FormControl();
  myControl2 = new FormControl();
  options = [];
  filteredOptions: Observable<any>;
  filteredOptionsEmp: Observable<any>;

  constructor(public _apiService: ApiServiceService,
    private _snackBar: MatSnackBar,
    public router: Router,
    private authservice: AuthService,
    private currentRoute: ActivatedRoute,
    private datepipe: DatePipe)  { 
      this.filteredOptions = this.myControl.valueChanges.pipe(

        startWith(''),
  
        debounceTime(400),
  
        distinctUntilChanged(),
  
        switchMap(val => {
          if(val!=''){
            return this.filter(val || '')
          }else{
            return '';
          }
  
         }) 
  
      )

      this.filteredOptionsEmp = this.myControl2.valueChanges.pipe(

        startWith(''),
  
        debounceTime(400),
  
        distinctUntilChanged(),
  
        switchMap(val => {
          if(val!=''){
            return this.filter2(val || '')
          }else{
            return '';
          }
  
         }) 
  
      )
    }

    newBlogForm!: FormGroup;
    id: number = 0;
    asset_Owner_Id: number = 0;
    asset_Book_Id: number = 0;
    item_Description: string = '';
    asset_Item_Name: string = '';
    asset_No= '';
    asset_Spare_Parts_Id: number = 0;
    allocation_Type= '';
    allocation_Date : any;
    company_Id: number = 0;
    unit_Id: number = 0;
    department_Id: number = 0;
    employee_Id: number = 0;
    employee_Name= '';
    employee_Code= '';
    custodian_Id: number = 0;
    sub_Custodian_Id: number = 0;
    available_Qty: number = 0;
    purchase_Price: number = 0;
    purchase_Qty: number = 0;
    user_Id: number = this.authservice.getUserId;
    is_active: boolean = true;


    assetOwnerList$!: Observable<any[]>;
    companyList$!:Observable<any[]>;
    unitList$!:Observable<any[]>;
    sparePartList$!:Observable<any[]>;
    assetBookList$!:Observable<any[]>;

    //View Control
    isEmployeeControl: boolean = false;
    isAssetControl: boolean = false;

  ngOnInit(): void {
    let currentDateTime =this.datepipe.transform((new Date), 'MM/dd/yyyy h:mm:ss');
    this.newBlogForm = new FormGroup({
      id: new FormControl(0),
      asset_Owner_Id: new FormControl(0),
      asset_Book_Id: new FormControl(0),
      asset_Spare_Parts_Id: new FormControl(0),
      allocation_Type: new FormControl(''),
      allocation_Date: new FormControl(null),
      company_Id: new FormControl(0),
      unit_Id: new FormControl(0),
      department_Id: new FormControl(0),
      employee_Id: new FormControl(0),
      custodian_Id: new FormControl(0),
      sub_Custodian_Id: new FormControl(0),
      purchase_Price: new FormControl(0),
      purchase_Qty: new FormControl(0),
      is_active: new FormControl(true),

    });

    this.assetOwnerList$=this._apiService.getAssetOwnerList();
    if(this.user_Id>0){
      this.companyList$ = this._apiService.getCompanyListByUser(this.user_Id);
    }else{
      this.companyList$ = this._apiService.getCompanyList();
    }

    let id = this.currentRoute.snapshot.paramMap.get('id');
    if (id != null) {
      this.getAssetSparePartBookById(id);
     
    }else{
      this.allocation_Date=currentDateTime;
    }
  }
  getAssetSparePartBookById(id: number | string) {
    this._apiService.getAssetSparePartBookById(id).subscribe((data: any) => {
      this.setPageView(data.allocation_Type);

      this.id=data.id;
      this.asset_Owner_Id=data.asset_Owner_Id;
      this.asset_Book_Id=data.asset_Book_Id;
      this.asset_No=data.asset_No;
      this.asset_Spare_Parts_Id=data.asset_Spare_Parts_Id;
      this.allocation_Type=data.allocation_Type;
      this.allocation_Date=data.allocation_Date;
      this.company_Id=data.company_Id;
      this.unit_Id=data.unit_Id;
      this.department_Id=data.department_Id;
      this.employee_Id=data.employee_Id;
      this.employee_Code=data.employee_Code;
      this.custodian_Id=data.custodian_Id;
      this.sub_Custodian_Id=data.sub_Custodian_Id;
      this.purchase_Price=data.purchase_Price;
      this.purchase_Qty=data.purchase_Qty;
      this.is_active=data.is_active;

      this.unitList$=this._apiService.getUnitListByCompanyId(this.company_Id);
      this.sparePartList$=this._apiService.getAssetSparePartsByOwner(this.asset_Owner_Id);
      if(this.employee_Id>0){
        this.assetBookList$=this._apiService.getAssetByEmployeeID(this.employee_Id);
      }
      if(this.asset_Book_Id>0){
      this._apiService.getAssetBookById(this.asset_Book_Id).subscribe((data: any) => {
        this.asset_Item_Name=data.asset_Item_Name;
        this.item_Description=data.item_Description;
       })
      }
    });
  }

  onSubmit(data: any){
    data.id=this.id;

    if(data.allocation_Date == ''||data.allocation_Date == null) {
      alert("Allocation Date is Required")
      return;
    }
    if(data.allocation_Type == ''||data.allocation_Type == null) {
      alert("Allocation Type is Required")
      return;
    }
    if (data.asset_Owner_Id == 0||data.asset_Owner_Id == null) {
      alert("Asset Owner is Required")
      return;
    }
    if (data.asset_Book_Id == 0||data.asset_Book_Id == null) {
      alert("Asset Book is Required")
      return;
    }
    if (data.asset_Spare_Parts_Id == 0||data.asset_Spare_Parts_Id == null) {
      alert("Asset Spare Parts is Required")
      return;
    }
    if(data.purchase_Qty>this.available_Qty){
      alert("Invalid Quantity")
    return;
    }
    const formData = new FormData();

    formData.append('id', data.id);
    formData.append('asset_Owner_Id', data.asset_Owner_Id);
    formData.append('allocation_Date', data.allocation_Date);
    formData.append('allocation_Type', data.allocation_Type == null ? '' : data.allocation_Type);
    formData.append('asset_Book_Id', data.asset_Book_Id);
    formData.append('asset_Spare_Parts_Id', data.asset_Spare_Parts_Id);
    formData.append('company_Id', data.company_Id);
    formData.append('unit_Id', data.unit_Id);
    formData.append('employee_Id', data.employee_Id);
    formData.append('purchase_Price', data.purchase_Price);
    formData.append('purchase_Qty', data.purchase_Qty);
    formData.append('user_Id', this.user_Id.toString());
    formData.append('is_active', data.is_active);

    if (this.newBlogForm.valid) {
      if (data.id != 0) {
  
        this._apiService.updateAssetSparePartBook(formData).subscribe(res => {
  
          this._snackBar.open("Asset Spare Part Updated Successfully", "Update", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });
  
          this.router.navigate(['/asset-spare-part-book']);
  
  
        })
      }
      else {
        this._apiService.addAssetSparePartBook(formData).subscribe(res => {
  
          this._snackBar.open("Asset Spare Part Saved Successfully", "Success", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });
  
          this.router.navigate(['/asset-spare-part-book']);
  
  
        })
      }
    }


  }
  changeView(event: any) {
    if(event.target.value!=null){
      this.setPageView(event.target.value);
    }
    
  }


  setPageView(value: number | string) {
    if(value=='Asset Book'){
      this.resetPageView();
      this.isAssetControl=true;
    }else if(value=='Individual User'){
      this.resetPageView();
      this.isEmployeeControl=true;
    } else{
      this.resetPageView();
    }
  }
  resetPageView() {
    this.isAssetControl=false;this.isEmployeeControl=false;
  }
  gotoBack() {
    this.router.navigate(['/asset-spare-part-book']);
  }
  reset(): void {
    this.ngOnInit();
  }
  changeUnit(event: any) {
  
    this.unitList$=this._apiService.getUnitListByCompanyId(event.target.value);
   
  }

  changeOwner(event: any) {
    if(event.target.value>0){
     this.asset_Owner_Id=event.target.value;
     this.sparePartList$=this._apiService.getAssetSparePartsByOwner(event.target.value);
    }}
    changeSpareParts(event: any) {
      if(event.target.value>0){
        this.asset_Spare_Parts_Id=event.target.value;
        
      }
    }

    changeAsset(event: any) {
      if(event.target.value>0){
        this._apiService.getAssetBookById(event.target.value).subscribe((data: any) => {
          this.asset_Item_Name=data.asset_Item_Name;
          this.item_Description=data.item_Description;
          this.company_Id=data.company_Id;
          this.asset_Book_Id=event.target.value;
         })

         if(this.asset_Spare_Parts_Id>0 && this.company_Id>0){
          this._apiService.getAvailableSparePartQty(this.asset_Spare_Parts_Id,this.company_Id)
          .subscribe((data: any) => {
            this.available_Qty=data;
          })}
      }
    }

    changeQty(data: any) {
      
      if(data.purchase_Qty!=null){
        if (data.asset_Spare_Parts_Id == 0||data.asset_Spare_Parts_Id == null) {
          alert("Asset Spare Parts is Required")
          return;
        }
        data.purchase_Qty=data.purchase_Qty!;
        if(data.purchase_Qty>this.available_Qty){
          alert("Invalid Quantity")
        return;
        }
      }
      
    }
    filter(val: string): Observable <any>{

      const formData = new FormData();
      formData.append('asset_No', val);
      if (this.user_Id != 0||this.user_Id != null) {
        formData.append('user_Id', this.user_Id.toString());
      }
      if (this.asset_Owner_Id != 0||this.asset_Owner_Id != null) {
        formData.append('asset_Owner_Id', this.asset_Owner_Id.toString());
      }
      // formData.append('status', 'STOCKED');
      // formData.append('asset_Item_Category_Id', this.asset_Item_Category_Id.toString());
  
      return this._apiService.getAssetBookingFiltered(formData)
  
      .pipe(
  
        map(response => response.filter((option: { asset_No: string; }) => { 
  
          return option.asset_No.toLowerCase().indexOf(val.toLowerCase()) !== -1
  
        }))
  
      )
  
     }  
  
     filter2(val: string): Observable <any>{
      const formData = new FormData();
      formData.append('employee_Id', val);
      if (this.asset_Owner_Id != 0||this.asset_Owner_Id != null) {
        formData.append('asset_Owner_Id', this.asset_Owner_Id.toString());
      }
      if (this.user_Id != 0||this.user_Id != null) {
        formData.append('user_Id', this.user_Id.toString());
      }
      formData.append('emp_Status', 'Active');
  
      return this._apiService.getEmployeesFiltered(formData)
  
      .pipe(
  
        map(response => response.filter((option: { employee_Id: string; }) => { 
  
          return option.employee_Id.toLowerCase().indexOf(val.toLowerCase()) !== -1
  
        }))
  
      )
  
     }  
  
     onSelFunc(option: any){
      if(option.id>0){
        this.asset_Book_Id=option.id;
        this.company_Id=option.company_Id;
        if(this.company_Id>0){
          this.unitList$=this._apiService.getUnitListByCompanyId(this.company_Id);
        }
        this.unit_Id=option.unit_Id;
       this._apiService.getAssetBookById(option.id).subscribe((data: any) => {
        this.asset_Item_Name=data.asset_Item_Name;
        this.item_Description=data.item_Description;
       })
       if(this.asset_Spare_Parts_Id>0 && this.company_Id>0){
        this._apiService.getAvailableSparePartQty(this.asset_Spare_Parts_Id,this.company_Id)
        .subscribe((data: any) => {
          this.available_Qty=data;
        })}
      }
    }
  
    onSelFunc2(option: any){
      if(option.id>0){
        this.employee_Id=option.id;
        this.employee_Name=option.employee_Name;
        this.department_Id=option.department_Id;
        this.company_Id=option.company_Id;

        if(this.company_Id>0){
          this.unitList$=this._apiService.getUnitListByCompanyId(this.company_Id);
        }
        this.unit_Id=option.unit_Id;

        if(this.employee_Id>0){
          this.assetBookList$=this._apiService.getAssetByEmployeeID(this.employee_Id);
        }
        
      }
    }
}
