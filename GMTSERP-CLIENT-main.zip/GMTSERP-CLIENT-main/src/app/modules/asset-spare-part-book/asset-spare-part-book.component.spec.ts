import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetSparePartBookComponent } from './asset-spare-part-book.component';

describe('AssetSparePartBookComponent', () => {
  let component: AssetSparePartBookComponent;
  let fixture: ComponentFixture<AssetSparePartBookComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AssetSparePartBookComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AssetSparePartBookComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
