import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditAssetAllocationVehicleReturnComponent } from './add-edit-asset-allocation-vehicle-return.component';

describe('AddEditAssetAllocationVehicleReturnComponent', () => {
  let component: AddEditAssetAllocationVehicleReturnComponent;
  let fixture: ComponentFixture<AddEditAssetAllocationVehicleReturnComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddEditAssetAllocationVehicleReturnComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddEditAssetAllocationVehicleReturnComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
