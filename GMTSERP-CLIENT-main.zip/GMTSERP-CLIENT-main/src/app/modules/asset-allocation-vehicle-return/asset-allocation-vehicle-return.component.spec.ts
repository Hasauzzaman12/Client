import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetAllocationVehicleReturnComponent } from './asset-allocation-vehicle-return.component';

describe('AssetAllocationVehicleReturnComponent', () => {
  let component: AssetAllocationVehicleReturnComponent;
  let fixture: ComponentFixture<AssetAllocationVehicleReturnComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AssetAllocationVehicleReturnComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AssetAllocationVehicleReturnComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
