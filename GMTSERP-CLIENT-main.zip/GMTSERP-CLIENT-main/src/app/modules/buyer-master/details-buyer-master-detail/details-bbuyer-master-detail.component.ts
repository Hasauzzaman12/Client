import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-details-bbuyer-master-detail',
  templateUrl: './details-bbuyer-master-detail.component.html',
  styleUrls: ['./details-bbuyer-master-detail.component.scss']
})
export class DetailsBbuyerMasterDetailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
