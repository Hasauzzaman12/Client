import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DetailsBbuyerMasterDetailComponent } from './details-bbuyer-master-detail.component';

describe('DetailsBbuyerMasterDetailComponent', () => {
  let component: DetailsBbuyerMasterDetailComponent;
  let fixture: ComponentFixture<DetailsBbuyerMasterDetailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DetailsBbuyerMasterDetailComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DetailsBbuyerMasterDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
