import { HttpClient } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { debounceTime, distinctUntilChanged, filter, finalize, map, Observable, of, startWith, switchMap, tap } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';

@Component({
  selector: 'app-add-edit-buyer-master',
  templateUrl: './add-edit-buyer-master.component.html',
  styleUrls: ['./add-edit-buyer-master.component.scss']
})
export class AddEditBuyerMasterComponent implements OnInit {

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';
  // selectedFile!: File;
  newBlogForm!:FormGroup;
  submitted = false;
  UserType:any;

  activeUserList$!:Observable<any[]>;
  countryList$!:Observable<any[]>;
  BuyerTypeList$!:Observable<any[]>;
  RoleList$!:Observable<any[]>;



  id: number = 0;
  countryId: number = 0;
  buyer_Type:string="";
  short_Name:string="";
  website:string="";
  is_active: boolean=true;

  userid: number = 0;
  companyid: number = 0;


  


  rows:any = [];

  options:string[]=["One","Two","Three"];
  
  myControl=new FormControl;

  constructor(
    public router:Router,
    public _apiService:ApiServiceService,
    public _authService:AuthService,
    private _snackBar: MatSnackBar,
    private authservice:AuthService,
    private currentRoute: ActivatedRoute,
    public http:HttpClient,
    public formBuilder:FormBuilder
    ) { 


    }



    get f(){
      return this.newBlogForm.controls;
    }

    changeUnit(event: any) {

      // this.selectedDay = event.target.value;
      // alert(this.selectedDay);
     
    }

   


  ngOnInit(): void {

    let id = this.currentRoute.snapshot.paramMap.get('id');
    if (id != null){
      this.getBuyerMasterById(id);

    }

    this.newBlogForm = this.formBuilder.group({
      id:new FormControl(0),
      buyer_Name:new FormControl(null),
      f_Office_Address:new FormControl(null),
      l_Office_Address:new FormControl(null), 
      short_Name:new FormControl(null),
      f_Contact_Person:new FormControl(null),
      l_Contact_Person: new FormControl(null),
      buyer_Code: new FormControl(null),
      f_Contact_No: new FormControl(null),
      l_Contact_No: new FormControl(null),
      countryId: new FormControl(null),
      f_Contact_Email: new FormControl(null),
      l_Contact_Email: new FormControl(null),
      buyer_Type: new FormControl(null),
      website: new FormControl(null),
      is_active: new FormControl(null),

      
      userid: new FormControl(this.authservice.getUserId),
      companyid: new FormControl(this.authservice.getCompanyId),


    });

    this.rows = [{
      userName:"",
      employeeName:"",
      dds:"",
      ddpt:"",
      role:""
     }]


    const buyerType = [
      {id: 'Foreign',name: 'Foreign' },
      {id: 'Local',name: 'Local'},
      {id: 'Internal',name: 'Internal'}
    ];


    const roleName = [
      {id: 'MTH',name: 'Marchandiser Team Head' },
      {id: 'MT',name: 'Marchandiser'},
      {id: 'DEO',name: 'Data Entry Operator'},
      {id: 'AD',name: 'Auditor'}
    ];

    this.userid=this.authservice.getUserId;
    this.companyid=this.authservice.getCompanyId;

    this.countryList$=this._apiService.getCountryList();
    this.activeUserList$=this.authservice.getUserList();
    this.BuyerTypeList$= of(buyerType);
    this.RoleList$=of(roleName);



            


  }

  gotoBack() {
    this.router.navigate(['/buyer-master']);
  }

  onReset(): void {
    this.submitted = false;
    this.newBlogForm.reset();
  }


  addRow() {
    let row = {userName: "", employeeName: "",dds:"",ddpt:"",role:""};
    this.rows.push(row);
 }
 deleteRow(index:any) {
      this.rows.splice(index, 1);
 }


  onSubmit(data: any) {
    // this.submitted = true;
    // if (this.newBlogForm.invalid) {
    //   return;
    // }
    if(data.id!=0)
    {
      this.newBlogForm = this.formBuilder.group({
        id:new FormControl(data.id),
        buyer_Name:new FormControl(data.buyer_Name),
        f_Office_Address:new FormControl(data.f_Office_Address),
        l_Office_Address:new FormControl(data.l_Office_Address), 
        short_Name:new FormControl(data.short_Name),
        f_Contact_Person:new FormControl(data.f_Contact_Person),
        l_Contact_Person: new FormControl(data.l_Contact_Person),
        buyer_Code: new FormControl(data.buyer_Code),
        f_Contact_No: new FormControl(data.f_Contact_No),
        l_Contact_No: new FormControl(data.l_Contact_No),
        countryId: new FormControl(data.countryId),
        f_Contact_Email: new FormControl(data.f_Contact_Email),
        l_Contact_Email: new FormControl(data.l_Contact_Email),
        buyer_Type: new FormControl(data.buyer_Type),
        website: new FormControl(data.website),
        is_active: new FormControl(data.is_active),
  

  
  
      });

      this._apiService.updateBuyerMaster(data).subscribe(res => {

        this._snackBar.open("Buyer Master Updated Successfully", "Update", {
          horizontalPosition: this.horizontalPosition,
          verticalPosition: this.verticalPosition,
          duration: 2000
        });
  
        this.router.navigate(['/buyer-master']);
  
       
      })

    }
    else
    {


    const formData = new FormData();

    formData.append('id', data.id);
    formData.append('buyer_Name', data.buyer_Name);
    formData.append('short_Name', data.short_Name);
    formData.append('buyer_Code', data.buyer_Code);
    formData.append('countryId', data.countryId);
    formData.append('buyer_Type', data.buyer_Type);
    formData.append('website', data.website);

    formData.append('f_Office_Address', data.f_Office_Address);
    formData.append('f_Contact_Person', data.f_Contact_Person);
    formData.append('f_Contact_No', data.f_Contact_No);
    formData.append('f_Contact_Email', data.f_Contact_Email);
  
    
    formData.append('l_Office_Address', data.l_Office_Address);
    formData.append('l_Contact_Person', data.l_Contact_Person);
    formData.append('l_Contact_No', data.l_Contact_No);
    formData.append('l_Contact_Email', data.l_Contact_Email);

    formData.append('is_active', data.is_active);

    formData.append('userid',this.authservice.getUserId);
    


    console.log(formData);
    

    this._apiService.addBuyerList(formData).subscribe(res => {
     

        this._snackBar.open("Buyer Saved Successfully", "Success", {
          horizontalPosition: this.horizontalPosition,
          verticalPosition: this.verticalPosition,
          duration: 2000
        });
  
        this.router.navigate(['/buyer-master']);
     
      })
    }
  }

  


  getBuyerMasterById(id:number|string){
    this._apiService.getBuyerMasterById(id)
    .subscribe((data: any) => {
    
      this.newBlogForm = new FormGroup({

        id:new FormControl(data.id),
        buyer_Name:new FormControl(data.buyer_Name),
        f_Office_Address:new FormControl(data.f_Office_Address),
        l_Office_Address:new FormControl(data.l_Office_Address), 
        short_Name:new FormControl(data.short_Name),
        f_Contact_Person:new FormControl(data.f_Contact_Person),
        l_Contact_Person: new FormControl(data.l_Contact_Person),
        buyer_Code: new FormControl(data.buyer_Code),
        f_Contact_No: new FormControl(data.f_Contact_No),
        l_Contact_No: new FormControl(data.l_Contact_No),
        countryId: new FormControl(data.countryId),
        f_Contact_Email: new FormControl(data.f_Contact_Email),
        l_Contact_Email: new FormControl(data.l_Contact_Email),
        buyer_Type: new FormControl(data.buyer_Type),
        website: new FormControl(data.website),
        is_active: new FormControl(data.is_active),
  
        
        userid: new FormControl(this.authservice.getUserId),
        companyid: new FormControl(this.authservice.getCompanyId),
  
      });
  


    });
  
  }



}
