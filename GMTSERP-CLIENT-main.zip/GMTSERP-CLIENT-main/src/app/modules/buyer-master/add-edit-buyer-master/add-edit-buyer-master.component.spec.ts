import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditBuyerMasterComponent } from './add-edit-buyer-master.component';

describe('AddEditBuyerMasterComponent', () => {
  let component: AddEditBuyerMasterComponent;
  let fixture: ComponentFixture<AddEditBuyerMasterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddEditBuyerMasterComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddEditBuyerMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
