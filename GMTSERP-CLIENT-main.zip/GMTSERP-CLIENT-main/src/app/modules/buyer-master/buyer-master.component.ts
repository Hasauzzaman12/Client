import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';

@Component({
  selector: 'app-buyer-master',
  templateUrl: './buyer-master.component.html',
  styleUrls: ['./buyer-master.component.scss']
})
export class BuyerMasterComponent implements OnInit {

  displayedColumns: string[] = ['buyer_Name','short_Name', 'buyer_Code', 'buyer_Type', 'f_Office_Address', 'l_Office_Address','f_Contact_Person','is_active','action'];
  dataSource!: MatTableDataSource<any>;

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(public authservice:AuthService,private _servive:ApiServiceService, private router:Router) { }


  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }


  gotoNew() {
    this.router.navigate(['/addbuyermaster']);
  }


  ngOnInit(): void {
    this. getAllExistingBuyerMasterList();
  }

  getAllExistingBuyerMasterList(){
    this._servive.getBuyerList()
    .subscribe({
      next:(res)=>{
        this.dataSource=new MatTableDataSource(res);
        this.dataSource.paginator=this.paginator;
        this.dataSource.sort=this.sort;
      },
      error:(err)=>{
        console.log("Error");
      }
      
    })
  }

  openForEdit(itemId: number) {
   
    this.router.navigate(['/buyer-master/edit/' + itemId]);
  }


  gotoBack() {
    this.router.navigate(['/buyer-master']);
  }

}