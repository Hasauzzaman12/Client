

import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { ApiServiceService } from 'src/app/api-service.service';

@Component({
  selector: 'app-admin-company-unit',
  templateUrl: './admin-company-unit.component.html',
  styleUrls: ['./admin-company-unit.component.scss']
})
export class AdminCompanyUnitComponent implements OnInit {

  displayedColumns: string[] = ['companyName', 'unitName','display_Order', 'isActive', 'action'];
  dataSource!: MatTableDataSource<any>;

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';


  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(public _apiService: ApiServiceService,
    private _snackBar: MatSnackBar,
    public dialog: MatDialog,
    private router: Router) { }

  ngOnInit(): void {
    this.getCompanyUnitList();
  }

  getCompanyUnitList() {
    this._apiService.getUnitList()
      .subscribe({
        next: (res) => {
          this.dataSource = new MatTableDataSource(res);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
        },
        error: (err) => {
          console.log("Error");
        }

      })
  }

  openForEdit(id: number) {

    this.router.navigate(['/company-unit/edit/' + id]);
  }
  gotoNew() {
    this.router.navigate(['/addcompanyunit']);
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  deleteCompanyUnit(id: number) {

    if (confirm("Are you sure to delete?")) {
      this._apiService.deleteUnit(id)
        .subscribe({
          next: (res) => {
            this._snackBar.open("Company Unit Deleted Successfully", "Delete", {
              horizontalPosition: this.horizontalPosition,
              verticalPosition: this.verticalPosition,
              duration: 1000
            });
            this.getCompanyUnitList();
          },
          error: () => {
            this._snackBar.open("Delete Failed", "Failed");
          }
        })
    }



  }

}


