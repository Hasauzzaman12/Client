import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminCompanyUnitComponent } from './admin-company-unit.component';

describe('AdminCompanyUnitComponent', () => {
  let component: AdminCompanyUnitComponent;
  let fixture: ComponentFixture<AdminCompanyUnitComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminCompanyUnitComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdminCompanyUnitComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
