import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddAdminCompanyUnitComponent } from './add-admin-company-unit.component';

describe('AddAdminCompanyUnitComponent', () => {
  let component: AddAdminCompanyUnitComponent;
  let fixture: ComponentFixture<AddAdminCompanyUnitComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddAdminCompanyUnitComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddAdminCompanyUnitComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
