

import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';

@Component({
  selector: 'app-add-admin-company-unit',
  templateUrl: './add-admin-company-unit.component.html',
  styleUrls: ['./add-admin-company-unit.component.scss']
})
export class AddAdminCompanyUnitComponent implements OnInit {

  public result: boolean = false;
  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';

  constructor(
    public _apiService: ApiServiceService,
    private _snackBar: MatSnackBar,
    public router: Router,
    private authservice: AuthService,
    private currentRoute: ActivatedRoute,
  ) { }

  newBlogForm!: FormGroup;
  @Input() adminUnit: any;
  id: number = 0;
  companyId: number = 0;
  unitName: string = '';
  display_Order: number = 0;
  isActive: boolean = true;

  companyList$!: Observable<any[]>;

  ngOnInit(): void {

    this.newBlogForm = new FormGroup({
      id: new FormControl(0),
      companyId: new FormControl('', [Validators.required]),
      unitName: new FormControl("0",[Validators.required]),
      display_Order:new FormControl(0),
      isActive: new FormControl(0),
    });
    this.companyList$ = this._apiService.getCompanyList();

    let id = this.currentRoute.snapshot.paramMap.get('id');
    if (id != null) {
      this.getAdminCompanyUnitById(id);
    }

  }

  checkExist1(event: any) {
    this.companyId=event.target.value;
    this._apiService.checkduplicateCompanyUnit(this.unitName,this.companyId).subscribe(response => {
      this.result = response;
      if (this.result == true) {
        this._snackBar.open("It is already exist", "Please Update", {
          horizontalPosition: this.horizontalPosition,
          verticalPosition: this.verticalPosition,
          duration: 2000
        });
      }
    });
  }

  checkExist2(event: any) {
    this.unitName=event.target.value;
    this._apiService.checkduplicateCompanyUnit(this.unitName,this.companyId).subscribe(response => {
      this.result = response;
      if (this.result == true) {
        this._snackBar.open("It is already exist", "Please Update", {
          horizontalPosition: this.horizontalPosition,
          verticalPosition: this.verticalPosition,
          duration: 2000
        });
      }
    });
  }


  getAdminCompanyUnitById(id: number | string) {
    this._apiService.getAdminCompanyUnitById(id).subscribe((data: any) => {

      this.newBlogForm = new FormGroup({
        id: new FormControl(data.id),
        unitName: new FormControl(data.unitName),
        companyId: new FormControl(data.companyId),
        display_Order:new FormControl(data.display_Order),
        isActive: new FormControl(data.isActive)
      });
    });
  }

  onSubmit(data: any) {


    if (data.unitName == '' || data.unitName == null) {
      alert("Unit Name is Required")
      return;
    }
    if (data.companyId == 0 || data.companyId == '' || data.companyId == null) {
      alert("Company is Required")
      return;
    }


    if(this.result==true){
      return;
    }


    const formData = new FormData();
    formData.append('id', data.id);
    formData.append('unitName', data.unitName);
    formData.append('companyId', data.companyId);
    formData.append('display_Order', data.display_Order);
    formData.append('isActive', data.isActive);



    if (this.newBlogForm.valid) {
      if (data.id != 0) {

        this._apiService.updateUnit(data).subscribe(res => {

          this._snackBar.open("Admin Company Unit Updated Successfully", "Update", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });

          this.router.navigate(['/company-unit']);
        })
      }
      else {
        this._apiService.addUnit(data).subscribe(res => {

          this._snackBar.open("Admin Company Unit  Saved Successfully", "Success", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });

          // this.router.navigate(['/item-sub-category']);
          this.ngOnInit();
        })
      }
    }
  }
  gotoBack() {
    this.router.navigate(['/company-unit']);
  }
  reset(): void {
    this.ngOnInit();
  }
}

