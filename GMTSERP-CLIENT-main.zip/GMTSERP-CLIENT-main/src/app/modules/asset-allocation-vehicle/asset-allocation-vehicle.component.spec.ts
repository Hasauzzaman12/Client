import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetAllocationVehicleComponent } from './asset-allocation-vehicle.component';

describe('AssetAllocationVehicleComponent', () => {
  let component: AssetAllocationVehicleComponent;
  let fixture: ComponentFixture<AssetAllocationVehicleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AssetAllocationVehicleComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AssetAllocationVehicleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
