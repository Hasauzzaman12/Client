import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditAssetAllocationVehicleComponent } from './add-edit-asset-allocation-vehicle.component';

describe('AddEditAssetAllocationVehicleComponent', () => {
  let component: AddEditAssetAllocationVehicleComponent;
  let fixture: ComponentFixture<AddEditAssetAllocationVehicleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddEditAssetAllocationVehicleComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddEditAssetAllocationVehicleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
