import { HttpClient, HttpEventType, HttpRequest } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable, of,startWith, debounceTime, distinctUntilChanged, switchMap, map } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';
import { DatePipe } from '@angular/common';
import { SD } from 'src/environments/sd';

@Component({
  selector: 'app-add-edit-asset-allocation-vehicle',
  templateUrl: './add-edit-asset-allocation-vehicle.component.html',
  styleUrls: ['./add-edit-asset-allocation-vehicle.component.scss']
})
export class AddEditAssetAllocationVehicleComponent implements OnInit {

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';

  myControl = new FormControl();
  myControl2 = new FormControl();
  options = [];
  filteredOptions: Observable<any>;
  filteredOptionsEmp: Observable<any>;

  constructor(public _apiService: ApiServiceService,
    private _snackBar: MatSnackBar,
    public router: Router,
    private authservice: AuthService,
    private currentRoute: ActivatedRoute,
    private datepipe: DatePipe) { 
      this.filteredOptions = this.myControl.valueChanges.pipe(

        startWith(''),
  
        debounceTime(400),
  
        distinctUntilChanged(),
  
        switchMap(val => {
  
              return this.filter(val || '')
  
         }) 
  
      )

      this.filteredOptionsEmp = this.myControl2.valueChanges.pipe(

        startWith(''),
  
        debounceTime(400),
  
        distinctUntilChanged(),
  
        switchMap(val => {
  
          if(val!=''){
            return this.filter2(val || '')
          }else{
            return '';
          }
  
         }) 
  
      )
    }

    newBlogForm!: FormGroup;
    id: number = 0;
    allocation_Date : any;
    asset_Book_Id: number = 0;
    asset_No= '';
    allocation_Type= '';
    company_Id: number = 0;
    department_Id: number = 0;
    employee_Id: number = 0;
    employee_Code= '';
    employee_Name= '';
    is_active: boolean = true;
    user_Id: number = this.authservice.getUserId;
    asset_Item_Category_Id: number = SD.asset_Item_Category_Id_vehicle;
    asset_Owner_Id: number = SD.asset_Owner_Id_Transport;

    assetBookList$!:Observable<any[]>;
    companyList$!:Observable<any[]>;
    departmentList$!:Observable<any[]>;
    employeeList$!:Observable<any[]>;

  ngOnInit(): void {

    let currentDateTime =this.datepipe.transform((new Date), 'MM/dd/yyyy h:mm:ss');
    this.newBlogForm = new FormGroup({
      id: new FormControl(0),
      allocation_Date: new FormControl(null),
      asset_Book_Id: new FormControl(0),
      allocation_Type: new FormControl(''),
      company_Id: new FormControl({value: 0, disabled: true}),
      department_Id: new FormControl({value: 0, disabled: true}),
      employee_Id: new FormControl(0),
      is_active: new FormControl(true)
    });

   
    this.companyList$ = this._apiService.getCompanyList();
    this.departmentList$ = this._apiService.getDepartmentList();

    let id = this.currentRoute.snapshot.paramMap.get('id');
    if (id != null) {
      this.getAssetAllocationById(id);
     
    }else{
      this.allocation_Date=currentDateTime;
    }
  }


  getAssetAllocationById(id: number | string) {
    this._apiService.getAssetAllocationkById(id).subscribe((data: any) => {
      this.id=data.id;
      this.allocation_Date=data.allocation_Date;
      this.asset_Book_Id=data.asset_Book_Id;
      this.asset_No=data.asset_No;
      this.allocation_Type=data.allocation_Type;
      this.company_Id=data.company_Id;
      this.department_Id=data.department_Id;
      this.employee_Id=data.employee_Id;
      this.employee_Code=data.employee_Code;
      this.employee_Name=data.employee_Name;
      this.is_active=data.is_active;

    });

    
  }

  onSubmit(data: any){
    data.id=this.id;
    data.department_Id=this.department_Id;
    data.company_Id=this.company_Id;
    
    if(data.allocation_Date == ''||data.allocation_Date == null) {
      alert("Allocation Date is Required")
      return;
    }
    if (data.allocation_Type == ''||data.allocation_Type == null) {
      alert("Allocation Type is Required")
      return;
    }
    if (data.asset_Book_Id == 0||data.asset_Book_Id == null) {
      alert("Asset Book is Required")
      return;
    }

    const formData = new FormData();

    
    formData.append('id', data.id);
    formData.append('allocation_Date', data.allocation_Date);
    formData.append('asset_Book_Id', data.asset_Book_Id);
    formData.append('allocation_Type', data.allocation_Type);
    formData.append('company_Id', data.company_Id);
    formData.append('department_Id', data.department_Id);
    formData.append('employee_Id', data.employee_Id);
    formData.append('user_Id', this.user_Id.toString());
    formData.append('is_active', data.is_active);

    if (this.newBlogForm.valid) {
      if (data.id != 0) {
  
        this._apiService.updateAssetAllocation(formData).subscribe(res => {
  
          this._snackBar.open("Asset Allocation Updated Successfully", "Update", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });
  
          this.router.navigate(['/asset-allocation-vehicle']);
  
  
        })
      }
      else {
        this._apiService.addAssetAllocation(formData).subscribe(res => {
  
          this._snackBar.open("Asset Allocation Saved Successfully", "Success", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });
  
          this.router.navigate(['/asset-allocation-vehicle']);
  
  
        })
      }
    }

  }

  filter(val: string): Observable <any>{

    const formData = new FormData();
    if (this.asset_Owner_Id != 0||this.asset_Owner_Id != null) {
      formData.append('asset_Owner_Id', this.asset_Owner_Id.toString());
    }
    if (this.user_Id != 0||this.user_Id != null) {
      formData.append('user_Id', this.user_Id.toString());
    }
    formData.append('status', 'STOCKED');
    formData.append('asset_Item_Category_Id', this.asset_Item_Category_Id.toString());
    

    return this._apiService.getAssetBookingFiltered(formData)

    .pipe(

      map(response => response.filter((option: { asset_No: string; }) => { 

        return option.asset_No.toLowerCase().indexOf(val.toLowerCase()) !== -1

      }))

    )

   }  

   filter2(val: string): Observable <any>{

    const formData = new FormData();
    formData.append('employee_Id', val);
    if (this.user_Id != 0||this.user_Id != null) {
      formData.append('user_Id', this.user_Id.toString());
    }
    formData.append('emp_Status', 'Active');

    return this._apiService.getEmployeesFiltered(formData)

    .pipe(

      map(response => response.filter((option: { employee_Id: string; }) => { 

        return option.employee_Id.toLowerCase().indexOf(val.toLowerCase()) !== -1

      }))

    )

   }  

   onSelFunc(option: any){
    if(option.id>0){
      this.asset_Book_Id=option.id;
    }
  }

  onSelFunc2(option: any){
    if(option.id>0){
      this.employee_Id=option.id;
      this.employee_Name=option.employee_Name;
      this.department_Id=option.department_Id;
      this.company_Id=option.company_Id;
    }
  }
gotoBack() {
    this.router.navigate(['/asset-allocation-vehicle']);
  }
  reset(): void {
    this.ngOnInit();
  }
}
