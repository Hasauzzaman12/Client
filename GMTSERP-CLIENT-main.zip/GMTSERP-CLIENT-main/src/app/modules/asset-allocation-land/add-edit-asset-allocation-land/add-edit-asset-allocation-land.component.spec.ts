import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditAssetAllocationLandComponent } from './add-edit-asset-allocation-land.component';

describe('AddEditAssetAllocationLandComponent', () => {
  let component: AddEditAssetAllocationLandComponent;
  let fixture: ComponentFixture<AddEditAssetAllocationLandComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddEditAssetAllocationLandComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddEditAssetAllocationLandComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
