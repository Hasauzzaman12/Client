import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetAllocationLandComponent } from './asset-allocation-land.component';

describe('AssetAllocationLandComponent', () => {
  let component: AssetAllocationLandComponent;
  let fixture: ComponentFixture<AssetAllocationLandComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AssetAllocationLandComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AssetAllocationLandComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
