import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditAssetAllocationComponent } from './add-edit-asset-allocation.component';

describe('AddEditAssetAllocationComponent', () => {
  let component: AddEditAssetAllocationComponent;
  let fixture: ComponentFixture<AddEditAssetAllocationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddEditAssetAllocationComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddEditAssetAllocationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
