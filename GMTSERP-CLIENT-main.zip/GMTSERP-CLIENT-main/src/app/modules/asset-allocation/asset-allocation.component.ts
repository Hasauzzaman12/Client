import { DatePipe } from '@angular/common';
import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';
import { SD } from 'src/environments/sd';
import { ShowAssetBookComponent } from '../asset-book/show-asset-book/show-asset-book.component';
import { ShowAssetEmployeeComponent } from '../asset-employee/show-asset-employee/show-asset-employee.component';

@Component({
  selector: 'app-asset-allocation',
  templateUrl: './asset-allocation.component.html',
  styleUrls: ['./asset-allocation.component.scss']
})
export class AssetAllocationComponent implements OnInit {

  asset_Owner_Id: number = SD.asset_Owner_Id_IT;
  asset_No: string = '';
  employee_Name: string = '';
  user_Id: number = this.authservice.getUserId;
  company_Id: number = 0;
  isFilterShow: boolean = false;

  from_Date : any=null;
  to_Date : any=null;

  companyList$!:Observable<any[]>;

  displayedColumns: string[] = ['allocation_Date','allocation_Type','asset_No','employee_Name','department_Name','company_Name','is_active','action'];
  dataSource!: MatTableDataSource<any>;

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';


  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(public _apiService: ApiServiceService,
    private authservice: AuthService,
    private _snackBar: MatSnackBar,
    public dialog: MatDialog,
    private datepipe: DatePipe,
    private router: Router) { }

  ngOnInit(): void {
    this.getAssetAllocationList();
    if(this.user_Id>0){
      this.companyList$ = this._apiService.getCompanyListByUser(this.user_Id);
    }else{
      this.companyList$ = this._apiService.getCompanyList();
    }
    
  }

  getAssetAllocationList() {
    const formData = new FormData();

    if (this.asset_Owner_Id != 0||this.asset_Owner_Id != null) {
      formData.append('asset_Owner_Id', this.asset_Owner_Id.toString());
    }
    if (this.asset_No != ''||this.asset_No != null) {
      formData.append('asset_No', this.asset_No);
    }
    if (this.employee_Name != ''||this.employee_Name != null) {
      formData.append('employee_Name', this.employee_Name);
    }
    if (this.user_Id != 0||this.user_Id != null) {
      formData.append('user_Id', this.user_Id.toString());
    }
    if (this.company_Id != 0||this.company_Id != null) {
      formData.append('company_Id', this.company_Id.toString());
    }

    if(this.from_Date != null && this.to_Date != null){
      formData.append('from_Date', this.from_Date);
      formData.append('to_Date', this.to_Date);
    }

    this._apiService.getAssetAllocationsFiltered(formData)
      .subscribe({
        next: (res) => {
          this.dataSource = new MatTableDataSource(res);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
        },
        error: (err) => {
          console.log("Error");
        }

      })
  }
  SearchSummary() {
    this.getAssetAllocationList();
  }
  reset() {

    this.asset_No='';
    this.employee_Name='';
    this.company_Id=0;
    this.from_Date=null;
    this.to_Date=null;

    this.getAssetAllocationList();
  }

  toggleFilter() {
    this.isFilterShow = !this.isFilterShow;
  }
  openForEdit(id: number) {

    this.router.navigate(['/asset-allocation/edit/' + id]);
  }
  gotoNew() {
    this.router.navigate(['/add-asset-allocation']);
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  deleteAssetAllocation(id: number) {

    if (confirm("Are you sure to delete?")) {
      this._apiService.deleteAssetAllocation(id)
        .subscribe({
          next: (res) => {
            this._snackBar.open("Asset Allocation Deleted Successfully", "Delete", {
              horizontalPosition: this.horizontalPosition,
              verticalPosition: this.verticalPosition,
              duration: 1000
            });
            this.getAssetAllocationList();
          },
          error: () => {
            this._snackBar.open("Delete Failed", "Failed");
          }
        })
    }



  }

  openAssetForView(id: number) {
    this.router.navigate([]).then((result) => {
      window.open('/#/asset-book/detail/' + id, '_blank');
    });
  }
  openAssetEmployeeForView(id: number) {
    this.router.navigate([]).then((result) => {
      window.open('/#/asset-employee/detail/' + id, '_blank');
    });
  }

}

