import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';
import { ShowAssetBookComponent } from '../asset-book/show-asset-book/show-asset-book.component';

@Component({
  selector: 'app-asset-maintenance-receive',
  templateUrl: './asset-maintenance-receive.component.html',
  styleUrls: ['./asset-maintenance-receive.component.scss']
})
export class AssetMaintenanceReceiveComponent implements OnInit {
  user_Id: number = this.authservice.getUserId;
  maintenance_No: string = '';
  supplier_Name: string = '';
  asset_No: string = '';
  status: string = 'Maintenance Receive';
  company_Id: number = 0;
  isFilterShow: boolean = false;

  from_Date : any=null;
  to_Date : any=null;

  companyList$!:Observable<any[]>;

  displayedColumns: string[] = ['maintenance_Date','maintenance_No','asset_No','supplier_Name','service_Amount','is_active','action'];
  dataSource!: MatTableDataSource<any>;

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';


  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(public _apiService: ApiServiceService,
    private authservice: AuthService,
    private _snackBar: MatSnackBar,
    public dialog: MatDialog,
    private router: Router) { }

  ngOnInit(): void {
    this.getAssetMaintenanceReceiveList();
    if(this.user_Id>0){
      this.companyList$ = this._apiService.getCompanyListByUser(this.user_Id);
    }else{
      this.companyList$ = this._apiService.getCompanyList();
    }
  }

  getAssetMaintenanceReceiveList() {
    const formData = new FormData();

    if (this.maintenance_No != ''||this.maintenance_No != null) {
      formData.append('maintenance_No', this.maintenance_No);
    }
    if (this.asset_No != ''||this.asset_No != null) {
      formData.append('asset_No', this.asset_No);
    }
    if (this.supplier_Name != ''||this.supplier_Name != null) {
      formData.append('supplier_Name', this.supplier_Name);
    }
    if (this.user_Id != 0||this.user_Id != null) {
      formData.append('user_Id', this.user_Id.toString());
    }
    if (this.status != ''||this.status != null) {
      formData.append('status', this.status);
    }
    if (this.company_Id != 0||this.company_Id != null) {
      formData.append('company_Id', this.company_Id.toString());
    }

    if(this.from_Date != null && this.to_Date != null){
      formData.append('from_Date', this.from_Date);
      formData.append('to_Date', this.to_Date);
    }

    this._apiService.getAssetMaintenancesFiltered(formData)
      .subscribe({
        next: (res) => {
          this.dataSource = new MatTableDataSource(res);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
        },
        error: (err) => {
          console.log("Error");
        }

      })
  }

  toggleFilter() {
    this.isFilterShow = !this.isFilterShow;
  }
  SearchSummary() {
    this.getAssetMaintenanceReceiveList();
  }
  reset() {
    this.company_Id=0;
    this.maintenance_No='';
    this.supplier_Name='';
    this.from_Date=null;
    this.to_Date=null;

    this.getAssetMaintenanceReceiveList();
  }
  openForEdit(id: number) {

    this.router.navigate(['/asset-maintenance-receive/edit/' + id]);
  }
  gotoNew() {
    this.router.navigate(['/add-asset-maintenance-receive']);
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  deleteAssetMaintenanceReceive(id: number) {

    if (confirm("Are you sure to delete?")) {
      this._apiService.deleteAssetMaintenance(id)
        .subscribe({
          next: (res) => {
            this._snackBar.open("Asset Maintenance Receive Deleted Successfully", "Delete", {
              horizontalPosition: this.horizontalPosition,
              verticalPosition: this.verticalPosition,
              duration: 1000
            });
            this.getAssetMaintenanceReceiveList();
          },
          error: () => {
            this._snackBar.open("Delete Failed", "Failed");
          }
        })
    }



  }
  openAssetForView(id: number) {
    this.router.navigate([]).then((result) => {
      window.open('/#/asset-book/detail/' + id, '_blank');
    });
  }

}

