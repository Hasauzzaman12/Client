import { HttpClient, HttpEventType, HttpRequest } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable, of,startWith, debounceTime, distinctUntilChanged, switchMap, map } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-add-edit-asset-maintenance-receive',
  templateUrl: './add-edit-asset-maintenance-receive.component.html',
  styleUrls: ['./add-edit-asset-maintenance-receive.component.scss']
})
export class AddEditAssetMaintenanceReceiveComponent implements OnInit {

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';

  myControl = new FormControl();
  options = [];
  filteredOptions: Observable<any>;

  constructor(public _apiService: ApiServiceService,
    private _snackBar: MatSnackBar,
    public router: Router,
    private authservice: AuthService,
    private currentRoute: ActivatedRoute,
    private datepipe: DatePipe) { 
      this.filteredOptions = this.myControl.valueChanges.pipe(

        startWith(''),
  
        debounceTime(400),
  
        distinctUntilChanged(),
  
        switchMap(val => {
  
              return this.filter(val || '')
  
         }) 
  
      )
    }

    newBlogForm!: FormGroup;
    id: number = 0;
    maintenance_Date : any;
    maintenance_No= '';
    asset_Book_Id: number = 0;
    asset_No= '';
    supplier_Id: number = 0;
    service_Amount: number = 0;
    reason_Of_Maintenance= '';
    aprrox_Return_Date : any;
    remarks= '';
    is_active: boolean = true;
    attachment_Id: number = 0;
    attachment_File_Name= '';

    selectedFile!: File;

    supplierList$!: Observable<any[]>;
    user_Id: number = this.authservice.getUserId;

  ngOnInit(): void {

    let currentDateTime =this.datepipe.transform((new Date), 'MM/dd/yyyy h:mm:ss');
    this.newBlogForm = new FormGroup({
      id: new FormControl(0),
      maintenance_No: new FormControl(''),
      maintenance_Date: new FormControl(null),
      asset_Book_Id: new FormControl(0),
      supplier_Id: new FormControl(0),
      service_Amount: new FormControl(0),
      reason_Of_Maintenance: new FormControl(''),
      aprrox_Return_Date: new FormControl(null),
      is_active: new FormControl(true),
      attachment_Id: new FormControl(0),
    });

    this.supplierList$=this._apiService.getSuulierList();

    let id = this.currentRoute.snapshot.paramMap.get('id');
    if (id != null) {
      this.getAssetMaintenanceReturnById(id);
     
    }else{
      this.maintenance_Date=currentDateTime;
      this.getAMNO();
    }
  }

  getAssetMaintenanceReturnById(id: number | string) {
    this._apiService.getAssetMaintenanceById(id).subscribe((data: any) => {
      this.id=data.id;
      this.maintenance_Date=data.maintenance_Date;
      this.maintenance_No=data.maintenance_No;
      this.asset_Book_Id=data.asset_Book_Id;
      this.asset_No=data.asset_No;
      this.supplier_Id=data.supplier_Id;
      this.service_Amount=data.service_Amount;
      this.reason_Of_Maintenance=data.reason_Of_Maintenance;
      this.aprrox_Return_Date=data.aprrox_Return_Date;
      this.is_active=data.is_active;
      this.attachment_Id=data.attachment_Id;
      this.attachment_File_Name=data.attachment_File_Name;

    });
  }
  onSelectFile(fileInput: any) {
    this.selectedFile = <File>fileInput.target.files[0];
    this.attachment_Id = 0;
  }
  filter(val: string): Observable <any>{

    const formData = new FormData();
    if (this.user_Id != 0||this.user_Id != null) {
      formData.append('user_Id', this.user_Id.toString());
    }
    formData.append('status', 'Maintenance STOCKED');

    return this._apiService.getAssetForDdlFiltered(formData)

      .pipe(
 
        map(response => response.filter((option: { asset_No: string; }) => { 
 
          return option.asset_No.toLowerCase().indexOf(val.toLowerCase()) !== -1
 
        }))
 
      )
    
   }  
   onSubmit(data: any){
    data.id=this.id;
    
    if(data.maintenance_Date == ''||data.maintenance_Date == null) {
      alert("Maintenance Date is Required")
      return;
    }

    if (data.asset_Book_Id == 0||data.asset_Book_Id == null) {
      alert("Asset Book is Required")
      return;
    }
    if (data.supplier_Id == 0||data.supplier_Id == null) {
      alert("Supplier is Required")
      return;
    }


    const formData = new FormData();

    formData.append('id', data.id);
    formData.append('maintenance_Date', data.maintenance_Date);
    formData.append('maintenance_No', data.maintenance_No);
    formData.append('asset_Book_Id', data.asset_Book_Id);
    formData.append('supplier_Id', data.supplier_Id);
    formData.append('reason_Of_Maintenance', data.reason_Of_Maintenance == null ? '' : data.reason_Of_Maintenance);

    if(data.aprrox_Return_Date != null){
      formData.append('aprrox_Return_Date', data.aprrox_Return_Date);
    }
   
    formData.append('service_Amount', data.service_Amount);
    formData.append('employee_Id', data.employee_Id);
    formData.append('is_active', data.is_active);
    formData.append('attachment_Id', data.attachment_Id);
    formData.append('attachmentFile', this.selectedFile);

    if (this.newBlogForm.valid) {
      if (data.id != 0) {
  
        this._apiService.updateAssetMaintenance(formData).subscribe(res => {
  
          this._snackBar.open("Asset Maintenance Updated Successfully", "Update", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });
  
          this.router.navigate(['/asset-maintenance-receive']);
  
  
        })
      }
      else {
        this._apiService.addAssetMaintenance(formData).subscribe(res => {
  
          this._snackBar.open("Asset Maintenance Saved Successfully", "Success", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });
  
          this.router.navigate(['/asset-maintenance-receive']);
  
  
        })
      }
    }
   }
   onSelFunc(option: any){
    if(option.id>0){
      this.asset_Book_Id=option.id;
        // this.getAssetAllocationByAssetId(this.asset_Book_Id);
    }
  }
  gotoBack() {
    this.router.navigate(['/asset-maintenance-receive']);
  }
  reset(): void {
    this.ngOnInit();
  }

  getAMNO() {
    this._apiService.getAMNO()
    .subscribe((data: any) => {
      console.log(data);
      this.maintenance_No = data;
    })}
}
