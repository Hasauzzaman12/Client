import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditAssetMaintenanceReceiveComponent } from './add-edit-asset-maintenance-receive.component';

describe('AddEditAssetMaintenanceReceiveComponent', () => {
  let component: AddEditAssetMaintenanceReceiveComponent;
  let fixture: ComponentFixture<AddEditAssetMaintenanceReceiveComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddEditAssetMaintenanceReceiveComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddEditAssetMaintenanceReceiveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
