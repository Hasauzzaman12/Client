import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetMaintenanceReceiveComponent } from './asset-maintenance-receive.component';

describe('AssetMaintenanceReceiveComponent', () => {
  let component: AssetMaintenanceReceiveComponent;
  let fixture: ComponentFixture<AssetMaintenanceReceiveComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AssetMaintenanceReceiveComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AssetMaintenanceReceiveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
