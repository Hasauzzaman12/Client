import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';

@Component({
  selector: 'app-add-edit-admin-company',
  templateUrl: './add-edit-admin-company.component.html',
  styleUrls: ['./add-edit-admin-company.component.scss']
})
export class AddEditAdminCompanyComponent implements OnInit {

  companyForm!:FormGroup;
  actionBtn: string="Save";
  submitted = false;
  newBlogForm!:FormGroup;

  imagePreviewSrc: string | ArrayBuffer | null | undefined = '';
  isImageSelected: boolean = false;
  selectedFile!: File;

  
  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';

  onSelectFile(fileInput: any) {
    this.selectedFile = <File>fileInput.target.files[0];
  }
  constructor(public _apiService:ApiServiceService,
     private _snackBar: MatSnackBar,
     public router:Router, 
     private authservice:AuthService,
     private currentRoute: ActivatedRoute) {


     }

  
  @Input() company:any;
  id: number = 0;
  companyName: string = "";
  shortcutName: string = "";
  addressLine1: string = "";
  addressLine2: string = "";
  websiteUrl: string = "";
  display_Order: number = 0;
  isActive: boolean=true;

  ngOnInit(): void {
    
    this.newBlogForm = new FormGroup({
      id:new FormControl(0),
      companyName: new FormControl(null),
      shortcutName: new FormControl(null),
      addressLine1: new FormControl(null),
      addressLine2: new FormControl(null),
      websiteUrl: new FormControl(null),
      LogoImage: new FormControl(null),
      display_Order:new FormControl(0),
      isActive: new FormControl(null),    

      userid: new FormControl(this.authservice.getUserId),
      companyid: new FormControl(this.authservice.getCompanyId),

    });

    let id = this.currentRoute.snapshot.paramMap.get('id');
    if (id != null){
      this.getAdminCompanyById(id);

    }

  }

  addCompany() {

    var company = {
      companyName:this.companyName,
      shortcutName:this.shortcutName,
      addressLine1:this.addressLine1,
      addressLine2:this.addressLine2,
      websiteUrl:this.websiteUrl,
      display_Order:this.display_Order,
      isActive:this.isActive,
     
    }
    this._apiService.addCompany(company).subscribe(res => {
      var closeModalBtn = document.getElementById('add-edit-modal-close');
      if(closeModalBtn) {
        closeModalBtn.click();
      }

      var showAddSuccess = document.getElementById('add-success-alert');
      if(showAddSuccess) {
        showAddSuccess.style.display = "block";
      }
      setTimeout(function() {
        if(showAddSuccess) {
          showAddSuccess.style.display = "none"
        }
      }, 4000);
    })
  }

  onSubmit(data: any) {

    if(data.id!=0){

    const formData = new FormData();
    console.log(data.id);

    formData.append('id', data.id);
    formData.append('companyName', data.companyName == null ? '' : data.companyName);
    formData.append('company_Name', data.companyName == null ? '' : data.companyName);
    formData.append('shortcutName', data.shortcutName == null ? '' : data.shortcutName);
    formData.append('addressLine1', data.addressLine1 == null ? '' : data.addressLine1);
    formData.append('addressLine2', data.addressLine2 == null ? '' : data.addressLine2);
    formData.append('websiteUrl', data.websiteUrl == null ? '' : data.websiteUrl);
    formData.append('display_Order', data.display_Order);
    formData.append('isActive', data.isActive);
    formData.append('LogoImage', this.selectedFile);

    formData.append('userid',this.authservice.getUserId);

    // formData.append('userid', data.userid);
    // formData.append('companyid', data.companyid);


      this._apiService.updateCompany(formData).subscribe(res => {

        this._snackBar.open("Company Updated Successfully", "Update", {
          horizontalPosition: this.horizontalPosition,
          verticalPosition: this.verticalPosition,
          duration: 2000
        });
  
        this.router.navigate(['/admin-company']);      
      })
    }
    else
    {

    const formData = new FormData();

    formData.append('id', data.id);
    formData.append('companyName', data.companyName == null ? '' : data.companyName);
    formData.append('company_Name', data.companyName == null ? '' : data.companyName);
    formData.append('shortcutName', data.shortcutName == null ? '' : data.shortcutName);
    formData.append('addressLine1', data.addressLine1 == null ? '' : data.addressLine1);
    formData.append('addressLine2', data.addressLine2 == null ? '' : data.addressLine2);
    formData.append('websiteUrl', data.websiteUrl == null ? '' : data.websiteUrl);
    formData.append('display_Order', data.display_Order);
    formData.append('isActive', data.isActive);
    formData.append('LogoImage', this.selectedFile);

    formData.append('userid', data.userid);
    formData.append('companyid', data.companyid);

    formData.append('userid',this.authservice.getUserId);


      this._apiService.addCompany(formData).subscribe(res => {

        this._snackBar.open("Company Saved Successfully", "Success", {
          horizontalPosition: this.horizontalPosition,
          verticalPosition: this.verticalPosition,
          duration: 2000
        });  
        this.router.navigate(['/admin-company']);      
      })
    }



  }
  


showPreview(event: Event) {
  let selectedFile = (event.target as HTMLInputElement).files?.item(0)

  if (selectedFile) {
    if (["image/jpeg", "image/png", "image/svg+xml"].includes(selectedFile.type)) {
      let fileReader = new FileReader();
      fileReader.readAsDataURL(selectedFile);

      fileReader.addEventListener('load', (event) => {
        this.imagePreviewSrc = event.target?.result;
        this.isImageSelected = true
      })
    }
  } else {
    this.isImageSelected = false
  }
}

  gotoBack() {
    this.router.navigate(['/admin-company']);
  }

  onReset(): void {
    this.submitted = false;
    this.newBlogForm.reset();
  }

  getAdminCompanyById(id:number|string){
    this._apiService.getAdminCompanyById(id)
    .subscribe((data: any) => {
    
      this.newBlogForm = new FormGroup({

        id:new FormControl(data.id),
        companyName: new FormControl(data.companyName),
        shortcutName: new FormControl(data.shortcutName),
        addressLine1: new FormControl(data.addressLine1),
        addressLine2: new FormControl(data.addressLine2),
        websiteUrl: new FormControl(data.websiteUrl),
        isActive: new FormControl(data.isActive),
        display_Order:new FormControl(data.display_Order),
        
        userid: new FormControl(data.userid),
        companyid: new FormControl(data.companyid),
  
      });
  


    });
  
  }


}
