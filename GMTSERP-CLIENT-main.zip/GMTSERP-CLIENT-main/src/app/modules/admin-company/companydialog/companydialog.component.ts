import { ApiServiceService } from './../../../api-service.service';
import { Component, Inject, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';

@Component({
  selector: 'app-companydialog',
  templateUrl: './companydialog.component.html',
  styleUrls: ['./companydialog.component.scss']
})
export class CompanydialogComponent implements OnInit {
  companyForm!:FormGroup;
  actionBtn: string="Save";
  submitted = false;
  newBlogForm!:FormGroup;

  imagePreviewSrc: string | ArrayBuffer | null | undefined = '';
  isImageSelected: boolean = false;
  selectedFile!: File;

  onSelectFile(fileInput: any) {
    this.selectedFile = <File>fileInput.target.files[0];
  }
  constructor(public _apiService:ApiServiceService, private _snackBar: MatSnackBar,public router:Router) {}



  @Input() company:any;
  id: number = 0;
  companyName: string = "";
  shortcutName: string = "";
  addressLine1: string = "";
  addressLine2: string = "";
  websiteUrl: string = "";
  isActive: boolean=true;



  ngOnInit(): void {
    this.id = this.company.id;
    this.companyName = this.company.companyName;
    this.shortcutName = this.company.shortcutName;
    this.addressLine1 = this.company.addressLine1;
    this.addressLine2 = this.company.addressLine2;
    this.websiteUrl = this.company.websiteUrl;
    this.isActive = this.company.isActive;
  }


  addCompany() {

    var company = {
      companyName:this.companyName,
      shortcutName:this.shortcutName,
      addressLine1:this.addressLine1,
      addressLine2:this.addressLine2,
      websiteUrl:this.websiteUrl,
      isActive:this.isActive,
     
    }
    this._apiService.addCompany(company).subscribe(res => {
      var closeModalBtn = document.getElementById('add-edit-modal-close');
      if(closeModalBtn) {
        closeModalBtn.click();
      }

      var showAddSuccess = document.getElementById('add-success-alert');
      if(showAddSuccess) {
        showAddSuccess.style.display = "block";
      }
      setTimeout(function() {
        if(showAddSuccess) {
          showAddSuccess.style.display = "none"
        }
      }, 4000);
    })
  }




// Show Image in Display

showPreview(event: Event) {
  let selectedFile = (event.target as HTMLInputElement).files?.item(0)

  if (selectedFile) {
    if (["image/jpeg", "image/png", "image/svg+xml"].includes(selectedFile.type)) {
      let fileReader = new FileReader();
      fileReader.readAsDataURL(selectedFile);

      fileReader.addEventListener('load', (event) => {
        this.imagePreviewSrc = event.target?.result;
        this.isImageSelected = true
      })
    }
  } else {
    this.isImageSelected = false
  }
}

  gotoBack() {
    this.router.navigate(['/admin-company']);
  }

  onReset(): void {
    this.submitted = false;
    this.newBlogForm.reset();
  }

  

  // addCompany(){
  //   if(!this.editData){
  //     if(this.companyForm.valid){
  //       console.log(this.companyForm.value);
  //       this.service.addCompany(this.companyForm.value)
  //       .subscribe({
  //         next:(res)=>{
  //           this._snackBar.open("User Save Successfully", "Success", {
  //             duration: 1000
  //           });
  //           this.companyForm.reset();
  //           this.dialogRef.close('save');
  //         },
  //         error:()=>{
  //           this._snackBar.open("Save Failed", "Failed");
  //         }
  //       })
  //     }
  //   }
  //   else{
  //     this.updateUser()
  //   }
  //  }
   
  
  //  updateUser(){
  //   this.service.updateCompany(this.companyForm.value)
  //   .subscribe({
  //     next:(res)=>{
  //       this._snackBar.open("Company Update Successfully", "Update", {
  //         duration: 1000
  //       });
  //       this.companyForm.reset();
  //       this.dialogRef.close('update');
  //     },
  //     error:()=>{
  //       this._snackBar.open("Update Failed", "Failed");
  //     }
  //   })
  // }




  onFileChanged() {
    
  }

}
