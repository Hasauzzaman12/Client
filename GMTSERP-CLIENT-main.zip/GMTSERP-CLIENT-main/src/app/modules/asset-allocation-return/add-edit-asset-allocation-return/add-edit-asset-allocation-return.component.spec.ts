import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditAssetAllocationReturnComponent } from './add-edit-asset-allocation-return.component';

describe('AddEditAssetAllocationReturnComponent', () => {
  let component: AddEditAssetAllocationReturnComponent;
  let fixture: ComponentFixture<AddEditAssetAllocationReturnComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddEditAssetAllocationReturnComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddEditAssetAllocationReturnComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
