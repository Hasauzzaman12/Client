import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetAllocationReturnComponent } from './asset-allocation-return.component';

describe('AssetAllocationReturnComponent', () => {
  let component: AssetAllocationReturnComponent;
  let fixture: ComponentFixture<AssetAllocationReturnComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AssetAllocationReturnComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AssetAllocationReturnComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
