import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditAssetBookPlantComponent } from './add-edit-asset-book-plant.component';

describe('AddEditAssetBookPlantComponent', () => {
  let component: AddEditAssetBookPlantComponent;
  let fixture: ComponentFixture<AddEditAssetBookPlantComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddEditAssetBookPlantComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddEditAssetBookPlantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
