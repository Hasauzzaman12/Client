import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetBookPlantComponent } from './asset-book-plant.component';

describe('AssetBookPlantComponent', () => {
  let component: AssetBookPlantComponent;
  let fixture: ComponentFixture<AssetBookPlantComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AssetBookPlantComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AssetBookPlantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
