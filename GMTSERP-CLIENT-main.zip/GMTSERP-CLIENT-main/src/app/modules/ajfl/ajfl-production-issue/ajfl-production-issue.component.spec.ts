import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AjflProductionIssueComponent } from './ajfl-production-issue.component';

describe('AjflProductionIssueComponent', () => {
  let component: AjflProductionIssueComponent;
  let fixture: ComponentFixture<AjflProductionIssueComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AjflProductionIssueComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AjflProductionIssueComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
