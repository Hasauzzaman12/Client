import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditProductionIssueComponent } from './add-edit-production-issue.component';

describe('AddEditProductionIssueComponent', () => {
  let component: AddEditProductionIssueComponent;
  let fixture: ComponentFixture<AddEditProductionIssueComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddEditProductionIssueComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddEditProductionIssueComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
