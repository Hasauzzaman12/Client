import { HttpClient, HttpEventType, HttpRequest } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable, of, startWith, debounceTime, distinctUntilChanged, switchMap, map } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-add-edit-production-issue',
  templateUrl: './add-edit-production-issue.component.html',
  styleUrls: ['./add-edit-production-issue.component.scss']
})
export class AddEditProductionIssueComponent implements OnInit {

  myControl = new FormControl();
  myControl2 = new FormControl();
  options = [];
  filteredOptionsEmp: Observable<any>;
  filteredOptionsPr: Observable<any>;

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';
  constructor( public _apiService: ApiServiceService,
    private _snackBar: MatSnackBar,
    public router: Router,
    private authservice: AuthService,
    private currentRoute: ActivatedRoute,
    private datepipe: DatePipe) { 
      this.filteredOptionsEmp = this.myControl2.valueChanges.pipe(

        startWith(''),
  
        debounceTime(400),
  
        distinctUntilChanged(),
  
        switchMap(val => {
  
          if(val!=''){
            return this.filter2(val || '')
          }else{
            return '';
          }
  
         }) 
  
      )
      this.filteredOptionsPr = this.myControl.valueChanges.pipe(

        startWith(''),
  
        debounceTime(400),
  
        distinctUntilChanged(),
  
        switchMap(val => {
  
          if(val!=''){
            return this.filter1(val || '')
          }else{
            return '';
          }
  
         }) 
  
      )
    }

    newBlogForm!: FormGroup;

    @Input() ajflpi: any;
    id: number = 0;
    code: string = '';
    issue_Date: any;
    production_Requisition_Id: number = 0;
    production_Requisition_Code: string = '';
    total_Weight: number = 0;
    total_Weight_Mond: number = 0;
    issue_By_Id: number = 0;
    issue_By: string = '';
    employee_Code= '';
    employee_Name= '';
    remarks: string = '';
    is_active: boolean = true;
    user_Id: number = this.authservice.getUserId;

    pi_detail_list: any[] = [];

    areaList$!: Observable<any[]>;
    itemGradeList$!: Observable<any[]>;

  ngOnInit(): void {
    let currentDateTime = this.datepipe.transform((new Date), 'MM/dd/yyyy h:mm:ss');
    this.newBlogForm = new FormGroup({
      id: new FormControl(0),
      code: new FormControl(''),
      issue_Date: new FormControl(null),
      total_Weight: new FormControl(0),
      total_Weight_Mond: new FormControl(0),

      remarks: new FormControl(''),
      is_active: new FormControl(''),


    });

    this.areaList$=this._apiService.getAJflAreaList();
    this.itemGradeList$=this._apiService.getAjflItemGradeList();

    let id = this.currentRoute.snapshot.paramMap.get('id');
    if (id != null) {
      this.getAjflProductionIssueById(id);

    } else { 
      this.issue_Date = currentDateTime;
      this.getProductionIssueCode();
    }
  }
  getAjflProductionIssueById(id: number | string) {
    this._apiService.getAjflProductionIssueById(id).subscribe((data: any) => {

      this.id= data.id;
      this.code = data.code;
      this.issue_Date = data.issue_Date;
      this.production_Requisition_Id = data.production_Requisition_Id;
      this.production_Requisition_Code = data.production_Requisition;
      this.total_Weight = data.total_Weight;
      this.total_Weight_Mond = data.total_Weight_Mond;
      this.issue_By_Id = data.issue_By_Id;
      this.issue_By = data.issue_By;
      this.employee_Code=data.employee_Code;
      this.employee_Name=data.employee_Name;

      this.remarks =  data.remarks;
      this.is_active=data.is_active;

      this.pi_detail_list = data.productionIssueDetailList;

    });
    
  }
  onSubmit(data: any) {

    const formData = new FormData();
    if (data.code == '') {
      alert("Code No is Required")
      return;
    }
    if (data.issue_Date == '' || data.issue_Date == null) {
      alert("Issue Date is Required")
      return;
    }
    if (this.production_Requisition_Id== null || this.production_Requisition_Id == 0) {
      alert("PR is Required")
      return;
    }

    if (this.pi_detail_list.length==0) {
      alert("Enter PI Deatils")
      return;
    }
    // if (this.total_Per!=100) {
    //   alert("Wrong Total Percent Value !!!. Percent Value must be 100 in total !")
    //   return;
    // }

    data.id = this.id;

    formData.append('id', this.id.toString());
    formData.append('code', data.code == null ? '' : data.code);
    if (data.issue_Date != null) {
      formData.append('issue_Date', data.issue_Date);
    }
    formData.append('production_Requisition_Id', this.production_Requisition_Id.toString());
    formData.append('total_Weight', data.total_Weight);
    formData.append('total_Weight_Mond', data.total_Weight_Mond);
    formData.append('issue_By_Id', this.issue_By_Id.toString());
    formData.append('remarks', data.remarks == null ? '' : data.remarks);
    formData.append('is_active', data.is_active);
    formData.append('user_Id', this.user_Id.toString());

    for (let i = 0; i < this.pi_detail_list.length; i++) {

      if ((this.pi_detail_list[i].qty == 0 || this.pi_detail_list[i].qty == "" || this.pi_detail_list[i].qty == null)) {
        alert("Qty is Required is PR Detail!!");
        return;
      }
      const keyPrefix = "productionIssueDetailList[" + i.toString() + "].";
      formData.append(keyPrefix + "id", this.pi_detail_list[i].id);
      formData.append(keyPrefix + "item_Grade_Id", this.pi_detail_list[i].item_Grade_Id);
      formData.append(keyPrefix + "area_Id", this.pi_detail_list[i].area_Id);
      formData.append(keyPrefix + "qty", this.pi_detail_list[i].qty);
      formData.append(keyPrefix + "remarks", this.pi_detail_list[i].remarks == null ? '' : this.pi_detail_list[i].remarks);
    }

    if (this.newBlogForm.valid) {
      if (data.id != 0) {

        this._apiService.updateAjflProductionIssue(formData).subscribe(res => {

          this._snackBar.open("PI Updated Successfully", "Update", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });

          this.router.navigate(['/ajfl-production-issue']);


        })
      }
      else {
        this._apiService.addAjflProductionIssue(formData).subscribe(res => {

          this._snackBar.open("PI Saved Successfully", "Success", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });

          this.router.navigate(['/ajfl-production-issue']);


        })
      }
    }
  }
  getProductionIssueCode() {
    this._apiService.getProductionIssueCode()
      .subscribe((data: any) => {
        this.code = data;
      })
  }


  filter2(val: string): Observable <any>{

    const formData = new FormData();
    formData.append('employee_Id', val);
    if (this.user_Id != 0||this.user_Id != null) {
      formData.append('user_Id', this.user_Id.toString());
    }
    formData.append('emp_Status', 'Active');

    return this._apiService.getEmployeesFiltered(formData)

    .pipe(

      map(response => response.filter((option: { employee_Id: string; }) => { 

        return option.employee_Id.toLowerCase().indexOf(val.toLowerCase()) !== -1

      }))

    )

   } 

   filter1(val: string): Observable <any>{

    const formData = new FormData();
    // if (this.production_Requisition_Code != ''||this.production_Requisition_Code != null) {
    //   formData.append('code', this.production_Requisition_Code);
    // }
    formData.append('status', 'Open');

    return this._apiService.getProductionRequisitionListFiltered(formData)

    .pipe(

      map(response => response.filter((option: { code: string; }) => { 

        return option.code.toLowerCase().indexOf(val.toLowerCase()) !== -1

      }))

    )

   } 

   onSelFunc1(option: any){
    this.production_Requisition_Id=option.id;
    this.production_Requisition_Code=option.code;
    this._apiService.getPrDetailForIssue(this.production_Requisition_Id)
    .subscribe((data: any) => {
      this.pi_detail_list  = data;
    })
  }
   onSelFunc2(option: any){
    this.issue_By_Id=option.id;
    this.employee_Name=option.employee_Name;
  }
  gotoBack() {
    this.router.navigate(['/ajfl-production-issue']);
  }
  reset(): void {
    this.ngOnInit();
  }

  updateCalculation(data: any) {

    if(data!=null){
      if(this.id>0){
        data.open_Qty=data.actual_Open_Qty+data.old_Qty;
        if(data.qty<=data.open_Qty){
          data.open_Qty=data.open_Qty-data.qty;
        }else{
          data.qty=0;
          data.open_Qty=data.actual_Open_Qty;
          alert('Quantity Cannot be Greater than SR Balance Qty !');
         
        }
      }else{
        data.open_Qty=data.actual_Open_Qty;
        if(data.qty<=data.open_Qty){
          data.open_Qty=data.open_Qty-data.qty;
        }else{
          data.qty=0;
          data.open_Qty=data.actual_Open_Qty;
          alert('Quantity Cannot be Greater than SR Balance Qty !');
         
        }
      }
     
      this.updateTotal();
    } 
    
  }
  deletePrDetailRow(Index: any) {
    if (confirm('Are you sure want to delete?')) {
      this.pi_detail_list.splice(Index, 1);
     
      this.updateTotal();
    }
  }
  updateTotal(){
    this.total_Weight=0;
    this.total_Weight_Mond=0;

    for (let i = 0; i < this.pi_detail_list.length; i++) {
      this.total_Weight+=this.pi_detail_list[i].qty;
    }

    this.total_Weight_Mond=this.total_Weight/40;
  }
}
