import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';

@Component({
  selector: 'app-ajfl-production-issue',
  templateUrl: './ajfl-production-issue.component.html',
  styleUrls: ['./ajfl-production-issue.component.scss']
})
export class AjflProductionIssueComponent implements OnInit {

  code: string = '';
  pr_No: string = '';
  from_Date : any=null;
  to_Date : any=null;

  user_Id: number = this.authservice.getUserId;
  isFilterShow: boolean = false;

  displayedColumns: string[] = ['code','issue_Date','production_Requisition','total_Weight','action'];
  dataSource!: MatTableDataSource<any>;

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';


  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;


  constructor(public _apiService: ApiServiceService,
    private authservice: AuthService,
    private _snackBar: MatSnackBar,
    public dialog: MatDialog,
    private router: Router) { }

  ngOnInit(): void {
    this.getProductionIssueList();
  }
  getProductionIssueList() {
    const formData = new FormData();
    if (this.code != ''||this.code != null) {
      formData.append('code', this.code);
    }

    if (this.pr_No != ''||this.pr_No != null) {
      formData.append('pr_No', this.pr_No);
    }
    if(this.from_Date != null && this.to_Date != null){
      formData.append('from_Date', this.from_Date);
      formData.append('to_Date', this.to_Date);
    }


    this._apiService.getProductionIssueListFiltered(formData)
      .subscribe({
        next: (res) => {
          this.dataSource = new MatTableDataSource(res);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
        },
        error: (err) => {
          console.log("Error");
        }

      })
  }

  openForEdit(id: number) {

    this.router.navigate(['/ajfl-production-issue/edit/' + id]);
  }
  gotoNew() {
    this.router.navigate(['/add-ajfl-production-issue']);
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  SearchSummary() {
    this.getProductionIssueList();
  }
  reset() {

    this.code='';
    this.pr_No='';
    this.from_Date=null;
    this.to_Date=null;

    this.getProductionIssueList();
  }
  toggleFilter() {
    this.isFilterShow = !this.isFilterShow;
  }
}
