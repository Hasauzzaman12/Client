import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AjflReportComponent } from './ajfl-report.component';

describe('AjflReportComponent', () => {
  let component: AjflReportComponent;
  let fixture: ComponentFixture<AjflReportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AjflReportComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AjflReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
