import { DatePipe } from '@angular/common';
import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, NgForm, Validators } from '@angular/forms';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { debounceTime, distinctUntilChanged, map, Observable, of, ReplaySubject, startWith, switchMap } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-ajfl-report',
  templateUrl: './ajfl-report.component.html',
  styleUrls: ['./ajfl-report.component.scss']
})
export class AjflReportComponent implements OnInit {

  farmerList$!: Observable<any[]>;
  flockList$!: Observable<any[]>;  
  reortTypeList$!: Observable<any[]>;

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';


  showDiv_FromDate: boolean = false;
  showDiv_ToDate: boolean = false;
  showDiv_Date: boolean = false;
  showDiv_Status: boolean = false;


  current_Yr = new Date().getFullYear();
  current_mon = new Date().getMonth();

  myControl = new FormControl();
  options = [];
  filteredOptionsEmp: Observable<any>;

  reportName: any;
  fileType: any;
  endpoint: string = `${environment.reportServerUrl}`;
  isSubmitted = false;
  form!: FormGroup;


  public websiteCtrl: FormControl = new FormControl();
  public websiteFilterCtrl: FormControl = new FormControl();




  constructor(
    public _apiService: ApiServiceService, public fb: FormBuilder,
    private _snackBar: MatSnackBar,
    public router: Router,
    private authservice: AuthService,
    private currentRoute: ActivatedRoute,
    private datepipe: DatePipe
  ) {
    
    this.filteredOptionsEmp = this.myControl.valueChanges.pipe(
      startWith(''),
      debounceTime(400),
      distinctUntilChanged(),
      switchMap(val => {
        if(val!=''){
          return this.filter(val || '')
        }else{
          // this.farmerId = 0;
          // this.flock_Id = "0";
          return '';
        }
       }) 
    )

    this.form = this.fb.group({
      from_Date: '',
      to_Date: '',      
      reporttype_Id: 0,
      date:''
      
    });
  }


  newBlogForm!: FormGroup;
  @Input() adminUnit: any;  
  
  assetReportRadio: string = "";  
 
  reporttype_Id: number = 0;
  from_Date: any;
  date: any;
  to_Date: any;
  ngOnInit(): void {
    let currentDateTime = this.datepipe.transform((new Date), 'yyyy-MM-dd');
    let currentDateTime2 = this.datepipe.transform((new Date), 'yyyy-MM-dd');

    this.from_Date=currentDateTime;
    this.to_Date=currentDateTime2;
    //this.farmerList$ = this._apiService.getCfFarmerList();  
    this.showDiv_Date = false;
    const reportType = [
      { id: '1', name: 'Jute Purchase Statement' },
      //{ id: '2', name: 'CF Daily Flock Activity Report' },     
    ];
    this.reortTypeList$ = of(reportType);
  }
  changeReportType(event: any) {

    if (event.target.value == '1') {
      // this.showDiv_Date = false;
      this.showDiv_FromDate = false;
      this.showDiv_ToDate = false;
      // this.showDiv_Status = true;
      this.assetReportRadio = "AJFL/GetAJFLPurchaseStatementExport";
    }     
  }

  filter(val: string): Observable <any>{
    const formData = new FormData();
    formData.append('code', val);
    return this._apiService.getCfFarmersFiltered(formData)
    .pipe(
      map(response => response.filter((option: { code: string; }) => { 
        return option.code.toLowerCase().indexOf(val.toLowerCase()) !== -1
      }))
    )
   }  


  btnPdf() {    
    if (this.reporttype_Id == 0) {
      this._snackBar.open("Please select any report option !", "Notice", {
        horizontalPosition: this.horizontalPosition,
        verticalPosition: this.verticalPosition,
        duration: 2000,
        panelClass: ['mat-toolbar', 'mat-warn']
      });
      return;
    }

    // if (this.farmerId == 0 && this.reporttype_Id != 1) {
    //   this._snackBar.open("Please select farmer !", "Notice", {
    //     horizontalPosition: this.horizontalPosition,
    //     verticalPosition: this.verticalPosition,
    //     duration: 2000,
    //     panelClass: ['mat-toolbar', 'mat-warn']
    //   });
    //   return;
    // }
    //http://localhost:56281/ContractFarm/GetCFBillOfFlockSummaryExport?FileType=pdf&ContentType=application/pdf&Flock_Id=0&Farmer_Id=0&Status=Close

    this.reportName = this.endpoint + this.assetReportRadio + "?FileType=pdf&ContentType=application/pdf&From_Date="
      + this.from_Date + "&To_Date=" + this.to_Date;
    return window.open(this.reportName, "_blank");

  }
  // onSelFunc(option: any) {    
  //   if (option.id > 0) {      
  //     this.farmerId = option.id; 
  //     this.flock_Id = "0";         
  //     this.flockList$ = this._apiService.getFlockByFarmer(this.farmerId);    
  //   }
  // }
  btnExcel() {
    if (this.reporttype_Id == 0) {
      this._snackBar.open("Please select any report option !", "Notice", {
        horizontalPosition: this.horizontalPosition,
        verticalPosition: this.verticalPosition,
        duration: 2000,
        panelClass: ['mat-toolbar', 'mat-warn']
      });
      return;
    } 
    this.reportName = this.endpoint + this.assetReportRadio + "?FileType=Excel&ContentType=application/vnd.ms-excel&From_Date="
    + this.from_Date + "&To_Date=" + this.to_Date;
    return window.open(this.reportName, "_blank");
  }

  gotoBack() {
    this.router.navigate(['/home']);
  }

  reset() {
    
    let currentDateTime = this.datepipe.transform((new Date), 'yyyy-MM-dd');
    let currentDateTime2 = this.datepipe.transform((new Date), 'yyyy-MM-dd');

    this.from_Date=currentDateTime;
    this.to_Date=currentDateTime2;
    
    
  }

}
