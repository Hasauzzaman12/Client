import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AjflItemGradeComponent } from './ajfl-item-grade.component';

describe('AjflItemGradeComponent', () => {
  let component: AjflItemGradeComponent;
  let fixture: ComponentFixture<AjflItemGradeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AjflItemGradeComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AjflItemGradeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
