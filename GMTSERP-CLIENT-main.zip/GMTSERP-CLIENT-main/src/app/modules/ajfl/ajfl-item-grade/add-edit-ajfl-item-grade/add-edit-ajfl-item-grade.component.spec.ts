import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditAjflItemGradeComponent } from './add-edit-ajfl-item-grade.component';

describe('AddEditAjflItemGradeComponent', () => {
  let component: AddEditAjflItemGradeComponent;
  let fixture: ComponentFixture<AddEditAjflItemGradeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddEditAjflItemGradeComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddEditAjflItemGradeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
