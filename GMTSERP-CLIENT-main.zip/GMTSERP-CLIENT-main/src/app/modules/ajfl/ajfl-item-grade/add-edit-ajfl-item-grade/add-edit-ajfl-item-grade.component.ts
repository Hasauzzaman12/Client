import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';


@Component({
  selector: 'app-add-edit-ajfl-item-grade',
  templateUrl: './add-edit-ajfl-item-grade.component.html',
  styleUrls: ['./add-edit-ajfl-item-grade.component.scss']
})
export class AddEditAjflItemGradeComponent implements OnInit {

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';

  constructor(public _apiService:ApiServiceService,
    private _snackBar: MatSnackBar,
    public router:Router,
    private authservice: AuthService,
    private currentRoute: ActivatedRoute) {}

    newBlogForm!: FormGroup;
    id: number = 0;
    grade: string = "";
    item_Id: number = 0;
    user_Id: number = this.authservice.getUserId;
    is_active: boolean=true;
    itemList$!: Observable<any[]>;  

  ngOnInit(): void {

    this.newBlogForm = new FormGroup({
      id: new FormControl(0),
      grade: new FormControl(''),
      item_Id: new FormControl(0),     
      is_active: new FormControl(true)

    });
    
    this.itemList$ = this._apiService.getAjflItemList();   
    let id = this.currentRoute.snapshot.paramMap.get('id');
    if (id != null) {
      this.getAjflItemGradeById(id);
    }
  }

  getAjflItemGradeById(id: number | string) {
    this._apiService.getAjflItemGradeById(id).subscribe((data: any) => {      
      this.id= data.id;
      this.grade = data.grade;
      this.item_Id = data.item_Id;  
      this.is_active =  data.is_active;
    });
  }

  onSubmit(data: any) {
    const formData = new FormData();

    if (data.grade == '') {
      alert("Grade is Required")
      return;
    }
    if (data.item_Id == '' || data.item_Id == null) {
      alert("Item Type is Required")
      return;
    }

    data.id = this.id;
    formData.append('id', data.id);
    formData.append('grade', data.grade);
    formData.append('item_Id', this.item_Id.toString());
    formData.append('is_active', data.is_active);
    formData.append('user_Id', this.user_Id.toString());

    if (this.newBlogForm.valid) {
      if (data.id != 0) {
        this._apiService.updateAjflItemGrade(formData).subscribe(res => {
          this._snackBar.open("Item Grade Updated Successfully", "Update", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });
          this.router.navigate(['/ajfl-item-grade']);
        })
      }
      else {
        this._apiService.addAjflItemGrade(formData).subscribe(res => {
          this._snackBar.open("Item Grade Saved Successfully", "Success", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });
          this.router.navigate(['/ajfl-item-grade']);
        })
      }
    }

  }
  gotoBack() {
    this.router.navigate(['/ajfl-item-grade']);
  }
  reset(): void {
    this.ngOnInit();
  }
}
