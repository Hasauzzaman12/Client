import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditProductionRequisitionComponent } from './add-edit-production-requisition.component';

describe('AddEditProductionRequisitionComponent', () => {
  let component: AddEditProductionRequisitionComponent;
  let fixture: ComponentFixture<AddEditProductionRequisitionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddEditProductionRequisitionComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddEditProductionRequisitionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
