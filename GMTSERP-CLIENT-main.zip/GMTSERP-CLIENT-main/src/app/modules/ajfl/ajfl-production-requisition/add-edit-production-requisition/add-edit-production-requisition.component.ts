import { HttpClient, HttpEventType, HttpRequest } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable, of, startWith, debounceTime, distinctUntilChanged, switchMap, map } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-add-edit-production-requisition',
  templateUrl: './add-edit-production-requisition.component.html',
  styleUrls: ['./add-edit-production-requisition.component.scss']
})
export class AddEditProductionRequisitionComponent implements OnInit {

  myControl2 = new FormControl();
  options = [];
  filteredOptionsEmp: Observable<any>;

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';
  constructor( public _apiService: ApiServiceService,
    private _snackBar: MatSnackBar,
    public router: Router,
    private authservice: AuthService,
    private currentRoute: ActivatedRoute,
    private datepipe: DatePipe) { 
      this.filteredOptionsEmp = this.myControl2.valueChanges.pipe(

        startWith(''),
  
        debounceTime(400),
  
        distinctUntilChanged(),
  
        switchMap(val => {
  
          if(val!=''){
            return this.filter2(val || '')
          }else{
            return '';
          }
  
         }) 
  
      )
    }

    newBlogForm!: FormGroup;

    @Input() ajflpr: any;
    id: number = 0;
    code: string = '';
    req_Date: any;
    total_Weight: number = 0;
    total_Weight_Mond: number = 0;
    purchase_By_Id: number = 0;
    purchase_By: string = '';
    employee_Code= '';
    employee_Name= '';
    remarks: string = '';
    is_active: boolean = true;
    user_Id: number = this.authservice.getUserId;

    pr_detail_list: any[] = [];

    areaList$!: Observable<any[]>;
    itemGradeList$!: Observable<any[]>;

  ngOnInit(): void {
    let currentDateTime = this.datepipe.transform((new Date), 'MM/dd/yyyy h:mm:ss');
    this.newBlogForm = new FormGroup({
      id: new FormControl(0),
      code: new FormControl(''),
      req_Date: new FormControl(null),
      total_Weight: new FormControl(0),
      total_Weight_Mond: new FormControl(0),

      remarks: new FormControl(''),
      is_active: new FormControl(''),


    });
    this.areaList$=this._apiService.getAJflAreaList();
    this.itemGradeList$=this._apiService.getAjflItemGradeList();

    let id = this.currentRoute.snapshot.paramMap.get('id');
    if (id != null) {
      this.getAjflProductionRequisitionById(id);

    } else { 
      this.req_Date = currentDateTime;
      this.getProductionRequisitionCode();
    }

  }
  onSubmit(data: any) {

    const formData = new FormData();
    if (data.code == '') {
      alert("Code No is Required")
      return;
    }
    if (data.req_Date == '' || data.req_Date == null) {
      alert("Requisition Date is Required")
      return;
    }

    if (this.pr_detail_list.length==0) {
      alert("Enter PR Deatils")
      return;
    }
    // if (this.total_Per!=100) {
    //   alert("Wrong Total Percent Value !!!. Percent Value must be 100 in total !")
    //   return;
    // }

    data.id = this.id;

    formData.append('id', this.id.toString());
    formData.append('code', data.code == null ? '' : data.code);
    if (data.req_Date != null) {
      formData.append('req_Date', data.req_Date);
    }
    formData.append('total_Weight', data.total_Weight);
    formData.append('total_Weight_Mond', data.total_Weight_Mond);
    formData.append('purchase_By_Id', this.purchase_By_Id.toString());
    formData.append('remarks', data.remarks == null ? '' : data.remarks);
    formData.append('is_active', data.is_active);
    formData.append('user_Id', this.user_Id.toString());

    for (let i = 0; i < this.pr_detail_list.length; i++) {

      if ((this.pr_detail_list[i].qty == 0 || this.pr_detail_list[i].qty == "" || this.pr_detail_list[i].qty == null)) {
        alert("Qty is Required is PI Detail!!");
        return;
      }
      const keyPrefix = "prDetailList[" + i.toString() + "].";
      formData.append(keyPrefix + "id", this.pr_detail_list[i].id);
      formData.append(keyPrefix + "item_Grade_Id", this.pr_detail_list[i].item_Grade_Id);
      formData.append(keyPrefix + "area_Id", this.pr_detail_list[i].area_Id);
      formData.append(keyPrefix + "qty", this.pr_detail_list[i].qty);
      formData.append(keyPrefix + "remarks", this.pr_detail_list[i].remarks == null ? '' : this.pr_detail_list[i].remarks);
    }

    if (this.newBlogForm.valid) {
      if (data.id != 0) {

        this._apiService.updateAjflProductionRequisition(formData).subscribe(res => {

          this._snackBar.open("PR Updated Successfully", "Update", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });

          this.router.navigate(['/ajfl-production-requisition']);


        })
      }
      else {
        this._apiService.addAjflProductionRequisition(formData).subscribe(res => {

          this._snackBar.open("PR Saved Successfully", "Success", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });

          this.router.navigate(['/ajfl-production-requisition']);


        })
      }
    }
  }
  getAjflProductionRequisitionById(id: number | string) {
    this._apiService.getAjflProductionRequisitionById(id).subscribe((data: any) => {

      this.id= data.id;
      this.code = data.code;
      this.req_Date = data.req_Date;
      this.total_Weight = data.total_Weight;
      this.total_Weight_Mond = data.total_Weight_Mond;
      this.purchase_By_Id = data.purchase_By_Id;
      this.purchase_By = data.purchase_By;
      this.employee_Code=data.employee_Code;
      this.employee_Name=data.employee_Name;

      this.remarks =  data.remarks;
      this.is_active=data.is_active;

      this.pr_detail_list = data.prDetailList;

    });
    
  }
  
  addPRDetailRow() {


    this.pr_detail_list.push({
      id: 0,
      item_Grade_Id: 0,
      area_Id: 0,
      qty: 0,
      remarks: ''
    });
  }

  updateCalculation() {
    this.total_Weight=0;
    this.total_Weight_Mond=0;

    for (let i = 0; i < this.pr_detail_list.length; i++) {
      this.total_Weight+=this.pr_detail_list[i].qty;
    }

    this.total_Weight_Mond=this.total_Weight/40;
  }
  deletePrDetailRow(Index: any) {
    if (confirm('Are you sure want to delete?')) {
      this.pr_detail_list.splice(Index, 1);
      this.updateCalculation();
      
    }
  }
  filter2(val: string): Observable <any>{

    const formData = new FormData();
    formData.append('employee_Id', val);
    if (this.user_Id != 0||this.user_Id != null) {
      formData.append('user_Id', this.user_Id.toString());
    }
    formData.append('emp_Status', 'Active');

    return this._apiService.getEmployeesFiltered(formData)

    .pipe(

      map(response => response.filter((option: { employee_Id: string; }) => { 

        return option.employee_Id.toLowerCase().indexOf(val.toLowerCase()) !== -1

      }))

    )

   } 

   onSelFunc2(option: any){
    this.purchase_By_Id=option.id;
    this.employee_Name=option.employee_Name;
  }
  getProductionRequisitionCode() {
    this._apiService.getProductionRequisitionCode()
      .subscribe((data: any) => {
        this.code = data;
      })
  }
  gotoBack() {
    this.router.navigate(['/ajfl-production-requisition']);
  }
  reset(): void {
    this.ngOnInit();
  }
  
}
