import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AjflProductionRequisitionComponent } from './ajfl-production-requisition.component';

describe('AjflProductionRequisitionComponent', () => {
  let component: AjflProductionRequisitionComponent;
  let fixture: ComponentFixture<AjflProductionRequisitionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AjflProductionRequisitionComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AjflProductionRequisitionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
