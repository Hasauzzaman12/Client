import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AjflBasisSetupComponent } from './ajfl-basis-setup.component';

describe('AjflBasisSetupComponent', () => {
  let component: AjflBasisSetupComponent;
  let fixture: ComponentFixture<AjflBasisSetupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AjflBasisSetupComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AjflBasisSetupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
