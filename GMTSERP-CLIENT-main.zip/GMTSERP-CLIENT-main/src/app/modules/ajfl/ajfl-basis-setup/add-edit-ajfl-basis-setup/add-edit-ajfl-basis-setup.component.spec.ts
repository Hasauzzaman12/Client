import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditAjflBasisSetupComponent } from './add-edit-ajfl-basis-setup.component';

describe('AddEditAjflBasisSetupComponent', () => {
  let component: AddEditAjflBasisSetupComponent;
  let fixture: ComponentFixture<AddEditAjflBasisSetupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddEditAjflBasisSetupComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddEditAjflBasisSetupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
