import { HttpClient, HttpEventType, HttpRequest } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable, of, startWith, debounceTime, distinctUntilChanged, switchMap, map } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-add-edit-ajfl-basis-setup',
  templateUrl: './add-edit-ajfl-basis-setup.component.html',
  styleUrls: ['./add-edit-ajfl-basis-setup.component.scss']
})
export class AddEditAjflBasisSetupComponent implements OnInit {

  myControl2 = new FormControl();
  options = [];
  filteredOptionsEmp: Observable<any>;

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';
  constructor( public _apiService: ApiServiceService,
    private _snackBar: MatSnackBar,
    public router: Router,
    private authservice: AuthService,
    private currentRoute: ActivatedRoute,
    private datepipe: DatePipe) { 
      this.filteredOptionsEmp = this.myControl2.valueChanges.pipe(

        startWith(''),
  
        debounceTime(400),
  
        distinctUntilChanged(),
  
        switchMap(val => {
  
          if(val!=''){
            return this.filter2(val || '')
          }else{
            return '';
          }
  
         }) 
  
      )
    }

    newBlogForm!: FormGroup;

    @Input() ajflpurchase: any;
    id: number = 0;
    code: string = '';
    from_Date: any;
    to_Date: any;
    supplier_Id: number = 0;
    supplier_Name: string = '';
    area_Id: number = 0;
    area: string = '';
    item_Id: number = 0;
    item_Name: string = '';
    price: number = 0;
    collected_By_Id: number = 0;
    collected_By: string = '';
    employee_Code= '';
    employee_Name= '';
    remarks: string = '';
    is_active: boolean = true;
    user_Id: number = this.authservice.getUserId;

    total_Per: number = 0;
    is_invalid_total: boolean = false;

    supplierList$!: Observable<any[]>;
    itemList$!: Observable<any[]>;
    areaList$!: Observable<any[]>;
    itemGradeList$!: Observable<any[]>;

    basis_detail_list: any[] = [];

  ngOnInit(): void {
    let currentDateTime = this.datepipe.transform((new Date), 'MM/dd/yyyy h:mm:ss');

    
    this.newBlogForm = new FormGroup({
      id: new FormControl(0),
      code: new FormControl(''),
      from_Date: new FormControl(null),
      to_Date: new FormControl(null),
      supplier_Id: new FormControl(0),
      area_Id: new FormControl(0),
      item_Id: new FormControl(0),
      price: new FormControl(0),
      // collected_By_Id: new FormControl(0),

      remarks: new FormControl(''),
      is_active: new FormControl(''),


    });

    this.supplierList$=this._apiService.getAjflSupplierList();
    this.itemList$=this._apiService.getAjflItemList();
    this.areaList$=this._apiService.getAJflAreaList();

    let id = this.currentRoute.snapshot.paramMap.get('id');
    if (id != null) {
      this.getAjflBasisSetupById(id);

    } else {
      this.from_Date = currentDateTime;
      this.to_Date = currentDateTime;
      // this.getAjflBasisSetupCode();
    }
  }

  getAjflBasisSetupById(id: number | string) {
    this._apiService.getAjflBasisSetupById(id).subscribe((data: any) => {

      this.id= data.id;
      this.code = data.code;
      this.from_Date = data.from_Date;
      this.to_Date = data.to_Date;
      this.supplier_Id = data.supplier_Id;
      this.area_Id = data.area_Id;
      this.area = data.area;
      this.item_Id = data.item_Id;
      this.item_Name = data.item_Name;
      this.price = data.price;
      this.collected_By_Id = data.collected_By_Id;
      this.collected_By = data.collected_By;
      this.employee_Code=data.employee_Code;
      this.employee_Name=data.employee_Name;

      this.remarks =  data.remarks;
      this.is_active=data.is_active;


      this.basis_detail_list = data.basisDetaillList;
      this.itemGradeList$=this._apiService.getItemGradesByItem(this.item_Id);

      this.basis_detail_list.forEach(a => this.total_Per += a.qty_Per);

    });
    
  }
  onSubmit(data: any) {
    const formData = new FormData();
    if (data.code == '') {
      alert("Code No is Required")
      return;
    }
    if (data.from_Date == '' || data.from_Date == null) {
      alert("From Date is Required")
      return;
    }
    if (data.to_Date == '' || data.to_Date == null) {
      alert("To Date is Required")
      return;
    }
    if (data.supplier_Id == '' || data.supplier_Id == null || data.supplier_Id == 0) {
      alert("Supplier is Required")
      return;
    }
    if (this.basis_detail_list.length==0) {
      alert("Enter Basis Deatils")
      return;
    }

    if (this.total_Per!=100) {
      alert("Wrong Total Percent Value !!!. Percent Value must be 100 in total !")
      return;
    }

    data.id = this.id;

    formData.append('id', this.id.toString());
    formData.append('code', data.code == null ? '' : data.code);
    if (data.from_Date != null) {
      formData.append('from_Date', data.from_Date);
    }
    if (data.to_Date != null) {
      formData.append('to_Date', data.to_Date);
    }
    formData.append('supplier_Id', data.supplier_Id);
    formData.append('area_Id', data.area_Id);
    formData.append('item_Id', this.item_Id.toString());
    formData.append('price', data.price);
    formData.append('collected_By_Id', this.collected_By_Id.toString());
    formData.append('remarks', data.remarks == null ? '' : data.remarks);
    formData.append('is_active', data.is_active);
    formData.append('user_Id', this.user_Id.toString());

    for (let i = 0; i < this.basis_detail_list.length; i++) {

      if ((this.basis_detail_list[i].item_Grade_Id == 0 || this.basis_detail_list[i].item_Grade_Id == "" || this.basis_detail_list[i].item_Grade_Id == null)) {
        alert("Item Grade is Required !!");
        return;
      }

      if ((this.basis_detail_list[i].qty_Per == 0 || this.basis_detail_list[i].qty_Per == "" || this.basis_detail_list[i].qty_Per == null)) {
        alert("Qty is Required in Detail!!");
        return;
      }
      const keyPrefix = "basisDetaillList[" + i.toString() + "].";
      formData.append(keyPrefix + "id", this.basis_detail_list[i].id);
      formData.append(keyPrefix + "item_Grade_Id", this.basis_detail_list[i].item_Grade_Id);
      formData.append(keyPrefix + "qty_Per", this.basis_detail_list[i].qty_Per);
      formData.append(keyPrefix + "amount", this.basis_detail_list[i].amount);
    }

    if (this.newBlogForm.valid) {
      if (data.id != 0) {

        this._apiService.updatAjflBasisSetup(formData).subscribe(res => {

          this._snackBar.open("Basis Setup Updated Successfully", "Update", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });

          this.router.navigate(['/ajfl-basis-setup']);


        })
      }
      else {
        this._apiService.addAjflBasisSetup(formData).subscribe(res => {

          this._snackBar.open("Basis Setup Saved Successfully", "Success", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });

          this.router.navigate(['/ajfl-basis-setup']);


        })
      }
    }
  }
  getAjflBasisSetupCode() {
    this._apiService.getAjflBasisSetupCode()
      .subscribe((data: any) => {
        this.code = data;
      })
  }
  gotoBack() {
    this.router.navigate(['/ajfl-basis-setup']);
  }
  reset(): void {
    this.ngOnInit();
  }
  changeItem(event: any) {
    if(event.target.value>0){
     this.item_Id=event.target.value;
     this.itemGradeList$=this._apiService.getItemGradesByItem(event.target.value);
    }
  }
  filter2(val: string): Observable <any>{

    const formData = new FormData();
    formData.append('employee_Id', val);
    if (this.user_Id != 0||this.user_Id != null) {
      formData.append('user_Id', this.user_Id.toString());
    }
    formData.append('emp_Status', 'Active');

    return this._apiService.getEmployeesFiltered(formData)

    .pipe(

      map(response => response.filter((option: { employee_Id: string; }) => { 

        return option.employee_Id.toLowerCase().indexOf(val.toLowerCase()) !== -1

      }))

    )

   } 
   onSelFunc2(option: any){
    if(option.id>0){
      this.collected_By_Id=option.id;
      this.employee_Name=option.employee_Name;
    }
  }


  addBSDetailRow() {

    if (this.item_Id == null || this.item_Id == 0) {
      alert("Select Item")
      return;
    }
    if (this.price == null || this.price == 0) {
      alert("Enter Price")
      return;
    }

    this.basis_detail_list.push({
      id: 0,
      item_Grade_Id: 0,
      qty_Per: 0,
      amount: 0
    });
  }
  deleteBsDetailRow(Index: any) {
    if (confirm('Are you sure want to delete?')) {
      this.basis_detail_list.splice(Index, 1);
      this.updateCalculation();
      
    }
  }
  updatePrice(data: any) {
      this.price=data.price;
      this.updateCalculation();
  }
  updateCalculation() {
    this.total_Per=0;

    for (let i = 0; i < this.basis_detail_list.length; i++) {
      if(this.basis_detail_list[i].qty_Per>0){
        this.basis_detail_list[i].amount=this.naiveRound((this.price*this.basis_detail_list[i].qty_Per)/100)
      }
      this.total_Per+=this.basis_detail_list[i].qty_Per;
    }

    if(this.total_Per===100){
      this.is_invalid_total=false;
    }else{
      this.is_invalid_total=true;
    }
  }

  naiveRound(num: number = 0, decimalPlaces = 2) {
    var p = Math.pow(10, decimalPlaces);
    return Math.round(num * p) / p;
  }
}
