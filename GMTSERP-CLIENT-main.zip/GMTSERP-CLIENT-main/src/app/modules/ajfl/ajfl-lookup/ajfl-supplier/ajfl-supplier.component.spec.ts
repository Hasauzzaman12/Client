import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AjflSupplierComponent } from './ajfl-supplier.component';

describe('AjflSupplierComponent', () => {
  let component: AjflSupplierComponent;
  let fixture: ComponentFixture<AjflSupplierComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AjflSupplierComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AjflSupplierComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
