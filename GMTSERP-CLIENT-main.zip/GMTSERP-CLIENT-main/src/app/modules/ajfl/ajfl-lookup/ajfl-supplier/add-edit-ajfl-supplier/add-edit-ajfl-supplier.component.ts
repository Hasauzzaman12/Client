import { Component, Input, OnInit } from '@angular/core';
import { MatSnackBar , MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition} from '@angular/material/snack-bar';
import { ActivatedRoute ,Router} from '@angular/router';
import { Observable } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';
import { SD } from 'src/environments/sd';
@Component({
  selector: 'app-add-edit-ajfl-supplier',
  templateUrl: './add-edit-ajfl-supplier.component.html',
  styleUrls: ['./add-edit-ajfl-supplier.component.scss']
})
export class AddEditAjflSupplierComponent implements OnInit {

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';

  constructor(public _apiService:ApiServiceService,
    private _snackBar: MatSnackBar,
    public router:Router,
    private authservice: AuthService,
    private currentRoute: ActivatedRoute) {}

    @Input() supplier:any;
    id: number = 0;
    name: string = "";
    supplier_Code: string = "";
    code_No: number = 0;
    supplier_Group_Lookup_Id: number = SD.AJFL_Supplier_Group_Lookup_Id;
    address: string = "";
    contact_No: string = "";
    email: string = "";
    website: string = "";
    facebook: string = "";
    user_Id: number = this.authservice.getUserId;
    company_Id: number = this.authservice.getCompanyId;
    is_active: boolean=true;



  ngOnInit(): void {
    
    let id = this.currentRoute.snapshot.paramMap.get('id');
    if (id != null){
      this.getSupplierById(id);

    }
  }
  getSupplierById(id:number|string){
    this._apiService.getSupplierById(id)
    .subscribe((data: any) => {
      this.id=data.id;
      this.name=data.name;
      this.supplier_Code=data.supplier_Code;
      this.code_No=data.code_No;
      this.address=data.address;
      this.contact_No=data.contact_No;
      this.email=data.email;
      this.website=data.website;
      this.facebook=data.facebook;
      this.is_active =data.is_active;
    });
  
  }

  addNewSupplier() {

    var supplier = {
      name:this.name,
      supplier_Code:this.supplier_Code,
      code_No:this.code_No,
      supplier_Group_Lookup_Id:this.supplier_Group_Lookup_Id,
      address:this.address,
      contact_No:this.contact_No,
      email:this.email,
      website:this.website,
      facebook:this.facebook,
      company_Id:this.company_Id,
      is_active:this.is_active
    }
    
    this._apiService.addSupplier(supplier).subscribe(res => {

      this._snackBar.open("Supplier Added Successfully", "Success", {
        horizontalPosition: this.horizontalPosition,
        verticalPosition: this.verticalPosition,
        duration: 2000
      });

      this.router.navigate(['/ajfl-supplier']);
      
    })
  }

  updateSupplier() {

    var supplier = {
      id:this.id,
      name:this.name,
      supplier_Code:this.supplier_Code,
      code_No:this.code_No,
      supplier_Group_Lookup_Id:this.supplier_Group_Lookup_Id,
      address:this.address,
      contact_No:this.contact_No,
      email:this.email,
      website:this.website,
      facebook:this.facebook,
      company_Id:this.company_Id,
      is_active:this.is_active
     
    }
    this._apiService.updateSupplier(supplier).subscribe(res => {
      this._snackBar.open("Supplier Updated Successfully", "Update", {
        horizontalPosition: this.horizontalPosition,
        verticalPosition: this.verticalPosition,
        duration: 2000
      });

      this.router.navigate(['/ajfl-supplier']);
 
    })
  }

  gotoBack() {
    this.router.navigate(['/ajfl-supplier']);
  }

}
