import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';

@Component({
  selector: 'app-ajfl-purchase',
  templateUrl: './ajfl-purchase.component.html',
  styleUrls: ['./ajfl-purchase.component.scss']
})
export class AjflPurchaseComponent implements OnInit {

  code: string = '';
  challan_No: string = '';
  from_Date : any=null;
  to_Date : any=null;

  user_Id: number = this.authservice.getUserId;
  isFilterShow: boolean = false;

  displayedColumns: string[] = ['code','purchase_Date','basis_Setup_Code','challan_No','supplier_Name','total_Amount','action'];
  dataSource!: MatTableDataSource<any>;

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';


  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;


  constructor(public _apiService: ApiServiceService,
    private authservice: AuthService,
    private _snackBar: MatSnackBar,
    public dialog: MatDialog,
    private router: Router) { }

  ngOnInit(): void {
    this.getPurchaseList();
  }
  getPurchaseList() {
    const formData = new FormData();
    if (this.code != ''||this.code != null) {
      formData.append('code', this.code);
    }
    if (this.challan_No != ''||this.challan_No != null) {
      formData.append('challan_No', this.challan_No);
    }

    if(this.from_Date != null && this.to_Date != null){
      formData.append('from_Date', this.from_Date);
      formData.append('to_Date', this.to_Date);
    }


    this._apiService.getPurchaseListFiltered(formData)
      .subscribe({
        next: (res) => {
          this.dataSource = new MatTableDataSource(res);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
        },
        error: (err) => {
          console.log("Error");
        }

      })
  }

  openForEdit(id: number) {

    this.router.navigate(['/ajfl-purchase/edit/' + id]);
  }
  gotoNew() {
    this.router.navigate(['/add-ajfl-purchase']);
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  SearchSummary() {
    this.getPurchaseList();
  }
  reset() {

    this.code='';
    this.challan_No='';
    this.from_Date=null;
    this.to_Date=null;

    this.getPurchaseList();
  }
  toggleFilter() {
    this.isFilterShow = !this.isFilterShow;
  }
}
