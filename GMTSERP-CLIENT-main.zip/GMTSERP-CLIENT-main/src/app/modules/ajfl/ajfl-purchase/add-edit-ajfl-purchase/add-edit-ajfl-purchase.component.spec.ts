import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditAjflPurchaseComponent } from './add-edit-ajfl-purchase.component';

describe('AddEditAjflPurchaseComponent', () => {
  let component: AddEditAjflPurchaseComponent;
  let fixture: ComponentFixture<AddEditAjflPurchaseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddEditAjflPurchaseComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddEditAjflPurchaseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
