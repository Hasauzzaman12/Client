import { HttpClient, HttpEventType, HttpRequest } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable, of, startWith, debounceTime, distinctUntilChanged, switchMap, map } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-add-edit-ajfl-purchase',
  templateUrl: './add-edit-ajfl-purchase.component.html',
  styleUrls: ['./add-edit-ajfl-purchase.component.scss']
})
export class AddEditAjflPurchaseComponent implements OnInit {

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';
  constructor( public _apiService: ApiServiceService,
    private _snackBar: MatSnackBar,
    public router: Router,
    private authservice: AuthService,
    private currentRoute: ActivatedRoute,
    private datepipe: DatePipe) { }

    
    newBlogForm!: FormGroup;

    @Input() ajflpurchase: any;
    id: number = 0;
    code: string = '';
    purchase_Date: any;
    basis_Setup_Id: number = 0;
    basis_Setup_Code: string = '';
    challan_No: string = '';
    challan_Date: any;
    supplier_Id: number = 0;
    supplier_Name: string = '';
    area_Id: number = 0;
    area: string = '';
    item_Id: number = 0;
    item_Name: string = '';
    bill_No: string = '';
    bundle_Qty: number = 0;
    challan_Weight: number = 0;
    total_Weight: number = 0;
    total_Weight_Mond: number = 0;
    mR_Per: number = 0;
    mR_Deduct_Weight: number = 0;
    scale_Weight: number = 0;
    deduction_Weight_Per_Kg: number = 0;
    actual_Weight: number = 0;
    actual_Weight_Mond: number = 0;
    total_Amount: number = 0;
   
    delivery_Date: any;
    driver_Name: string = '';
    driver_Number: string = '';
    vehicle_No: string = '';

    remarks: string = '';
    is_active: boolean = true;
    user_Id: number = this.authservice.getUserId;

    total_Per: number = 0;
   
    supplierList$!: Observable<any[]>;
    itemList$!: Observable<any[]>;
    basisSetupList$!: Observable<any[]>;
    areaList$!: Observable<any[]>;
    itemGradeList$!: Observable<any[]>;

    purchase_detail_list: any[] = [];


  ngOnInit(): void {
    let currentDateTime = this.datepipe.transform((new Date), 'MM/dd/yyyy h:mm:ss');

    
    this.newBlogForm = new FormGroup({
      id: new FormControl(0),
      code: new FormControl(''),
      purchase_Date: new FormControl(null),
      basis_Setup_Id: new FormControl(0),
      challan_No: new FormControl(''),
      challan_Date: new FormControl(null),
      supplier_Id: new FormControl(0),
      area_Id: new FormControl(0),
      item_Id: new FormControl(0),
      bill_No: new FormControl(''),
      bundle_Qty: new FormControl(0),
      challan_Weight: new FormControl(0),
      total_Weight: new FormControl(0),
      total_Weight_Mond: new FormControl(0),
      mR_Per: new FormControl(0),
      mR_Deduct_Weight: new FormControl(0),
      scale_Weight: new FormControl(0),
      deduction_Weight_Per_Kg: new FormControl(0),
      actual_Weight: new FormControl(0),
      actual_Weight_Mond: new FormControl(0),
      total_Amount: new FormControl(0),
      
      delivery_Date: new FormControl(null),
      driver_Name: new FormControl(''),
      driver_Number: new FormControl(''),
      vehicle_No: new FormControl(''),
     
      remarks: new FormControl(''),
      is_active: new FormControl(''),

    });

    this.supplierList$=this._apiService.getAjflSupplierList();
    this.itemList$=this._apiService.getAjflItemList();
    this.basisSetupList$=this._apiService.getAJflBasisSetupList();
    this.areaList$=this._apiService.getAJflAreaList();


    let id = this.currentRoute.snapshot.paramMap.get('id');
    if (id != null) {
      this.getPurchaseById(id);

    } else {
      this.purchase_Date = currentDateTime;
      this.getPurchaseCode();
    }
  }

  onSubmit(data: any) {

    const formData = new FormData();
    if (data.code == '') {
      alert("Code No is Required")
      return;
    }
    if (data.purchase_Date == '' || data.purchase_Date == null) {
      alert("Purchase Date is Required")
      return;
    }
    if (data.supplier_Id == '' || data.supplier_Id == null || data.supplier_Id == 0) {
      alert("Supplier is Required")
      return;
    }
    if (this.purchase_detail_list.length==0) {
      alert("Enter Purchase Deatils")
      return;
    }
    if (this.total_Per!=100) {
      alert("Wrong Total Percent Value !!!. Percent Value must be 100 in total !")
      return;
    }

    data.id = this.id;

    formData.append('id', this.id.toString());
    formData.append('code', data.code == null ? '' : data.code);
    if (data.purchase_Date != null) {
      formData.append('purchase_Date', data.purchase_Date);
    }
    formData.append('basis_Setup_Id', data.basis_Setup_Id);
    formData.append('challan_No', data.challan_No == null ? '' : data.challan_No);
    if (data.challan_Date != null) {
      formData.append('challan_Date', data.challan_Date);
    }
    formData.append('supplier_Id', data.supplier_Id);
    formData.append('area_Id', data.area_Id);
    formData.append('item_Id', data.item_Id);
    formData.append('bill_No', data.bill_No == null ? '' : data.bill_No);
    formData.append('bundle_Qty', data.bundle_Qty);
    formData.append('challan_Weight', data.challan_Weight);
    formData.append('total_Weight', data.total_Weight);
    formData.append('total_Weight_Mond', data.total_Weight_Mond);
    formData.append('mR_Per', data.mR_Per);
    formData.append('mR_Deduct_Weight', data.mR_Deduct_Weight);
    formData.append('scale_Weight', data.scale_Weight);
    formData.append('deduction_Weight_Per_Kg', data.deduction_Weight_Per_Kg);
    formData.append('actual_Weight', data.actual_Weight);
    formData.append('actual_Weight_Mond', data.actual_Weight_Mond);
    formData.append('total_Amount', data.total_Amount);

    if (data.delivery_Date != null) {
      formData.append('delivery_Date', data.delivery_Date);
    }
    formData.append('driver_Name', data.driver_Name == null ? '' : data.driver_Name);
    formData.append('driver_Number', data.driver_Number == null ? '' : data.driver_Number);
    formData.append('vehicle_No', data.vehicle_No == null ? '' : data.vehicle_No);
    formData.append('remarks', data.remarks == null ? '' : data.remarks);
    formData.append('is_active', data.is_active);
    formData.append('user_Id', this.user_Id.toString());

    for (let i = 0; i < this.purchase_detail_list.length; i++) {

      if ((this.purchase_detail_list[i].qty_Per == 0 || this.purchase_detail_list[i].qty_Per == "" || this.purchase_detail_list[i].qty_Per == null)) {
        alert("Qty is Required is Purchase Detail!!");
        return;
      }
      const keyPrefix = "purchaseDetaillList[" + i.toString() + "].";
      formData.append(keyPrefix + "id", this.purchase_detail_list[i].id);
      formData.append(keyPrefix + "item_Grade_Id", this.purchase_detail_list[i].item_Grade_Id);
      formData.append(keyPrefix + "qty_Per", this.purchase_detail_list[i].qty_Per);
      formData.append(keyPrefix + "weight_Mond", this.purchase_detail_list[i].weight_Mond);
      formData.append(keyPrefix + "rate", this.purchase_detail_list[i].rate);
      formData.append(keyPrefix + "total_Amount", this.purchase_detail_list[i].total_Amount);
    }

    if (this.newBlogForm.valid) {
      if (data.id != 0) {

        this._apiService.updateAjflPurchase(formData).subscribe(res => {

          this._snackBar.open("Purchase Updated Successfully", "Update", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });

          this.router.navigate(['/ajfl-purchase']);


        })
      }
      else {
        this._apiService.addAjflPurchase(formData).subscribe(res => {

          this._snackBar.open("Purchase Saved Successfully", "Success", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });

          this.router.navigate(['/ajfl-purchase']);


        })
      }
    }
  }

  getPurchaseById(id: number | string) {
    this._apiService.getCAjflPurchaseById(id).subscribe((data: any) => {

      this.id= data.id;
      this.code = data.code;
      this.purchase_Date = data.purchase_Date;
      this.basis_Setup_Id = data.basis_Setup_Id;
      this.challan_No = data.challan_No;
      this.challan_Date = data.challan_Date;
      this.supplier_Id = data.supplier_Id;
      this.area_Id = data.area_Id;
      this.item_Id = data.item_Id;
      this.bill_No = data.bill_No;
      this.bundle_Qty = data.bundle_Qty;
      this.challan_Weight = data.challan_Weight;
      this.total_Weight = data.total_Weight;
      this.total_Weight_Mond = data.total_Weight_Mond;
      this.mR_Per = data.mR_Per;
      this.mR_Deduct_Weight = data.mR_Deduct_Weight;
      this.scale_Weight = data.scale_Weight;
      this.deduction_Weight_Per_Kg = data.deduction_Weight_Per_Kg;
      this.actual_Weight = data.actual_Weight;
      this.actual_Weight_Mond = data.actual_Weight_Mond;
      this.total_Amount = data.total_Amount;
      this.delivery_Date = data.delivery_Date;
      this.driver_Name = data.driver_Name;
      this.driver_Number = data.driver_Number;
      this.vehicle_No = data.vehicle_No;

      this.remarks =  data.remarks;
      this.is_active=data.is_active;

      this.purchase_detail_list = data.purchaseDetaillList;
      this.purchase_detail_list.forEach(a => this.total_Per += a.qty_Per);
      this.itemGradeList$=this._apiService.getItemGradesByItem(this.item_Id);


    });
  }

  getPurchaseCode() {
    this._apiService.getPurchaseCode()
      .subscribe((data: any) => {
        this.code = data;
      })
  }
  gotoBack() {
    this.router.navigate(['/ajfl-purchase']);
  }
  reset(): void {
    this.ngOnInit();
  }
  changeBs(event: any) {
     this.basis_Setup_Id=event.target.value;
  }
  changeItem(event: any) {
     this.item_Id=event.target.value;
     this.itemGradeList$=this._apiService.getItemGradesByItem(event.target.value);
  }
  addDetailRow() {

    if (this.item_Id == null || this.item_Id == 0) {
      alert("Select Item")
      return;
    }
    if (this.basis_Setup_Id == null || this.basis_Setup_Id == 0) {
      alert("Select Basis Setup")
      return;
    }

    this.purchase_detail_list.push({
      id: 0,
      item_Grade_Id: 0,
      qty_Per: 0,
      weight_Mond: 0,
      rate: 0,
      total_Amount: 0,
    });
  }
  deleteDetailRow(Index: any) {
    if (confirm('Are you sure want to delete?')) {
      this.purchase_detail_list.splice(Index, 1);
      
    }
  }

  updatePrice(data: any) {
    this.total_Weight=0;
    this.total_Weight_Mond=0;
    this.mR_Deduct_Weight=0;
    this.deduction_Weight_Per_Kg=0;
    this.actual_Weight=0;
    this.actual_Weight_Mond=0;

    this.total_Weight=this.naiveRound(data.bundle_Qty*data.challan_Weight)
    this.total_Weight_Mond=this.naiveRound(this.total_Weight/40)
    if(data.mR_Per>25){
      this.mR_Deduct_Weight=this.naiveRound((this.total_Weight*data.mR_Per)/100)
    }

    this.deduction_Weight_Per_Kg=this.naiveRound((data.scale_Weight*1)/100)
    this.actual_Weight=this.naiveRound(data.scale_Weight-this.deduction_Weight_Per_Kg)
    this.actual_Weight_Mond=this.naiveRound(this.actual_Weight/40)
    this.updateCalculation();
}
updateCalculation() {
  this.total_Amount=0;
  this.total_Per=0;

    for (let i = 0; i < this.purchase_detail_list.length; i++) {
      if(this.purchase_detail_list[i].qty_Per>0){
        this.purchase_detail_list[i].weight_Mond=this.naiveRound((this.actual_Weight_Mond*this.purchase_detail_list[i].qty_Per)/100)
        this.purchase_detail_list[i].total_Amount=this.naiveRound(this.purchase_detail_list[i].weight_Mond*this.purchase_detail_list[i].rate)
      }
      this.total_Amount+=this.purchase_detail_list[i].total_Amount;
      this.total_Per+=this.purchase_detail_list[i].qty_Per;
    }

}

changeItemChild(row: any) {
  if (row.item_Grade_Id >0) {
  this._apiService.getItemRateByBs(row.item_Grade_Id,this.basis_Setup_Id).subscribe((data: any) => {
    row.rate = data.amount;
    this.updateCalculation();
  });
}
}
  

  naiveRound(num: number = 0, decimalPlaces = 2) {
    var p = Math.pow(10, decimalPlaces);
    return Math.round(num * p) / p;
  }
}
