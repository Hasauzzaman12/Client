import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AjflPurchaseComponent } from './ajfl-purchase.component';

describe('AjflPurchaseComponent', () => {
  let component: AjflPurchaseComponent;
  let fixture: ComponentFixture<AjflPurchaseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AjflPurchaseComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AjflPurchaseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
