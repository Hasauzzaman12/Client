import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditAssetItemAssignSoftwareComponent } from './add-edit-asset-item-assign-software.component';

describe('AddEditAssetItemAssignSoftwareComponent', () => {
  let component: AddEditAssetItemAssignSoftwareComponent;
  let fixture: ComponentFixture<AddEditAssetItemAssignSoftwareComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddEditAssetItemAssignSoftwareComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddEditAssetItemAssignSoftwareComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
