import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetItemAssignSoftwareComponent } from './asset-item-assign-software.component';

describe('AssetItemAssignSoftwareComponent', () => {
  let component: AssetItemAssignSoftwareComponent;
  let fixture: ComponentFixture<AssetItemAssignSoftwareComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AssetItemAssignSoftwareComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AssetItemAssignSoftwareComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
