import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetItemEmailComponent } from './asset-item-email.component';

describe('AssetItemEmailComponent', () => {
  let component: AssetItemEmailComponent;
  let fixture: ComponentFixture<AssetItemEmailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AssetItemEmailComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AssetItemEmailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
