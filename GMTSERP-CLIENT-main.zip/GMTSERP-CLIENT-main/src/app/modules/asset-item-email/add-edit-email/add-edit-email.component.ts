import { HttpClient, HttpEventType, HttpRequest } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable, of,startWith, debounceTime, distinctUntilChanged, switchMap, map } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';
import { DatePipe } from '@angular/common';
import { SD } from 'src/environments/sd';

@Component({
  selector: 'app-add-edit-email',
  templateUrl: './add-edit-email.component.html',
  styleUrls: ['./add-edit-email.component.scss']
})
export class AddEditEmailComponent implements OnInit {

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';

  constructor(public _apiService: ApiServiceService,
    private _snackBar: MatSnackBar,
    public router: Router,
    private authservice: AuthService,
    private currentRoute: ActivatedRoute,
    private datepipe: DatePipe) {  }
    
    newBlogForm!: FormGroup;
    id: number = 0;
    item_Name= '';
    asset_Owner_Id: number = 1;
    company_Id: number = 0;
    user_Id: number = this.authservice.getUserId;
    is_Active: boolean = true;
    asset_Item_Category_Id: number = SD.asset_Item_Category_Id_email;
    email_Address= '';
    email_Create_Date : any;
    email_Expire_Date : any;

    assetOwnerList$!: Observable<any[]>;
    companyList$!:Observable<any[]>;

  ngOnInit(): void {

    this.newBlogForm = new FormGroup({
      id: new FormControl(0),
      item_Name: new FormControl(''),
      asset_Owner_Id: new FormControl({value: this.asset_Owner_Id, disabled: true}),
      company_Id: new FormControl(0),
      is_Active: new FormControl(true),
      asset_Item_Category_Id: new FormControl(0),
      email_Address: new FormControl(''),
      email_Create_Date: new FormControl(null),
      email_Expire_Date: new FormControl(null),
    });

    this.assetOwnerList$=this._apiService.getAssetOwnerList();
    if(this.user_Id>0){
      this.companyList$ = this._apiService.getCompanyListByUser(this.user_Id);
    }else{
      this.companyList$ = this._apiService.getCompanyList();
    }


    let id = this.currentRoute.snapshot.paramMap.get('id');
    if (id != null) {
      this.getAssetItemById(id);
      
    }
  }

  
  getAssetItemById(id: number | string) {
   
    this._apiService.getAssetItemnById(id).subscribe((data: any) => {
      this.id=data.id;
      this.item_Name=data.item_Name;
      this.asset_Owner_Id=data.asset_Owner_Id;
      this.company_Id=data.company_Id;
      this.is_Active=data.is_Active;
      this.asset_Item_Category_Id=data.asset_Item_Category_Id;
      this.email_Address=data.email_Address;
      this.email_Create_Date=data.email_Create_Date;
      this.email_Expire_Date=data.email_Expire_Date;
    });
  
  }

  onSubmit(data: any) {
    data.id=this.id;
    data.asset_Owner_Id=this.asset_Owner_Id;
    data.asset_Item_Category_Id=this.asset_Item_Category_Id;

    const formData = new FormData();

    if (data.company_Id == 0||data.company_Id == null) {
      alert("Company is Required")
      return;
    }
    if (data.item_Name == ''||data.item_Name == null) {
      alert("Email Adrress is Required")
      return;
    }

    if(data.email_Create_Date == ''||data.email_Create_Date == null) {
      alert("Create Date is Required")
      return;
    }

    formData.append('id', data.id);
    formData.append('item_Name', data.item_Name == null ? '' : data.item_Name);
    formData.append('asset_Owner_Id', data.asset_Owner_Id);
    formData.append('company_Id', data.company_Id);
    formData.append('is_Active', data.is_Active);
    formData.append('asset_Item_Category_Id', data.asset_Item_Category_Id);
    formData.append('email_Address', data.item_Name == null ? '' : data.item_Name);
    formData.append('email_Create_Date', data.email_Create_Date);

    if(data.email_Expire_Date != null) {
      formData.append('email_Expire_Date', data.email_Expire_Date);
    }
   

    if (this.newBlogForm.valid) {
      if (data.id != 0) {
  
        this._apiService.updateAssetItem(formData).subscribe(res => {
  
          this._snackBar.open("Asset Item Updated Successfully", "Update", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });
  
          this.router.navigate(['/asset-item-email']);
  
  
        })
      }
      else {
        this._apiService.addAssetItem(formData).subscribe(res => {
  
          this._snackBar.open("Asset Item Saved Successfully", "Success", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });
  
          this.router.navigate(['/asset-item-email']);
  
  
        })
      }
    }
  }
  gotoBack() {
    this.router.navigate(['/asset-item-email']);
  }
  reset(): void {
    this.ngOnInit();
  }

}
