
import { Component, Input, OnInit } from '@angular/core';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';

@Component({
  selector: 'app-add-admin-role',
  templateUrl: './add-admin-role.component.html',
  styleUrls: ['./add-admin-role.component.scss']
})
export class AddAdminRoleComponent implements OnInit {
  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';

  constructor(public _apiService: ApiServiceService,
    private _snackBar: MatSnackBar,
    public router: Router,
    private authservice: AuthService,
    private currentRoute: ActivatedRoute) { }

  @Input() roleModel: any;
  id: number = 0;
  role_Name: string = "";
  is_active: boolean = true;

  ngOnInit(): void {
    let id = this.currentRoute.snapshot.paramMap.get('id');
    if (id != null) {
      this.getRoleById(id);

    }
  }

  getRoleById(id: number | string) {
    this.authservice.getRoleById(id)
      .subscribe((data: any) => {
        this.id = data.id;
        this.role_Name = data.role_Name;
        this.is_active = data.is_active;
      });

  }

  addNewRole() {

    var role = {
      role_Name: this.role_Name,
      is_active: this.is_active
    }

    this.authservice.addRole(role).subscribe(res => {

      this._snackBar.open("Role Added Successfully", "Success", {
        horizontalPosition: this.horizontalPosition,
        verticalPosition: this.verticalPosition,
        duration: 2000
      });

      this.router.navigate(['/role']);

    })
  }

  updateRole() {

    var role = {
      id: this.id,
      role_Name: this.role_Name,
      is_active: this.is_active

    }
    this.authservice.updateRole(role).subscribe(res => {
      this._snackBar.open("Role Updated Successfully", "Update", {
        horizontalPosition: this.horizontalPosition,
        verticalPosition: this.verticalPosition,
        duration: 2000
      });

      this.router.navigate(['/role']);

    })
  }

  gotoBack() {
    this.router.navigate(['/role']);
  }

}

