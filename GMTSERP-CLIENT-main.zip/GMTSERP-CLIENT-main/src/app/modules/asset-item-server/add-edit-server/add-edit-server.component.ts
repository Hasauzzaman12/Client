import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-edit-server',
  templateUrl: './add-edit-server.component.html',
  styleUrls: ['./add-edit-server.component.scss']
})
export class AddEditServerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
