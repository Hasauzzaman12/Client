import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetItemServerComponent } from './asset-item-server.component';

describe('AssetItemServerComponent', () => {
  let component: AssetItemServerComponent;
  let fixture: ComponentFixture<AssetItemServerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AssetItemServerComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AssetItemServerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
