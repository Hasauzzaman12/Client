import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-asset-item-server',
  templateUrl: './asset-item-server.component.html',
  styleUrls: ['./asset-item-server.component.scss']
})
export class AssetItemServerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
