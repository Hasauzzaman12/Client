import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, NgForm, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { debounceTime, distinctUntilChanged, map, Observable, ReplaySubject, startWith, switchMap } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-asset-report',
  templateUrl: './asset-report.component.html',
  styleUrls: ['./asset-report.component.scss']
})
export class AssetReportComponent implements OnInit {

  companyList$!: Observable<any[]>;
  assetItemList$!: Observable<any[]>;
  unitListByComId$!: Observable<any[]>;
  departmentList$!: Observable<any[]>;
  custodianListByComId$!: Observable<any[]>;
  subcustodianListByCusId$!: Observable<any[]>;


  myControl = new FormControl();
  options = [];
  filteredOptionsEmp: Observable<any>;

  showControl_Company: boolean = false;
  showControl_CompanyUnit: boolean = false;
  showControl_Department: boolean = false;
  showControl_Custodian: boolean = false;
  showControl_SubCustodian: boolean = false;
  showControl_ItemCategory: boolean = false;
  showControl_EmployeeCode: boolean = false;


  reportName: any;
  fileType: any;
  endpoint: string = `${environment.reportServerUrl}`;
  isSubmitted = false;
  form!: FormGroup;


  public websiteCtrl: FormControl = new FormControl();
  public websiteFilterCtrl: FormControl = new FormControl();


  constructor(
    public _apiService: ApiServiceService, public fb: FormBuilder,
    private _snackBar: MatSnackBar,
    public router: Router,
    private authservice: AuthService,
    private currentRoute: ActivatedRoute,
  ) {
    this.filteredOptionsEmp = this.myControl.valueChanges.pipe(

      startWith(''),
      debounceTime(400),
      distinctUntilChanged(),
      switchMap(val => {
        if(val!=''){
          return this.filter(val || '')
        }else{
          return '';
        }
      })

    )
  }





  newBlogForm!: FormGroup;
  @Input() adminUnit: any;
  id: number = 0;
  companyId: number = 0;
  assetReportRadio: string = "";
  itemcategoryId: number = 0;
  unit_Id: number = 0;
  department_Id: number = 0;
  custodian_Id: number = 0;
  subcustodian_Id: number = 0;
  employee_Id: number = 0;
  employee_Code: string = "";

  ngOnInit(): void {
    this.companyList$ = this._apiService.getCompanyList();
    this.assetItemList$ = this._apiService.getAssetItemByOwner(1);
    this.departmentList$ = this._apiService.getDepartmentList();

  }

  onOptionsCompanySelected(event: any) {
    const value = event.target.value;
    this.companyId = value;
    this.unitListByComId$ = this._apiService.getUnitListByCompanyId(this.companyId);
    this.custodianListByComId$ = this._apiService.getCustodianByCompanyId(this.companyId);

  }

  onOptionsItemCustodianSelected(event: any) {
    const value = event.target.value;
    this.custodian_Id = value;
    this.subcustodianListByCusId$ = this._apiService.getSubCustodianByCustodian(this.custodian_Id);

  }

  onOptionsItemSubCustodianSelected(event: any) {
    const value = event.target.value;
    this.subcustodian_Id = value;
  }

  onOptionsUnitSelected(event: any) {
    const value = event.target.value;
    this.unit_Id = value;
  }

  onOptionsDepartmentSelected(event: any) {
    const value = event.target.value;
    this.department_Id = value;
  }




  onOptionsItemCategorySelected(event: any) {
    const value = event.target.value;
    this.itemcategoryId = value;
  }

  onItemChange(event: any) {


    // alert(event.target.value);

    const value = event.target.value;
    this.assetReportRadio = value;

    if (event.target.value == 'Asset/AssetReturnReportExport') {
      this.showControl_Company = true;
      this.showControl_CompanyUnit = true;
      this.showControl_Department = true;
      this.showControl_Custodian = true;
      this.showControl_SubCustodian = true;
      this.showControl_ItemCategory = true;
      this.showControl_EmployeeCode = false;
      this.ValueReset();
    } else if (event.target.value == 'Asset/TotalAssetsReportExport') {
      this.showControl_Company = true;
      this.showControl_CompanyUnit = true;
      this.showControl_Department = true;
      this.showControl_Custodian = true;
      this.showControl_SubCustodian = true;
      this.showControl_ItemCategory = true;
      this.showControl_EmployeeCode = true;
      this.ValueReset();
    } else if (event.target.value == 'Asset/IntransibleAssetReportExport') {
      this.showControl_Company = true;
      this.showControl_CompanyUnit = true;
      this.showControl_Department = true;
      this.showControl_Custodian = true;
      this.showControl_SubCustodian = true;
      this.showControl_ItemCategory = true;
      this.showControl_EmployeeCode = true;
      this.ValueReset();
    } else if (event.target.value == 'Asset/AssetReportByCompanyExport') {
      this.showControl_Company = false;
      this.showControl_CompanyUnit = false;
      this.showControl_Department = false;
      this.showControl_Custodian = false;
      this.showControl_SubCustodian = false;
      this.showControl_ItemCategory = false;
      this.showControl_EmployeeCode = true;
      this.ValueReset();
    } else if (event.target.value == 'Asset/AssetReportByCompanyUnitExport') {
      this.showControl_Company = false;
      this.showControl_CompanyUnit = false;
      this.showControl_Department = false;
      this.showControl_Custodian = false;
      this.showControl_SubCustodian = false;
      this.showControl_ItemCategory = false;
      this.showControl_EmployeeCode = true;
      this.ValueReset();
    } else if (event.target.value == 'Asset/AssetReportByItemCategoryExport') {
      this.showControl_Company = false;
      this.showControl_CompanyUnit = false;
      this.showControl_Department = false;
      this.showControl_Custodian = false;
      this.showControl_SubCustodian = false;
      this.showControl_ItemCategory = false;
      this.showControl_EmployeeCode = true;
      this.ValueReset();
    } else if (event.target.value == 'Asset/AssetReportByCompanyRegisterExport') {
      this.showControl_Company = false;
      this.showControl_CompanyUnit = false;
      this.showControl_Department = false;
      this.showControl_Custodian = false;
      this.showControl_SubCustodian = false;
      this.showControl_ItemCategory = false;
      this.showControl_EmployeeCode = true;
      this.ValueReset();
    } else if (event.target.value == 'Asset/AssetReportByItemCategoryStockExport') {
      this.showControl_Company = false;
      this.showControl_CompanyUnit = false;
      this.showControl_Department = false;
      this.showControl_Custodian = false;
      this.showControl_SubCustodian = false;
      this.showControl_ItemCategory = false;
      this.showControl_EmployeeCode = true;
      this.ValueReset();
    } else if (event.target.value == 'Asset/AssetReportByDepartmentExport') {
      this.showControl_Company = false;
      this.showControl_CompanyUnit = false;
      this.showControl_Department = false;
      this.showControl_Custodian = false;
      this.showControl_SubCustodian = false;
      this.showControl_ItemCategory = false;
      this.showControl_EmployeeCode = true;
      this.ValueReset();
    } else if (event.target.value == 'Asset/AssetReportByCustodianExport') {
      this.showControl_Company = false;
      this.showControl_CompanyUnit = false;
      this.showControl_Department = false;
      this.showControl_Custodian = false;
      this.showControl_SubCustodian = false;
      this.showControl_ItemCategory = false;
      this.showControl_EmployeeCode = true;
      this.ValueReset();
    } else if (event.target.value == 'Asset/GroupAssetsSummaryReportExport') {
      this.showControl_Company = false;
      this.showControl_CompanyUnit = false;
      this.showControl_Department = false;
      this.showControl_Custodian = false;
      this.showControl_SubCustodian = false;
      this.showControl_ItemCategory = false;
      this.showControl_EmployeeCode = true;
      this.ValueReset();
    } else if (event.target.value == 'Asset/AssetsSummaryReportExport') {
      this.showControl_Company = false;
      this.showControl_CompanyUnit = false;
      this.showControl_Department = false;
      this.showControl_Custodian = false;
      this.showControl_SubCustodian = false;
      this.showControl_ItemCategory = false;
      this.showControl_EmployeeCode = true;
      this.ValueReset();
    } else if (event.target.value == 'Asset/GroupAssetsSummaryReportIntangibleExport') {
      this.showControl_Company = false;
      this.showControl_CompanyUnit = false;
      this.showControl_Department = false;
      this.showControl_Custodian = false;
      this.showControl_SubCustodian = false;
      this.showControl_ItemCategory = false;
      this.showControl_EmployeeCode = true;
      this.ValueReset();
    }


    else {
      this.showControl_Company = false;
      this.showControl_CompanyUnit = false;
      this.showControl_Department = false;
      this.showControl_Custodian = false;
      this.showControl_SubCustodian = false;
      this.showControl_ItemCategory = false;
      this.showControl_EmployeeCode = false;
      this.ValueReset();
    }




  }

  ValueReset() {
    this.itemcategoryId = 0;
    this.department_Id = 0;
    this.unit_Id = 0;
    this.subcustodian_Id = 0;
    this.custodian_Id = 0;
    this.companyId = 0;

  }


  filter(val: string): Observable<any> {

    const formData = new FormData();
    formData.append('employee_Id', val);

    return this._apiService.getEmployeesFiltered(formData)

      .pipe(

        map(response => response.filter((option: { employee_Id: string; }) => {

          return option.employee_Id.toLowerCase().indexOf(val.toLowerCase()) !== -1

        }))

      )

  }


  btnPdf() {
    this.reportName = this.endpoint + this.assetReportRadio + "?FileType=pdf&ContentType=application/pdf&companyId="
      + this.companyId + "&UnitId=" + this.unit_Id + "&DepartmentId=" + this.department_Id + "&CustodianId=" + this.custodian_Id
      + "&SubCustodianId=" + this.subcustodian_Id + "&AssetItemId=" + this.itemcategoryId + "&EmployeeCode=" + this.employee_Code;
    return window.open(this.reportName, "_blank");

  }

  onSelFunc(option: any) {
    if (option.id > 0) {
      this._apiService.getEmployeeById(option.id)
        .subscribe((data: any) => {
          this.employee_Code = data.employee_Id;

        });
    }
  }


  btnExcel() {
    this.reportName = this.endpoint + this.assetReportRadio + "?FileType=Excel&ContentType=application/vnd.ms-excel&companyId="
      + this.companyId + "&UnitId=" + this.unit_Id + "&DepartmentId=" + this.department_Id + "&CustodianId=" + this.custodian_Id
      + "&SubCustodianId=" + this.subcustodian_Id + "&AssetItemId=" + this.itemcategoryId + "&EmployeeCode=" + this.employee_Code;
    return window.open(this.reportName, "_blank");
  }

  gotoBack() {
    this.router.navigate(['/home']);
  }

}
