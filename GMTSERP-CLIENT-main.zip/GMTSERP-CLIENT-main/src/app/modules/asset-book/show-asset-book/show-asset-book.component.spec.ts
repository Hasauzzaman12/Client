import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowAssetBookComponent } from './show-asset-book.component';

describe('ShowAssetBookComponent', () => {
  let component: ShowAssetBookComponent;
  let fixture: ComponentFixture<ShowAssetBookComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ShowAssetBookComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ShowAssetBookComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
