import { HttpClient, HttpEventType, HttpRequest } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable, of,startWith, debounceTime, distinctUntilChanged, switchMap, map } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';
import { DatePipe } from '@angular/common';
import { SD } from 'src/environments/sd';
import { ShowAssetEmployeeComponent } from '../../asset-employee/show-asset-employee/show-asset-employee.component';


@Component({
  selector: 'app-show-asset-book',
  templateUrl: './show-asset-book.component.html',
  styleUrls: ['./show-asset-book.component.scss']
})
export class ShowAssetBookComponent implements OnInit {

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';
  public selectedOption: any;

  constructor(public _apiService: ApiServiceService, public dialog: MatDialog,
    private _snackBar: MatSnackBar,
    public router: Router,
    private authservice: AuthService,
    private currentRoute: ActivatedRoute,
    private datepipe: DatePipe) { }

    newBlogForm!: FormGroup;
    id: number = 0;
    asset_Item_Id: number = 0;
    item_Name= '';
    asset_Owner_Id: number = 1;
    item_Description: string = '';
    model_No: string = '';
    sR_No: string = '';
    brand_Name: string = '';
    generation: string = '';
    origin: string = '';
    serial_No: string = '';
    processor: string = '';
    motherboard: string = '';
    ram: string = '';
    item_Type: string = '';
    bus_Speed: string = '';
    addition_Ram: string = '';
    storage_SSD: string = '';
    storage_Sata: string = '';
    addition_Storage: string = '';
    adapter_Serial_No: string = '';
    size: string = '';
    color: string = '';
    va: string = '';
    backup_Duration: number = 0;
    asset_No: string = '';
    is_Warranty: boolean = false;
    warranty_Start_Date : any;
    warranty_End_Date : any;
    warranty_For: string = '';
    supplier_Id: number = 0;
    purchase_Date : any;
    purchase_Price: number = 0;
    purchase_Qty: number = 1;
    pO_No: string = '';
    uom_Id: number = 1;
    ram_Type: string = '';
    monitor_Type: string = '';
    mouse_Type: string = '';
    keyboard_Type: string = '';
    status: string = '';
    company_Id: number = 0;
    unit_Id: number = 0;
    user_Id: number = this.authservice.getUserId;
  
 

    assetItemList$!: Observable<any[]>;
    assetOwnerList$!: Observable<any[]>;
    supplierList$!: Observable<any[]>;
    uomList$!: Observable<any[]>;
    companyList$!:Observable<any[]>;
    unitList$!:Observable<any[]>;
    ramTypeList$!:Observable<any[]>;
    monitorTypeList$!:Observable<any[]>;
    keyboardTypeList$!:Observable<any[]>;
    mouseTypeList$!:Observable<any[]>;

    allocation_list: any[] = [];
    maintenance_list: any[] = [];
    spare_part_list: any[] = [];
    attchament_list: any[] = []

    //View Control
    isModelNoShow: boolean = false;
    isBrand_NameShow: boolean = false;
    isGenerationShow: boolean = false;
    iSoriginShow: boolean = false;
    isSerial_NoShow: boolean = false;
    isProcessorShow: boolean = false;
    isMotherboardShow: boolean = false;
    isRamShow: boolean = false;
    isItem_TypeShow: boolean = false;
    isBus_SpeedShow: boolean = false;
    isAddition_RamShow: boolean = false;
    isStorage_SSDShow: boolean = false;
    isStorage_SataShow: boolean = false;
    isAddition_StorageShow: boolean = false;
    isAdapter_Serial_NoShow: boolean = false;
    isSizeShow: boolean = false;
    isColorShow: boolean = false;
    isVaShow: boolean = false;
    isBackup_DurationShow: boolean = false;
    isRamTypeShow: boolean = false;
    isMonitorTypeShow: boolean = false;
    isMouseTypeShow: boolean = false;
    isKeyboardTypeShow: boolean = false;

  ngOnInit(): void {
    this.newBlogForm = new FormGroup({
      id: new FormControl(0),
      asset_Item_Id: new FormControl({value: this.asset_Item_Id, disabled: true}),
      asset_Owner_Id: new FormControl({value: this.asset_Owner_Id, disabled: true}),
      item_Description: new FormControl(''),
      model_No: new FormControl(''),
      brand_Name: new FormControl(''),
      generation: new FormControl(''),
      origin: new FormControl(''),
      serial_No: new FormControl(''),
      processor: new FormControl(''),
      motherboard: new FormControl(''),
      ram: new FormControl(''),
      item_Type: new FormControl(''),
      bus_Speed: new FormControl(''),
      addition_Ram: new FormControl(''),
      storage_SSD: new FormControl(''),
      storage_Sata: new FormControl(''),
      addition_Storage: new FormControl(''),
      adapter_Serial_No: new FormControl(''),
      size: new FormControl(''),
      color: new FormControl(''),
      va: new FormControl(''),
      backup_Duration: new FormControl(0),
      asset_No: new FormControl(''),
      is_Warranty: new FormControl(''),
      warranty_Start_Date: new FormControl(null),
      warranty_End_Date: new FormControl(null),
      supplier_Id: new FormControl({value: this.supplier_Id, disabled: true}),
      purchase_Date: new FormControl(null),
      purchase_Price: new FormControl(0),
      purchase_Qty: new FormControl(1),
      pO_No: new FormControl(''),
      uom_Id: new FormControl({value: this.uom_Id, disabled: true}),
      ram_Type: new FormControl({value: '', disabled: true}),
      monitor_Type: new FormControl({value: '', disabled: true}),
      mouse_Type: new FormControl({value: '', disabled: true}),
      keyboard_Type: new FormControl({value: '', disabled: true}),
      status: new FormControl(''),
      company_Id: new FormControl({value: this.company_Id, disabled: true}),
      unit_Id: new FormControl({value: this.unit_Id, disabled: true}),
    });

    // this.assetItemList$ = this._apiService.getAssetItemList();
    this.assetItemList$ = this._apiService.getAssetItemByOwner(this.asset_Owner_Id);
    this.assetOwnerList$=this._apiService.getAssetOwnerList();
    this.supplierList$=this._apiService.getSuulierList();
    this.uomList$=this._apiService.getUOMList();
    if(this.user_Id>0){
      this.companyList$ = this._apiService.getCompanyListByUser(this.user_Id);
    }else{
      this.companyList$ = this._apiService.getCompanyList();
    }
    // this.unitList$=this._apiService.getUnitList();
    this.ramTypeList$=this._apiService.getAssetRamTypeList();
    this.monitorTypeList$=this._apiService.getAssetMonitorTypeList();
    this.keyboardTypeList$=this._apiService.getAssetKeyboardTypeList();
    this.mouseTypeList$=this._apiService.getAssetMouseTypeList();

    let id = this.currentRoute.snapshot.paramMap.get('id');
    if (id != null) {
      this.getAssetBookById(id);
      
    }
    
  }
  getAssetBookById(id: number | string) {
   
    this._apiService.getAssetBookById(id).subscribe((data: any) => {
    
      this.setPageView(data.asset_Item_Id);
      this.allocation_list = data.allocationList;
      this.maintenance_list = data.maintenanceList;
      this.spare_part_list=data.assetBookSparePartList;
      this.attchament_list = data.attachmentList;

      this.id=data.id;
      this.asset_Item_Id=data.asset_Item_Id;
      this.asset_Owner_Id=data.asset_Owner_Id;
      this.item_Description=data.item_Description;
      this.model_No=data.model_No;
      this.brand_Name=data.brand_Name;
      this.generation=data.generation;
      this.origin=data.origin;
      this.serial_No=data.serial_No;
      this.processor=data.processor;
      this.motherboard=data.motherboard;
      this.ram=data.ram;
      this.item_Type=data.item_Type;
      this.bus_Speed=data.bus_Speed;
      this.addition_Ram=data.addition_Ram;
      this.storage_SSD=data.storage_SSD;
      this.storage_Sata=data.storage_Sata;
      this.addition_Storage=data.addition_Storage;
      this.adapter_Serial_No=data.adapter_Serial_No;
      this.size=data.size;
      this.color=data.color;
      this.va=data.va;
      this.backup_Duration=data.backup_Duration;
      this.asset_No=data.asset_No;
      this.is_Warranty=data.is_Warranty;
      this.warranty_Start_Date=data.warranty_Start_Date;
      this.warranty_End_Date=data.warranty_End_Date;
      this.supplier_Id=data.supplier_Id;
      this.purchase_Date=data.purchase_Date;
      this.purchase_Price=data.purchase_Price;
      this.purchase_Qty=data.purchase_Qty;
      this.pO_No=data.pO_No;
      this.ram_Type=data.ram_Type;
      this.monitor_Type=data.monitor_Type;
      this.mouse_Type=data.mouse_Type;
      this.keyboard_Type=data.keyboard_Type;
      this.status=data.status;
      this.uom_Id=data.uom_Id;
      this.company_Id=data.company_Id;
      this.unit_Id=data.unit_Id;

      this.unitList$=this._apiService.getUnitListByCompanyId(this.company_Id);
      this.calculateDiff(data);
    });
   this.assetItemList$ = this._apiService.getAssetItemByOwner(this.asset_Owner_Id);
  
  }
  calculateDiff(data: any){
    if (data.warranty_Start_Date!= null && data.warranty_End_Date!= null && this.is_Warranty==true)
    {
      var date1 = new Date(data.warranty_Start_Date);
      var date2 = new Date(data.warranty_End_Date);
     
      if(date2.getTime()> date1.getTime()){
        var diff = Math.abs(date2.getTime() - date1.getTime());
        var diffDays = Math.ceil(diff / (1000 * 3600 * 24)); 
  
        var years = Math.floor(diffDays/365);
        var months = Math.floor(diffDays/30);
        if(months>=12){
          months=Math.floor(months/12);
        }
        var day = Math.floor(diffDays%30);
  
        var message = "";
        years>0 ? message += years + " Years "  : ''
        months>0 ? message += months + " Months "  : ''
        day>0 ? message += day + " Day "  : ''

        this.warranty_For=message;
      }else{
       
        alert('Invalid Date');
      }
      
    }
  }

  changeOwner(event: any) {
    if(event.target.value>0){
      this.assetItemList$ = this._apiService.getAssetItemByOwner(event.target.value);
    }
  }
 

changeItemWiseView(event: any) {
  if(event.target.value>0){
    this.setPageView(event.target.value);
    this._apiService.getAssetItemById(event.target.value)
    .subscribe((data: any) => {
      this.item_Description='';
      this.item_Description+=data.item_Name;
      this.item_Name='';
      this.item_Name+=data.item_Name;
      
    });
  }
}

setPageView(itemId: number | string) {

  if(itemId==SD.asseet_brand_PC_Id){ 
    this.resetPageView();
    this.isModelNoShow=true;this.isBrand_NameShow=true;this.isGenerationShow=true;
    this.iSoriginShow=true;this.isSerial_NoShow=true; this.isProcessorShow=true;
    this.isRamShow=true; this.isBus_SpeedShow=true;this.isAddition_RamShow=true;
    this.isStorage_SSDShow=true;this.isStorage_SataShow=true; this.isAddition_StorageShow=true; this.isRamTypeShow=true;this.isMonitorTypeShow=true;
  }
  else if(itemId==SD.asseet_clone_PC_Id){ 
    this.resetPageView();
    this.isGenerationShow=true;this.isMotherboardShow=true;
    this.isRamShow=true; this.isBus_SpeedShow=true;this.isAddition_RamShow=true;this.isProcessorShow=true;
    this.isStorage_SSDShow=true;this.isStorage_SataShow=true; this.isAddition_StorageShow=true;this.isRamTypeShow=true;this.isMonitorTypeShow=true;
  }
  else if(itemId==SD.asseet_laptop){ 
    this.resetPageView();
    this.isModelNoShow=true;this.isBrand_NameShow=true;this.isGenerationShow=true;this.iSoriginShow=true;this.isSerial_NoShow=true; this.isProcessorShow=true;
    this.isRamShow=true;this.isBus_SpeedShow=true;this.isAddition_RamShow=true;this.isStorage_SSDShow=true;this.isStorage_SataShow=true; this.isAddition_StorageShow=true;this,this.isAdapter_Serial_NoShow=true;this.isRamTypeShow=true;
  }
  else if(itemId==SD.asseet_monitor){ 
    this.resetPageView();
    this.isModelNoShow=true;this.isMonitorTypeShow=true;this.isBrand_NameShow=true;this.isSerial_NoShow=true;this.isAdapter_Serial_NoShow=true;this.isSizeShow=true;this.isColorShow=true;
  }
  else if(itemId==SD.asseet_ups){ 
    this.resetPageView();
    this.isBrand_NameShow=true;this.isVaShow=true;this.isBackup_DurationShow=true;this.isSerial_NoShow=true;
  }
  else if(itemId==SD.asseet_mouse){ 
    this.resetPageView();
    this.isBrand_NameShow=true;this.isMouseTypeShow=true;
  }
  else if(itemId==SD.asseet_keyboard){ 
    this.resetPageView();
    this.isBrand_NameShow=true;this.isKeyboardTypeShow=true;
  }
  else if(itemId==SD.asseet_multiplug){ 
    this.resetPageView();
    this.isBrand_NameShow=true;this.isItem_TypeShow=true;
  }
  else if(itemId==SD.asseet_mobile){ 
    this.resetPageView();
    this.isModelNoShow=true;this.isBrand_NameShow=true;this.iSoriginShow=true;this.isSerial_NoShow=true;
  }
  else if(itemId==SD.asseet_online_UPS){ 
    this.resetPageView();
    this.isModelNoShow=true;this.isBrand_NameShow=true;this.iSoriginShow=true;this.isSerial_NoShow=true;this.isItem_TypeShow=true;this.isVaShow=true;
  }}

resetPageView() {
    this.isModelNoShow=false;this.isBrand_NameShow=false;this.isGenerationShow=false;
    this.iSoriginShow=false;this.isSerial_NoShow=false; this.isProcessorShow=false;this.isMotherboardShow=false;
    this.isRamShow=false;this.isItem_TypeShow=false; this.isBus_SpeedShow=false;this.isAddition_RamShow=false;
    this.isStorage_SSDShow=false;this.isStorage_SataShow=false; this.isAddition_StorageShow=false;this.isAdapter_Serial_NoShow=false;
    this.isSizeShow=false;this.isColorShow=false; this.isVaShow=false;this.isBackup_DurationShow=false;this.isRamTypeShow=false;this.isMonitorTypeShow=false;
    this.isKeyboardTypeShow=false;this.isMouseTypeShow=false;
  }
  changeItemDescription(formValue: any) {
   
    if(formValue.asset_Item_Id==SD.asseet_brand_PC_Id || formValue.asset_Item_Id==SD.asseet_clone_PC_Id ||formValue.asset_Item_Id==SD.asseet_laptop){ 
      this.item_Description=this.item_Name+' '+formValue.brand_Name+' '+formValue.processor+' '+formValue.generation;
    }
    else if(formValue.asset_Item_Id==SD.asseet_monitor){ 
      this.item_Description=this.item_Name+' '+formValue.brand_Name+' '+formValue.item_Type+' '+formValue.size;
    }
    else if(formValue.asset_Item_Id==SD.asseet_mouse){ 
      this.item_Description=this.item_Name+' '+formValue.brand_Name+' '+formValue.mouse_Type;
    }
    else if(formValue.asset_Item_Id==SD.asseet_keyboard){ 
      this.item_Description=this.item_Name+' '+formValue.brand_Name+' '+formValue.keyboard_Type;
    }
    else if(formValue.asset_Item_Id==SD.asseet_multiplug){ 
      this.item_Description=this.item_Name+' '+formValue.brand_Name+' '+formValue.item_Type;
    }
    else if(formValue.asset_Item_Id==SD.asseet_ups||formValue.asset_Item_Id==SD.asseet_online_UPS){ 
      this.item_Description=this.item_Name+' '+formValue.brand_Name+' '+formValue.va;
    }
    else if(formValue.asset_Item_Id==SD.asseet_mobile){ 
      this.item_Description=this.item_Name+' '+formValue.brand_Name+' '+formValue.model_No;
    }
  // this._apiService.getAssetItemDescription(formValue)
      // .subscribe((data: any) => {
      //   // console.log(data);
      //   this.item_Description=data.item_Description;
      // });
  }

      

isValidForm(data: any): boolean {

  let isValid:boolean = true;

  if(data.asset_Item_Id==SD.asseet_brand_PC_Id){
    if (data.model_No == ''||data.model_No == null){
      alert("Model No is Required")
      isValid=false;
    }
    else if (data.brand_Name == ''||data.brand_Name == null){
      alert("Brand No is Required")
      isValid=false;
    }
    else if (data.generation == ''||data.generation == null){
      alert("Generation is Required")
      isValid=false;
    }
    else if (data.origin == ''||data.origin == null){
      alert("Origin is Required")
      isValid=false;
    }
    else if (data.serial_No == ''||data.serial_No == null){
      alert("Serial No is Required")
      isValid=false;
    }
    else if (data.processor == ''||data.processor == null){
      alert("processor is Required")
      isValid=false;
    }
   
    else if (data.ram == ''||data.ram == null){
      alert("Ram is Required")
      isValid=false;
    }
    else if (data.bus_Speed == ''||data.bus_Speed == null){
      alert("Bus Speed is Required")
      isValid=false;
    }
    else if (data.addition_Ram == ''||data.addition_Ram == null){
      alert("Addition Ram is Required")
      isValid=false;
    }
    else if (data.storage_SSD == ''||data.storage_SSD == null){
      alert("Storage SSD is Required")
      isValid=false;
    }
    else if (data.storage_Sata == ''||data.storage_Sata == null){
      alert("Storage Sata is Required")
      isValid=false;
    }
    else if (data.addition_Storage == ''||data.addition_Storage == null){
      alert("Addition Storage is Required")
      isValid=false;
    }
    else if (data.ram_Type == ''||data.ram_Type == null){
      alert("RAM Type is Required")
      isValid=false;
    }
    else if (data.monitor_Type == ''||data.monitor_Type == null){
      alert("Monitor Type is Required")
      isValid=false;
    }

  }
  else if(data.asset_Item_Id==SD.asseet_clone_PC_Id){ 
  
    if (data.generation == ''||data.generation == null){
      alert("Generation is Required")
      isValid=false;
    }
    else if (data.motherboard == ''||data.motherboard == null){
      alert("Motherboard is Required")
      isValid=false;
    }
    else if (data.ram == ''||data.ram == null){
      alert("Ram is Required")
      isValid=false;
    }
    else if (data.bus_Speed == ''||data.bus_Speed == null){
      alert("Bus Speed is Required")
      isValid=false;
    }
    else if (data.addition_Ram == ''||data.addition_Ram == null){
      alert("Addition Ram is Required")
      isValid=false;
    }
    else if (data.storage_SSD == ''||data.storage_SSD == null){
      alert("Storage SSD is Required")
      isValid=false;
    }
    else if (data.storage_Sata == ''||data.storage_Sata == null){
      alert("Storage Sata is Required")
      isValid=false;
    }
    else if (data.addition_Storage == ''||data.addition_Storage == null){
      alert("Addition Storage is Required")
      isValid=false;
    }
    else if (data.ram_Type == ''||data.ram_Type == null){
      alert("RAM Type is Required")
      isValid=false;
    }
    else if (data.monitor_Type == ''||data.monitor_Type == null){
      alert("Monitor Type is Required")
      isValid=false;
    }
    else if (data.processor == ''||data.processor == null){
      alert("processor is Required")
      isValid=false;
    }
  }
  else if(data.asset_Item_Id==SD.asseet_laptop){ 
    if (data.model_No == ''||data.model_No == null){
      alert("Model No is Required")
      isValid=false;
    }
    else if (data.brand_Name == ''||data.brand_Name == null){
      alert("Brand No is Required")
      isValid=false;
    }
    else if (data.generation == ''||data.generation == null){
      alert("Generation is Required")
      isValid=false;
    }
    else if (data.origin == ''||data.origin == null){
      alert("Origin is Required")
      isValid=false;
    }
    else if (data.serial_No == ''||data.serial_No == null){
      alert("Serial No is Required")
      isValid=false;
    }
    else if (data.processor == ''||data.processor == null){
      alert("processor is Required")
      isValid=false;
    }
    else if (data.ram == ''||data.ram == null){
      alert("Ram is Required")
      isValid=false;
    }
    
    else if (data.bus_Speed == ''||data.bus_Speed == null){
      alert("Bus Speed is Required")
      isValid=false;
    }
    else if (data.addition_Ram == ''||data.addition_Ram == null){
      alert("Addition Ram is Required")
      isValid=false;
    }
    else if (data.storage_SSD == ''||data.storage_SSD == null){
      alert("Storage SSD is Required")
      isValid=false;
    }
    else if (data.storage_Sata == ''||data.storage_Sata == null){
      alert("Storage Sata is Required")
      isValid=false;
    }
    else if (data.addition_Storage == ''||data.addition_Storage == null){
      alert("Addition Storage is Required")
      isValid=false;
    }
    else if (data.addition_Storage == ''||data.addition_Storage == null){
      alert("Addition Storage is Required")
      isValid=false;
    }
    else if (data.adapter_Serial_No == ''||data.adapter_Serial_No == null){
      alert("Adapter Serial No is Required")
      isValid=false;
    }
    else if (data.ram_Type == ''||data.ram_Type == null){
      alert("RAM Type is Required")
      isValid=false;
    }
  }
  else if(data.asset_Item_Id==SD.asseet_monitor){ 
    if (data.model_No == ''||data.model_No == null){
      alert("Model No is Required")
      isValid=false;
    }
    else if (data.brand_Name == ''||data.brand_Name == null){
      alert("Brand No is Required")
      isValid=false;
    }
    else if (data.serial_No == ''||data.serial_No == null){
      alert("Serial No is Required")
      isValid=false;
    }
    else if (data.monitor_Type == ''||data.monitor_Type == null){
      alert("Monitor Type is Required")
      isValid=false;
    }
    else if (data.adapter_Serial_No == ''||data.adapter_Serial_No == null){
      alert("Adapter Serial No is Required")
      isValid=false;
    }
    else if (data.size == ''||data.size == null){
      alert("Size is Required")
      isValid=false;
    }
    else if (data.color == ''||data.color == null){
      alert("Color is Required")
      isValid=false;
    }
  }
  else if(data.asset_Item_Id==SD.asseet_ups){ 
    if (data.brand_Name == ''||data.brand_Name == null){
      alert("Brand No is Required")
      isValid=false;
    } 
    else if (data.va == ''||data.va == null){
      alert("VA is Required")
      isValid=false;
    }
    else if (data.serial_No == ''||data.serial_No == null){
      alert("Serial No is Required")
      isValid=false;
    }
    else if (data.backup_Duration == ''||data.backup_Duration == null){
      alert("Backup Duration is Required")
      isValid=false;
    }
  }
  else if(data.asset_Item_Id==SD.asseet_mouse){ 
    if (data.brand_Name == ''||data.brand_Name == null){
      alert("Brand No is Required")
      isValid=false;
    } 
    else if (data.mouse_Type == ''||data.mouse_Type == null){
      alert("Mouse Type is Required")
      isValid=false;
    }
  }
  else if(data.asset_Item_Id==SD.asseet_keyboard){ 
    if (data.brand_Name == ''||data.brand_Name == null){
      alert("Brand No is Required")
      isValid=false;
    } 
    else if (data.keyboard_Type == ''||data.keyboard_Type == null){
      alert("Keyboard Type is Required")
      isValid=false;
    }
  }
  else if(data.asset_Item_Id==SD.asseet_multiplug){ 
    if (data.brand_Name == ''||data.brand_Name == null){
      alert("Brand No is Required")
      isValid=false;
    } 
    else if (data.item_Type == ''||data.item_Type == null){
      alert("Item Type is Required")
      isValid=false;
    }
  }
  else if(data.asset_Item_Id==SD.asseet_mobile){ 
    if (data.model_No == ''||data.model_No == null){
      alert("Model No is Required")
      isValid=false;
    }
    else if (data.brand_Name == ''||data.brand_Name == null){
      alert("Brand No is Required")
      isValid=false;
    }
    else if (data.origin == ''||data.origin == null){
      alert("Origin is Required")
      isValid=false;
    }
    else if (data.serial_No == ''||data.serial_No == null){
      alert("Serial No is Required")
      isValid=false;
    }
  }
  else if(data.asset_Item_Id==SD.asseet_online_UPS){ 
    if (data.model_No == ''||data.model_No == null){
      alert("Model No is Required")
      isValid=false;
    }
    else if (data.brand_Name == ''||data.brand_Name == null){
      alert("Brand No is Required")
      isValid=false;
    }
    else if (data.origin == ''||data.origin == null){
      alert("Origin is Required")
      isValid=false;
    }
    else if (data.serial_No == ''||data.serial_No == null){
      alert("Serial No is Required")
      isValid=false;
    }
    else if (data.item_Type == ''||data.item_Type == null){
      alert("Item Type is Required")
      isValid=false;
    }
    else if (data.va == ''||data.va == null){
      alert("VA is Required")
      isValid=false;
    }
  }

  return isValid; 
  }
  changeUnit(event: any) {
    
    this.unitList$=this._apiService.getUnitListByCompanyId(event.target.value);
   
  }
   onSelectChildFile(data: any, fileInput: any) {
    data.attachmentFile = <File>fileInput.target.files[0];
    data.attachment_Id = 0;
  }
 
  gotoBack() {
    this.router.navigate(['/asset-book']);
  }



  openAssetEmployeeForView(id: number) {
    this.router.navigate([]).then((result) => {
      window.open('/#/asset-employee/detail/' + id, '_blank');
    });
  }
}
