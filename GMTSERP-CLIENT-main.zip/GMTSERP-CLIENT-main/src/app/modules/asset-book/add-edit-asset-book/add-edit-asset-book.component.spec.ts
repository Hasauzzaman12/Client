import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditAssetBookComponent } from './add-edit-asset-book.component';

describe('AddEditAssetBookComponent', () => {
  let component: AddEditAssetBookComponent;
  let fixture: ComponentFixture<AddEditAssetBookComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddEditAssetBookComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddEditAssetBookComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
