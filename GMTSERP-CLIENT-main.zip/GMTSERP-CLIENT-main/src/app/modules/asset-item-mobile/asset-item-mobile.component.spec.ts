import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetItemMobileComponent } from './asset-item-mobile.component';

describe('AssetItemMobileComponent', () => {
  let component: AssetItemMobileComponent;
  let fixture: ComponentFixture<AssetItemMobileComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AssetItemMobileComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AssetItemMobileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
