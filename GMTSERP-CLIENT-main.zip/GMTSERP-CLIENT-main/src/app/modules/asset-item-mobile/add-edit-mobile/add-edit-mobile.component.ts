import { HttpClient, HttpEventType, HttpRequest } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable, of,startWith, debounceTime, distinctUntilChanged, switchMap, map } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';
import { DatePipe } from '@angular/common';
import { SD } from 'src/environments/sd';

@Component({
  selector: 'app-add-edit-mobile',
  templateUrl: './add-edit-mobile.component.html',
  styleUrls: ['./add-edit-mobile.component.scss']
})
export class AddEditMobileComponent implements OnInit {

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';

  constructor(public _apiService: ApiServiceService,
    private _snackBar: MatSnackBar,
    public router: Router,
    private authservice: AuthService,
    private currentRoute: ActivatedRoute,
    private datepipe: DatePipe) {  }


    newBlogForm!: FormGroup;
    id: number = 0;
    item_Name= '';
    asset_Owner_Id: number = 1;
    company_Id: number = 0;
    user_Id: number = this.authservice.getUserId;
    is_Active: boolean = true;
    asset_Item_Category_Id: number = SD.asset_Item_Category_Id_sim;

    mobile_No= '';
    mobile_Service_Provider= 'GP';

    assetOwnerList$!: Observable<any[]>;
    companyList$!:Observable<any[]>;

  ngOnInit(): void {
    this.newBlogForm = new FormGroup({
      id: new FormControl(0),
      item_Name: new FormControl(''),
      asset_Owner_Id: new FormControl({value: this.asset_Owner_Id, disabled: true}),
      company_Id: new FormControl(0),
      is_Active: new FormControl(true),
      asset_Item_Category_Id: new FormControl(0),
      mobile_No: new FormControl(''),
      mobile_Service_Provider: new FormControl(''),

    });

    this.assetOwnerList$=this._apiService.getAssetOwnerList();
    if(this.user_Id>0){
      this.companyList$ = this._apiService.getCompanyListByUser(this.user_Id);
    }else{
      this.companyList$ = this._apiService.getCompanyList();
    }
    
    let id = this.currentRoute.snapshot.paramMap.get('id');
    if (id != null) {
      this.getAssetItemById(id);
      
    }
  }

  getAssetItemById(id: number | string) {
   
    this._apiService.getAssetItemnById(id).subscribe((data: any) => {
      this.id=data.id;
      this.item_Name=data.item_Name;
      this.asset_Owner_Id=data.asset_Owner_Id;
      this.company_Id=data.company_Id;
      this.is_Active=data.is_Active;
      this.asset_Item_Category_Id=data.asset_Item_Category_Id;
      this.mobile_No=data.mobile_No;
      this.mobile_Service_Provider=data.mobile_Service_Provider;
    });
  
  }

  onSubmit(data: any) {
    data.id=this.id;
    data.asset_Owner_Id=this.asset_Owner_Id;
    data.asset_Item_Category_Id=this.asset_Item_Category_Id;

    const formData = new FormData();

    if (data.company_Id == 0||data.company_Id == null) {
      alert("Company is Required")
      return;
    }
    if (data.item_Name == ''||data.item_Name == null) {
      alert("Mobile Number is Required")
      return;
    }

    formData.append('id', data.id);
    formData.append('item_Name', data.item_Name == null ? '' : data.item_Name);
    formData.append('asset_Owner_Id', data.asset_Owner_Id);
    formData.append('company_Id', data.company_Id);
    formData.append('is_Active', data.is_Active);
    formData.append('asset_Item_Category_Id', data.asset_Item_Category_Id);
    formData.append('mobile_No', data.item_Name == null ? '' : data.item_Name);
    formData.append('mobile_Service_Provider', data.mobile_Service_Provider == null ? '' : data.mobile_Service_Provider);
    

    if (this.newBlogForm.valid) {
      if (data.id != 0) {
  
        this._apiService.updateAssetItem(formData).subscribe(res => {
  
          this._snackBar.open("Asset Item Updated Successfully", "Update", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });
  
          this.router.navigate(['/asset-item-mobile']);
  
  
        })
      }
      else {
        this._apiService.addAssetItem(formData).subscribe(res => {
  
          this._snackBar.open("Asset Item Saved Successfully", "Success", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });
  
          this.router.navigate(['/asset-item-mobile']);
  
  
        })
      }
    }
  }

  gotoBack() {
    this.router.navigate(['/asset-item-mobile']);
  }
  reset(): void {
    this.ngOnInit();
  }
}
