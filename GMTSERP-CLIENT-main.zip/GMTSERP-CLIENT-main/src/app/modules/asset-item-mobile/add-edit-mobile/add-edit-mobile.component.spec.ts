import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditMobileComponent } from './add-edit-mobile.component';

describe('AddEditMobileComponent', () => {
  let component: AddEditMobileComponent;
  let fixture: ComponentFixture<AddEditMobileComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddEditMobileComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddEditMobileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
