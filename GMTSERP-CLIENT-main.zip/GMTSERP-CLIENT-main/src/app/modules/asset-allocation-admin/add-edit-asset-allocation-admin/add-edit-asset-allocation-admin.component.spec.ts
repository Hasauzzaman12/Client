import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditAssetAllocationAdminComponent } from './add-edit-asset-allocation-admin.component';

describe('AddEditAssetAllocationAdminComponent', () => {
  let component: AddEditAssetAllocationAdminComponent;
  let fixture: ComponentFixture<AddEditAssetAllocationAdminComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddEditAssetAllocationAdminComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddEditAssetAllocationAdminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
