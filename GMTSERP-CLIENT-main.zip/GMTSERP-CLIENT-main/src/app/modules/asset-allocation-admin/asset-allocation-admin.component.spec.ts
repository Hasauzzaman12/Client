import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetAllocationAdminComponent } from './asset-allocation-admin.component';

describe('AssetAllocationAdminComponent', () => {
  let component: AssetAllocationAdminComponent;
  let fixture: ComponentFixture<AssetAllocationAdminComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AssetAllocationAdminComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AssetAllocationAdminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
