import { HttpClient, HttpEventType, HttpRequest } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable, of,startWith, debounceTime, distinctUntilChanged, switchMap, map } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-add-edit-asset-item',
  templateUrl: './add-edit-asset-item.component.html',
  styleUrls: ['./add-edit-asset-item.component.scss']
})
export class AddEditAssetItemComponent implements OnInit {
  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';

  constructor(public _apiService: ApiServiceService,
    private _snackBar: MatSnackBar,
    public router: Router,
    private authservice: AuthService,
    private currentRoute: ActivatedRoute,
    private datepipe: DatePipe) {  }

    newBlogForm!: FormGroup;
    id: number = 0;
    item_Name= '';
    asset_Owner_Id: number = 0;
    company_Id: number = 0;
    is_Active: boolean = true;
    asset_Item_Category_Id: number = 0;
    software_Name= '';
    software_Supplier_Id: number = 0;
    software_AMC: boolean = true;
    software_AMC_Start_Date : any;
    software_AMC_End_Date : any;
    software_No_Of_Users: number = 0;
    software_AMC_Amount: number = 0;
    email_Address= '';
    email_Create_Date : any;
    email_Expire_Date : any;
    mobile_No= '';
    mobile_Service_Provider= '';
    attachment_Id: number = 0;
    attachment_File_Name= '';
    selectedFile!: File;


  ngOnInit(): void {
    let currentDateTime =this.datepipe.transform((new Date), 'MM/dd/yyyy h:mm:ss');

    this.newBlogForm = new FormGroup({
      id: new FormControl(0),
      item_Name: new FormControl(''),
      asset_Owner_Id: new FormControl(0),
      company_Id: new FormControl(0),
      is_active: new FormControl(true),
      asset_Item_Category_Id: new FormControl(0),
      software_Name: new FormControl(''),
      software_Supplier_Id: new FormControl(0),
      software_AMC: new FormControl(true),
      software_AMC_Start_Date: new FormControl(null),
      software_AMC_End_Date: new FormControl(null),

      service_Amount: new FormControl(0),
      reason_Of_Maintenance: new FormControl(''),
      aprrox_Return_Date: new FormControl(null),
     
      attachment_Id: new FormControl(0),
    });
  }

}
