import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditAssetItemComponent } from './add-edit-asset-item.component';

describe('AddEditAssetItemComponent', () => {
  let component: AddEditAssetItemComponent;
  let fixture: ComponentFixture<AddEditAssetItemComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddEditAssetItemComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddEditAssetItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
