import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { ApiServiceService } from 'src/app/api-service.service';

@Component({
  selector: 'app-asset-item',
  templateUrl: './asset-item.component.html',
  styleUrls: ['./asset-item.component.scss']
})
export class AssetItemComponent implements OnInit {

  displayedColumns: string[] = ['asset_Owner_Name','asset_Item_Category_Name','item_Name','company_Name','is_Active','action'];
  dataSource!: MatTableDataSource<any>;

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';


  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(public _apiService: ApiServiceService,
    private _snackBar: MatSnackBar,
    public dialog: MatDialog,
    private router: Router) { }

  ngOnInit(): void {
    this.getAssetItemList();
  }

  getAssetItemList() {
    this._apiService.getAssetItemListN()
      .subscribe({
        next: (res) => {
          this.dataSource = new MatTableDataSource(res);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
        },
        error: (err) => {
          console.log("Error");
        }

      })
  }

  openForEdit(id: number) {

    this.router.navigate(['/asset-item/edit/' + id]);
  }
  gotoNew() {
    this.router.navigate(['/add-asset-item']);
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  // deleteAssetBook(id: number) {

  //   if (confirm("Are you sure to delete?")) {
  //     this._apiService.deleteAssetBook(id)
  //       .subscribe({
  //         next: (res) => {
  //           this._snackBar.open("Asset Book Deleted Successfully", "Delete", {
  //             horizontalPosition: this.horizontalPosition,
  //             verticalPosition: this.verticalPosition,
  //             duration: 1000
  //           });
  //           this.getAssetBookList();
  //         },
  //         error: () => {
  //           this._snackBar.open("Delete Failed", "Failed");
  //         }
  //       })
  //   }
  // }

}


