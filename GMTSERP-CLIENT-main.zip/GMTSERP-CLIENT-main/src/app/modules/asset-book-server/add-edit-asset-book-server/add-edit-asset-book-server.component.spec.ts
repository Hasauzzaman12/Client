import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditAssetBookServerComponent } from './add-edit-asset-book-server.component';

describe('AddEditAssetBookServerComponent', () => {
  let component: AddEditAssetBookServerComponent;
  let fixture: ComponentFixture<AddEditAssetBookServerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddEditAssetBookServerComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddEditAssetBookServerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
