import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowAssetBookServerComponent } from './show-asset-book-server.component';

describe('ShowAssetBookServerComponent', () => {
  let component: ShowAssetBookServerComponent;
  let fixture: ComponentFixture<ShowAssetBookServerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ShowAssetBookServerComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ShowAssetBookServerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
