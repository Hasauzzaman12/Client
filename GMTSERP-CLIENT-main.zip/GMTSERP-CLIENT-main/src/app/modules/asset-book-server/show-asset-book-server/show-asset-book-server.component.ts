import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-show-asset-book-server',
  templateUrl: './show-asset-book-server.component.html',
  styleUrls: ['./show-asset-book-server.component.scss']
})
export class ShowAssetBookServerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
