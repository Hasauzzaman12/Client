import { HttpClient, HttpEventType, HttpRequest } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable, of,startWith, debounceTime, distinctUntilChanged, switchMap, map } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-add-edit-asset-item-list',
  templateUrl: './add-edit-asset-item-list.component.html',
  styleUrls: ['./add-edit-asset-item-list.component.scss']
})
export class AddEditAssetItemListComponent implements OnInit {

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';

  constructor(public _apiService: ApiServiceService,
    private _snackBar: MatSnackBar,
    public router: Router,
    private authservice: AuthService,
    private currentRoute: ActivatedRoute,
    private datepipe: DatePipe) {  }


    newBlogForm!: FormGroup;
    id: number = 0;
    item_Name= '';
    asset_Owner_Id: number = 0;
    company_Id: number = 0;
    user_Id: number = this.authservice.getUserId;
    is_Active: boolean = true;
    asset_Item_Category_Id: number = 0;
    asset_Item_Group_Id: number = 0;
    display_Order: number = 0;



    assetOwnerList$!: Observable<any[]>;
    assetItemCategoryList$!: Observable<any[]>;
    companyList$!:Observable<any[]>;
    assetItemGroupList$!: Observable<any[]>;

  ngOnInit(): void {
    this.newBlogForm = new FormGroup({
      id: new FormControl(0),
      item_Name: new FormControl(''),
      asset_Owner_Id: new FormControl(0),
      company_Id: new FormControl(0),
      is_Active: new FormControl(true),
      asset_Item_Category_Id: new FormControl(0),
      asset_Item_Group_Id: new FormControl(0),
      mobile_No: new FormControl(''),
      display_Order: new FormControl(0),

    });

    this.assetOwnerList$=this._apiService.getAssetOwnerList();
    this.assetItemCategoryList$=this._apiService.getAssetItemCategoryList();
    this.assetItemGroupList$=this._apiService.getAssetItemGroupList();

    if(this.user_Id>0){
      this.companyList$ = this._apiService.getCompanyListByUser(this.user_Id);
    }else{
      this.companyList$ = this._apiService.getCompanyList();
    }
    
    let id = this.currentRoute.snapshot.paramMap.get('id');
    if (id != null) {
      this.getAssetItemById(id);
      
    }
  }

  getAssetItemById(id: number | string) {
   
    this._apiService.getAssetItemnById(id).subscribe((data: any) => {
      this.id=data.id;
      this.item_Name=data.item_Name;
      this.asset_Owner_Id=data.asset_Owner_Id;
      this.company_Id=data.company_Id;
      this.is_Active=data.is_Active;
      this.asset_Item_Category_Id=data.asset_Item_Category_Id;
      this.asset_Item_Group_Id=data.asset_Item_Group_Id;
      this.display_Order=data.display_Order;
    });
  
  }

  onSubmit(data: any) {

    data.id=this.id;

    const formData = new FormData();

    if (data.company_Id == 0||data.company_Id == null) {
      alert("Company is Required")
      return;
    }
    if (data.item_Name == ''||data.item_Name == null) {
      alert("Item Name is Required")
      return;
    }
    if (data.asset_Item_Category_Id == 0||data.asset_Item_Category_Id == null) {
      alert("Item Category is Required")
      return;
    }
    if (data.asset_Owner_Id == 0||data.asset_Owner_Id == null) {
      alert("Asset Owner is Required")
      return;
    }

    formData.append('id', data.id);
    formData.append('item_Name', data.item_Name == null ? '' : data.item_Name);
    formData.append('asset_Owner_Id', data.asset_Owner_Id);
    formData.append('company_Id', data.company_Id);
    formData.append('is_Active', data.is_Active);
    formData.append('asset_Item_Category_Id', data.asset_Item_Category_Id);
    formData.append('asset_Item_Group_Id', data.asset_Item_Group_Id);
    formData.append('display_Order', data.display_Order);

    if (this.newBlogForm.valid) {
      if (data.id != 0) {
  
        this._apiService.updateAssetItem(formData).subscribe(res => {
  
          this._snackBar.open("Asset Item Updated Successfully", "Update", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });
  
          this.router.navigate(['/asset-item-list']);
  
  
        })
      }
      else {
        this._apiService.addAssetItem(formData).subscribe(res => {
  
          this._snackBar.open("Asset Item Saved Successfully", "Success", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });
  
          this.router.navigate(['/asset-item-list']);
  
  
        })
      }
    }
  }

  gotoBack() {
    this.router.navigate(['/asset-item-list']);
  }
  reset(): void {
    this.ngOnInit();
  }
}
