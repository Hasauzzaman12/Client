import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditAssetItemListComponent } from './add-edit-asset-item-list.component';

describe('AddEditAssetItemListComponent', () => {
  let component: AddEditAssetItemListComponent;
  let fixture: ComponentFixture<AddEditAssetItemListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddEditAssetItemListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddEditAssetItemListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
