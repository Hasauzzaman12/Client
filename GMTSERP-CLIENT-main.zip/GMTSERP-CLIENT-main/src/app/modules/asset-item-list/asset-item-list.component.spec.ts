import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetItemListComponent } from './asset-item-list.component';

describe('AssetItemListComponent', () => {
  let component: AssetItemListComponent;
  let fixture: ComponentFixture<AssetItemListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AssetItemListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AssetItemListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
