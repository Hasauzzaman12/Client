import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowAssetVehicleDocumentsComponent } from './show-asset-vehicle-documents.component';

describe('ShowAssetVehicleDocumentsComponent', () => {
  let component: ShowAssetVehicleDocumentsComponent;
  let fixture: ComponentFixture<ShowAssetVehicleDocumentsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ShowAssetVehicleDocumentsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ShowAssetVehicleDocumentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
