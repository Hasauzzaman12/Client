import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-show-asset-book-vehicle',
  templateUrl: './show-asset-book-vehicle.component.html',
  styleUrls: ['./show-asset-book-vehicle.component.scss']
})
export class ShowAssetBookVehicleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
