import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowAssetBookVehicleComponent } from './show-asset-book-vehicle.component';

describe('ShowAssetBookVehicleComponent', () => {
  let component: ShowAssetBookVehicleComponent;
  let fixture: ComponentFixture<ShowAssetBookVehicleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ShowAssetBookVehicleComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ShowAssetBookVehicleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
