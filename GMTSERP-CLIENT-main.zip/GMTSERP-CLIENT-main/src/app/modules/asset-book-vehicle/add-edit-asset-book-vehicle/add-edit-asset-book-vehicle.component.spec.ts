import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditAssetBookVehicleComponent } from './add-edit-asset-book-vehicle.component';

describe('AddEditAssetBookVehicleComponent', () => {
  let component: AddEditAssetBookVehicleComponent;
  let fixture: ComponentFixture<AddEditAssetBookVehicleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddEditAssetBookVehicleComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddEditAssetBookVehicleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
