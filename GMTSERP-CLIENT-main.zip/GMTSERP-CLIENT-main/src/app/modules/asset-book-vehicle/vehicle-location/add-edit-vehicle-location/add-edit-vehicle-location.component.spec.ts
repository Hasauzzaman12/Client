import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditVehicleLocationComponent } from './add-edit-vehicle-location.component';

describe('AddEditVehicleLocationComponent', () => {
  let component: AddEditVehicleLocationComponent;
  let fixture: ComponentFixture<AddEditVehicleLocationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddEditVehicleLocationComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddEditVehicleLocationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
