import { HttpClient } from '@angular/common/http';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormControl, FormGroup, FormsModule } from '@angular/forms';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { filter, map, Observable } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';

@Component({
  selector: 'app-add-edit-vehicle-location',
  templateUrl: './add-edit-vehicle-location.component.html',
  styleUrls: ['./add-edit-vehicle-location.component.scss']
})
export class AddEditVehicleLocationComponent implements OnInit {

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';
  newBlogForm!: FormGroup;

  constructor(public _apiService: ApiServiceService,
    private _snackBar: MatSnackBar,
    private authservice: AuthService,
    private currentRoute: ActivatedRoute, public http: HttpClient, public router: Router) { }

  userid: number = 0;
  companyid: number = 0;
  LookupType_Id: number = 0;
  loouptypeList$!: Observable<any[]>;
  public inputGSMList: any[] = [{ id: 0, lookup_Value: '' }];

  public result: boolean = false;

  formsSelectedData: any = {
    Id: 0,
    LookupType_Id: "",
    CompanyId: "",
    lookupValueList: [
    ],
  };

  ngOnInit(): void {

    this.newBlogForm = new FormGroup({
      Id: new FormControl(0),
      // LookupType_Id: new FormControl(null),
      LookupType_Id: new FormControl({value: 0, disabled: true}),
      CompanyId: new FormControl(this.authservice.getCompanyId),

    });

    this.userid = this.authservice.getUserId;
    this.companyid = this.authservice.getCompanyId;
    this.loouptypeList$ = this._apiService.getLookupTypeListcompanywise(this.companyid);

    this.loouptypeList$ = this.loouptypeList$.pipe(
      map(a => a.filter(item => item.variable_Type === 'Company Variable'))
    );


    this.inputGSMList = [{ id: 0, lookup_Value: '' }];

    let id = this.currentRoute.snapshot.paramMap.get('id');
    if (id != null) {
      this.getlookuptypeById(id);

    }

  }

  getlookuptypeById(id: number | string) {
    this.inputGSMList = [];
    this._apiService.getLookupTypCompanyeById(id)
      .subscribe((data: any) => {
        this.LookupType_Id = data.lookupType_Id;

        data.companyLookupDetailList.map((item: any) => {

          this.inputGSMList.push(item);
        });

      });


  }

  addFieldValue() {
    this.inputGSMList.push({ id: 0, lookup_Value: '' });
  }

  deleteFieldValue(index: any) {
    if (this.inputGSMList.length == 1) {
      return false;
    } else {
      this.inputGSMList.splice(index, 1);
      return true;
    }
  }


  updateCalculation(newObj: any) {
    console.log(newObj);
    this._apiService.checkduplicatecompanylookupType(newObj).subscribe(response => {
      this.result = response;
      if (this.result == true) {
        this._snackBar.open("It is already exist", "Please Update", {
          horizontalPosition: this.horizontalPosition,
          verticalPosition: this.verticalPosition,
          duration: 2000
        });
      }
    });
  }

  onSubmit(data: any) {
    let id = this.currentRoute.snapshot.paramMap.get('id');
    data.id = id;
    if (data.id != null) {

 
      this.formsSelectedData.CompanyLookupDetailList = [];
      this.formsSelectedData.Id = data.id;
      this.formsSelectedData.LookupType_Id = data.LookupType_Id;
      this.formsSelectedData.CompanyId = this.companyid;
      this.inputGSMList.map((item) => {
        this.formsSelectedData.CompanyLookupDetailList.push(item);

      });

      console.log(this.formsSelectedData);

      this._apiService.updateCompanyLookupType(this.formsSelectedData).subscribe(res => {

        this._snackBar.open("Company Lookup data Updated Successfully", "Update", {
          horizontalPosition: this.horizontalPosition,
          verticalPosition: this.verticalPosition,
          duration: 2000
        });

        this.router.navigate(['/vehicle-location']);

      })
    }
    else {

      this._apiService.checkduplicatecompanylookupType(20);
      this.formsSelectedData.CompanyLookupDetailList = [];
      this.formsSelectedData.LookupType_Id = data.LookupType_Id;
      this.formsSelectedData.CompanyId = this.companyid;
      this.inputGSMList.map((item) => {
        this.formsSelectedData.CompanyLookupDetailList.push(item);

      });


      this._apiService.addCompanyLookupType(this.formsSelectedData).subscribe(res => {
        this._snackBar.open("Company Lookup Value Saved Successfully", "Success", {
          horizontalPosition: this.horizontalPosition,
          verticalPosition: this.verticalPosition,
          duration: 2000
        });

        this.router.navigate(['/vehicle-location']);

      })
    }

  }

  gotoBack() {
    this.router.navigate(['/vehicle-location']);
  }

}

