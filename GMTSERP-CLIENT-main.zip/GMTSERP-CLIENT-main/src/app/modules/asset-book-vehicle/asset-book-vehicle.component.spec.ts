import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetBookVehicleComponent } from './asset-book-vehicle.component';

describe('AssetBookVehicleComponent', () => {
  let component: AssetBookVehicleComponent;
  let fixture: ComponentFixture<AssetBookVehicleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AssetBookVehicleComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AssetBookVehicleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
