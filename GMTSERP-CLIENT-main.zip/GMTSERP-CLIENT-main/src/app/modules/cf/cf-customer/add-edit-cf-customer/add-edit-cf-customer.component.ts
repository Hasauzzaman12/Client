import { HttpClient, HttpEventType, HttpRequest } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable, of,startWith, debounceTime, distinctUntilChanged, switchMap, map } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';
import { DatePipe } from '@angular/common';
import { SD } from 'src/environments/sd';

@Component({
  selector: 'app-add-edit-cf-customer',
  templateUrl: './add-edit-cf-customer.component.html',
  styleUrls: ['./add-edit-cf-customer.component.scss']
})
export class AddEditCfCustomerComponent implements OnInit {
  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';

  constructor(public _apiService: ApiServiceService,
    private _snackBar: MatSnackBar,
    public router: Router,
    private authservice: AuthService,
    private currentRoute: ActivatedRoute,
    private datepipe: DatePipe) { }

    newBlogForm!: FormGroup;
    id: number = 0;
    customer_Code= '';
    customer_Name= '';
    contact_Person= '';
    designation= '';
    mobile= '';
    email= '';
    website= '';
    customer_Group_Lookup_Id = SD.CF_Customer_Group_Lookup_Id;
    is_active: boolean = true;
    company_Id=this.authservice.getCompanyId;
    user_Id: number = this.authservice.getUserId;

  ngOnInit(): void {

    this.newBlogForm = new FormGroup({
      id: new FormControl(0),
      customer_Code: new FormControl(''),
      customer_Name: new FormControl(''),
      contact_Person: new FormControl(''),
      designation: new FormControl(''),
      mobile: new FormControl(''),
      email: new FormControl(''),
      website: new FormControl(''),
      is_active: new FormControl(true),
    });
    let id = this.currentRoute.snapshot.paramMap.get('id');
    if (id != null){
      this.getCustomerById(id);

    }else{
      this.getCustomerNo();
    }
  }

  getCustomerById(id:number|string){
    this._apiService.getCustomerById(id)
    .subscribe((data: any) => {
      this.id=data.id;
      this.customer_Code=data.customer_Code;
      this.customer_Name=data.customer_Name;
      this.contact_Person=data.contact_Person;
      this.designation=data.designation;
      this.mobile=data.mobile;
      this.email=data.email;
      this.website=data.website;
      this.is_active=data.is_active;
    });

  }
  getCustomerNo() {
    this._apiService.getCustomerNo()
    .subscribe((data: any) => {
      console.log(data);
      this.customer_Code = data;
    })}
    onSubmit(data: any){
      data.id=this.id.toString();
  
      if (data.customer_Code == ''||data.customer_Code == null) {
        alert("Customer Code is Required")
        return;
      }
      if (data.customer_Name == ''||data.customer_Name == null) {
        alert("Customer Name is Required")
        return;
      }
      if (data.mobile == ''||data.mobile == null) {
        alert("Mobile is Required")
        return;
      }

  
  
      const formData = new FormData();
      formData.append('id', this.id.toString());
      formData.append('customer_Code', data.customer_Code == null ? '' : data.customer_Code);
      formData.append('customer_Name', data.customer_Name == null ? '' : data.customer_Name);
      formData.append('contact_Person', data.contact_Person == null ? '' : data.contact_Person);
      formData.append('designation', data.designation == null ? '' : data.designation);
      formData.append('mobile', data.mobile == null ? '' : data.mobile);
      formData.append('email', data.email == null ? '' : data.email);
      formData.append('website', data.website == null ? '' : data.website);

      formData.append('customer_Group_Lookup_Id',this.customer_Group_Lookup_Id.toString());
      formData.append('is_active', data.is_active);
      formData.append('user_Id', this.user_Id.toString());

  
      if (this.newBlogForm.valid) {
        if (data.id != 0) {
    
          this._apiService.updateCustomer(formData).subscribe(res => {
    
            this._snackBar.open("Customer Updated Successfully", "Update", {
              horizontalPosition: this.horizontalPosition,
              verticalPosition: this.verticalPosition,
              duration: 2000
            });
    
            this.router.navigate(['/cf-customer']);
    
    
          })
        }
        else {
          this._apiService.addCustomer(formData).subscribe(res => {
    
            this._snackBar.open("Customer Saved Successfully", "Success", {
              horizontalPosition: this.horizontalPosition,
              verticalPosition: this.verticalPosition,
              duration: 2000
            });
    
            this.router.navigate(['/cf-customer']);
    
    
          })
        }
      }
    
    }
    gotoBack() {
      this.router.navigate(['/cf-customer']);
    }
    reset(): void {
      this.ngOnInit();
    }
}
