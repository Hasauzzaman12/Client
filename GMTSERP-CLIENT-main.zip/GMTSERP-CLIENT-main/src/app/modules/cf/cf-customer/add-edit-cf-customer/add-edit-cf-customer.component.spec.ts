import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditCfCustomerComponent } from './add-edit-cf-customer.component';

describe('AddEditCfCustomerComponent', () => {
  let component: AddEditCfCustomerComponent;
  let fixture: ComponentFixture<AddEditCfCustomerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddEditCfCustomerComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddEditCfCustomerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
