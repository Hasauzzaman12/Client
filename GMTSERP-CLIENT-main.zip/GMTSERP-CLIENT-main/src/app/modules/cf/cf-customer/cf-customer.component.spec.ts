import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CfCustomerComponent } from './cf-customer.component';

describe('CfCustomerComponent', () => {
  let component: CfCustomerComponent;
  let fixture: ComponentFixture<CfCustomerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CfCustomerComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CfCustomerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
