import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CfFarmerComponent } from './cf-farmer.component';

describe('CfFarmerComponent', () => {
  let component: CfFarmerComponent;
  let fixture: ComponentFixture<CfFarmerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CfFarmerComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CfFarmerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
