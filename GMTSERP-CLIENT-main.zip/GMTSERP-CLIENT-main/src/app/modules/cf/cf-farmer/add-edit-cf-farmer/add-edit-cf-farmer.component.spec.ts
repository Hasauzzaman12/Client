import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditCfFarmerComponent } from './add-edit-cf-farmer.component';

describe('AddEditCfFarmerComponent', () => {
  let component: AddEditCfFarmerComponent;
  let fixture: ComponentFixture<AddEditCfFarmerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddEditCfFarmerComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddEditCfFarmerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
