import { HttpClient, HttpEventType, HttpRequest } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';
import { DatePipe } from '@angular/common';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-add-edit-cf-farmer',
  templateUrl: './add-edit-cf-farmer.component.html',
  styleUrls: ['./add-edit-cf-farmer.component.scss']
})
export class AddEditCfFarmerComponent implements OnInit {

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';

  constructor(
    public _apiService: ApiServiceService,
    private _snackBar: MatSnackBar,
    public router: Router,
    private authservice: AuthService,
    private currentRoute: ActivatedRoute,
    private datepipe: DatePipe
  ) { }

  newBlogForm!: FormGroup;

  @Input() salesorder: any;
  id: number = 0;
  code: string = '';
  name: string = '';
  fathers_Name: string = '';
  mothers_Name: string = '';
  cluster_Id: number = 0;
  branch_Id: number = 0;
  branch_Name: string = '';
  region_Id: number = 0;
  region_Name: string = '';
  present_Address: string = '';
  permanent_Address: string = '';
  mobile_No: string = '';
  email: string = '';
  nid_No: string = '';
  dob_Date: any;
  farm_Name: string = '';
  bank_Acc_Name: string = '';
  bank_Acc_Number: string = '';
  bank_Branch: string = '';
  bank_Name: string = '';
  remarks: string = '';
  attachment_Id: number = 0;
  attachment_File_Name= '';
  image_Id: number = 0;
  imagePath: string = "";
  image_File_Name: string = "";
  longitude_Id: string = "";
  latitude_Id: string = "";
  
  is_active: boolean = true;
  inactive_Reason : string = "";
  inactive_Date : any;
  user_Id: number =  this.authservice.getUserId;

  clusterList$!: Observable<any[]>;
  selectedFile!: File;
  selectedFileImage!: File;

  public isValidImage: boolean = false;
  imagePreviewSrc: string | ArrayBuffer | null | undefined = '';
  isImageSelected: boolean = false;
  isEditImageSelected: boolean = false;

  ngOnInit(): void {

    this.newBlogForm = new FormGroup({
      id: new FormControl(0),
      code: new FormControl(''),
      name: new FormControl('', [Validators.required]),
      fathers_Name: new FormControl(''),
      mothers_Name: new FormControl(''),
      cluster_Id: new FormControl(0),
      branch_Id: new FormControl(0),
      region_Id: new FormControl(0),
      present_Address: new FormControl(''),
      permanent_Address: new FormControl(''),
      mobile_No: new FormControl(''),
      email: new FormControl(''),
      nid_No: new FormControl(''),
      dob_Date: new FormControl(null),
      farm_Name: new FormControl(''),
      bank_Acc_Name: new FormControl(''),
      bank_Acc_Number: new FormControl(''),
      bank_Branch: new FormControl(''),
      bank_Name: new FormControl(''),
      remarks: new FormControl(''),
      attachment_Id: new FormControl(0),
      image_Id: new FormControl(0),
      imageFarmer: new FormControl(null),
      image_File_Name: new FormControl(null),
      emp_File_Name: new FormControl(null),
      is_active: new FormControl(''),
      inactive_Reason : new FormControl(''),
      inactive_Date : new FormControl(null),
      longitude_Id : new FormControl(''),
      latitude_Id : new FormControl(''),
    });

    this.clusterList$ = this._apiService.getCfClusterList();

    let id = this.currentRoute.snapshot.paramMap.get('id');
    if (id != null) {
      this.getCfFarmerById(id);

    }else {
      this.getFarmerCode();
    }
  }

  getCfFarmerById(id: number | string) {
    this._apiService.getCfFarmerById(id).subscribe((data: any) => {
      //console.log(data);
      this.id= data.id;
      this.code = data.code;
      this.name = data.name;
      this.fathers_Name = data.fathers_Name;
      this.mothers_Name = data.mothers_Name;
      this.cluster_Id = data.cluster_Id;
      this.branch_Id = data.branch_Id;
      this.branch_Name=data.branch_Name;
      this.region_Id = data.region_Id;
      this.region_Name = data.region_Name;
      this.present_Address = data.present_Address;
      this.permanent_Address = data.permanent_Address;
      this.mobile_No = data.mobile_No;
      this.email = data.email;
      this.nid_No = data.nid_No;
      this.dob_Date = data.dob_Date;
      this.farm_Name = data.farm_Name;
      this.bank_Acc_Name = data.bank_Acc_Name;
      this.bank_Acc_Number = data.bank_Acc_Number;
      this.bank_Branch = data.bank_Branch;
      this.bank_Name = data.bank_Name;
      this.remarks = data.remarks;
      this.attachment_Id=data.attachment_Id;
      this.attachment_File_Name=data.attachment_File_Name;
      this.image_Id=data.image_Id;
      this.image_File_Name=data.image_File_Name;
      this.is_active =  data.is_active;
      this.inactive_Reason = data.inactive_Reason;
      this.inactive_Date = data.inactive_Date;
      this.longitude_Id = data.longitude_Id;
      this.latitude_Id = data.latitude_Id;

      if (data.image_Id > 0) {
        this.isEditImageSelected = true;
        this.imagePreviewSrc = data.image_File_Name;
      } else {
        this.image_Id = 0;
      }

    });
  }

  onSubmit(data: any) {

    const formData = new FormData();
   
    if (data.code == '') {
      alert("Code is Required")
      return;
    }
    if (data.name == '') {
      alert("Name is Required")
      return;
    }

    if (data.cluster_Id == '' || data.cluster_Id == null || data.cluster_Id == 0) {
      alert("Cluster is Required")
      return;
    }

    if (data.is_active === false && (data.inactive_Reason == '' || data.inactive_Reason == null || data.inactive_Date == '' || data.inactive_Date == null)) {        
  
        alert("Inactive reason and date is required is Required")
        return;     
    }

    data.id = this.id;
    formData.append('id', data.id);
    formData.append('code', data.code == null ? '' : data.code);
    formData.append('name', data.name == null ? '' : data.name);
    formData.append('fathers_Name', data.fathers_Name == null ? '' : data.fathers_Name);
    formData.append('mothers_Name', data.mothers_Name == null ? '' : data.mothers_Name);
    formData.append('cluster_Id', this.cluster_Id.toString());
    formData.append('branch_Id', this.branch_Id.toString());
    formData.append('region_Id',this.region_Id.toString());
    formData.append('present_Address', data.present_Address == null ? '' : data.present_Address);
    formData.append('permanent_Address', data.permanent_Address == null ? '' : data.permanent_Address);
    formData.append('mobile_No', data.mobile_No == null ? '' : data.mobile_No);
    formData.append('email', data.email == null ? '' : data.email);
    formData.append('nid_No', data.nid_No == null ? '' : data.nid_No);
    if (data.dob_Date != null) {
      formData.append('dob_Date', data.dob_Date);
    }
    formData.append('farm_Name', data.farm_Name == null ? '' : data.farm_Name);
    formData.append('bank_Acc_Name', data.bank_Acc_Name == null ? '' : data.bank_Acc_Name);
    formData.append('bank_Acc_Number', data.bank_Acc_Number == null ? '' : data.bank_Acc_Number);
    formData.append('bank_Branch', data.bank_Branch == null ? '' : data.bank_Branch);
    formData.append('bank_Name', data.bank_Name == null ? '' : data.bank_Name);
    formData.append('remarks', data.remarks == null ? '' : data.remarks);
    formData.append('attachment_Id', this.attachment_Id.toString());
    formData.append('attachmentFile', this.selectedFile);
    formData.append('image_Id', this.image_Id.toString());
    formData.append('imageFarmer', this.selectedFileImage);
    formData.append('is_active', data.is_active);
    formData.append('user_Id', this.user_Id.toString());
    formData.append('inactive_Reason', data.inactive_Reason == null ? '' : data.inactive_Reason); 
    formData.append('longitude_Id', data.longitude_Id == null ? '' : data.longitude_Id);
    formData.append('latitude_Id', data.latitude_Id == null ? '' : data.latitude_Id);
    if(data.inactive_Date != null){
      formData.append('inactive_Date', data.inactive_Date);
    }

    if (this.newBlogForm.valid) {
      if (data.id != 0) {

        this._apiService.updateCfFarmer(formData).subscribe(res => {

          this._snackBar.open("CF Farmer Updated Successfully", "Update", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });

          this.router.navigate(['/cf-farmer']);


        })
      }
      else {
        this._apiService.addCfFarmer(formData).subscribe(res => {

          this._snackBar.open("CF Farmer Saved Successfully", "Success", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });

          this.router.navigate(['/cf-farmer']);


        })
      }
    }

  }

  
  gotoBack() {
    this.router.navigate(['/cf-farmer']);
  }
  reset(): void {
    this.ngOnInit();
  }

  changeCluster(event: any) {
    this.cluster_Id = event.target.value;
    if (this.cluster_Id > 0) {
      this._apiService.getCfClusterById(this.cluster_Id).subscribe((data: any) => {
        this.branch_Id = data.branch_Id;
        this.branch_Name=data.branch_Name;
        this.region_Id = data.region_Id;
        this.region_Name=data.region_Name;
  
      });

    }
  }
  getFarmerCode() {
    this._apiService.getFarmerCode()
      .subscribe((data: any) => {
        this.code = "F-" + data;
      })
  }
  onSelectFile(fileInput: any) {
    this.selectedFile = <File>fileInput.target.files[0];
    this.attachment_Id = 0;
  }

  onChangeStatus(event : any) {
    //this.selectedFile = <File>fileInput.target.files[0];
    var a = event.target.value;
    console.log(a);
    
  }
  onSelectFileImage(fileInput: any) {
    this.selectedFileImage = <File>fileInput.target.files[0];
    this.image_Id = 0;

    let sizeInBytes: number = this.selectedFileImage.size;
    let myfileSize = sizeInBytes / 1024;
    if (myfileSize > 300) {
      alert("Max image size is 300 kb !");
      this.selectedFileImage = new File([], '');
      this.isValidImage = false;
      return;
    } else {
      this.isValidImage = true;
    }


  }
  showPreview(event: Event) {
    if (this.isValidImage) {
      this.image_Id = 0;
      let selectedFile = (event.target as HTMLInputElement).files?.item(0)

      if (selectedFile) {
        if (["image/jpeg", "image/png", "image/svg+xml"].includes(selectedFile.type)) {
          let fileReader = new FileReader();
          fileReader.readAsDataURL(selectedFile);

          fileReader.addEventListener('load', (event) => {
            this.imagePreviewSrc = event.target?.result;
            this.isImageSelected = true
          })
        }
      } else {
        this.isImageSelected = false
      }
    }

  }
}
