import { HttpClient, HttpEventType, HttpRequest } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable, of,startWith, debounceTime, distinctUntilChanged, switchMap, map } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';
import { DatePipe } from '@angular/common';
import { environment } from 'src/environments/environment';
@Component({
  selector: 'app-add-edit-cf-farm-management-cost',
  templateUrl: './add-edit-cf-farm-management-cost.component.html',
  styleUrls: ['./add-edit-cf-farm-management-cost.component.scss']
})
export class AddEditCfFarmManagementCostComponent implements OnInit {

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';

  constructor(
    public _apiService: ApiServiceService,
    private _snackBar: MatSnackBar,
    public router: Router,
    private authservice: AuthService,
    private currentRoute: ActivatedRoute,
    private datepipe: DatePipe
  ) { }

  newBlogForm!: FormGroup;

  @Input() item: any;
  id: number = 0;  
  branch_Id : string | number = 0;  
  year_Id: number = 0; 
  month_Id: number = 0; 
  cost: number = 0; 
  is_active = true;
  user_Id: number = this.authservice.getUserId;
  


  branchList$!: Observable<any[]>;
  yearList$!: Observable<any[]>;
  monthList$!: any[];

  year_Filter = 0;
  month_Filter = 0;
  isEdit = false;
  route_id = 0;

  item_purchase_rate_list: any[] = [];

  ngOnInit(): void {
    this.isEdit = false;
    this.newBlogForm = new FormGroup({
      id: new FormControl(0),
      branch_Id: new FormControl(this.branch_Id),
      year_Id: new FormControl(0),
      month_Id: new FormControl(0),
      cost: new FormControl(0),
      is_active: new FormControl(true),
      user_Id : new FormControl(0), 
      year_Filter: new FormControl(0),
      month_Filter: new FormControl(0),      
    });
    console.log(this.newBlogForm.value.year_Filter);
    this.branchList$=this._apiService.getCfBranchList();
    this.yearList$=this._apiService.getYearList();
    this.monthList$ = environment.monthListStatic;
    this.user_Id=this.authservice.getUserId;
    
    let route = this.currentRoute.snapshot.paramMap.get('id');
    if (route != null) {
      this.branch_Id = route;
      this.SearchSummary();
      //this.getItemById(this.branch_Id);
    }
  }

  getItemById() {    
    let formData = new FormData();
    formData.append("branch_Id", this.branch_Id.toString());
    formData.append("year", this.newBlogForm.value.year_Filter.toString());    
    formData.append("month", this.newBlogForm.value.month_Filter.toString());   
    

    this._apiService.getCffarmMngtCost(formData).subscribe((data:any)=>{
      this.item_purchase_rate_list = data;
    });          
  }  
  
  addRateRow() {   
    
    //if (this.item_purchase_rate_list.length<1) {
      this.item_purchase_rate_list.push({
        id: 0,
        year: 0,
        month: 0,        
        branch_Id : this.branch_Id,
        cost: 0,     
        user_Id : this.authservice.getUserId,
        is_Active : true,  
        is_Edit : false,   
      });
    //}
  }
  
  

  onSubmit(data: any) {

    if (data.branch_Id == 0 || data.branch_Id == null || data.branch_Id == '') {
      alert("branch is Required")
      return;
    }
    if (data.year_Id == 0 || data.year_Id == null || data.year_Id == '') {
      alert("year is Required")
      return;
    }
    if (data.month_Id == 0 || data.month_Id == null || data.month_Id == '') {
      alert("Month is Required")
      return;
    }
    if (data.cost == 0 || data.cost == null || data.cost == '') {
      alert("Cost is Required")
      return;
    }

    const formData = new FormData();
    formData.append('id', data.id);  
    formData.append("branch_Id", data.branch_Id);
    formData.append("year", data.year_Id);
    formData.append("month", data.month_Id);   
    formData.append("cost", data.cost);    
    formData.append("is_Active", data.is_active); 
    formData.append("user_Id", this.user_Id.toString());    
    
    if (this.newBlogForm.valid) {
      if (data.id != 0) {  
        this._apiService.UpdateCffarmMngtCost(formData).subscribe((res:any) => {  

          this._snackBar.open(res.message, "Update", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });  
          // this.router.navigate(['/item-afl']);          
        })
      }
      else {
        this._apiService.SaveCffarmMngtCost(formData).subscribe((res:any) => {  
          console.log(res);          
            this._snackBar.open(res.message, "Success", {
              horizontalPosition: this.horizontalPosition,
              verticalPosition: this.verticalPosition,
              duration: 4000
            });            
        })
      }
      this.ngOnInit();
    }
  }
  gotoBack() {
    this.router.navigate(['/cf-farm-mngt-cost']);
  }
  reset(): void {
    this.isEdit = false;
    //this.getItemById(this.branch_Id);       
    this.id = 0;
    this.year_Id = 0;
    this.month_Id = 0;    
    this.year_Filter = 0;
    this.month_Filter = 0;
    this.item_purchase_rate_list = [];
    this.ngOnInit(); 
    this.SearchSummary();
  }
  refresh(): void {
    window.location.reload();
  }

  
 
  deleteRateRow(Index: any) {
    if (confirm('Are you sure want to delete?')) {
      this.item_purchase_rate_list.splice(Index, 1);
    }
    
  }
  openForEdit(row : any){
    this.isEdit = true;

    this.id = row.id;
    this.year_Id = row.year;
    this.month_Id = row.month;
    this.cost = row.cost;
    this.is_active = row.is_Active;
    
    this.newBlogForm.controls['id'].setValue(row.id);
    this.newBlogForm.controls['year_Id'].setValue(row.year);
    this.newBlogForm.controls['month_Id'].setValue(row.month);
    this.newBlogForm.controls['cost'].setValue(row.cost);
    this.newBlogForm.controls['is_active'].setValue(row.is_Active);
  }
  SearchSummary(){
    this.getItemById();
  }

}
