import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditCfFarmManagementCostComponent } from './add-edit-cf-farm-management-cost.component';

describe('AddEditCfFarmManagementCostComponent', () => {
  let component: AddEditCfFarmManagementCostComponent;
  let fixture: ComponentFixture<AddEditCfFarmManagementCostComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddEditCfFarmManagementCostComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddEditCfFarmManagementCostComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
