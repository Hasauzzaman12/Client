import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';

@Component({
  selector: 'app-cf-farm-management-cost',
  templateUrl: './cf-farm-management-cost.component.html',
  styleUrls: ['./cf-farm-management-cost.component.scss']
})
export class CfFarmManagementCostComponent implements OnInit {

  code: string = '';
  name: string = '';
  user_Id: number = this.authservice.getUserId;
  isFilterShow: boolean = false;
  company_Id: number = 0; 
  unit_Id: number = 0;  

  from_Date : any=null;
  to_Date : any=null;

  displayedColumns: string[] = ['code','name','status','action'];
  dataSource!: MatTableDataSource<any>;

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';


  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  companyList$!: Observable<any[]>;  
  unitList$!: Observable<any[]>;  

  constructor(public _apiService: ApiServiceService,
    private authservice: AuthService,
    private _snackBar: MatSnackBar,
    public dialog: MatDialog,
    private router: Router) { }
    
  ngOnInit(): void {
    this.getCfRegionInfoList();
    this.companyList$ = this._apiService.getCompanyList();    
    this.unitList$ = this._apiService.getUnitList();    
  }

  getCfRegionInfoList() {
    const formData = new FormData();
    if (this.code != ''||this.code != null) {
      formData.append('code', this.code);
    }
    if (this.name != ''||this.name != null) {
      formData.append('name', this.name);
    }
    if (this.company_Id != 0||this.company_Id != null) {
      formData.append('company_Id', this.company_Id.toString());
    }   
    if (this.unit_Id != 0||this.unit_Id != null) {
      formData.append('unit_Id', this.unit_Id.toString());
    }  
    if(this.from_Date != null && this.to_Date != null){
      formData.append('from_Date', this.from_Date);
      formData.append('to_Date', this.to_Date);
    }
    
    this._apiService.getCfBranchList()
      .subscribe({
        next: (res) => {
          console.log(res);
          this.dataSource = new MatTableDataSource(res);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
        },
        error: (err) => {
          console.log("Error");
        }
      })
  }


  openForEdit(id: number) {

    this.router.navigate(['/cf-farm-mngt-cost/edit/' + id]);
  }
  gotoNew() {
    //this.router.navigate(['/add-cf-region']);
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }


  SearchSummary() {
    this.getCfRegionInfoList();
  }
  reset() {

    this.code='';
    this.name='';
    this.company_Id=0;  
    this.unit_Id=0;    
    this.from_Date=null;
    this.to_Date=null;

    this.getCfRegionInfoList();
  }
  toggleFilter() {
    this.isFilterShow = !this.isFilterShow;
  } 


}
