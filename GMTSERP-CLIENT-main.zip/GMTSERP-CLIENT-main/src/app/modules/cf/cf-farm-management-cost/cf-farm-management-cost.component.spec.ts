import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CfFarmManagementCostComponent } from './cf-farm-management-cost.component';

describe('CfFarmManagementCostComponent', () => {
  let component: CfFarmManagementCostComponent;
  let fixture: ComponentFixture<CfFarmManagementCostComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CfFarmManagementCostComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CfFarmManagementCostComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
