import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';

@Component({
  selector: 'app-cf-cluster',
  templateUrl: './cf-cluster.component.html',
  styleUrls: ['./cf-cluster.component.scss']
})
export class CfClusterComponent implements OnInit {

  code: string = '';
  name: string = '';
  incharge_Name: string = '';
  incharge_Number: string = '';
  user_Id: number = this.authservice.getUserId;
  isFilterShow: boolean = false;
  branch_Id: number = 0; 
  region_Id: number = 0;  
  branch_Name: string = ''; 
  region_Name: string = '';  

  from_Date : any=null;
  to_Date : any=null;

  displayedColumns: string[] = ['code','name','branch_Name','region_Name','status','action'];//,'incharge_Name','incharge_Number',
  dataSource!: MatTableDataSource<any>;

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';


  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  branchList$!: Observable<any[]>;  
  regionList$!: Observable<any[]>;  

  constructor(public _apiService: ApiServiceService,
    private authservice: AuthService,
    private _snackBar: MatSnackBar,
    public dialog: MatDialog,
    private router: Router) { }
    
  ngOnInit(): void {
    this.getCfClusterInfoList();
    this.branchList$ = this._apiService.getCfBranchList();    
    this.regionList$ = this._apiService.getCfRegionList();    
  }

  getCfClusterInfoList() {
    const formData = new FormData();
    if (this.code != ''||this.code != null) {
      formData.append('code', this.code);
    }
    if (this.name != ''||this.name != null) {
      formData.append('name', this.name);
    }
    if (this.branch_Name != ''||this.branch_Name != null) {
      formData.append('branch_Name', this.branch_Name);
    }
    if (this.region_Name != ''||this.region_Name != null) {
      formData.append('region_Name', this.region_Name);
    }
    if (this.branch_Id != 0||this.branch_Id != null) {
      formData.append('branch_Id', this.branch_Id.toString());
    }   
    if (this.region_Id != 0||this.region_Id != null) {
      formData.append('region_Id', this.region_Id.toString());
    }      
    if(this.from_Date != null && this.to_Date != null){
      formData.append('from_Date', this.from_Date);
      formData.append('to_Date', this.to_Date);
    }
    
    this._apiService.getCfClusterList()
      .subscribe({
        next: (res) => {
          console.log(res);
          this.dataSource = new MatTableDataSource(res);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
        },
        error: (err) => {
          console.log("Error");
        }
      })
  }


  openForEdit(id: number) {

    this.router.navigate(['/cf-cluster/edit/' + id]);
  }
  gotoNew() {
    this.router.navigate(['/add-cf-cluster']);
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }


  SearchSummary() {
    this.getCfClusterInfoList();
  }
  reset() {

    this.code='';
    this.name='';
    this.branch_Id=0;  
    this.region_Id=0;    
    this.from_Date=null;
    this.to_Date=null;

    this.getCfClusterInfoList();
  }
  toggleFilter() {
    this.isFilterShow = !this.isFilterShow;
  } 

  

}
