import { HttpClient, HttpEventType, HttpRequest } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable, of,startWith, debounceTime, distinctUntilChanged, switchMap, map } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-add-edit-cf-cluster',
  templateUrl: './add-edit-cf-cluster.component.html',
  styleUrls: ['./add-edit-cf-cluster.component.scss']
})
export class AddEditCfClusterComponent implements OnInit {

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';

  myControl2 = new FormControl();
  options = [];
  filteredOptionsEmp: Observable<any>;

    constructor(
    public _apiService: ApiServiceService,
    private _snackBar: MatSnackBar,
    public router: Router,
    private authservice: AuthService,
    private currentRoute: ActivatedRoute,
    
  ) {   
    this.filteredOptionsEmp = this.myControl2.valueChanges.pipe(

      startWith(''),

      debounceTime(400),

      distinctUntilChanged(),

      switchMap(val => {

        if(val!=''){
          return this.filter2(val || '')
        }else{
          return '';
        }

       }) 

    )
  }

  newBlogForm!: FormGroup;
  id: number = 0;
  code: string = '';
  name: string = '';
  branch_Id: number = 0;
  region_Id: number = 0; 
  incharge_Name: string = '';
  incharge_Number: string = '';
  region_Name: string = '';
  cluster_Incharge_Id: number = 0;
  employee_Code= '';
  employee_Name= '';
  is_active: boolean = true;
  user_Id: number =  this.authservice.getUserId;  
  branchList$!: Observable<any[]>;  
  

  ngOnInit(): void {   

    this.newBlogForm = new FormGroup({
      id: new FormControl(0),
      code: new FormControl(''),
      name: new FormControl(''),
      incharge_Name: new FormControl(''),
      incharge_Number: new FormControl(''),
      branch_Id: new FormControl(0),     
      region_Id: new FormControl(0), 
      is_active: new FormControl(true)

    });
    this.branchList$ = this._apiService.getCfBranchList();   

    let id = this.currentRoute.snapshot.paramMap.get('id');
    if (id != null) {
      this.getCfClusterById(id);
    } else {      
      //this.getFlockNo();
    }
    
  }
  getCfClusterById(id: number | string) {
    this._apiService.getCfClusterById(id).subscribe((data: any) => {      
      this.id= data.id;
      this.code = data.code;
      this.name = data.name;  
      this.region_Name = data.region_Name;
      this.cluster_Incharge_Id = data.cluster_Incharge_Id;
      this.employee_Code = data.employee_Code;
      this.incharge_Name = data.incharge_Name;
      this.incharge_Number = data.incharge_Number;      
      this.branch_Id = data.branch_Id;
      this.region_Id = data.region_Id;  
      this.is_active =  data.is_active;
    });
  }

  onSubmit(data: any) {
    const formData = new FormData();

    if (data.code == '') {
      alert("Code is Required")
      return;
    }
    if (data.name == '') {
      alert("Name is Required")
      return;
    }
    if (data.branch_Id == '' || data.branch_Id == null) {
      alert("Branch Id Id is Required")
      return;
    }
    if (this.region_Id == 0 || this.region_Id.toString() == '' || this.region_Id.toString() == null) {
      alert("Region Id is Required")
      return;
    }
    if (this.cluster_Incharge_Id == 0 || this.cluster_Incharge_Id.toString() == '' || this.cluster_Incharge_Id.toString() == null) {
      alert("Incharge Emp Code is Required")
      return;
    }

    data.id = this.id;
    formData.append('id', data.id);
    formData.append('code', data.code == null ? '' : data.code);
    formData.append('name', data.name);
    formData.append('incharge_Name', data.incharge_Name);
    formData.append('incharge_Number', data.incharge_Number);
    formData.append('branch_Id', this.branch_Id.toString());
    formData.append('region_Id', this.region_Id.toString());
    formData.append('cluster_Incharge_Id', this.cluster_Incharge_Id.toString());
    formData.append('is_active', data.is_active);
    formData.append('user_Id', this.user_Id.toString());

    if (this.newBlogForm.valid) {
      if (data.id != 0) {
        this._apiService.updateCfCluster(formData).subscribe(res => {
          this._snackBar.open("Cluster Info Updated Successfully", "Update", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });
          this.router.navigate(['/cf-cluster']);
        })
      }
      else {
        this._apiService.addCfCluster(formData).subscribe(res => {
          this._snackBar.open("Cluster Info Saved Successfully", "Success", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });
          this.router.navigate(['/cf-cluster']);
        })
      }
    }

  }
  gotoBack() {
    this.router.navigate(['/cf-cluster']);
  }
  reset(): void {
    this.ngOnInit();
  }

  changeBranch(event: any) {
    if(event.target.value>0){         
      this._apiService.getCfBranchById(this.branch_Id).subscribe((data:any)=>{
          this._apiService.getCfRegionById(data.region_Id).subscribe((data1:any)=>{   
            this.region_Id = data1.id; 
            this.region_Name = data1.name;
          });                 
      });         
      
    }else{
      this.region_Id = 0;
      this.region_Name = "";
    }
  }
  filter2(val: string): Observable <any>{

    const formData = new FormData();
    formData.append('employee_Id', val);
    if (this.user_Id != 0||this.user_Id != null) {
      formData.append('user_Id', this.user_Id.toString());
    }
    formData.append('emp_Status', 'Active');

    return this._apiService.getEmployeesFiltered(formData)

    .pipe(

      map(response => response.filter((option: { employee_Id: string; }) => { 

        return option.employee_Id.toLowerCase().indexOf(val.toLowerCase()) !== -1

      }))

    )

   } 
   onSelFunc2(option: any){
    this.cluster_Incharge_Id=option.id;
    this.employee_Name=option.employee_Name;
    this.incharge_Name=option.employee_Name;
  }
}
