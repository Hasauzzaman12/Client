import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditCfClusterComponent } from './add-edit-cf-cluster.component';

describe('AddEditCfClusterComponent', () => {
  let component: AddEditCfClusterComponent;
  let fixture: ComponentFixture<AddEditCfClusterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddEditCfClusterComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddEditCfClusterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
