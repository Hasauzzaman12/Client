import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CfClusterComponent } from './cf-cluster.component';

describe('CfClusterComponent', () => {
  let component: CfClusterComponent;
  let fixture: ComponentFixture<CfClusterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CfClusterComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CfClusterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
