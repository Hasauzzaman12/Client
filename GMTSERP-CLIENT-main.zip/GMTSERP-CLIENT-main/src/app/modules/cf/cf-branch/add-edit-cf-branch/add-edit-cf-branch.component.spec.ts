import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditCfBranchComponent } from './add-edit-cf-branch.component';

describe('AddEditCfBranchComponent', () => {
  let component: AddEditCfBranchComponent;
  let fixture: ComponentFixture<AddEditCfBranchComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddEditCfBranchComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddEditCfBranchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
