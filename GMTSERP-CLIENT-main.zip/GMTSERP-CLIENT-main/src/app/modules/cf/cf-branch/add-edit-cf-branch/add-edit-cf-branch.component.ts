import { HttpClient, HttpEventType, HttpRequest } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable, of,startWith, debounceTime, distinctUntilChanged, switchMap, map } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';
import { DatePipe } from '@angular/common';


@Component({
  selector: 'app-add-edit-cf-branch',
  templateUrl: './add-edit-cf-branch.component.html',
  styleUrls: ['./add-edit-cf-branch.component.scss']
})
export class AddEditCfBranchComponent implements OnInit {

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';

  myControl = new FormControl();
  options = [];
  filteredOptions: Observable<any>;

  constructor(
    public _apiService: ApiServiceService,
    private _snackBar: MatSnackBar,
    public router: Router,
    private authservice: AuthService,
    private currentRoute: ActivatedRoute,
    private datepipe: DatePipe
  ) { 
    this.filteredOptions = this.myControl.valueChanges.pipe(

      startWith(''),

      debounceTime(400),

      distinctUntilChanged(),

      switchMap(val => {

        if(val!=''){
          return this.filter(val || '')
        }else{
          return '';
        }

       }) 

    )
  }

  newBlogForm!: FormGroup;
  id: number = 0;
  code: string = '';
  name: string = '';
  region_Id: number = 0;
  region_Name: string = '';  
  is_active: boolean = true;
  user_Id: number =  this.authservice.getUserId;
  regionList$!: Observable<any[]>;  

  ngOnInit(): void {
    let currentDateTime = this.datepipe.transform((new Date), 'MM/dd/yyyy h:mm:ss');

    this.newBlogForm = new FormGroup({
      id: new FormControl(0),
      code: new FormControl(''),
      name: new FormControl(''),
      region_Id: new FormControl(0),      
      is_active: new FormControl(true)

    });
    
    let id = this.currentRoute.snapshot.paramMap.get('id');
    if (id != null) {
      this.getCfBranchById(id);
    } else {      
      //this.getFlockNo();
    }
    this.regionList$ = this._apiService.getCfRegionList();
  }
  getCfBranchById(id: number | string) {
    this._apiService.getCfBranchById(id).subscribe((data: any) => {      
      this.id= data.id;
      this.code = data.code;
      this.name = data.name;      
      this.region_Id = data.region_Id;
      //this.region_Name = data.region_Name;      
      this.is_active =  data.is_active;

    });
  }

  onSubmit(data: any) {

    const formData = new FormData();

    if (data.code == '') {
      alert("Code is Required")
      return;
    }
    if (data.name == '') {
      alert("Name is Required")
      return;
    }
    if (data.region_Id == '' || data.region_Id == null) {
      alert("Region Id is Required")
      return;
    }

    data.id = this.id;
    formData.append('id', data.id);
    formData.append('code', data.code == null ? '' : data.code);
    formData.append('name', data.name);
    formData.append('region_Id', this.region_Id.toString());
    formData.append('is_active', data.is_active);
    formData.append('user_Id', this.user_Id.toString());

    if (this.newBlogForm.valid) {
      if (data.id != 0) {
        this._apiService.updateCfBranch(formData).subscribe(res => {
          this._snackBar.open("Branch Info Updated Successfully", "Update", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });
          this.router.navigate(['/cf-branch']);
        })
      }
      else {
        this._apiService.addCfBranch(formData).subscribe(res => {
          this._snackBar.open("Branch Info Saved Successfully", "Success", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });

          this.router.navigate(['/cf-branch']);
        })
      }
    }

  }
  gotoBack() {
    this.router.navigate(['/cf-branch']);
  }
  reset(): void {
    this.ngOnInit();
  }

  filter(val: string): Observable <any>{

    const formData = new FormData();
    formData.append('code', val);

    return this._apiService.getCfFarmersFiltered(formData)

    .pipe(

      map(response => response.filter((option: { code: string; }) => { 

        return option.code.toLowerCase().indexOf(val.toLowerCase()) !== -1

      }))

    )

   }  

   onSelFunc(option: any){
    // console.log(option);
    // if(option.id>0){
    //   this.farmer_Id=option.id;
    //   if (this.farmer_Id > 0) {
    //     this._apiService.getCfFarmerById(this.farmer_Id).subscribe((data: any) => {
    //       this.farmer_Name=data.name;
    //       this.farmer_Code=data.code;
    //       this.cluster_Id = data.cluster_Id;
    //       this.cluster_Name=data.cluster_Name;
    //       this.branch_Id = data.branch_Id;
    //       this.branch_Name=data.branch_Name;
    //       this.region_Id = data.region_Id;
    //       this.region_Name=data.region_Name;
    
    //     });
  
    //   }
    // }
  }

  

}
