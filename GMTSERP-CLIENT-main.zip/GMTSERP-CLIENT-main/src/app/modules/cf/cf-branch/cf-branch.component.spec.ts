import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CfBranchComponent } from './cf-branch.component';

describe('CfBranchComponent', () => {
  let component: CfBranchComponent;
  let fixture: ComponentFixture<CfBranchComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CfBranchComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CfBranchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
