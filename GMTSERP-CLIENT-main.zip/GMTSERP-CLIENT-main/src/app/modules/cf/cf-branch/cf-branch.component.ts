import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';

@Component({
  selector: 'app-cf-branch',
  templateUrl: './cf-branch.component.html',
  styleUrls: ['./cf-branch.component.scss']
})
export class CfBranchComponent implements OnInit {

  code: string = '';
  name: string = '';
  user_Id: number = this.authservice.getUserId;
  isFilterShow: boolean = false;
  region_Id: number = 0;  

  from_Date : any=null;
  to_Date : any=null;

  displayedColumns: string[] = ['code','name','status','action'];
  dataSource!: MatTableDataSource<any>;

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';


  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  regionList$!: Observable<any[]>;  

  constructor(public _apiService: ApiServiceService,
    private authservice: AuthService,
    private _snackBar: MatSnackBar,
    public dialog: MatDialog,
    private router: Router) { }
    
  ngOnInit(): void {
    this.getBranchInfoList();
    this.regionList$ = this._apiService.getCfRegionList();
  }

  getBranchInfoList() {
    const formData = new FormData();
    if (this.code != ''||this.code != null) {
      formData.append('code', this.code);
    }
    if (this.name != ''||this.name != null) {
      formData.append('name', this.name);
    }
    if (this.region_Id != 0||this.region_Id != null) {
      formData.append('region_Id', this.region_Id.toString());
    }    
    if(this.from_Date != null && this.to_Date != null){
      formData.append('from_Date', this.from_Date);
      formData.append('to_Date', this.to_Date);
    }
    
    this._apiService.getCfBranchList()
      .subscribe({
        next: (res) => {
          console.log(res);
          this.dataSource = new MatTableDataSource(res);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
        },
        error: (err) => {
          console.log("Error");
        }

      })
  }


  openForEdit(id: number) {

    this.router.navigate(['/cf-branch/edit/' + id]);
  }
  gotoNew() {
    this.router.navigate(['/add-cf-branch']);
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }


  SearchSummary() {
    this.getBranchInfoList();
  }
  reset() {
    this.code='';
    this.name='';
    this.region_Id=0;    
    this.from_Date=null;
    this.to_Date=null;
    this.getBranchInfoList();
  }

  toggleFilter() {
    this.isFilterShow = !this.isFilterShow;
  }
  
}
