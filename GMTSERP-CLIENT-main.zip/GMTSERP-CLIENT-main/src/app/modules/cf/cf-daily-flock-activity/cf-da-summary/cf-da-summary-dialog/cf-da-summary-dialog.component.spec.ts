import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CfDaSummaryDialogComponent } from './cf-da-summary-dialog.component';

describe('CfDaSummaryDialogComponent', () => {
  let component: CfDaSummaryDialogComponent;
  let fixture: ComponentFixture<CfDaSummaryDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CfDaSummaryDialogComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CfDaSummaryDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
