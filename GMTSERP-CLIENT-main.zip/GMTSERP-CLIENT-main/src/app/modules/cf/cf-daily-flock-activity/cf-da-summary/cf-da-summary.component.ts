import { Component, OnInit } from '@angular/core';
import { Breakpoints, BreakpointObserver } from '@angular/cdk/layout';
import { ApiServiceService } from 'src/app/api-service.service';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { FormBuilder, FormGroup } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { MatDialog } from '@angular/material/dialog';
import { CfDaSummaryDialogComponent } from './cf-da-summary-dialog/cf-da-summary-dialog.component';

@Component({
  selector: 'app-cf-da-summary',
  templateUrl: './cf-da-summary.component.html',
  styleUrls: ['./cf-da-summary.component.scss']
})
export class CfDaSummaryComponent implements OnInit {

  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';

  endpoint: string = `${environment.reportServerUrl}`;
    flock_DA_Summary_Data!: any[];  

  region_Id: number = 0;
  branch_Id: number = 0;
  cluster_Id: number = 0;
  form!: FormGroup;

  
  cols_Value: number = 2;
  cfregionList$!: Observable<any[]>;
  cfbranchList$!: Observable<any[]>;
  cfClusterList$!: Observable<any[]>;

  documentStyle = getComputedStyle(document.documentElement);
  textColor = '#495057';
  textColorSecondary = '#6c757d';
  surfaceBorder = '#dfe7ef';
  /** Based on the screen size, switch from standard to one column per row */
  constructor(private breakpointObserver: BreakpointObserver,
     public _apiService: ApiServiceService, 
     private _snackBar: MatSnackBar,
     public fb: FormBuilder,
     private datepipe: DatePipe,public dialog: MatDialog) {

   }

  ngOnInit(): void {

    this.cfbranchList$ = this._apiService.getCfBranchList();

    this.cols_Value = (window.innerWidth <= 1000) ? 1 : 2;    

    this._apiService.getFlockDASummaryData(this.branch_Id,this.cluster_Id,0,0).subscribe((data: any[]) => {
       this.flock_DA_Summary_Data = data;
    });   
  }
  onResize(event: any) {
    this.cols_Value = (event.target.innerWidth <= 1000) ? 1 : 2;
  }  
  onClick() {

    
    this._apiService.getFlockDASummaryData(this.branch_Id,this.cluster_Id,0,0).subscribe((data: any[]) => {
      this.flock_DA_Summary_Data = data;
   });    
    

  }

  OnChangeBranch(event : any){
    this.cfClusterList$ = this._apiService.getClusterByBranch(this.branch_Id);
  }


  openDialog(newObj: any): void {

    const dialogRef = this.dialog.open(CfDaSummaryDialogComponent, {
      height: '50%',
      autoFocus: false,
      width: '20%',
      backdropClass: 'custom-dialog-backdrop-class',
      panelClass: 'custom-dialog-panel-class',
      // position: {right:'10px', top: '10px'} ,
      data: { pageValue: newObj }
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log(result.data);
    });
  }

}
