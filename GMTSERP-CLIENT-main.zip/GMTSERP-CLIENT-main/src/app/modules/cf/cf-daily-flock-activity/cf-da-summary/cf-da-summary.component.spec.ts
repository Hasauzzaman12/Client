import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CfDaSummaryComponent } from './cf-da-summary.component';

describe('CfDaSummaryComponent', () => {
  let component: CfDaSummaryComponent;
  let fixture: ComponentFixture<CfDaSummaryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CfDaSummaryComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CfDaSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
