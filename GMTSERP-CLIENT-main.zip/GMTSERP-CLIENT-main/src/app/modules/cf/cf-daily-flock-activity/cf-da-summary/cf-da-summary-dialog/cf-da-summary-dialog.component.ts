import { Component, Inject, OnInit, Optional } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Observable, of } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';


@Component({
  selector: 'app-cf-da-summary-dialog',
  templateUrl: './cf-da-summary-dialog.component.html',
  styleUrls: ['./cf-da-summary-dialog.component.scss']
})
export class CfDaSummaryDialogComponent implements OnInit {

  missingDaysList!: any[];  
  constructor(
    public _apiService:ApiServiceService,
    public dialogRef: MatDialogRef<CfDaSummaryDialogComponent>,
    @Optional() @Inject(MAT_DIALOG_DATA) public data: any
  ) { 
    this.missingDaysList = data.pageValue.missingDateList;
  }

  ngOnInit(): void {
  }
  closeDialog() {
    this.dialogRef.close({ event: 'close', data: this.missingDaysList });    
  }
}
