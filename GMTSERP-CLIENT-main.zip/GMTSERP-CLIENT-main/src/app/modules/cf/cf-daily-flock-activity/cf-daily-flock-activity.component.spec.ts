import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CfDailyFlockActivityComponent } from './cf-daily-flock-activity.component';

describe('CfDailyFlockActivityComponent', () => {
  let component: CfDailyFlockActivityComponent;
  let fixture: ComponentFixture<CfDailyFlockActivityComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CfDailyFlockActivityComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CfDailyFlockActivityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
