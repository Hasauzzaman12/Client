import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditCfDailyFlockActivityComponent } from './add-edit-cf-daily-flock-activity.component';

describe('AddEditCfDailyFlockActivityComponent', () => {
  let component: AddEditCfDailyFlockActivityComponent;
  let fixture: ComponentFixture<AddEditCfDailyFlockActivityComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddEditCfDailyFlockActivityComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddEditCfDailyFlockActivityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
