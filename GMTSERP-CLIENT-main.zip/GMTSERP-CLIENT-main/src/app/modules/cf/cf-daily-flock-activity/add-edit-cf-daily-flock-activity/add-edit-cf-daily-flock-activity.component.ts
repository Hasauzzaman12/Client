import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable, of, startWith, debounceTime, distinctUntilChanged, switchMap, map } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-add-edit-cf-daily-flock-activity',
  templateUrl: './add-edit-cf-daily-flock-activity.component.html',
  styleUrls: ['./add-edit-cf-daily-flock-activity.component.scss']
})
export class AddEditCfDailyFlockActivityComponent implements OnInit {

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';

  myControl = new FormControl();
  options = [];
  filteredOptions: Observable<any>;


  constructor( public _apiService: ApiServiceService,
    private _snackBar: MatSnackBar,
    public router: Router,
    private authservice: AuthService,
    private currentRoute: ActivatedRoute,
    private datepipe: DatePipe) { 
      this.filteredOptions = this.myControl.valueChanges.pipe(

        startWith(''),
  
        debounceTime(400),
  
        distinctUntilChanged(),
  
        switchMap(val => {
  
          if(val!=''){
            return this.filter(val || '')
          }else{
            return '';
          }
  
         }) 
  
      )
    }

    newBlogForm!: FormGroup;
    @Input() cfissue: any;
    id: number = 0;
    activity_Date: any;
    farmer_Id: number = 0;
    farmer_Name: string = '';
    farmer_Code: string = '';
    flock_Id: number = 0;
    open_Date: any;
    cluster_Id: number = 0;
    cluster_Name: string = '';
    branch_Id: number = 0;
    branch_Name: string = '';
    region_Id: number = 0;
    region_Name: string = '';
    total_Birds_Qty: number = 0;
    total_Issued_Feed: number = 0;
    birds_Age: number = 0;
    dead_Today: number = 0;
    dead_Total: number = 0;
    dead_Total_Current: number = 0;
    dead_Per: number = 0;
    dead_Reason: string = '';
    dead_Action_Taken: string = '';
    current_Bird_Qty: number = 0;
    feed_Used_Today: number = 0;
    feed_Used_Total: number = 0;
    feed_Used_Total_Current: number = 0;
    current_Feed_Stock: number = 0;
    weight_Gain_Today: number = 0;
    weight_Gain_Total: number = 0;
    weight_Gain_Total_Current: number = 0;
    weight_Gain_Avg: number = 0;
    fG_Sales_Weight: number = 0;
    fcr: number = 0;
    is_Sanitized: boolean = false;

    remarks: string = '';
    is_active: boolean = true;
    user_Id: number = this.authservice.getUserId;
    isHide = true;

    flockList$!: Observable<any[]>;
    // deadReasonList$!: Observable<any[]>;
    // deadActionList$!: Observable<any[]>;

    dead_reason_list: any[] = [];
    dead_action_list: any[] = [];
    selectedValueDr: string[]=[]
    selectedValueDa: string[]=[]
    // public isExistDA: boolean = false;

  ngOnInit(): void {
    let currentDateTime = this.datepipe.transform((new Date), 'MM/dd/yyyy h:mm:ss');
    this.newBlogForm = new FormGroup({
      id: new FormControl(0),
      activity_Date: new FormControl(null),
      farmer_Id: new FormControl(0),
      flock_Id: new FormControl(0),
      total_Birds_Qty: new FormControl(0),
      total_Issued_Feed: new FormControl(0),
      birds_Age: new FormControl(0),
      dead_Today: new FormControl(0),
      dead_Total: new FormControl(0),
      dead_Per: new FormControl(0),
      dead_Reason: new FormControl(''),
      dead_Action_Taken: new FormControl(''),
      current_Bird_Qty: new FormControl(0),
      feed_Used_Today: new FormControl(0),
      feed_Used_Total: new FormControl(0),
      current_Feed_Stock: new FormControl(0),
      weight_Gain_Today: new FormControl(0),
      weight_Gain_Total: new FormControl(0),
      weight_Gain_Avg: new FormControl(0),
      fG_Sales_Weight: new FormControl(0),
      fcr: new FormControl(0),
      is_Sanitized: new FormControl(''),
      remarks: new FormControl(''),
      is_active: new FormControl(''),
      selectedValueDr: new FormControl(''),
      selectedValueDa: new FormControl('')

    });

    let id = this.currentRoute.snapshot.paramMap.get('id');
    if (id != null) {
      this.getCFDailyFlockActivityById(id);

    } else {
      this.activity_Date = currentDateTime;
    }

    // this.deadReasonList$ = this._apiService.getCFDeadReasonList();
    // this.deadActionList$ = this._apiService.getCFDeadActionList();

    this._apiService.getCFDeadReasonList().subscribe((data: any) => {

      this.dead_reason_list = data;

    });
    this._apiService.getCFDeadActionList().subscribe((data: any) => {

      this.dead_action_list = data;

    });
  }

  getCFDailyFlockActivityById(id: number | string) {
    this._apiService.getCFDailyFlockActivityById(id).subscribe((data: any) => {

      this.id= data.id;
      this.activity_Date = data.activity_Date;
      this.farmer_Id = data.farmer_Id;
      this.farmer_Name=data.farmer_Name;
      this.farmer_Code = data.farmer_Code;
      this.cluster_Id = data.cluster_Id;
      this.cluster_Name=data.cluster_Name;
      this.branch_Id = data.branch_Id;
      this.branch_Name=data.branch_Name;
      this.region_Id = data.region_Id;
      this.region_Name=data.region_Name;
      this.flock_Id = data.flock_Id;
      this.open_Date = data.open_Date;
      this.total_Birds_Qty = data.total_Birds_Qty;
      this.total_Issued_Feed = data.total_Issued_Feed;
      this.birds_Age = data.birds_Age;
      this.dead_Total = data.dead_Total;
      this.dead_Total_Current = data.dead_Total;
      this.dead_Today = data.dead_Today;
      this.dead_Per = data.dead_Per;
      // this.dead_Reason = data.dead_Reason == null ? '' : data.dead_Reason;
      // this.dead_Action_Taken = data.dead_Action_Taken == null ? '' : data.dead_Action_Taken;
      this.selectedValueDa =data.selectedValueDa == null ? [] : data.selectedValueDa;
      this.selectedValueDr = data.selectedValueDr == null ? [] : data.selectedValueDr;
      this.current_Bird_Qty = data.current_Bird_Qty;
      this.feed_Used_Today = data.feed_Used_Today;
      this.feed_Used_Total = data.feed_Used_Total;
      this.feed_Used_Total_Current = data.feed_Used_Total;
      this.current_Feed_Stock = data.current_Feed_Stock;
      this.weight_Gain_Today = data.weight_Gain_Today;
      this.weight_Gain_Total = data.weight_Gain_Total;
      this.weight_Gain_Total_Current = data.weight_Gain_Total;
      this.weight_Gain_Avg = data.weight_Gain_Avg;
      this.fG_Sales_Weight = data.fG_Sales_Weight;
      this.fcr = data.fcr;
      this.is_Sanitized = data.is_Sanitized;
      this.remarks =  data.remarks;
      
      this.flockList$=this._apiService.getFlockByFarmer(data.farmer_Id);

    });
};

onSubmit(data: any) {

  console.log(data);

  if (data.activity_Date == '' || data.activity_Date == null) {
    alert("Date is Required")
    return;
  }
  if (data.farmer_Id == '' || data.farmer_Id == null || data.farmer_Id == 0) {
    alert("Farmer is Required")
    return;
  }
  if (data.flock_Id == '' || data.flock_Id == null || data.flock_Id == 0) {
    alert("Flock is Required")
    return;
  }

  if (data.dead_Today>0 && this.selectedValueDr.length==0) {
    alert("Dead Reason is Required")
    return;
  }



  const formData = new FormData();

  data.id = this.id;

  formData.append('id', this.id.toString());
  if (data.activity_Date != null) {
    formData.append('activity_Date', data.activity_Date);
  }
  formData.append('farmer_Id', data.farmer_Id);
  formData.append('flock_Id', data.flock_Id);
  formData.append('cluster_Id', this.cluster_Id.toString());
  formData.append('branch_Id', this.branch_Id.toString());
  formData.append('region_Id', this.region_Id.toString());

  formData.append('total_Birds_Qty', data.total_Birds_Qty);
  formData.append('total_Issued_Feed', data.total_Issued_Feed);
  formData.append('birds_Age', data.birds_Age);
  formData.append('dead_Today', data.dead_Today);
  formData.append('dead_Total', data.dead_Total);
  formData.append('dead_Per', data.dead_Per);
  if (this.selectedValueDr.length>0) {
  formData.append('dead_Reason', this.selectedValueDr.toString());
  }
  if (this.selectedValueDa.length>0) {
  formData.append('dead_Action_Taken', this.selectedValueDa.toString());
  }
  formData.append('current_Bird_Qty', data.current_Bird_Qty);
  formData.append('feed_Used_Today', data.feed_Used_Today);
  formData.append('feed_Used_Total', data.feed_Used_Total);
  formData.append('current_Feed_Stock', data.current_Feed_Stock);
  formData.append('weight_Gain_Today', data.weight_Gain_Today);
  formData.append('weight_Gain_Avg', data.weight_Gain_Avg);
  formData.append('weight_Gain_Total', data.weight_Gain_Total);
  formData.append('fG_Sales_Weight', data.fG_Sales_Weight);
  formData.append('fcr', data.fcr);
  formData.append('is_Sanitized', data.is_Sanitized);

  formData.append('remarks', data.remarks == null ? '' : data.remarks);
  formData.append('is_active', data.is_active);
  formData.append('user_Id', this.user_Id.toString());
  
  if (this.newBlogForm.valid) {
    if (data.id != 0) {
      this._apiService.updateCFDailyFlockActivity(formData)
      .subscribe({
        next: (res) => {
          this._snackBar.open("Flock Activity Updated Successfully", "Update", {
                horizontalPosition: this.horizontalPosition,
                verticalPosition: this.verticalPosition,
                duration: 2000
          });
              
          this.router.navigate(['/cf-daily-flock-activity']);
        },
        error: (err) => {
          if(err.status==400){
            this._snackBar.open("This Activity Already Exist", "Exist", {
             horizontalPosition: this.horizontalPosition,
             verticalPosition: this.verticalPosition,
              duration: 2000
        }
        )}}

      })
    }
    else {
      this._apiService.addCFDailyFlockActivity(formData)
      .subscribe({
        next: (res) => {
       this._snackBar.open("Flock Activity Saved Successfully", "Success", {
          horizontalPosition: this.horizontalPosition,
          verticalPosition: this.verticalPosition,
          duration: 2000
        }
        );

        this.router.navigate(['/cf-daily-flock-activity']);
        },
        error: (err) => {
          if(err.status==400){
            this._snackBar.open("This Activity Already Exist", "Exist", {
             horizontalPosition: this.horizontalPosition,
             verticalPosition: this.verticalPosition,
              duration: 2000
        }
        )}}

      })
    }
  }
}


  filter(val: string): Observable <any>{

    const formData = new FormData();
    formData.append('code', val);
    formData.append('is_active', 'true');
    formData.append('user_Id', this.user_Id.toString());
    
    return this._apiService.getCfFarmersFiltered(formData)

    .pipe(

      map(response => response.filter((option: { code: string; }) => { 

        return option.code.toLowerCase().indexOf(val.toLowerCase()) !== -1

      }))

    )

   }  
   onSelFunc(option: any){
    if(option.id>0){
      this.farmer_Id=option.id;
      this.flock_Id=0;
      this._apiService.getCfFarmerById(this.farmer_Id).subscribe((data: any) => {
       this.farmer_Name=data.name;
       this.cluster_Id = data.cluster_Id;
       this.cluster_Name=data.cluster_Name;
       this.branch_Id = data.branch_Id;
       this.branch_Name=data.branch_Name;
       this.region_Id = data.region_Id;
       this.region_Name=data.region_Name;
   
       this.flockList$=this._apiService.getOpenFlockByFarmer(this.farmer_Id);
     });
      
     }
  }

  gotoBack() {
    this.router.navigate(['/cf-daily-flock-activity']);
  }
  reset(): void {
    this.ngOnInit();
  }
  changeFlock(event: any) {
 
    if (event.target.value > 0) {
      this.flock_Id = event.target.value;
      this._apiService.getDailyFlockData(this.flock_Id).subscribe((data: any) => {
        this.open_Date = data.open_Date;
        this.total_Birds_Qty = data.total_Birds_Qty;
        this.total_Issued_Feed = data.total_Issued_Feed;
        this.dead_Total = data.dead_Total;
        this.dead_Total_Current = data.dead_Total;
        this.feed_Used_Total = data.feed_Used_Total;
        this.feed_Used_Total_Current = data.feed_Used_Total;
        this.weight_Gain_Total = data.weight_Gain_Total;
        this.weight_Gain_Total_Current = data.weight_Gain_Total;
        this.fG_Sales_Weight = data.fG_Sales_Weight;
  
        data.open_Date=this.datepipe.transform(this.open_Date, 'yyyy-MM-dd');
        data.work_Date=this.datepipe.transform(this.activity_Date, 'yyyy-MM-dd');
        var date1 = new Date(data.open_Date);
        var date2 = new Date(data.work_Date);
  
        if(date2.getTime()> date1.getTime()){
          var diff = Math.abs(date2.getTime() - date1.getTime());
          var diffDays = Math.ceil(diff / (1000 * 3600 * 24));
  
          this.birds_Age=diffDays
        }else{
          this.birds_Age=0
        }

      });
      
    }
  }
  
  updateCalculation(data: any) {
    if (data.farmer_Id == '' || data.farmer_Id == null || data.farmer_Id == 0) {
      alert("Farmer is Required")
      return;
    }
    if (data.flock_Id == '' || data.flock_Id == null || data.flock_Id == 0) {
      alert("Flock is Required")
      return;
    }
    if(data.dead_Today>this.total_Birds_Qty){
      alert("Invalid Qty")
      return;
    }

    this.dead_Total = 0;
    this.dead_Per = 0;
    this.current_Bird_Qty = 0;

    this.feed_Used_Total=0;
    this.current_Feed_Stock=0;
    this.weight_Gain_Total=0;
    
    if (data != null) {
      this.dead_Total = this.dead_Total_Current+data.dead_Today;
      this.dead_Per=this.naiveRound((this.dead_Total*100)/this.total_Birds_Qty);
      this.current_Bird_Qty=this.total_Birds_Qty- this.dead_Total;

      this.feed_Used_Total = this.feed_Used_Total_Current+data.feed_Used_Today;
      this.current_Feed_Stock=this.total_Issued_Feed- this.feed_Used_Total;

      if(data.weight_Gain_Avg>0){
        this.weight_Gain_Today=data.weight_Gain_Avg-this.weight_Gain_Total_Current;
      }
      this.weight_Gain_Total = this.weight_Gain_Total_Current+this.weight_Gain_Today;
  
      this.fcr=this.naiveRound(this.feed_Used_Total/((this.weight_Gain_Total/1000)*this.current_Bird_Qty)+this.fG_Sales_Weight);
 
     
    }
   
  }
  naiveRound(num: number = 0, decimalPlaces = 2) {
    var p = Math.pow(10, decimalPlaces);
    return Math.round(num * p) / p;
  }
  calculateDiff(data: any){
    if(this.flock_Id>0){
      data.open_Date=this.datepipe.transform(this.open_Date, 'yyyy-MM-dd');
      var date1 = new Date(data.open_Date);
      var date2 = new Date(data.activity_Date);
  
        if(date2.getTime()> date1.getTime()){
          var diff = Math.abs(date2.getTime() - date1.getTime());
          var diffDays = Math.ceil(diff / (1000 * 3600 * 24));
  
          this.birds_Age=diffDays
          // this.isExistDailyActivity(this.flock_Id,data.activity_Date)
        }else{
          this.birds_Age=0
        }   
    }
    }

}
