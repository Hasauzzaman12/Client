import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';

@Component({
  selector: 'app-cf-daily-flock-activity',
  templateUrl: './cf-daily-flock-activity.component.html',
  styleUrls: ['./cf-daily-flock-activity.component.scss']
})
export class CfDailyFlockActivityComponent implements OnInit {

  code: string = '';
  farmer_Name: string = '';
  flock_No: string = '';
  isFilterShow: boolean = false;
  branch_Id: number = 0;
  from_Date : any=null;
  to_Date : any=null;
  user_Id: number = this.authservice.getUserId;

  displayedColumns: string[] = ['activity_Date','farmer_Name','flock_No','branch_Name','dead_Today','feed_Used_Today','weight_Gain_Avg','fcr','action'];
  dataSource!: MatTableDataSource<any>;

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';


  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  
  branchList$!: Observable<any[]>;
  warehouseList$!: Observable<any[]>;

  constructor(public _apiService: ApiServiceService,
    private authservice: AuthService,
    private _snackBar: MatSnackBar,
    public dialog: MatDialog,
    private router: Router) { }


  ngOnInit(): void {
    this.getCFDailyFlockActivityList();
    this.branchList$ = this._apiService.getCfBranchList();
  }
  getCFDailyFlockActivityList() {
    const formData = new FormData();
    if (this.farmer_Name != ''||this.farmer_Name != null) {
      formData.append('name', this.farmer_Name);
    }
    if (this.flock_No != ''||this.flock_No != null) {
      formData.append('flock_No', this.flock_No);
    }
    if (this.branch_Id != 0||this.branch_Id != null) {
      formData.append('branch_Id', this.branch_Id.toString());
    }
    if(this.from_Date != null && this.to_Date != null){
      formData.append('from_Date', this.from_Date);
      formData.append('to_Date', this.to_Date);
    }
    if (this.user_Id != 0||this.user_Id != null) {
      formData.append('user_Id', this.user_Id.toString());
    }

    this._apiService.getCFDailyFlockActivityListFiltered(formData)
      .subscribe({
        next: (res) => {
          this.dataSource = new MatTableDataSource(res);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
        },
        error: (err) => {
          console.log("Error");
        }

      })
  }

  openForEdit(id: number) {

    this.router.navigate(['/cf-daily-flock-activity/edit/' + id]);
  }
  gotoNew() {
    this.router.navigate(['/add-cf-daily-flock-activity']);
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  SearchSummary() {
    this.getCFDailyFlockActivityList();
  }
  reset() {

    this.code='';
    this.farmer_Name='';
    this.flock_No='';
    this.branch_Id=0;
    this.from_Date=null;
    this.to_Date=null;

    this.getCFDailyFlockActivityList();
  }
  toggleFilter() {
    this.isFilterShow = !this.isFilterShow;
  }
}
