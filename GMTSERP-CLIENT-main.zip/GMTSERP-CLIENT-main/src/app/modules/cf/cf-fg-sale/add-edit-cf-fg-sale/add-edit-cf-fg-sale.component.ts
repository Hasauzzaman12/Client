import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable, of, startWith, debounceTime, distinctUntilChanged, switchMap, map } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';
import { DatePipe } from '@angular/common';
import { SD } from 'src/environments/sd';

@Component({
  selector: 'app-add-edit-cf-fg-sale',
  templateUrl: './add-edit-cf-fg-sale.component.html',
  styleUrls: ['./add-edit-cf-fg-sale.component.scss']
})
export class AddEditCfFgSaleComponent implements OnInit {

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';

  myControl = new FormControl();
  options = [];
  filteredOptions: Observable<any>;

  constructor( public _apiService: ApiServiceService,
    private _snackBar: MatSnackBar,
    public router: Router,
    private authservice: AuthService,
    private currentRoute: ActivatedRoute,
    private datepipe: DatePipe) {
      this.filteredOptions = this.myControl.valueChanges.pipe(

        startWith(''),
  
        debounceTime(400),
  
        distinctUntilChanged(),
  
        switchMap(val => {
  
          if(val!=''){
            return this.filter(val || '')
          }else{
            return '';
          }
  
         }) 
  
      )
     }

    newBlogForm!: FormGroup;

    @Input() cffgsale: any;
    id: number = 0;
    code: string = '';
    sale_Date: any;
    farmer_Id: number = 0;
    farmer_Name: string = '';
    farmer_Code: string = '';
    flock_Id: number = 0;
    sold_Qty: number = 0;
    open_Qty: number = 0;
    cluster_Id: number = 0;
    cluster_Name: string = '';
    branch_Id: number = 0;
    branch_Name: string = '';
    region_Id: number = 0;
    region_Name: string = '';
    customer_Info_Id: number = 0;
    company_Id: number = this.authservice.getCompanyId;
    unit_Id: number =this.authservice.getUnitId;
    total_Qty: number = 0;
    total_Weight: number = 0;
    total_Amount: number = 0;
    remarks: string = '';
    is_active: boolean = true;
    user_Id: number = this.authservice.getUserId;
  


    flockList$!: Observable<any[]>;
    customerList$!: Observable<any[]>;
    itemList$!: Observable<any[]>;
    unitListByUserId$!: Observable<any[]>;

    fg_sale_detail_list: any[] = [];

  ngOnInit(): void {
    let currentDateTime = this.datepipe.transform((new Date), 'MM/dd/yyyy h:mm:ss');

    this.newBlogForm = new FormGroup({
      id: new FormControl(0),
      code: new FormControl(''),
      sale_Date: new FormControl(null),
      farmer_Id: new FormControl(0),
      flock_Id: new FormControl(0),
      customer_Info_Id: new FormControl(0),
      total_Qty: new FormControl(0),
      total_Weight: new FormControl(0),
      total_Amount: new FormControl(0),
      remarks: new FormControl(''),
      is_active: new FormControl(''),
      unit_Id: new FormControl(this.unit_Id)

    });

    this.customerList$ = this._apiService.getCfCustomerList();
    this.unitListByUserId$ = this._apiService.getUnitListByUserId(this.user_Id);
    this.itemList$ = this._apiService.getCfItemsListBySubCategory(SD.Broiler_FG_Id);

    let id = this.currentRoute.snapshot.paramMap.get('id');
    if (id != null) {
      this.getCFFGSaleById(id);

    } else {
      this.sale_Date = currentDateTime;
      this.getCFFGSaleCode();
    }
  }

  getCFFGSaleById(id: number | string) {
    this._apiService.getCFFGSaleById(id).subscribe((data: any) => {

      this.id= data.id;
      this.code = data.code;
      this.sale_Date = data.sale_Date;
      this.farmer_Id = data.farmer_Id;
      this.farmer_Name=data.farmer_Name;
      this.farmer_Code = data.farmer_Code;
      this.cluster_Id = data.cluster_Id;
      this.cluster_Name=data.cluster_Name;
      this.branch_Id = data.branch_Id;
      this.branch_Name=data.branch_Name;
      this.region_Id = data.region_Id;
      this.region_Name=data.region_Name;
      this.flock_Id = data.flock_Id;
      this.customer_Info_Id = data.customer_Info_Id;
      this.total_Qty = data.total_Qty;
      this.total_Weight = data.total_Weight;
      this.total_Amount = data.total_Amount;
      this.unit_Id =  data.unit_Id;
      this.remarks =  data.remarks;
      this.is_active=data.is_active;

      
      this.fg_sale_detail_list = data.fgSaleDetailList;
      this.flockList$=this._apiService.getFlockByFarmer(data.farmer_Id);
      this._apiService.getFlockAvailabaleQty(this.flock_Id).subscribe((data: any) => {
        this.open_Qty=data.open_Qty;
        this.sold_Qty=data.sold_Qty;
      });
  

    });
  }
  getCFFGSaleCode() {
    this._apiService.getCFFGSaleCode()
      .subscribe((data: any) => {
        this.code = data;
      })
  }
  onSubmit(data: any) {

    const formData = new FormData();

    if (data.code == '') {
      alert("GRN No is Required")
      return;
    }
    if (data.sale_Date == '' || data.sale_Date == null) {
      alert("Sale Date is Required")
      return;
    }
    if (this.farmer_Id == null || this.farmer_Id == 0) {
      alert("Select Farmer")
      return;
    }
    if (this.flock_Id == null || this.flock_Id == 0) {
      alert("Select Flock")
      return;
    }
    if (data.customer_Info_Id == null ||  data.customer_Info_Id == 0) {
      alert("Select Customer")
      return;
    }
    if (this.fg_sale_detail_list.length==0) {
      alert("Enter Sale Deatils")
      return;
    }

    data.id = this.id;

    formData.append('id', this.id.toString());
    formData.append('code', data.code == null ? '' : data.code);
    if (data.sale_Date != null) {
      formData.append('sale_Date', data.sale_Date);
    }

    formData.append('farmer_Id', data.farmer_Id);
    formData.append('flock_Id', data.flock_Id);
    formData.append('customer_Info_Id', data.customer_Info_Id);
    formData.append('cluster_Id', this.cluster_Id.toString());
    formData.append('branch_Id', this.branch_Id.toString());
    formData.append('region_Id', this.region_Id.toString());
    
    formData.append('company_Id', this.company_Id.toString());
    formData.append('unit_Id', data.unit_Id);
    formData.append('total_Qty', data.total_Qty);
    formData.append('total_Weight', data.total_Weight);
    formData.append('total_Amount', data.total_Amount);

    formData.append('remarks', data.remarks == null ? '' : data.remarks);
    formData.append('is_active', data.is_active);
    formData.append('user_Id', this.user_Id.toString());

    for (let i = 0; i < this.fg_sale_detail_list.length; i++) {

      if ((this.fg_sale_detail_list[i].inv_Item_Id == 0 || this.fg_sale_detail_list[i].inv_Item_Id == "" || this.fg_sale_detail_list[i].inv_Item_Id == null)) {
        alert("Invalid Input in Sale Detail Tab!");
        return;
      }
      if ((this.fg_sale_detail_list[i].uom_Id == 0 || this.fg_sale_detail_list[i].uom_Id == "" || this.fg_sale_detail_list[i].uom_Id == null)) {
        alert("Invalid Input in Sale Detail Tab! Select UOM");
        return;
      }

      const keyPrefix = "fgSaleDetailList[" + i.toString() + "].";
      formData.append(keyPrefix + "id", this.fg_sale_detail_list[i].id);
      formData.append(keyPrefix + "inv_Item_Id", this.fg_sale_detail_list[i].inv_Item_Id);
      formData.append(keyPrefix + "uom_Id", this.fg_sale_detail_list[i].uom_Id);
      formData.append(keyPrefix + "qty", this.fg_sale_detail_list[i].qty);
      formData.append(keyPrefix + "weight", this.fg_sale_detail_list[i].weight);
      formData.append(keyPrefix + "avg_Weight", this.fg_sale_detail_list[i].avg_Weight);
      formData.append(keyPrefix + "rate", this.fg_sale_detail_list[i].rate);
      formData.append(keyPrefix + "total", this.fg_sale_detail_list[i].total);
    }

    if (this.newBlogForm.valid) {
      if (data.id != 0) {

        this._apiService.updateCFFGSale(formData).subscribe(res => {

          this._snackBar.open("Broiler Sale Updated Successfully", "Update", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });

          this.router.navigate(['/cf-fg-sale']);


        })
      }
      else {
        this._apiService.addCFFGSale(formData).subscribe(res => {

          this._snackBar.open("Broiler Sale Saved Successfully", "Success", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });

          this.router.navigate(['/cf-fg-sale']);


        })
      }
    }

  }

  addFGSaleDetailRow() {

    if (this.farmer_Id == null || this.farmer_Id == 0) {
      alert("Select Farmer")
      return;
    }

    this.fg_sale_detail_list.push({
      id: 0,
      inv_Item_Id: 0,
      uom_Id: 0,
      qty: 0,
      weight: 0,
      avg_Weight: 0,
      rate: 0,
      total: 0
    });
  }

  deleteFGSaleDetailRow(Index: any) {
    if (confirm('Are you sure want to delete?')) {
      this.fg_sale_detail_list.splice(Index, 1);
      this.total_Qty = 0;
      this.total_Weight = 0;
      this.total_Amount = 0;
      this.fg_sale_detail_list.forEach(a => this.total_Qty += a.qty);
      this.fg_sale_detail_list.forEach(a => this.total_Weight += a.weight);
      this.fg_sale_detail_list.forEach(a => this.total_Amount += a.total);
    }
  }

  gotoBack() {
    this.router.navigate(['/cf-fg-sale']);
  }
  reset(): void {
    this.ngOnInit();
  }


  updateCalculation(data: any) {
    this.total_Qty = 0;
    this.total_Weight = 0;
    this.total_Amount = 0;

    if (data != null) {
      data.avg_Weight = this.naiveRound(data.weight/data.qty);
      data.total = this.naiveRound(data.weight * data.rate);
    }
    this.fg_sale_detail_list.forEach(a => this.total_Qty += a.qty);
    this.fg_sale_detail_list.forEach(a => this.total_Weight += a.weight);
    this.fg_sale_detail_list.forEach(a => this.total_Amount += a.total);
  }

  changeItem(row: any) {

    if (row.inv_Item_Id >0) {
    this._apiService.getItemById(row.inv_Item_Id).subscribe((data: any) => {

      row.item_Name = data.item_Name;
      row.uom_Id = data.uom_Id;
      row.uom_Name = data.uom_Name;
    });


  }
}

naiveRound(num: number = 0, decimalPlaces = 2) {
  var p = Math.pow(10, decimalPlaces);
  return Math.round(num * p) / p;
}
filter(val: string): Observable <any>{

  const formData = new FormData();
  formData.append('code', val);
  formData.append('is_active', 'true');
  
  return this._apiService.getCfFarmersFiltered(formData)

  .pipe(

    map(response => response.filter((option: { code: string; }) => { 

      return option.code.toLowerCase().indexOf(val.toLowerCase()) !== -1

    }))

  )

 }  
 onSelFunc(option: any){
  if(option.id>0){
    this.farmer_Id=option.id;
    this._apiService.getCfFarmerById(this.farmer_Id).subscribe((data: any) => {
     this.farmer_Name=data.name;
     this.cluster_Id = data.cluster_Id;
     this.cluster_Name=data.cluster_Name;
     this.branch_Id = data.branch_Id;
     this.branch_Name=data.branch_Name;
     this.region_Id = data.region_Id;
     this.region_Name=data.region_Name;
 
     this.flockList$=this._apiService.getOpenFlockByFarmer(this.farmer_Id);

   });
    
   }
}

changeFlock(event: any) {
  this.flock_Id = event.target.value;
  if (this.flock_Id > 0) {
    this._apiService.getFlockAvailabaleQty(this.flock_Id).subscribe((data: any) => {
      this.open_Qty=data.open_Qty;
      this.sold_Qty=data.sold_Qty;
    });

  }
}
}
