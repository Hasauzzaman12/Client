import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditCfFgSaleComponent } from './add-edit-cf-fg-sale.component';

describe('AddEditCfFgSaleComponent', () => {
  let component: AddEditCfFgSaleComponent;
  let fixture: ComponentFixture<AddEditCfFgSaleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddEditCfFgSaleComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddEditCfFgSaleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
