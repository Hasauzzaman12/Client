import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';
import { DetailCfFgSaleComponent } from './detail-cf-fg-sale/detail-cf-fg-sale.component';

@Component({
  selector: 'app-cf-fg-sale',
  templateUrl: './cf-fg-sale.component.html',
  styleUrls: ['./cf-fg-sale.component.scss']
})
export class CfFgSaleComponent implements OnInit {

  code: string = '';
  farmer_Name: string = '';
  flock_No: string = '';
  user_Id: number = this.authservice.getUserId;
  isFilterShow: boolean = false;

  branch_Id: number = 0;
  from_Date : any=null;
  to_Date : any=null;


  displayedColumns: string[] = ['sale_Date','code','farmer_Name','branch_Name','flock_No','customer_Name','total_Qty','total_Weight','total_Amount','status','action'];
  dataSource!: MatTableDataSource<any>;

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';


  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  branchList$!: Observable<any[]>;

  constructor(public _apiService: ApiServiceService,
    private authservice: AuthService,
    private _snackBar: MatSnackBar,
    public dialog: MatDialog,
    private router: Router) { }

  ngOnInit(): void {
    this.getCFFGSaleList();
    this.branchList$ = this._apiService.getCfBranchList();
  }

  getCFFGSaleList() {
    const formData = new FormData();
    if (this.code != ''||this.code != null) {
      formData.append('code', this.code);
    }
    if (this.farmer_Name != ''||this.farmer_Name != null) {
      formData.append('name', this.farmer_Name);
    }
    if (this.flock_No != ''||this.flock_No != null) {
      formData.append('flock_No', this.flock_No);
    }
    if (this.branch_Id != 0||this.branch_Id != null) {
      formData.append('branch_Id', this.branch_Id.toString());
    }

    if(this.from_Date != null && this.to_Date != null){
      formData.append('from_Date', this.from_Date);
      formData.append('to_Date', this.to_Date);
    }
    

    this._apiService.getCFFGSaleListFiltered(formData)
      .subscribe({
        next: (res) => {
          this.dataSource = new MatTableDataSource(res);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
        },
        error: (err) => {
          console.log("Error");
        }

      })
  }
openForEdit(id: number) {

    this.router.navigate(['/cf-fg-sale/edit/' + id]);
  }
  gotoNew() {
    this.router.navigate(['/add-cf-fg-sale']);
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }


  SearchSummary() {
    this.getCFFGSaleList();
  }
  reset() {

    this.code='';
    this.farmer_Name='';
    this.flock_No='';
    this.branch_Id=0;
    this.from_Date=null;
    this.to_Date=null;

    this.getCFFGSaleList();
  }

  toggleFilter() {
    this.isFilterShow = !this.isFilterShow;
  }
  changeBranch(event: any) {
    if(event.target.value>0){
     this.branch_Id=event.target.value;
    }
  }
  openDialog(newObj: any): void {
    const dialogRef = this.dialog.open(DetailCfFgSaleComponent, {
      height: '90%',
      autoFocus: false,
      width: '70%',
      backdropClass: 'custom-dialog-backdrop-class',
      panelClass: 'custom-dialog-panel-class',
      data: { pageValue: newObj }
    });  
    dialogRef.afterClosed().subscribe(result => {
      console.log(result.data);
    });
  }
}
