import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CfFgSaleComponent } from './cf-fg-sale.component';

describe('CfFgSaleComponent', () => {
  let component: CfFgSaleComponent;
  let fixture: ComponentFixture<CfFgSaleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CfFgSaleComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CfFgSaleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
