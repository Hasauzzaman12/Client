import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';

@Component({
  selector: 'app-cf-approval-process',
  templateUrl: './cf-approval-process.component.html',
  styleUrls: ['./cf-approval-process.component.scss']
})
export class CfApprovalProcessComponent implements OnInit {

  code: string = '';
  region_Id: number = 0;
  branch_Id: number = 0;
  cluster_Id: number = 0;
  user_Id: number = this.authservice.getUserId;
  isFilterShow: boolean = false;

  displayedColumns: string[] = ['employee_Name','required_Process_Level','process_Level','region_Name','branch_Name','cluster_Name','is_Approval_Permision','is_Read_Permision','is_Write_Permision','effective_From','status','action'];
  dataSource!: MatTableDataSource<any>;

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';


  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  
  regionList$!: Observable<any[]>;
  branchList$!: Observable<any[]>;
  clusterList$!: Observable<any[]>;

  constructor(public _apiService: ApiServiceService,
    private authservice: AuthService,
    private _snackBar: MatSnackBar,
    public dialog: MatDialog,
    private router: Router) { }

  ngOnInit(): void {
    this.getCfApprovalProcessList();
    this.regionList$ = this._apiService.getCfRegionList();
  }


  getCfApprovalProcessList() {
    const formData = new FormData();
    if (this.code != ''||this.code != null) {
      formData.append('code', this.code);
    }
    if (this.region_Id != 0||this.region_Id != null) {
      formData.append('region_Id', this.region_Id.toString());
    }
    if (this.branch_Id != 0||this.branch_Id != null) {
      formData.append('branch_Id', this.branch_Id.toString());
    }
    if (this.cluster_Id != 0||this.cluster_Id != null) {
      formData.append('cluster_Id', this.cluster_Id.toString());
    }

  
    this._apiService.getCfApprovalProcessListFiltered(formData)
      .subscribe({
        next: (res) => {
          this.dataSource = new MatTableDataSource(res);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
        },
        error: (err) => {
          console.log("Error");
        }

      })
  }
  openForEdit(id: number) {

    this.router.navigate(['/cf-approval-process/edit/' + id]);
  }
  gotoNew() {
    this.router.navigate(['/add-cf-approval-process']);
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }


  SearchSummary() {
    this.getCfApprovalProcessList();
  }
  reset() {

    this.code='';
    this.region_Id=0;
    this.branch_Id=0;
    this.cluster_Id=0;

    this.getCfApprovalProcessList();
  }

  toggleFilter() {
    this.isFilterShow = !this.isFilterShow;
  }
  changeRegion(event: any) {
    if(event.target.value>0){
      this.branch_Id=0;
      this.cluster_Id=0;
      this.region_Id=event.target.value;
      this.branchList$=this._apiService.getBranchByRegion(this.region_Id);
      
    }
  }
  changeBranch(event: any) {
    if(event.target.value>0){
      this.cluster_Id=0;
      this.branch_Id=event.target.value;
      this.clusterList$=this._apiService.getClusterByBranch(this.branch_Id);
    }
  }


}
