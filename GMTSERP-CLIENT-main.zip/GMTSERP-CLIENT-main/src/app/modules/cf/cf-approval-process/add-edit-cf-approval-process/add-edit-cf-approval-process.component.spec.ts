import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditCfApprovalProcessComponent } from './add-edit-cf-approval-process.component';

describe('AddEditCfApprovalProcessComponent', () => {
  let component: AddEditCfApprovalProcessComponent;
  let fixture: ComponentFixture<AddEditCfApprovalProcessComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddEditCfApprovalProcessComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddEditCfApprovalProcessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
