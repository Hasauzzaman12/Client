import { DatePipe } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { debounceTime, distinctUntilChanged, map, Observable, startWith, switchMap } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';

@Component({
  selector: 'app-add-edit-cf-approval-process',
  templateUrl: './add-edit-cf-approval-process.component.html',
  styleUrls: ['./add-edit-cf-approval-process.component.scss']
})
export class AddEditCfApprovalProcessComponent implements OnInit {

 
  myControlEmpAuth = new FormControl();
  options = [];
  filteredOptionsEmpAuth: Observable<any>;

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';

  constructor( public _apiService: ApiServiceService,
    private _snackBar: MatSnackBar,
    private authservice: AuthService,
    private currentRoute: ActivatedRoute,
    public http: HttpClient,
    public router: Router,
    private datepipe: DatePipe) { 
      this.filteredOptionsEmpAuth = this.myControlEmpAuth.valueChanges.pipe(
        startWith(''),
        debounceTime(400),
        distinctUntilChanged(),
        switchMap(val => {
          if (val != '') {
            return this.filterEmpAuth(val || '')
          } else {
            return '';
          }
        })
      )
    }

    @Input() approvalprocess: any;
    id: number = 0; 
    authorised_Employee_Id: number = 0;
    authorised_Employee_Code: string = "";
    authorised_Employee_Name: string = "";
    required_Process_Level_ID: number = 0;
    process_Level_Id: number = 0;
    company_Id: number = this.authservice.getCompanyId;
    unit_Id: number =this.authservice.getUnitId;
    region_Id: number = 0;
    branch_Id: number = 0;
    cluster_Id: number = 0;
    farmer_Id: number = 0;

    is_Read_Permision: boolean = false;
    is_Write_Permision: boolean = false;
    is_Approval_Permision: boolean = false;
    effective_From: any;
    remarks: string = "";
    is_active: boolean = true;
    user_Id: number = this.authservice.getUserId;

    newBlogForm!: FormGroup;
    regionList$!: Observable<any[]>;
    branchList$!: Observable<any[]>;
    clusterList$!: Observable<any[]>;
    stageLevelList$!: Observable<any[]>;
    unitList$!: Observable<any[]>;

  ngOnInit(): void {
    let currentDateTime = this.datepipe.transform((new Date), 'MM/dd/yyyy h:mm:ss');
    this.newBlogForm = new FormGroup({
      id: new FormControl(0),
      authorised_Employee_Id: new FormControl(0),
      required_Process_Level_ID: new FormControl(0),
      process_Level_Id: new FormControl(0),
      unit_Id: new FormControl({value: this.unit_Id, disabled: true}),
      region_Id: new FormControl(0),
      branch_Id: new FormControl(0),
      emp_Category_Lookup_Id: new FormControl(0),
      cluster_Id: new FormControl(0),
      farmer_Id: new FormControl(0),
      is_Read_Permision: new FormControl(false),
      is_Write_Permision: new FormControl(false),
      is_Approval_Permision: new FormControl(false),
      effective_From: new FormControl(null),
      is_active: new FormControl(true),

    }
    )
    this.regionList$ = this._apiService.getCfRegionList();
    this.stageLevelList$=this._apiService.getCFStageLevelList();
    this.unitList$ = this._apiService.getUnitListByUserId(this.user_Id);

    let id = this.currentRoute.snapshot.paramMap.get('id');
    if (id != null) {
      this.getCfApprovalProcessById(id);

    } else {
      this.effective_From = currentDateTime;
    }
  }

  getCfApprovalProcessById(id: number | string) {
    this._apiService.getCfApprovalProcessById(id).subscribe((data: any) => {
      this.id= data.id;
      this.authorised_Employee_Id = data.authorised_Employee_ID;
      this.authorised_Employee_Code = data.employee_Code;
      this.authorised_Employee_Name = data.employee_Name;
      this.required_Process_Level_ID = data.required_Process_Level_ID;
      this.process_Level_Id = data.process_Level_Id;
      this.company_Id = data.company_Id;
      this.unit_Id=data.unit_Id;
      this.region_Id=data.region_Id;
      this.branch_Id=data.branch_Id;
      this.cluster_Id=data.cluster_Id;
      this.is_Read_Permision=data.is_Read_Permision;
      this.is_Write_Permision=data.is_Write_Permision;
      this.is_Approval_Permision=data.is_Approval_Permision;
      this.effective_From=data.effective_From;
      this.remarks = data.remarks;
      this.is_active=data.is_active;

      this.branchList$ = this._apiService.getBranchByRegion(data.region_Id);
      this.clusterList$=this._apiService.getClusterByBranch(data.branch_Id);


    });
  }
  filterEmpAuth(val: string): Observable<any> {
    const formData = new FormData();
    formData.append('employee_Id', val);
    if (this.user_Id != 0 || this.user_Id != null) {
      formData.append('user_Id', this.user_Id.toString());
    }
    formData.append('emp_Status', 'Active');

    return this._apiService.getEmployeesFiltered(formData)
      .pipe(
        map(response => response.filter((option: { employee_Id: string; }) => {
          return option.employee_Id.toLowerCase().indexOf(val.toLowerCase()) !== -1
        }))
      )
  }
  onSelFuncEmpAuth(option: any) {
    if (option.id > 0) {
      this.authorised_Employee_Id = option.id;
      this.authorised_Employee_Name = option.employee_Name;
    }
  }

  changeRegion(event: any) {
    if(event.target.value>0){
      this.branch_Id=0;
      this.cluster_Id=0;
      this.region_Id=event.target.value;
      this.branchList$=this._apiService.getBranchByRegion(this.region_Id);
      
    }
  }
  changeBranch(event: any) {
    if(event.target.value>0){
      this.cluster_Id=0;
      this.branch_Id=event.target.value;
      this.clusterList$=this._apiService.getClusterByBranch(this.branch_Id);
    }
  }
  onSubmit(data: any) {

    const formData = new FormData();
    if (data.authorised_Employee_Id == '' || data.authorised_Employee_Id == null || data.authorised_Employee_Id == 0) {
      alert("Authorized Employee is Required")
      return;
    }
    if (data.required_Process_Level_ID == '' || data.required_Process_Level_ID == null || data.required_Process_Level_ID == 0) {
      alert("Required Level is Required")
      return;
    }
    if (data.process_Level_Id == '' || data.process_Level_Id == null || data.process_Level_Id == 0) {
      alert("Superior Level is Required")
      return;
    }
    formData.append('id', this.id.toString());
    formData.append('authorised_Employee_ID', this.authorised_Employee_Id.toString());
    formData.append('required_Process_Level_ID',data.required_Process_Level_ID);
    formData.append('process_Level_Id',data.process_Level_Id);
    formData.append('company_Id', this.company_Id.toString());
    formData.append('unit_Id', this.unit_Id.toString());
    formData.append('region_Id', data.region_Id);
    formData.append('branch_Id',data.branch_Id);
    formData.append('cluster_Id', data.cluster_Id);
    formData.append('is_Read_Permision', data.is_Read_Permision);
    formData.append('is_Write_Permision', data.is_Write_Permision);
    formData.append('is_Approval_Permision', data.is_Approval_Permision);
    if (data.effective_From != null) {
      formData.append('effective_From', data.effective_From);
    }
   
    formData.append('remarks', data.remarks == null ? '' : data.remarks);
    formData.append('is_active', data.is_active);
    formData.append('user_Id', this.user_Id.toString());

    console.log(formData);

    if (this.newBlogForm.valid) {
      if (data.id != 0) {

        this._apiService.updateCfApprovalProcess(formData).subscribe(res => {

          this._snackBar.open("Approval Process Updated Successfully", "Update", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });

          this.router.navigate(['/cf-approval-process']);


        })
      }
      else {
        this._apiService.addCfApprovalProcess(formData).subscribe(res => {

          this._snackBar.open("Approval Process Successfully", "Success", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });

          this.router.navigate(['/cf-approval-process']);


        })
      }
    }
  }


  gotoBack() {
    this.router.navigate(['/cf-approval-process']);
  }
  reset(): void {
    this.ngOnInit();
  }

}
