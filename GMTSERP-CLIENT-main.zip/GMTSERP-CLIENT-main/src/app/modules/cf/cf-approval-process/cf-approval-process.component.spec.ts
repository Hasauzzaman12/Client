import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CfApprovalProcessComponent } from './cf-approval-process.component';

describe('CfApprovalProcessComponent', () => {
  let component: CfApprovalProcessComponent;
  let fixture: ComponentFixture<CfApprovalProcessComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CfApprovalProcessComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CfApprovalProcessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
