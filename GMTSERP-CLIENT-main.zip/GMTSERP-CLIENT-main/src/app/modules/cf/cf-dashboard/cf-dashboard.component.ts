import { Component, OnInit } from '@angular/core';
import { BreakpointObserver } from '@angular/cdk/layout';
import { ApiServiceService } from 'src/app/api-service.service';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';

@Component({
  selector: 'app-cf-dashboard',
  templateUrl: './cf-dashboard.component.html',
  styleUrls: ['./cf-dashboard.component.scss']
})


export class CfDashboardComponent implements OnInit {
  fgSalesHChartData: any = {};
  fgSalesWeightHChartData: any = {};
  feedIssuedChartData: any = {};
  docMedicineIssuedHChartData: any = {};
  fgSalesAreaChartOptions: any = {};
  dataChart: any;
  chartOptions: any = {};
  // chartOptionsData !: any;
  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';

  data: any[] = [];
  dataList1!: any[];
  dataList2!: any[];
  dataList3!: any[];
  dataList4!: any[];
  dataList5!: any[];
  dataList6!: any[];
  totalOpenFlock: number = 0;
  totalLiveBirds: number = 0;
  total1: number = 0;
  total2: number = 0;
  total3: number = 0;
  total4: number = 0;
  total5: number = 0;
  total6: number = 0;

  total_live_Bird1: number = 0;
  total_live_Bird2: number = 0;
  total_live_Bird3: number = 0;
  total_live_Bird4: number = 0;
  total_live_Bird5: number = 0;
  total_live_Bird6: number = 0;

  YearList$!: Observable<any[]>;
  MonthList$!: Observable<any[]>;
  monthList: string[] = environment.monthList;
  year_Id = new Date().getFullYear();
  month_Id = this.monthList[new Date().getMonth()];
  regionId: number = 0;
  branch_Id: number = 0;
  broilerTypeId : number = 0;
  year_Id1 = new Date().getFullYear();
  month_Id1 = this.monthList[new Date().getMonth()];
  regionId1: number = 0;
  branch_Id1: number = 0;

  FeedIssuedDataList: any[] = [];
  DOCAndMedicineDataList: any[] = [];
  FeedPurchasedDataList: any[] = [];
  DOCAndMedicinePurchasedDataList: any[] = [];
  FarmerWiseFlockSummaryOfRegisteredDataList: any[] = [];
  FarmerWiseFlockSummaryOfPendingDataList: any[] = [];
  ClosedFarmerDataList: any[] = [];
  BroilerSalesDataList: any[] = [];//amount
  BroilerSales2DataList: any[] = [];//qty
  monthColumns: any[] = [];
  monthColumns1: any[] = [];
  monthColumns2: any[] = [];
  pmonthColumns1: any[] = [];
  pmonthColumns2: any[] = [];
  cols_Value: number = 2;
  cfregionList$!: Observable<any[]>;
  cfbranchList$!: Observable<any[]>;
  cfbranchList1$!: Observable<any[]>;
  broiler_types$ !: Observable<any[]>;


  documentStyle = getComputedStyle(document.documentElement);
  textColor = '#495057';
  textColorSecondary = '#6c757d';
  surfaceBorder = '#dfe7ef';

  endpoint: string = `${environment.reportServerUrl}`;
  /** Based on the screen size, switch from standard to one column per row */
  constructor(private breakpointObserver: BreakpointObserver, public _apiService: ApiServiceService, private _snackBar: MatSnackBar) { }

  ngOnInit(): void {
    this.chartOptions = {
      maintainAspectRatio: false,
      aspectRatio: 1.2,
      plugins: {
        legend: {
          labels: {
            color: this.textColor
          }
        }
      },
      scales: {
        x: {
          ticks: {
            color: this.textColorSecondary,
            font: {
              weight: 500
            }
          },
          grid: {
            color: this.surfaceBorder,
            drawBorder: true
          },
          title: {
            display: true,
            text: 'Month',
            color: '#911',
            font: {
              family: 'Comic Sans MS',
              size: 15,
              weight: 'bold',
              lineHeight: 1,
            },
            padding: { top: 5, left: 0, right: 0, bottom: 0 }
          }
        },        
        y: {
          type: 'linear',
          display: true,
          position: 'left',
          ticks: {
            color: this.textColorSecondary
          },
          grid: {
            color: this.surfaceBorder
          },
          title: {
            display: true,
            text: 'Sales Value',
            color: '#911',
            font: {
              family: 'Comic Sans MS',
              size: 15,
              style: 'normal',
              weight: 'bold',
              lineHeight: 1
            },
            padding: { top: 5, left: 0, right: 0, bottom: 0 }
          },

        },
        y1: {
          type: 'linear',
          display: true,
          position: 'right',
          ticks: {
            color: this.textColorSecondary
          },
          grid: {
            drawOnChartArea: false,
            color: this.surfaceBorder
          },          
        }

      }
    };
    this.broiler_types$ = this._apiService.GetCfBroilerTypes();
    this.cfregionList$ = this._apiService.getCfRegionList();
    this.cols_Value = (window.innerWidth <= 1000) ? 1 : 2;
    this.YearList$ = this._apiService.getYearList();
    this.MonthList$ = this._apiService.getMonthList();
    this.getCfFeedIssuedData(this.year_Id, this.month_Id, this.regionId,this.branch_Id,this.broilerTypeId);
    this.getCfFeedPurchasedData(this.year_Id, this.month_Id, this.regionId,this.branch_Id);
    this.getCfBroilerSalesData(this.year_Id, this.month_Id, this.regionId,this.branch_Id,this.broilerTypeId);
    this._apiService.GetFarmerWiseFlockSummaryCountDashboardData(this.regionId,this.branch_Id).subscribe((data: any[]) => {
      this.FarmerWiseFlockSummaryOfRegisteredDataList = data.filter(function (el) {
        return el.totalFlockCount > 0 && el.totalOpenFlockClount == 0 && el.status == 1;
      });
      this.FarmerWiseFlockSummaryOfPendingDataList = data.filter(function (el) {
        return el.totalFlockCount == 0;
      });

      this.ClosedFarmerDataList = data.filter(function (el) {
        return el.status == 0;
      });
    });
    this._apiService.GetCFFlockAgeSummaryDashbordData(this.regionId,this.branch_Id,this.broilerTypeId).subscribe(
      data => {
        data.forEach(result => {
          this.totalLiveBirds = this.totalLiveBirds + result.avl_Live_Birds;
        });
        this.totalOpenFlock = data.length;
        this.dataList1 = data.filter(function (el) {
          return el.age_Value <= 10;
        }
        );
        this.dataList2 = data.filter(function (el) {
          return el.age_Value <= 20 && el.age_Value > 10;
        }
        );
        this.dataList3 = data.filter(function (el) {
          return el.age_Value <= 30 && el.age_Value > 20;
        }
        );
        this.dataList4 = data.filter(function (el) {
          return el.age_Value <= 40 && el.age_Value > 30;
        }
        );
        this.dataList5 = data.filter(function (el) {
          return el.age_Value <= 50 && el.age_Value > 40;
        }
        );
        this.dataList6 = data.filter(function (el) {
          return el.age_Value <= 60 && el.age_Value > 50;
        }
        );

        this.total1 = this.dataList1.length;
        this.total2 = this.dataList2.length;
        this.total3 = this.dataList3.length;
        this.total4 = this.dataList4.length;
        this.total5 = this.dataList5.length;
        this.total6 = this.dataList6.length;

        this.dataList1.forEach(result => {
          this.total_live_Bird1 = this.total_live_Bird1 + result.avl_Live_Birds;
        });
        this.dataList2.forEach(result => {
          this.total_live_Bird2 = this.total_live_Bird2 + result.avl_Live_Birds;
        });
        this.dataList3.forEach(result => {
          this.total_live_Bird3 = this.total_live_Bird3 + result.avl_Live_Birds;
        });
        this.dataList4.forEach(result => {
          this.total_live_Bird4 = this.total_live_Bird4 + result.avl_Live_Birds;
        });
        this.dataList5.forEach(result => {
          this.total_live_Bird5 = this.total_live_Bird5 + result.avl_Live_Birds;
        });
        this.dataList6.forEach(result => {
          this.total_live_Bird6 = this.total_live_Bird6 + result.avl_Live_Birds;
        });
      }
    );
  }
  onResize(event: any) {
    this.cols_Value = (event.target.innerWidth <= 1000) ? 1 : 2;
  }
  getCfFeedIssuedData(year: number, month: string, regionId: number,branchId: number,broilerTypeId: number) {
    this._apiService.GetCFProductionCostDetailsDashbordData(year, month, regionId,branchId,broilerTypeId)
      .subscribe((data: any[]) => {
        let result = this.getData(year, month, regionId,branchId, data);
        this.monthColumns = result[0]; this.FeedIssuedDataList = result[1]; this.DOCAndMedicineDataList = result[2];
        //this.generateFeedIssuedChart("");
      });
  }
  getCfFeedPurchasedData(year: number, month: string, regionId: number,branchId:number) {
    this._apiService.GetCFGRNDetailsDashbordData(year, month, regionId,branchId)
      .subscribe((data: any[]) => {
        let result = this.getData(year, month, regionId,branchId, data);
        this.monthColumns = result[0]; this.FeedPurchasedDataList = result[1]; this.DOCAndMedicinePurchasedDataList = result[2];
      });
  }  
  getLastTwoDigitOfYear(year : number){
    const lastDigit = String(year).slice(-2);
    return Number(lastDigit)
  }
  getLastThreeMonths() {
    var monthNames = ["January", "February", "March", "April", "May", "June","July", "August", "September", "October", "November", "December"];
    const date = new Date(this.year_Id, monthNames.indexOf(this.month_Id), 1);
    date.setMonth(date.getMonth()-2);
    var last3Months = []  
    for (var i = 2; i >= 0; i--) {
      date.setMonth(date.getMonth()+(i==2?0:1));
      last3Months.push(monthNames[(date.getMonth())].substring(0, 3) + '-' +this.getLastTwoDigitOfYear(date.getFullYear()));
    }
    return last3Months;
  }
  getData(year: number, month: string, regionId: number,branchId : number, data: any[]) {
    let monthColumns = this.getLastThreeMonths(); 
    if (data.length > 0) {       
      let FeedIssuedDataList = [];
      let DOCAndMedicineDataList = [];

      var starter = data.filter(function (el) { return el.feedType == "Starter"; });
      var finisher = data.filter(function (el) { return el.feedType == "Finisher"; });
      var grower = data.filter(function (el) { return el.feedType == "Grower"; });
      var doc = data.filter(function (el) { return el.feedType == "DOC"; });

      var c_starter = data.filter(function (el) { return el.feedType == "Color Starter"; });
      var c_finisher = data.filter(function (el) { return el.feedType == "Color Finisher"; });
      var c_grower = data.filter(function (el) { return el.feedType == "Color Grower"; });
      var c_doc = data.filter(function (el) { return el.feedType == "Color DOC"; });

      var medicine = data.filter(function (el) { return el.feedType == "Medicine"; });
      var vaccine = data.filter(function (el) { return el.feedType == "Vaccine"; });

      var total = { feedType: "Total :", unit: "Kg", month1value: 0, month2value: 0, month3value: 0, month1: monthColumns[0], month2: monthColumns[1], month3: monthColumns[2] }
      if (starter.length > 0) {
        var a = { feedType: "Starter", unit: "KG", month1value: 0, month2value: 0, month3value: 0, month1: monthColumns[0], month2: monthColumns[1], month3: monthColumns[2] };
        for (let index = 0; index < starter.length; index++) {
          a.feedType = starter[index].feedType;
          a.unit = starter[index].unit;
          if (a.month1 == starter[index].month) {  a.month1value = starter[index].qty; }
          else if (a.month2 == starter[index].month) { a.month2value = starter[index].qty; }
          else { a.month3value = starter[index].qty; }
        }
        total.month1value += a.month1value; total.month2value += a.month2value; total.month3value += a.month3value;
        FeedIssuedDataList.push(a);
      }     
      if (grower.length > 0) {
        a = { feedType: "Grower", unit: "KG", month1value: 0, month2value: 0, month3value: 0, month1: monthColumns[0], month2: monthColumns[1], month3: monthColumns[2] };
        for (let index = 0; index < grower.length; index++) {
          a.feedType = grower[index].feedType;
          a.unit = grower[index].unit;
          if (a.month1 == grower[index].month) { a.month1value = grower[index].qty; }
          else if (a.month2 == grower[index].month) { a.month2value = grower[index].qty; }
          else { a.month3value = grower[index].qty; }
        }
        total.month1value += a.month1value; total.month2value += a.month2value; total.month3value += a.month3value;
        FeedIssuedDataList.push(a);
      }
      if (finisher.length > 0) {
        a = { feedType: "Finisher", unit: "KG", month1value: 0, month2value: 0, month3value: 0, month1: monthColumns[0], month2: monthColumns[1], month3: monthColumns[2] };
        for (let index = 0; index < finisher.length; index++) {
          a.feedType = finisher[index].feedType;
          a.unit = finisher[index].unit;
          if (a.month1 == finisher[index].month) { a.month1value = finisher[index].qty; }
          else if (a.month2 == finisher[index].month) { a.month2value = finisher[index].qty; }
          else { a.month3value = finisher[index].qty; }
        }
        total.month1value += a.month1value; total.month2value += a.month2value; total.month3value += a.month3value;
        FeedIssuedDataList.push(a);
      }
      //color
      if (c_starter.length > 0) {
        var a = { feedType: "Starter", unit: "KG", month1value: 0, month2value: 0, month3value: 0, month1: monthColumns[0], month2: monthColumns[1], month3: monthColumns[2] };
        for (let index = 0; index < c_starter.length; index++) {
          a.feedType = c_starter[index].feedType;
          a.unit = c_starter[index].unit;
          if (a.month1 == c_starter[index].month) {  a.month1value = c_starter[index].qty; }
          else if (a.month2 == c_starter[index].month) { a.month2value = c_starter[index].qty; }
          else { a.month3value = c_starter[index].qty; }
        }
        total.month1value += a.month1value; total.month2value += a.month2value; total.month3value += a.month3value;
        FeedIssuedDataList.push(a);
      }     
      if (c_grower.length > 0) {
        a = { feedType: "Grower", unit: "KG", month1value: 0, month2value: 0, month3value: 0, month1: monthColumns[0], month2: monthColumns[1], month3: monthColumns[2] };
        for (let index = 0; index < c_grower.length; index++) {
          a.feedType = c_grower[index].feedType;
          a.unit = c_grower[index].unit;
          if (a.month1 == c_grower[index].month) { a.month1value = c_grower[index].qty; }
          else if (a.month2 == c_grower[index].month) { a.month2value = c_grower[index].qty; }
          else { a.month3value = c_grower[index].qty; }
        }
        total.month1value += a.month1value; total.month2value += a.month2value; total.month3value += a.month3value;
        FeedIssuedDataList.push(a);
      }
      if (c_finisher.length > 0) {
        a = { feedType: "Finisher", unit: "KG", month1value: 0, month2value: 0, month3value: 0, month1: monthColumns[0], month2: monthColumns[1], month3: monthColumns[2] };
        for (let index = 0; index < c_finisher.length; index++) {
          a.feedType = c_finisher[index].feedType;
          a.unit = c_finisher[index].unit;
          if (a.month1 == c_finisher[index].month) { a.month1value = c_finisher[index].qty; }
          else if (a.month2 == c_finisher[index].month) { a.month2value = c_finisher[index].qty; }
          else { a.month3value = c_finisher[index].qty; }
        }
        total.month1value += a.month1value; total.month2value += a.month2value; total.month3value += a.month3value;
        FeedIssuedDataList.push(a);
      }
      FeedIssuedDataList.push(total);      
      let l = FeedIssuedDataList.length-1;
      total = {
        feedType: "Total :", unit: "Ton", month1value: parseFloat((FeedIssuedDataList[l].month1value / 1000).toFixed(2)),
        month2value: parseFloat((FeedIssuedDataList[l].month2value / 1000).toFixed(2)), month3value: parseFloat((FeedIssuedDataList[l].month3value / 1000).toFixed(2)),
        month1: FeedIssuedDataList[l].month1, month2: FeedIssuedDataList[l].month2, month3: FeedIssuedDataList[l].month3
      }
      FeedIssuedDataList.push(total);
      
      total = { feedType: "Total :", unit: "", month1value: 0, month2value: 0, month3value: 0, month1: monthColumns[0], month2: monthColumns[1], month3: monthColumns[2] }
      if (doc.length > 0) {
        a = { feedType: "DOC", unit: "KG", month1value: 0, month2value: 0, month3value: 0, month1: monthColumns[0], month2: monthColumns[1], month3: monthColumns[2] };
        for (let index = 0; index < doc.length; index++) {
          a.feedType = doc[index].feedType;
          a.unit = doc[index].unit;
          if (a.month1 == doc[index].month) { a.month1value = doc[index].qty; }
          else if (a.month2 == doc[index].month) { a.month2value = doc[index].qty; }
          else { a.month3value = doc[index].qty; }
        }
        DOCAndMedicineDataList.push(a);
      }
      if (c_doc.length > 0) {
        a = { feedType: "DOC", unit: "KG", month1value: 0, month2value: 0, month3value: 0, month1: monthColumns[0], month2: monthColumns[1], month3: monthColumns[2] };
        for (let index = 0; index < c_doc.length; index++) {
          a.feedType = c_doc[index].feedType;
          a.unit = c_doc[index].unit;
          if (a.month1 == c_doc[index].month) { a.month1value = c_doc[index].qty; }
          else if (a.month2 == c_doc[index].month) { a.month2value = c_doc[index].qty; }
          else { a.month3value = c_doc[index].qty; }
        }
        DOCAndMedicineDataList.push(a);
      }
      if (medicine.length > 0) {
        a = { feedType: "Medicine", unit: "BDT", month1value: 0, month2value: 0, month3value: 0, month1: monthColumns[0], month2: monthColumns[1], month3: monthColumns[2] };
        for (let index = 0; index < medicine.length; index++) {
          a.feedType = medicine[index].feedType;
          if (a.month1 == medicine[index].month) { a.month1value = Math.round(medicine[index].amount); }
          else if (a.month2 == medicine[index].month) { a.month2value = Math.round(medicine[index].amount); }
          else { a.month3value = Math.round(medicine[index].amount); }
        }
        total.month1value += a.month1value; total.month2value += a.month2value; total.month3value += a.month3value;
        DOCAndMedicineDataList.push(a);
      }
      if (vaccine.length > 0) {
        a = { feedType: "Vaccine", unit: "BDT", month1value: 0, month2value: 0, month3value: 0, month1: monthColumns[0], month2: monthColumns[1], month3: monthColumns[2] };
        for (let index = 0; index < vaccine.length; index++) {
          a.feedType = vaccine[index].feedType;
          if (a.month1 == vaccine[index].month) { a.month1value = Math.round(vaccine[index].amount); }
          else if (a.month2 == vaccine[index].month) { a.month2value = Math.round(vaccine[index].amount); }
          else { a.month3value = Math.round(vaccine[index].amount); }
        }
        total.month1value += a.month1value; total.month2value += a.month2value; total.month3value += a.month3value;
        DOCAndMedicineDataList.push(a);
      }
      DOCAndMedicineDataList.push(total);
      return [monthColumns,  FeedIssuedDataList, DOCAndMedicineDataList];
    }
    else {
      // this.FeedIssuedDataList = [];
      // this.DOCAndMedicineDataList = [];
      return [[], [], []];
    }
  }
  getCfBroilerSalesData(year: number, month: string, regionId: number,branchId:number,broilerTypeId: number) {
    this._apiService.GetCFBroilerSalesDetailsDashbordData(year, month, regionId,branchId,broilerTypeId)
      .subscribe((data: any[]) => {
        if (data.length > 0) {
          //var monthId = new Date(Date.parse(month + " 1," + year)).getMonth() + 1;
          // this.monthColumns2 = [...new Map(data.map(item =>
          //   [item['month'], item.month])).values()];
          let monthColumns = this.getLastThreeMonths(); 

          var liveBroiler = data.filter(function (el) { return el.broiler == "Live Broiler"; });
          var rejectBroiler = data.filter(function (el) { return el.broiler == "Reject Broiler"; });
          var othersBroiler = data.filter(function (el) { return el.broiler == "Others Broiler"; });
          this.BroilerSalesDataList = [];
          this.BroilerSales2DataList = [];

          var totalBroiler = {
            Type: "Total :", unit1: "", unit2: "", month1value: 0, month2value: 0, month3value: 0,
            month1Qty: 0, month2Qty: 0, month3Qty: 0, month1Weight: 0, month2Weight: 0, month3Weight: 0, month1: monthColumns[0], month2: monthColumns[1], month3: monthColumns[2] 
          }
          if (liveBroiler.length > 0) {
            var a = {
              Type: "Live Broiler", unit1: "BDT", unit2: "KG", month1value: 0, month2value: 0, month3value: 0,
              month1Qty: 0, month2Qty: 0, month3Qty: 0, month1Weight: 0, month2Weight: 0, month3Weight: 0, month1: monthColumns[0], month2: monthColumns[1], month3: monthColumns[2] 
            };
            for (let index = 0; index < liveBroiler.length; index++) {
              // a.feedType = liveBroiler[index].broiler;
              a.unit1 = "BDT";
              a.unit2 = "KG";
              if (a.month1 == liveBroiler[index].month) {
                a.month1 = liveBroiler[index].month; a.month1value = Math.round(liveBroiler[index].amount);
                a.month1Weight = Math.round(liveBroiler[index].weight); a.month1Qty = Math.round(liveBroiler[index].qty);
              }
              else if (a.month2 == liveBroiler[index].month) {
                a.month2 = liveBroiler[index].month; a.month2value = Math.round(liveBroiler[index].amount);
                a.month2Weight = Math.round(liveBroiler[index].weight); a.month2Qty = Math.round(liveBroiler[index].qty);
              }
              else {
                a.month3 = liveBroiler[index].month; a.month3value = Math.round(liveBroiler[index].amount);
                a.month3Weight = Math.round(liveBroiler[index].weight); a.month3Qty = Math.round(liveBroiler[index].qty);
              }
            }
            totalBroiler.month1value += a.month1value; totalBroiler.month2value += a.month2value; totalBroiler.month3value += a.month3value;
            totalBroiler.month1Weight += a.month1Weight; totalBroiler.month2Weight += a.month2Weight; totalBroiler.month3Weight += a.month3Weight;
            //totalBroiler.month1Qty += a.month1Weight;totalBroiler.month2Weight += a.month2Weight;totalBroiler.month3Weight += a.month3Weight;
            //this.totalLiveBirds = this.totalLiveBirds - (a.month1Qty+a.month2Qty+a.month3Qty)
            this.BroilerSalesDataList.push(a);
          }
          if (rejectBroiler.length > 0) {
            a = {
              Type: "Reject Broiler", unit1: "BDT", unit2: "KG", month1value: 0, month2value: 0, month3value: 0,
              month1Qty: 0, month2Qty: 0, month3Qty: 0, month1Weight: 0, month2Weight: 0, month3Weight: 0, month1: monthColumns[0], month2: monthColumns[1], month3: monthColumns[2]
            };
            for (let index = 0; index < rejectBroiler.length; index++) {
              // a.feedType = rejectBroiler[index].broiler;
              // a.unit = rejectBroiler[index].currency;
              a.unit1 = "BDT";
              a.unit2 = "KG";
              if (a.month1 == rejectBroiler[index].month) {
                a.month1value = Math.round(rejectBroiler[index].amount);
                a.month1Weight = Math.round(rejectBroiler[index].weight); 
                a.month1Qty = Math.round(liveBroiler[index].qty);
              }
              else if (a.month2 == rejectBroiler[index].month) {
                a.month2value = Math.round(rejectBroiler[index].amount);
                a.month2Weight = Math.round(rejectBroiler[index].weight); 
                a.month2Qty = Math.round(liveBroiler[index].qty);
              }
              else {
                a.month3value = Math.round(rejectBroiler[index].amount);
                a.month3Weight = rejectBroiler[index].weight; 
                a.month3Qty = Math.round(liveBroiler[index].qty);
              }
            }
            totalBroiler.month1value += a.month1value; totalBroiler.month2value += a.month2value; totalBroiler.month3value += a.month3value;
            totalBroiler.month1Weight += a.month1Weight; totalBroiler.month2Weight += a.month2Weight; totalBroiler.month3Weight += a.month3Weight;

            this.BroilerSalesDataList.push(a);
          }
          if (othersBroiler.length > 0) {
            a = {
              Type: "Others Broiler", unit1: "BDT", unit2: "KG", month1value: 0, month2value: 0, month3value: 0,
              month1Qty: 0, month2Qty: 0, month3Qty: 0, month1Weight: 0, month2Weight: 0, month3Weight: 0, month1: monthColumns[0], month2: monthColumns[1], month3: monthColumns[2]
            };
            for (let index = 0; index < othersBroiler.length; index++) {
              // a.feedType = othersBroiler[index].broiler;
              // a.unit = othersBroiler[index].currency;
              a.unit1 = "BDT";
              a.unit2 = "KG";
              if (a.month1 == othersBroiler[index].month) {
                a.month1 = othersBroiler[index].month; a.month1value = Math.round(othersBroiler[index].amount);
                a.month1Weight = Math.round(othersBroiler[index].weight); a.month1Qty = Math.round(liveBroiler[index].qty);
              }
              else if (a.month2 == othersBroiler[index].month) {
                a.month2 = othersBroiler[index].month; a.month2value = Math.round(othersBroiler[index].amount);
                a.month2Weight = Math.round(othersBroiler[index].weight); a.month2Qty = Math.round(liveBroiler[index].qty);
              }
              else {
                a.month3 = othersBroiler[index].month; a.month3value = Math.round(othersBroiler[index].amount);
                a.month3Weight = Math.round(othersBroiler[index].weight); a.month3Qty = Math.round(liveBroiler[index].qty);
              }
            }
            totalBroiler.month1value += a.month1value; totalBroiler.month2value += a.month2value; totalBroiler.month3value += a.month3value;
            totalBroiler.month1Weight += a.month1Weight; totalBroiler.month2Weight += a.month2Weight; totalBroiler.month3Weight += a.month3Weight;
            this.BroilerSalesDataList.push(a);
          }
          this.BroilerSalesDataList.push(totalBroiler);
          this.generateFgSalesHChart("column");
          // this.generateFgSalesAreaChart("area"); 

        }
        else {
          this.BroilerSalesDataList = [];
          this.BroilerSales2DataList = [];
        }
      });

  }
  generateFgSalesHChart(type: any) {    
    this.fgSalesHChartData = {
      labels: [this.monthColumns2[0], this.monthColumns2[1], this.monthColumns2[2]],
      datasets: [
        {
          label: 'Live Broiler',
          fill: false,
          borderColor: '#108758',
          yAxisID: 'y',
          tension: 0.4,
          data: [this.BroilerSalesDataList[0].month1value, this.BroilerSalesDataList[0].month2value, this.BroilerSalesDataList[0].month3value]
        },
        {
          label: 'Reject Broiler',
          fill: false,
          borderColor: '#0F68A9',
          yAxisID: 'y1',
          tension: 0.4,
          data: [this.BroilerSalesDataList[1].month1value, this.BroilerSalesDataList[1].month2value, this.BroilerSalesDataList[1].month3value]
        },
        // {
        //   label: 'Others Broiler',
        //   fill: false,
        //   borderColor: this.documentStyle.getPropertyValue('--green-500'),
        //   yAxisID: 'y1',
        //   tension: 0.4,
        //   data: [this.BroilerSalesDataList[2].month1value, this.BroilerSalesDataList[2].month2value, this.BroilerSalesDataList[2].month3value]
        // }
      ]
    };
    this.fgSalesWeightHChartData = {
      labels: [this.monthColumns2[0], this.monthColumns2[1], this.monthColumns2[2]],
      datasets: [
        {
          label: 'Live Broiler',
          fill: false,
          borderColor: '#108758',
          yAxisID: 'y',
          tension: 0.4,
          data: [this.BroilerSalesDataList[0].month1Weight, this.BroilerSalesDataList[0].month2Weight, this.BroilerSalesDataList[0].month3Weight]
        },
        {
          label: 'Reject Broiler',
          fill: false,
          borderColor: '#0F68A9',
          yAxisID: 'y1',
          tension: 0.4,
          data: [this.BroilerSalesDataList[1].month1Weight, this.BroilerSalesDataList[1].month2Weight, this.BroilerSalesDataList[1].month3Weight]
        }
      ]
    }
  }
  generateFeedIssuedChart(type: any) {
    this.feedIssuedChartData = {
      labels: [this.monthColumns[0], this.monthColumns[1], this.monthColumns[2]],
      datasets: [
        {
          label: 'Starter',
          fill: false,
          borderColor: '#108758',
          yAxisID: 'y',
          tension: 0.4,
          data: [this.FeedIssuedDataList[0].month1value, this.FeedIssuedDataList[0].month2value, this.FeedIssuedDataList[0].month3value]
        },
        {
          label: 'Finisher',
          fill: false,
          borderColor: '#0F68A9',
          yAxisID: 'y',
          tension: 0.4,
          data: [this.FeedIssuedDataList[1].month1value, this.FeedIssuedDataList[1].month2value, this.FeedIssuedDataList[1].month3value]
        }   
        ,
        {
          label: 'Grower',
          fill: false,
          borderColor: '#728811',
          yAxisID: 'y',
          tension: 0.4,
          data: [this.FeedIssuedDataList[2].month1value, this.FeedIssuedDataList[2].month2value, this.FeedIssuedDataList[2].month3value]
        }        
      ]
    };
    this.docMedicineIssuedHChartData = {
      labels: [this.monthColumns1[0], this.monthColumns1[1], this.monthColumns1[2]],
      datasets: [
        {
          label: 'DOC',
          fill: false,
          borderColor: '#108758',
          yAxisID: 'y',
          tension: 0.4,
          data: [this.DOCAndMedicineDataList[0].month1value, this.DOCAndMedicineDataList[0].month2value, this.DOCAndMedicineDataList[0].month3value]
        },
        {
          label: 'Medicine',
          fill: false,
          borderColor: '#0F68A9',
          yAxisID: 'y',
          tension: 0.4,
          data: [this.DOCAndMedicineDataList[1].month1value, this.DOCAndMedicineDataList[1].month2value, this.DOCAndMedicineDataList[1].month3value]
        },
        {
          label: 'Vaccine',
          fill: false,
          borderColor: '#728811',
          yAxisID: 'y',
          tension: 0.4,
          data: [this.DOCAndMedicineDataList[2].month1value, this.DOCAndMedicineDataList[2].month2value, this.DOCAndMedicineDataList[2].month3value]
        }
      ]
    }
  }
  getMonthName(monthNumber: number) {
    const date = new Date();
    date.setMonth(monthNumber - 1);

    return date.toLocaleString('en-US', {
      month: 'long',
    });
  }
  onClick() {
    if (this.year_Id == 0) {
      this._snackBar.open("Please select any Year !", "Notice", {
        horizontalPosition: this.horizontalPosition,
        verticalPosition: this.verticalPosition,
        duration: 2000,
        panelClass: ['mat-toolbar', 'mat-warn']
      });

      return;
    }
    if (this.month_Id == "") {
      this._snackBar.open("Please select any month !", "Notice", {
        horizontalPosition: this.horizontalPosition,
        verticalPosition: this.verticalPosition,
        duration: 2000,
        panelClass: ['mat-toolbar', 'mat-warn']
      });

      return;
    }
    
    this.func1();
    this.func2();
    //this.onClick1();
  }
  func1(){
    this.getCfFeedIssuedData(this.year_Id, this.month_Id, this.regionId,this.branch_Id,this.broilerTypeId);
    this.getCfBroilerSalesData(this.year_Id, this.month_Id, this.regionId,this.branch_Id,this.broilerTypeId);
    this.getCfFeedPurchasedData(this.year_Id, this.month_Id, this.regionId,this.branch_Id);
    this._apiService.GetFarmerWiseFlockSummaryCountDashboardData(this.regionId,this.branch_Id).subscribe((data: any[]) => {
      this.FarmerWiseFlockSummaryOfRegisteredDataList = data.filter(function (el) {
        return el.totalFlockCount > 0 && el.totalOpenFlockClount == 0 && el.status == 1;
      });

      this.FarmerWiseFlockSummaryOfPendingDataList = data.filter(function (el) {
        return el.totalFlockCount == 0 || el.totalFlockCount == null || el.totalFlockCount == '';
      });

      this.ClosedFarmerDataList = data.filter(function (el) {
        return el.status == 0;
      });
    });
  }
  func2(){
    this.totalLiveBirds = 0;
    this.total_live_Bird1 = 0;
    this.total_live_Bird2 = 0;
    this.total_live_Bird3 =  0;
    this.total_live_Bird4 = 0;
    this.total_live_Bird5 = 0;
    this.total_live_Bird6 = 0;
    this._apiService.GetCFFlockAgeSummaryDashbordData(this.regionId,this.branch_Id,this.broilerTypeId).subscribe(
      data => {
        data.forEach(result => {
          this.totalLiveBirds = this.totalLiveBirds + result.avl_Live_Birds;
        });
        this.totalOpenFlock = data.length;
        this.dataList1 = data.filter(function (el) {
          return el.age_Value <= 10;
        }
        );
        this.dataList2 = data.filter(function (el) {
          return el.age_Value <= 20 && el.age_Value > 10;
        }
        );
        this.dataList3 = data.filter(function (el) {
          return el.age_Value <= 30 && el.age_Value > 20;
        }
        );
        this.dataList4 = data.filter(function (el) {
          return el.age_Value <= 40 && el.age_Value > 30;
        }
        );
        this.dataList5 = data.filter(function (el) {
          return el.age_Value <= 50 && el.age_Value > 40;
        }
        );
        this.dataList6 = data.filter(function (el) {
          return el.age_Value <= 60 && el.age_Value > 50;
        }
        );


        this.total1 = this.dataList1.length;
        this.total2 = this.dataList2.length;
        this.total3 = this.dataList3.length;
        this.total4 = this.dataList4.length;
        this.total5 = this.dataList5.length;
        this.total6 = this.dataList6.length;

        this.dataList1.forEach(result => {
          this.total_live_Bird1 = this.total_live_Bird1 + result.live_Bird;
        });
        this.dataList2.forEach(result => {
          this.total_live_Bird2 = this.total_live_Bird2 + result.live_Bird;
        });
        this.dataList3.forEach(result => {
          this.total_live_Bird3 = this.total_live_Bird3 + result.live_Bird;
        });
        this.dataList4.forEach(result => {
          this.total_live_Bird4 = this.total_live_Bird4 + result.live_Bird;
        });
        this.dataList5.forEach(result => {
          this.total_live_Bird5 = this.total_live_Bird5 + result.live_Bird;
        });
        this.dataList6.forEach(result => {
          this.total_live_Bird6 = this.total_live_Bird6 + result.live_Bird;
        });
      }
    );
  }
  onClick1() {        
    this.func1();
    this.func2();
  }
  OnChangeBranch(event : any){
    if(this.regionId==0){
      this.branch_Id = 0;
    }    
    this.cfbranchList$ = this._apiService.getBranchByRegion(this.regionId);    
  }
  downloadReport(id: number) {
    let reportLink = this.endpoint +"ContractFarm/GetCFBillOfFlockExport?FileType=pdf&ContentType=application/pdf&Id="+id;
    return window.open(reportLink, "_blank");
  }  
}
