import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CfDashboardComponent } from './cf-dashboard.component';

describe('CfDashboardComponent', () => {
  let component: CfDashboardComponent;
  let fixture: ComponentFixture<CfDashboardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CfDashboardComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CfDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
