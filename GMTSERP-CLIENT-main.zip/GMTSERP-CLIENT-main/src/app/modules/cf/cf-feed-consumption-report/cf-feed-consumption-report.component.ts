import { Component, OnInit } from '@angular/core';
import { Breakpoints, BreakpointObserver } from '@angular/cdk/layout';
import { ApiServiceService } from 'src/app/api-service.service';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { FormBuilder, FormGroup } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { MatDialog } from '@angular/material/dialog';
import { CfFeedConsumptionDetailComponent } from './cf-feed-consumption-detail/cf-feed-consumption-detail.component';

@Component({
  selector: 'app-cf-feed-consumption-report',
  templateUrl: './cf-feed-consumption-report.component.html',
  styleUrls: ['./cf-feed-consumption-report.component.scss']
})
export class CfFeedConsumptionReportComponent implements OnInit {

  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';

  endpoint: string = `${environment.reportServerUrl}`;
    feed_Consumption_Data!: any[];  

  region_Id: number = 0;
  branch_Id: number = 0;
  cluster_Id: number = 0;
  form!: FormGroup;
  date : any;
  from_Date : any;
  to_Date : any;

  
  cols_Value: number = 2;
  cfregionList$!: Observable<any[]>;
  cfbranchList$!: Observable<any[]>;
  cfClusterList$!: Observable<any[]>;

  documentStyle = getComputedStyle(document.documentElement);
  textColor = '#495057';
  textColorSecondary = '#6c757d';
  surfaceBorder = '#dfe7ef';
  /** Based on the screen size, switch from standard to one column per row */
  constructor(private breakpointObserver: BreakpointObserver,
     public _apiService: ApiServiceService, 
     private _snackBar: MatSnackBar,
     public fb: FormBuilder,
     private datepipe: DatePipe,public dialog: MatDialog) {
    // this.form = this.fb.group({
    //   from_Date: '',
    //   to_Date: '',        
    //   branch_Id: 0,      
    //   cluster_Id: 0,    
    // });

   }

  ngOnInit(): void {
    let currentDateTime = this.datepipe.transform((new Date), 'yyyy-MM-dd');
    this.date = currentDateTime;
    //this.to_Date= currentDateTime;
    this.cfbranchList$ = this._apiService.getCfBranchList();
    //this.cfClusterList$ = this._apiService.getCfClusterList();
    this.cols_Value = (window.innerWidth <= 1000) ? 1 : 2;    

    this._apiService.GetCFFeedConsumptionData(this.date,this.date,this.branch_Id,this.cluster_Id,0).subscribe((data: any[]) => {
       this.feed_Consumption_Data = data;
    });   
  }
  onResize(event: any) {
    this.cols_Value = (event.target.innerWidth <= 1000) ? 1 : 2;
  }  
  onClick() {
    // if (this.from_Date == null) {
    //   this._snackBar.open("Please select any Year !", "Notice", {
    //     horizontalPosition: this.horizontalPosition,
    //     verticalPosition: this.verticalPosition,
    //     duration: 2000,
    //     panelClass: ['mat-toolbar', 'mat-warn']
    //   });

    //   return;
    // }
    // if (this.month_Id == "") {
    //   this._snackBar.open("Please select any month !", "Notice", {
    //     horizontalPosition: this.horizontalPosition,
    //     verticalPosition: this.verticalPosition,
    //     duration: 2000,
    //     panelClass: ['mat-toolbar', 'mat-warn']
    //   });

    //   return;
    // }
    
    this._apiService.GetCFFeedConsumptionData(this.date,this.date,this.branch_Id,this.cluster_Id,0).subscribe((data: any[]) => {
      this.feed_Consumption_Data = data;
   });    
    

  }

  OnChangeBranch(event : any){
    this.cfClusterList$ = this._apiService.getClusterByBranch(this.branch_Id);
  }

  downloadReport(id: number) {
    const dialogRef = this.dialog.open(CfFeedConsumptionDetailComponent, {
      height: '90%',
      autoFocus: false,
      width: '80%',
      backdropClass: 'custom-dialog-backdrop-class',
      panelClass: 'custom-dialog-panel-class',
      data: { pageValue: id }
    });

    dialogRef.afterClosed().subscribe(result => {
      // this.updateCalculationFabricCost(result.data);
      // this.updateCalculation(result.data);
      console.log(result.data);
    });
  }

}
