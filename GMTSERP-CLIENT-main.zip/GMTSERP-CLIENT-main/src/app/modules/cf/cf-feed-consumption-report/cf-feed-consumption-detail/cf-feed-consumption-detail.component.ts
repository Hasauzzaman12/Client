import { Component, Inject, OnInit, Optional } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { ApiServiceService } from 'src/app/api-service.service';

@Component({
  selector: 'app-cf-feed-consumption-detail',
  templateUrl: './cf-feed-consumption-detail.component.html',
  styleUrls: ['./cf-feed-consumption-detail.component.scss']
})
export class CfFeedConsumptionDetailComponent implements OnInit {
  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';
  cols_Value: number = 2;
  documentStyle = getComputedStyle(document.documentElement);
  textColor = '#495057';
  textColorSecondary = '#6c757d';
  surfaceBorder = '#dfe7ef';
  feed_Consumption_Data!: any[];  
  flock_Id = 0;
  constructor(public dialogRef: MatDialogRef<CfFeedConsumptionDetailComponent>,
    @Optional() @Inject(MAT_DIALOG_DATA) public data: any,public _apiService: ApiServiceService, public router: Router ) {
      this.flock_Id = data.pageValue;
      // this._apiService.GetCFFeedConsumptionData('','',0,0,this.flock_Id).subscribe((data: any[]) => {
      //   this.feed_Consumption_Data = data;
      // }); 
      this._apiService.GetCFFeedConsumptionDataByFlock(this.flock_Id).subscribe((data: any[]) => {
        this.feed_Consumption_Data = data;
      }); 

     }

  ngOnInit(): void {
    // this._apiService.GetCFFeedConsumptionData('','',0,0,this.flock_Id).subscribe((data: any[]) => {
    //   this.feed_Consumption_Data = data;
    // });   
    this._apiService.GetCFFeedConsumptionDataByFlock(this.flock_Id).subscribe((data: any[]) => {
      this.feed_Consumption_Data = data;
    }); 
  }

  onResize(event: any) {
    this.cols_Value = (event.target.innerWidth <= 1000) ? 1 : 2;
  } 

  closeDialog() {
    this.dialogRef.close({ event: 'close', data: [] });
  }
}
