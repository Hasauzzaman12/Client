import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CfFeedConsumptionDetailComponent } from './cf-feed-consumption-detail.component';

describe('CfFeedConsumptionDetailComponent', () => {
  let component: CfFeedConsumptionDetailComponent;
  let fixture: ComponentFixture<CfFeedConsumptionDetailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CfFeedConsumptionDetailComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CfFeedConsumptionDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
