import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';

@Component({
  selector: 'app-asset-employee',
  templateUrl: './asset-employee.component.html',
  styleUrls: ['./asset-employee.component.scss']
})

export class AssetEmployeeComponent implements OnInit {

  employee_Name: string = '';
  user_Id: number = this.authservice.getUserId;
  company_Id: number = this.authservice.getCompanyId;
  custodian_Id: number = 0;
  sub_Custodian_Id: number = 0;
  department_Id: number = 0;
  designation_Id: number = 0;
  emp_Status: string = '';
  isFilterShow: boolean = false;

  companyList$!: Observable<any[]>;
  departmentList$!: Observable<any[]>;
  designationList$!: Observable<any[]>;
  custodianList$!: Observable<any[]>;
  subcustodianList$!: Observable<any[]>;

  displayedColumns: string[] = ['employee_Id', 'employee_Name', 'company_Name', 'department_Name', 'designation_Name', 'custodian_Name', 'sub_Custodian_Name', 'emp_Status', 'action'];
  dataSource!: MatTableDataSource<any>;

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';


  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;


  constructor(public _apiService: ApiServiceService, private authservice: AuthService, private _snackBar: MatSnackBar, public dialog: MatDialog, private router: Router) { }

  ngOnInit(): void {
    this.getAllEmployee();
    if (this.user_Id > 0) {
      this.companyList$ = this._apiService.getCompanyListByUser(this.user_Id);
    } else {
      this.companyList$ = this._apiService.getCompanyList();
    }
    if (this.user_Id > 0) {
      this.custodianList$ = this._apiService.getCustodianListByUser(this.user_Id);
    } else {
      this.custodianList$ = this._apiService.getEmployeeCustodian();
    }
    this.departmentList$ = this._apiService.getDepartmentList();
    this.designationList$ = this._apiService.getDesignationList();


  }
  changeCustodian() {
    if (this.custodian_Id > 0) {
      this.subcustodianList$ = this._apiService.getSubCustodianByCustodian(this.custodian_Id);
    }
  }
  openForEdit(itemId: number) {

    this.router.navigate(['/asset-employee/edit/' + itemId]);
  }

  getAllEmployee() {

    const formData = new FormData();

    if (this.user_Id != 0 || this.user_Id != null) {
      formData.append('user_Id', this.user_Id.toString());
    }
    if (this.company_Id != 0 || this.company_Id != null) {
      formData.append('company_Id', this.company_Id.toString());
    }
    if (this.department_Id != 0 || this.department_Id != null) {
      formData.append('department_Id', this.department_Id.toString());
    }
    if (this.designation_Id != 0 || this.designation_Id != null) {
      formData.append('designation_Id', this.designation_Id.toString());
    }
    if (this.custodian_Id != 0 || this.custodian_Id != null) {
      formData.append('custodian_Id', this.custodian_Id.toString());
    }
    if (this.sub_Custodian_Id != 0 || this.sub_Custodian_Id != null) {
      formData.append('sub_Custodian_Id', this.sub_Custodian_Id.toString());
    }
    if (this.employee_Name != '' || this.employee_Name != null) {
      formData.append('employee_Name', this.employee_Name);
    }
    if (this.emp_Status != '' || this.emp_Status != null) {
      formData.append('emp_Status', this.emp_Status);
    }

    this._apiService.getEmployeeListIndexFiltered(formData)
      .subscribe({
        next: (res) => {
          this.dataSource = new MatTableDataSource(res);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
        },
        error: (err) => {
          console.log("Error");
        }

      })
  }
  SearchSummary() {
    this.getAllEmployee();
  }
  reset() {
    this.employee_Name = '';
    this.company_Id = 0;
    this.designation_Id = 0;
    this.department_Id = 0;
    this.custodian_Id = 0;
    this.sub_Custodian_Id = 0;
    this.emp_Status = '';

    this.getAllEmployee();
  }

  toggleFilter() {
    this.isFilterShow = !this.isFilterShow;
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  gotoNew() {
    this.router.navigate(['/add-asset-employee']);
  }

  DetailsEmployee(id: number) {
    this.router.navigate(['/asset-employee/detail/' + id]);
  }
  openForView(id: number) {
    this.router.navigate([]).then((result) => {
      window.open('/#/asset-employee/detail/' + id, '_blank');
    });
  }


}

