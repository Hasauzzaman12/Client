import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditAssetEmployeeComponent } from './add-edit-asset-employee.component';

describe('AddEditAssetEmployeeComponent', () => {
  let component: AddEditAssetEmployeeComponent;
  let fixture: ComponentFixture<AddEditAssetEmployeeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddEditAssetEmployeeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddEditAssetEmployeeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
