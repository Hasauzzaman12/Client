import { HttpClient, HttpEventType, HttpRequest } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable, of } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';
import { ShowAssetBookComponent } from '../../asset-book/show-asset-book/show-asset-book.component';
import { MessageService } from 'primeng/api';

@Component({
  selector: 'app-add-edit-asset-employee',
  templateUrl: './add-edit-asset-employee.component.html',
  styleUrls: ['./add-edit-asset-employee.component.scss'],
  providers: [MessageService]
})

export class AddEditAssetEmployeeComponent implements OnInit {

  user_Id: number = this.authservice.getUserId;

  departmentList$!: Observable<any[]>;
  designationList$!: Observable<any[]>;
  divisionList$!: Observable<any[]>;
  jobLocationList$!: Observable<any[]>;
  custodianList$!: Observable<any[]>;
  subcustodianList$!: Observable<any[]>;
  companyList$!: Observable<any[]>;
  unitListByComId$!: Observable<any[]>;
  shiftList$!: Observable<any[]>;


  newBlogForm!: FormGroup;

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';

  constructor(public _apiService: ApiServiceService, public dialog: MatDialog,
    private _snackBar: MatSnackBar, private messageService: MessageService,
    private authservice: AuthService,
    private currentRoute: ActivatedRoute, public http: HttpClient, public router: Router) { }

  @Input() employee: any;
  id: number = 0;
  employee_Id: string = "";
  employee_Name: string = "";
  employee_Name_Bn: string = "";
  contact_No_Office: string = "";
  emp_Status: string = "";
  department_Id: number = 0;
  designation_Id: number = 0;
  section_Id: number = 0;
  division_Id: number = 0;
  job_Location_Lookup_Id: number = 0;
  joining_Date: any = "";
  custodian_Id: number = 0;
  sub_Custodian_Id: number = 0;
  resign_Date: any = "";
  company_Id: number = 0;
  unit_Id: number = 0;

  shift_Plan_Info_Id: number = 0;

  public isExist: boolean = false;
  public editMood: boolean = false;
  public isValidImage: boolean = false;


  allocation_list: any[] = [];
  asset_support_list: any[] = [];
  asset_software_list: any[] = [];

  ngOnInit(): void {

    this.newBlogForm = new FormGroup({
      id: new FormControl(0),
      employee_Id: new FormControl('', [Validators.required]),
      employee_Name: new FormControl('', [Validators.required]),
      employee_Name_Bn: new FormControl(''),
      contact_No_Office: new FormControl(''),
      department_Id: new FormControl([{ value: '' }, [Validators.required]]),
      designation_Id: new FormControl(0, [Validators.required]),
      section_Id: new FormControl(0),
      division_Id: new FormControl(0),
      job_Location_Lookup_Id: new FormControl(0),
      joining_Date: new FormControl('', [Validators.required]),
      custodian_Id: new FormControl(0),
      sub_Custodian_Id: new FormControl(0),
      unit_Id: new FormControl(0),
      emp_Status: new FormControl(0),
      shift_Plan_Info_Id: new FormControl(0),
      resign_Date: new FormControl(''),
      company_Id: new FormControl(0, [Validators.required]),
    });

    let id = this.currentRoute.snapshot.paramMap.get('id');
    if (id != null) {
      this.editMood = true;
      this.getEmployeeById(id);
    }


    if (this.user_Id > 0) {
      this.companyList$ = this._apiService.getCompanyListByUser(this.user_Id);
    } else {
      this.companyList$ = this._apiService.getCompanyList();
    }

    if (this.user_Id > 0) {
      this.unitListByComId$ = this._apiService.getUnitListByComUserId(this.user_Id, this.company_Id);
    }

    // if (this.user_Id > 0) {
    //   this.custodianList$ = this._apiService.getCustodianListByUser(this.user_Id);
    // }

    if (this.custodian_Id > 0) {
      this.subcustodianList$ = this._apiService.getSubCustodianByCustodian(this.custodian_Id);
    }


    this.shiftList$ = this._apiService.getEmployeeShiftList();
    this.designationList$ = this._apiService.getDesignationList();
    this.divisionList$ = this._apiService.getDivisionList();
    this.jobLocationList$ = this._apiService.getJobLocationList();

    this.unitListByComId$ = this._apiService.getUnitListByCompanyId(this.company_Id);

  }

  onOptionsCompanySelected(event: any) {
    const value = event.company_Id;
    this.company_Id = value;
    this.unitListByComId$ = this._apiService.getUnitListByCompanyId(this.company_Id);
    this.custodianList$ = this._apiService.getCustodianByCompanyId(this.company_Id);
    this.departmentList$ = this._apiService.getDepartmentsByCompany(this.company_Id);
  }

  onOptionsItemCustodianSelected(event: any) {
    const value = event.custodian_Id;
    this.custodian_Id = value;
    this.subcustodianList$ = this._apiService.getSubCustodianByCustodian(this.custodian_Id);

  }


  // changeCustodian(data: any) {
  //   if (data.custodian_Id > 0) {
  //     this.subcustodianList$ = this._apiService.getSubCustodianByCustodian(data.custodian_Id);
  //   }
  // }

  getEmployeeById(id: number | string) {
    this._apiService.getEmployeeById(id)
      .subscribe((data: any) => {

        this.joining_Date = data.joining_Date;
        this.resign_Date = data.resign_Date;
        this.allocation_list = data.allocationList;
        this.asset_support_list = data.assetUserSupportList;
        this.asset_software_list = data.assetUserSoftwareList;
        this.company_Id = data.company_Id;
        this.custodian_Id = data.custodian_Id;
        this.unit_Id = data.unit_Id;
        this.unitListByComId$ = this._apiService.getUnitListByCompanyId(this.company_Id);
        this.custodianList$ = this._apiService.getCustodianByCompanyId(this.company_Id);
        this.departmentList$ = this._apiService.getDepartmentsByCompany(this.company_Id);
        this.subcustodianList$ = this._apiService.getSubCustodianByCustodian(this.custodian_Id);

        this.newBlogForm = new FormGroup({
          id: new FormControl(id),
          employee_Id: new FormControl(data.employee_Id),
          employee_Name: new FormControl(data.employee_Name),
          employee_Name_Bn: new FormControl(data.employee_Name_Bn),
          contact_No_Office: new FormControl(data.contact_No_Office),
          department_Id: new FormControl(data.department_Id),
          designation_Id: new FormControl(data.designation_Id),
          section_Id: new FormControl(data.section_Id),
          division_Id: new FormControl(data.division_Id),
          job_Location_Lookup_Id: new FormControl(data.job_Location_Lookup_Id),
          joining_Date: new FormControl(data.joining_Date),
          custodian_Id: new FormControl(data.custodian_Id),
          sub_Custodian_Id: new FormControl(data.sub_Custodian_Id),
          unit_Id: new FormControl(data.unit_Id),
          emp_Status: new FormControl(data.emp_Status),
          resign_Date: new FormControl(data.resign_Date),
          company_Id: new FormControl(data.company_Id),
          shift_Plan_Info_Id: new FormControl(data.shift_Plan_Info_Id),

        });
      });

  }


  clear() {
    this.messageService.clear();
  }



  onSubmit(data: any) {


    const formData = new FormData();

    if (data.employee_Id == '') {
      alert("Employee Code is Required")
      return;
    }

    if (data.department_Id == 0) {

      alert("Department is Required")
      return;
    }

    if (data.designation_Id == 0) {

      alert("Designation is Required")
      return;
    }


    if (data.joining_Date == '') {
      alert("Joining Date is Required")
      return;
    }


    if (data.employee_Name == '') {
      alert("Employee Name is Required")
      return;
    }
    if (data.employee_Name_Bn == '') {
      alert("Bangla Name is Required")
      return;
    }

    if (data.emp_Status == 'InActive') {
      if (data.resign_Date == null) {
        alert("Resign Date is Required")
        return;
      }
    }

    formData.append('id', data.id);
    formData.append('employee_Id', data.employee_Id);
    formData.append('employee_Name', data.employee_Name == null ? '' : data.employee_Name);
    formData.append('employee_Name_Bn', data.employee_Name_Bn == null ? '' : data.employee_Name_Bn);
    formData.append('contact_No_Office', data.contact_No_Office == null ? '' : data.contact_No_Office);
    formData.append('department_Id', data.department_Id);
    formData.append('designation_Id', data.designation_Id);
    formData.append('section_Id', data.section_Id);
    formData.append('division_Id', data.division_Id);
    formData.append('job_Location_Lookup_Id', data.job_Location_Lookup_Id);
    formData.append('shift_Plan_Info_Id', data.shift_Plan_Info_Id);
    formData.append('custodian_Id', data.custodian_Id);
    formData.append('sub_Custodian_Id', data.sub_Custodian_Id);
    formData.append('unit_Id', data.unit_Id);

    formData.append('emp_Status', data.emp_Status);
    formData.append('company_Id', data.company_Id);

    if (data.resign_Date != null) {
      formData.append('resign_Date', data.resign_Date);
    }


    if (data.joining_Date != null) {
      formData.append('joining_Date', data.joining_Date);
    }




    if (this.newBlogForm.valid && this.isExist === false) {
      if (data.id != 0) {

        this._apiService.updateAssetEmployee(formData).subscribe(res => {

          // this._snackBar.open("Employee Updated Successfully", "Update", {
          //   horizontalPosition: this.horizontalPosition,
          //   verticalPosition: this.verticalPosition,
          //   duration: 2000
          // });

          this.messageService.add({ severity: 'error', summary: 'Update', life: 5000, detail: 'Employee Updated Successfully' });

          this.router.navigate(['/asset-employee']);


        })
      }
      else {
        this._apiService.addAssetEmployee(formData).subscribe(res => {

          this._snackBar.open("Employee Saved Successfully", "Success", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });

          this.router.navigate(['/asset-employee']);


        })
      }

    } else {
      if (this.isExist == true) {
        this._snackBar.open("This Employee Id already exist", "Please Update", {
          horizontalPosition: this.horizontalPosition,
          verticalPosition: this.verticalPosition,
          duration: 2000
        });
      }

    }

  }
  gotoBack() {
    this.router.navigate(['/asset-employee']);
  }

  reset(): void {
    this.ngOnInit();
  }

  isExistEmployeeId(data: any) {

    this._apiService.getIsEmployeeIdExist(data.employee_Id).subscribe(response => {
      this.isExist = response;
      if (this.isExist == true) {
        this._snackBar.open("This Employee Id already exist", "Please Update", {
          horizontalPosition: this.horizontalPosition,
          verticalPosition: this.verticalPosition,
          duration: 2000
        });
      }
    });
  }

  openAssetForView(id: number) {
    this.router.navigate([]).then((result) => {
      window.open('/#/asset-book/detail/' + id, '_blank');
    });
  }
}

