import { HttpClient, HttpEventType, HttpRequest } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable, of } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';
import { ShowAssetBookComponent } from '../../asset-book/show-asset-book/show-asset-book.component';


@Component({
  selector: 'app-show-asset-employee',
  templateUrl: './show-asset-employee.component.html',
  styleUrls: ['./show-asset-employee.component.scss']
})
export class ShowAssetEmployeeComponent implements OnInit {
  user_Id: number = this.authservice.getUserId;

  departmentList$!: Observable<any[]>;
  designationList$!: Observable<any[]>;
  divisionList$!: Observable<any[]>;
  jobLocationList$!: Observable<any[]>;
  custodianList$!: Observable<any[]>;
  subcustodianList$!: Observable<any[]>;
  companyList$!: Observable<any[]>;


  newBlogForm!: FormGroup;

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';

  constructor(public _apiService: ApiServiceService,public dialog: MatDialog,
    private _snackBar: MatSnackBar,
    private authservice: AuthService,
    private currentRoute: ActivatedRoute, public http: HttpClient, public router: Router) { }

  @Input() employee: any;
  id: number = 0;
  employee_Id: string = "";
  employee_Name: string = "";
  employee_Name_Bn: string = "";
  contact_No_Office: string = "";
  emp_Status:string="";
  department_Id: number = 0;
  designation_Id: number = 0;
  division_Id: number = 0;
  job_Location_Lookup_Id: number = 0;
  joining_Date: any = "";
  custodian_Id: number = 0;
  sub_Custodian_Id: number = 0;
  resign_Date: any = "";
  company_Id: number = 0;

  public isExist: boolean = false;
  public editMood: boolean = false;
  public isValidImage: boolean = false;


  allocation_list: any[] = [];
  asset_support_list: any[] = [];
  asset_software_list: any[] = [];

  ngOnInit(): void {

    this.newBlogForm = new FormGroup({
      id: new FormControl(0),
      employee_Id: new FormControl(''),
      employee_Name: new FormControl(''),
      employee_Name_Bn: new FormControl(''),
      contact_No_Office: new FormControl(''),
      department_Id: new FormControl({value: this.department_Id, disabled: true}),
      designation_Id: new FormControl({value: this.designation_Id, disabled: true}),
      division_Id: new FormControl({value: this.division_Id, disabled: true}),
      job_Location_Lookup_Id: new FormControl({value: this.job_Location_Lookup_Id, disabled: true}),
      joining_Date: new FormControl('', [Validators.required]),
      custodian_Id: new FormControl({value: this.custodian_Id, disabled: true}),
      sub_Custodian_Id: new FormControl({value: this.sub_Custodian_Id, disabled: true}),
      emp_Status: new FormControl({value: this.emp_Status, disabled: true}),
      resign_Date: new FormControl(''),
      company_Id: new FormControl({value: this.company_Id, disabled: true}),
    });

    let id = this.currentRoute.snapshot.paramMap.get('id');
    if (id != null) {
      this.editMood = true;
      this.getEmployeeById(id);
    }

    if(this.user_Id>0){
      this.companyList$ = this._apiService.getCompanyListByUser(this.user_Id);
    }else{
      this.companyList$ = this._apiService.getCompanyList();
    }
    this.departmentList$ = this._apiService.getDepartmentList();
    this.designationList$ = this._apiService.getDesignationList();
    this.divisionList$ = this._apiService.getDivisionList();
    this.jobLocationList$ = this._apiService.getJobLocationList();
    if(this.user_Id>0){
      this.custodianList$ = this._apiService.getCustodianListByUser(this.user_Id);
    }else{
      this.custodianList$ = this._apiService.getEmployeeCustodian();
    }
    if(this.custodian_Id>0){
      this.subcustodianList$ = this._apiService.getSubCustodianByCustodian(this.custodian_Id);
    }else{
      this.subcustodianList$ = this._apiService.getEmployeeSubCustodian();
    }

  }

changeCustodian(data: any) {
    if(data.custodian_Id>0){
      this.subcustodianList$ = this._apiService.getSubCustodianByCustodian(data.custodian_Id);
    }
  }

  getEmployeeById(id: number | string) {
    this._apiService.getEmployeeById(id)
      .subscribe((data: any) => {

        this.joining_Date = data.joining_Date;
        this.resign_Date = data.resign_Date;
        this.allocation_list = data.allocationList;
        this.asset_support_list = data.assetUserSupportList;
        this.asset_software_list = data.assetUserSoftwareList;

        this.newBlogForm = new FormGroup({
          id: new FormControl(id),
          employee_Id: new FormControl(data.employee_Id),
          employee_Name: new FormControl(data.employee_Name),
          employee_Name_Bn: new FormControl(data.employee_Name_Bn),
          contact_No_Office: new FormControl(data.contact_No_Office),
          department_Id: new FormControl(data.department_Id),
          designation_Id: new FormControl(data.designation_Id),
          division_Id: new FormControl(data.division_Id),
          job_Location_Lookup_Id: new FormControl(data.job_Location_Lookup_Id),
          joining_Date: new FormControl(data.joining_Date),
          custodian_Id: new FormControl(data.custodian_Id),
          sub_Custodian_Id: new FormControl(data.sub_Custodian_Id),
          emp_Status: new FormControl(data.emp_Status),
          resign_Date: new FormControl(data.resign_Date),
          company_Id: new FormControl(data.company_Id)

        });
      });

  }

 
  gotoBack() {
    this.router.navigate(['/asset-employee']);
  }

  reset(): void {
    this.ngOnInit();
  }

  isExistEmployeeId(data: any) {

    this._apiService.getIsEmployeeIdExist(data.employee_Id).subscribe(response => {
      this.isExist = response;
      if (this.isExist == true) {
        this._snackBar.open("This Employee Id already exist", "Please Update", {
          horizontalPosition: this.horizontalPosition,
          verticalPosition: this.verticalPosition,
          duration: 2000
        });
      }
    });
  }

  openAssetForView(id: number) {
    this.router.navigate([]).then((result) => {
      window.open('/#/asset-book/detail/' + id, '_blank');
    });
  }
}

