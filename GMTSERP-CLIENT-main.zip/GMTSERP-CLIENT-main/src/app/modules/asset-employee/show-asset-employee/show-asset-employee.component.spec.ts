import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowAssetEmployeeComponent } from './show-asset-employee.component';

describe('ShowAssetEmployeeComponent', () => {
  let component: ShowAssetEmployeeComponent;
  let fixture: ComponentFixture<ShowAssetEmployeeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ShowAssetEmployeeComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ShowAssetEmployeeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
