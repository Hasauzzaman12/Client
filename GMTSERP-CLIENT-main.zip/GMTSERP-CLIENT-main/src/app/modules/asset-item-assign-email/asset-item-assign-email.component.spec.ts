import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetItemAssignEmailComponent } from './asset-item-assign-email.component';

describe('AssetItemAssignEmailComponent', () => {
  let component: AssetItemAssignEmailComponent;
  let fixture: ComponentFixture<AssetItemAssignEmailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AssetItemAssignEmailComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AssetItemAssignEmailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
