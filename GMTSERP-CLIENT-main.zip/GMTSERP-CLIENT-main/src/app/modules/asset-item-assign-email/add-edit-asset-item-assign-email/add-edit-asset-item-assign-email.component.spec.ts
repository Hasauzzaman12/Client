import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditAssetItemAssignEmailComponent } from './add-edit-asset-item-assign-email.component';

describe('AddEditAssetItemAssignEmailComponent', () => {
  let component: AddEditAssetItemAssignEmailComponent;
  let fixture: ComponentFixture<AddEditAssetItemAssignEmailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddEditAssetItemAssignEmailComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddEditAssetItemAssignEmailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
