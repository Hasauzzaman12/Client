import { HttpClient, HttpEventType, HttpRequest } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable, of,startWith, debounceTime, distinctUntilChanged, switchMap, map } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';
import { DatePipe } from '@angular/common';
import { SD } from 'src/environments/sd';

@Component({
  selector: 'app-add-edit-asset-item-assign-email',
  templateUrl: './add-edit-asset-item-assign-email.component.html',
  styleUrls: ['./add-edit-asset-item-assign-email.component.scss']
})
export class AddEditAssetItemAssignEmailComponent implements OnInit {

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';

  myControl = new FormControl();
  myControl2 = new FormControl();
  options = [];
  filteredOptions: Observable<any>;
  filteredOptionsEmp: Observable<any>;

  constructor(public _apiService: ApiServiceService,
    private _snackBar: MatSnackBar,
    public router: Router,
    private authservice: AuthService,
    private currentRoute: ActivatedRoute,
    private datepipe: DatePipe) { 
      this.filteredOptions = this.myControl.valueChanges.pipe(

        startWith(''),
  
        debounceTime(400),
  
        distinctUntilChanged(),
  
        switchMap(val => {
  
              return this.filter(val || '')
  
         }) 
  
      )

      this.filteredOptionsEmp = this.myControl2.valueChanges.pipe(

        startWith(''),
  
        debounceTime(400),
  
        distinctUntilChanged(),
  
        switchMap(val => {
  
          if(val!=''){
            return this.filter2(val || '')
          }else{
            return '';
          }
  
         }) 
  
      )
    }

    newBlogForm!: FormGroup;
    id: number = 0;
    assign_Date : any;
    asset_Item_Category_Id: number = SD.asset_Item_Category_Id_email;
    user_Id: number = this.authservice.getUserId;
    asset_Item_Id: number = 0;
    item_Name= '';
    company_Id: number = 0;
    department_Id: number = 0;
    employee_Id: number = 0;
    employee_Code= '';
    employee_Name= '';
    expire_Date : any;
    remarks= '';
    is_active: boolean = true;

    companyList$!:Observable<any[]>;
    departmentList$!:Observable<any[]>;

  ngOnInit(): void {

    let currentDateTime =this.datepipe.transform((new Date), 'MM/dd/yyyy h:mm:ss');
    this.newBlogForm = new FormGroup({
      id: new FormControl(0),
      assign_Date: new FormControl(null),
      asset_Item_Category_Id: new FormControl(0),
      asset_Item_Id: new FormControl(0),
      company_Id: new FormControl({value: 0, disabled: true}),
      department_Id: new FormControl({value: 0, disabled: true}),
      employee_Id: new FormControl(0),
      expire_Date: new FormControl(null),
      remarks: new FormControl(''),
      is_active: new FormControl(true)
    });

    this.companyList$ = this._apiService.getCompanyList();
    this.departmentList$ = this._apiService.getDepartmentList();

    let id = this.currentRoute.snapshot.paramMap.get('id');
    if (id != null) {
      this.getAssetItemAssignById(id);
     
    }else{
      this.assign_Date=currentDateTime;
    }
  }

  getAssetItemAssignById(id: number | string) {
    this._apiService.getAssetItemAssignById(id).subscribe((data: any) => {
      this.id=data.id;
      this.assign_Date=data.assign_Date;
      this.asset_Item_Category_Id=data.asset_Item_Category_Id;
      this.asset_Item_Id=data.asset_Item_Id;
      this.item_Name=data.item_Name;
      this.company_Id=data.company_Id;
      this.department_Id=data.department_Id;
      this.employee_Id=data.employee_Id;
      this.employee_Code=data.employee_Code;
      this.employee_Name=data.employee_Name;
      this.expire_Date=data.expire_Date;
      this.remarks=data.remarks;
      this.is_active=data.is_active;

    });
  }

  onSubmit(data: any){

    data.id=this.id;
    data.asset_Item_Category_Id=this.asset_Item_Category_Id;

    if(data.assign_Date == ''||data.assign_Date == null) {
      alert("Assign Date is Required")
      return;
    }
    if (data.asset_Item_Id == 0||data.asset_Item_Id == null) {
      alert("Email is Required")
      return;
    }
    if (data.employee_Id == 0||data.employee_Id == null) {
      alert("Employee is Required")
      return;
    }

    const formData = new FormData();

    formData.append('id', data.id);
    formData.append('assign_Date', data.assign_Date);
    formData.append('asset_Item_Category_Id', data.asset_Item_Category_Id);
    formData.append('asset_Item_Id', data.asset_Item_Id);
    formData.append('employee_Id', data.employee_Id);

    if(data.expire_Date != null){
      formData.append('expire_Date', data.expire_Date);
    }
    formData.append('remarks', data.remarks == null ? '' : data.remarks);
    formData.append('is_active', data.is_active);
    formData.append('user_Id', this.user_Id.toString());
    if (this.newBlogForm.valid) {
      if (data.id != 0) {
  
        this._apiService.updateAssetItemAssign(formData).subscribe(res => {
  
          this._snackBar.open("Asset Item Assign Updated Successfully", "Update", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });
  
          this.router.navigate(['/asset-item-assign-email']);
  
  
        })
      }
      else {
        this._apiService.addAssetItemAssign(formData).subscribe(res => {
  
          this._snackBar.open("Asset Item Assign Saved Successfully", "Success", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });
  
          this.router.navigate(['/asset-item-assign-email']);
  
  
        })
      }
    }

  }

  filter(val: string): Observable <any>{

    const formData = new FormData();
    if (this.user_Id != 0||this.user_Id != null) {
      formData.append('user_Id', this.user_Id.toString());
    }
    if (this.asset_Item_Id != 0||this.asset_Item_Id != null) {
      formData.append('item_Id', this.asset_Item_Id.toString());
    }
    formData.append('asset_Item_Category_Id', this.asset_Item_Category_Id.toString());

    return this._apiService.getAvailableAssetItemListFiltered(formData)

    .pipe(

      map(response => response.filter((option: { item_Name: string; }) => { 

        return option.item_Name.toLowerCase().indexOf(val.toLowerCase()) !== -1

      }))

    )

   }  

   filter2(val: string): Observable <any>{

    const formData = new FormData();
    formData.append('employee_Id', val);
    if (this.user_Id != 0||this.user_Id != null) {
      formData.append('user_Id', this.user_Id.toString());
    }
    formData.append('emp_Status', 'Active');

    return this._apiService.getEmployeesFiltered(formData)

    .pipe(

      map(response => response.filter((option: { employee_Id: string; }) => { 

        return option.employee_Id.toLowerCase().indexOf(val.toLowerCase()) !== -1

      }))

    )

   }  

   onSelFunc(option: any){
    if(option.id>0){
      this.asset_Item_Id=option.id;
    }
  }

  onSelFunc2(option: any){
    if(option.id>0){
      this.employee_Id=option.id;
      this.employee_Name=option.employee_Name;
      this.department_Id=option.department_Id;
      this.company_Id=option.company_Id;
    }
  }
gotoBack() {
    this.router.navigate(['/asset-item-assign-email']);
  }
  reset(): void {
    this.ngOnInit();
  }
}
