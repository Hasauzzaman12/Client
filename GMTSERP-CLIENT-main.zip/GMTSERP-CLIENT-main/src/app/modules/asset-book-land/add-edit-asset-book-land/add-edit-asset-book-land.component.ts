import { HttpClient, HttpEventType, HttpRequest } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable, of,startWith, debounceTime, distinctUntilChanged, switchMap, map } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';
import { DatePipe } from '@angular/common';
import { SD } from 'src/environments/sd';

@Component({
  selector: 'app-add-edit-asset-book-land',
  templateUrl: './add-edit-asset-book-land.component.html',
  styleUrls: ['./add-edit-asset-book-land.component.scss']
})
export class AddEditAssetBookLandComponent implements OnInit {

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';
  public selectedOption: any;

  constructor(public _apiService: ApiServiceService, public dialog: MatDialog,
    private _snackBar: MatSnackBar,
    public router: Router,
    private authservice: AuthService,
    private currentRoute: ActivatedRoute,
    private datepipe: DatePipe) { }

    newBlogForm!: FormGroup;
    id: number = 0;
    asset_Item_Id: number = 0;
    item_Name= '';
    asset_No: string = '';
    asset_Owner_Id: number = SD.asset_Owner_Id_Land
    item_Description: string = '';
    model_No: string = '';
    brand_Name: string = '';
    remarks: string = '';


    uom_Id: number = 1;
    supplier_Id: number = 0;
    purchase_Date : any;
    purchase_Price: number = 0;
    purchase_Qty: number = 1;
    pO_No: string = '';

    status: string = '';
    company_Id: number = 0;
    unit_Id: number = 0;
    user_Id: number = this.authservice.getUserId;
    is_active: boolean = true;

    assetItemList$!: Observable<any[]>;
    assetOwnerList$!: Observable<any[]>;
    supplierList$!: Observable<any[]>;
    uomList$!: Observable<any[]>;
    companyList$!:Observable<any[]>;
    unitList$!:Observable<any[]>;

    allocation_list: any[] = [];
    // maintenance_list: any[] = [];
    attchament_list: any[] = []

  ngOnInit(): void {

    this.newBlogForm = new FormGroup({
      id: new FormControl(0),
      asset_Item_Id: new FormControl(0),
      asset_Owner_Id: new FormControl({value: this.asset_Owner_Id, disabled: true}),
      item_Description: new FormControl(''),
      asset_No: new FormControl(''),
      model_No: new FormControl(''),
      brand_Name: new FormControl(''),
      remarks: new FormControl(''),

      supplier_Id: new FormControl(0),
      purchase_Date: new FormControl(null),
      purchase_Price: new FormControl(0),
      purchase_Qty: new FormControl(1),
      pO_No: new FormControl(''),
      

      uom_Id: new FormControl({value: this.uom_Id, disabled: true}),

      status: new FormControl(''),
      company_Id: new FormControl(0),
      unit_Id: new FormControl(0),
      is_active: new FormControl('')
    });

    this.assetItemList$ = this._apiService.getAssetLandItemByOwner(this.asset_Owner_Id);
    this.assetOwnerList$=this._apiService.getAssetOwnerList();
    this.supplierList$=this._apiService.getSuulierList();
    this.uomList$=this._apiService.getUOMList();

    if(this.user_Id>0){
      this.companyList$ = this._apiService.getCompanyListByUser(this.user_Id);
    }else{
      this.companyList$ = this._apiService.getCompanyList();
    }

    let id = this.currentRoute.snapshot.paramMap.get('id');
    if (id != null) {
      this.getAssetBookById(id);
      
    }
  }

  getAssetBookById(id: number | string) {
   
    this._apiService.getAssetBookById(id).subscribe((data: any) => {
  
      this.allocation_list = data.allocationList;
      // this.maintenance_list = data.maintenanceList;
      this.attchament_list = data.attachmentList;
    
      this.id=data.id;
      this.asset_Item_Id=data.asset_Item_Id;
      this.asset_No=data.asset_No;
      this.asset_Owner_Id=data.asset_Owner_Id;
      this.item_Description=data.item_Description;
      this.model_No=data.model_No;
      this.brand_Name=data.brand_Name;
    
      this.remarks=data.remarks;
  
      this.supplier_Id=data.supplier_Id;
      this.purchase_Date=data.purchase_Date;
      this.purchase_Price=data.purchase_Price;
      this.purchase_Qty=data.purchase_Qty;
      this.pO_No=data.pO_No;
    
      this.status=data.status;
      this.uom_Id=data.uom_Id;
      this.company_Id=data.company_Id;
      this.unit_Id=data.unit_Id;
      this.is_active=data.is_active;
  
      this.unitList$=this._apiService.getUnitListByCompanyId(this.company_Id);
     
    });
   this.assetItemList$ = this._apiService.getAssetLandItemByOwner(this.asset_Owner_Id);
  
  }

  changeOwner(event: any) {
    if(event.target.value>0){
      this.assetItemList$ = this._apiService.getAssetItemByOwner(event.target.value);
    }
  }

  addAttachmentRow() {
    this.attchament_list.push({ id: 0, description: '', attachment_Id: 0, attachmentFile: '' });
  }
  deleteAttachmentROw(index: any) {
    if (confirm("Are you sure want to delete?")) {
      this.attchament_list.splice(index, 1);
    }
  }

  changeItemWiseView(event: any) {
    if(event.target.value>0){
      // this.setPageView(event.target.value);
      this._apiService.getAssetItemById(event.target.value)
      .subscribe((data: any) => {
        this.item_Description='';
        this.item_Description+=data.item_Name;
        this.item_Name='';
        this.item_Name+=data.item_Name;
        
      });
    }
  }

  // changeItemDescription(formValue: any) {

  //   if(formValue.asset_Item_Id>0){
  //     this.item_Description=this.item_Name+' '+formValue.brand_Name+' '+formValue.model_No+' '+formValue.vehicle_CC;
  //   }
  // }

  onSubmit(data: any) {

    if (data.asset_Item_Id == 0||data.asset_Item_Id == null) {
      alert("Vehicle is Required")
      return;
    }
    if (data.asset_No == ''||data.asset_No == null) {
      alert("Asset No is Required")
      return;
    }
    if (data.item_Description == ''||data.item_Description == null) {
      alert("Item Description is Required")
      return;
    }
    if (data.model_No == ''||data.model_No == null){
      alert("Model No & Year is Required")
      return;
    }
    else if (data.brand_Name == ''||data.brand_Name == null){
      alert("Brand of Origin is Required")
      return;
    }
    if (data.company_Id == 0||data.company_Id == null) {
      alert("Company is Required")
      return;
    }
    if (data.supplier_Id == 0||data.supplier_Id == null) {
      alert("Supplier is Required")
      return;
    }

    if (data.purchase_Price == 0||data.purchase_Price == null) {
      alert("Purchase Price is Required")
      return;
    }
    if (data.purchase_Qty == 0||data.purchase_Qty == null) {
      alert("Purchase Qty is Required")
      return;
    }
    if (data.purchase_Date == ''||data.purchase_Date == null) {
      alert("Purchase Date is Required")
      return;
    }
   


    data.asset_Owner_Id=this.asset_Owner_Id;
    data.uom_Id=this.uom_Id;
    data.id=this.id;

    const formData = new FormData();
    formData.append('id', data.id);
    formData.append('company_Id', data.company_Id);
    formData.append('unit_Id', data.unit_Id);
    formData.append('asset_Item_Id', data.asset_Item_Id);
    formData.append('asset_Owner_Id', data.asset_Owner_Id);
    formData.append('item_Description', data.item_Description == null ? '' : data.item_Description);
    formData.append('model_No', data.model_No == null ? '' : data.model_No);
    formData.append('brand_Name', data.brand_Name == null ? '' : data.brand_Name);
    formData.append('asset_No', data.asset_No == null ? '' : data.asset_No);
    formData.append('remarks', data.remarks == null ? '' : data.remarks);


    formData.append('supplier_Id', data.supplier_Id);
    if (data.purchase_Date  != null) {
      formData.append('purchase_Date', data.purchase_Date );
    }
    formData.append('purchase_Price', data.purchase_Price);
    formData.append('purchase_Qty', data.purchase_Qty);
    formData.append('pO_No', data.pO_No == null ? '' : data.pO_No);

    formData.append('status', data.status == null ? '' : data.status);
    formData.append('uom_Id', data.uom_Id);
    formData.append('user_Id', this.user_Id.toString());
    formData.append('is_active', data.is_active);

    

    for (let i = 0; i < this.attchament_list.length; i++) {

      if ((this.attchament_list[i].description == "" || this.attchament_list[i].description == null)) {
        alert("Invalid Input in Attchment Tab!");
        return;
      }

      const keyPrefix = "attachmentList[" + i.toString() + "].";
      formData.append(keyPrefix + "id", this.attchament_list[i].id);
      formData.append(keyPrefix + "description", this.attchament_list[i].description == null ? '' : this.attchament_list[i].description);
      formData.append(keyPrefix + "attachment_Id", this.attchament_list[i].attachment_Id);
      formData.append(keyPrefix + "attachmentFile", this.attchament_list[i].attachmentFile);

    }

    if (this.newBlogForm.valid) {
      if (data.id != 0) {
  
        this._apiService.updateAssetBook(formData).subscribe(res => {
  
          this._snackBar.open("Asset Book Updated Successfully", "Update", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });
  
          this.router.navigate(['/asset-book-land']);
  
  
        })
      }
      else {
        this._apiService.addAssetBook(formData).subscribe(res => {
  
          this._snackBar.open("Asset Book Saved Successfully", "Success", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });
  
          this.router.navigate(['/asset-book-land']);
  
  
        })
      }
    }
  
}
changeUnit(event: any) {
    
  this.unitList$=this._apiService.getUnitListByCompanyId(event.target.value);
 
}
 onSelectChildFile(data: any, fileInput: any) {
  data.attachmentFile = <File>fileInput.target.files[0];
  data.attachment_Id = 0;
}

gotoBack() {
  this.router.navigate(['/asset-book-land']);
}
reset(): void {
  this.ngOnInit();
}
openAssetEmployeeForView(id: number) {
  this.router.navigate([]).then((result) => {
    window.open('/#/asset-employee/detail/' + id, '_blank');
  });
}
}
