import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditAssetBookLandComponent } from './add-edit-asset-book-land.component';

describe('AddEditAssetBookLandComponent', () => {
  let component: AddEditAssetBookLandComponent;
  let fixture: ComponentFixture<AddEditAssetBookLandComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddEditAssetBookLandComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddEditAssetBookLandComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
