import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetBookLandComponent } from './asset-book-land.component';

describe('AssetBookLandComponent', () => {
  let component: AssetBookLandComponent;
  let fixture: ComponentFixture<AssetBookLandComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AssetBookLandComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AssetBookLandComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
