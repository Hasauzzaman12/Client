import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';

@Component({
  selector: 'app-asset-user-support',
  templateUrl: './asset-user-support.component.html',
  styleUrls: ['./asset-user-support.component.scss']
})
export class AssetUserSupportComponent implements OnInit {

  asset_No: string = '';
  support_No: string = '';
  employee_Name: string = '';
  status: string = '';
  user_Id: number = this.authservice.getUserId;
  company_Id: number = 0;
  isFilterShow: boolean = false;

  from_Date : any=null;
  to_Date : any=null;

  companyList$!:Observable<any[]>;

  displayedColumns: string[] = ['support_Date','support_No','asset_No','employee_Name','status','is_active','action'];
  dataSource!: MatTableDataSource<any>;

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';


  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(public _apiService: ApiServiceService,
    private authservice: AuthService,
    private _snackBar: MatSnackBar,
    public dialog: MatDialog,
    private router: Router) { }

  ngOnInit(): void {
    this.getAssetUserSupportList();
    if(this.user_Id>0){
      this.companyList$ = this._apiService.getCompanyListByUser(this.user_Id);
    }else{
      this.companyList$ = this._apiService.getCompanyList();
    }
  }
  getAssetUserSupportList() {

    const formData = new FormData();

    if (this.asset_No != ''||this.asset_No != null) {
      formData.append('asset_No', this.asset_No);
    }
    if (this.support_No != ''||this.support_No != null) {
      formData.append('support_No', this.support_No);
    }
    if (this.employee_Name != ''||this.employee_Name != null) {
      formData.append('employee_Name', this.employee_Name);
    }
    if (this.status != ''||this.status != null) {
      formData.append('status', this.status);
    }
    if (this.user_Id != 0||this.user_Id != null) {
      formData.append('user_Id', this.user_Id.toString());
    }
    if (this.company_Id != 0||this.company_Id != null) {
      formData.append('company_Id', this.company_Id.toString());
    }
    if(this.from_Date != null && this.to_Date != null){
      formData.append('from_Date', this.from_Date);
      formData.append('to_Date', this.to_Date);
    }

    this._apiService.getAssetUserSupportFiltered(formData)
      .subscribe({
        next: (res) => {
          this.dataSource = new MatTableDataSource(res);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
        },
        error: (err) => {
          console.log("Error");
        }

      })
  }
  SearchSummary() {
    this.getAssetUserSupportList();
  }
  reset() {

    this.asset_No='';
    this.support_No='';
    this.employee_Name='';
    this.status='';
    this.company_Id=0;
    this.from_Date=null;
    this.to_Date=null;

    this.getAssetUserSupportList();
  }

  toggleFilter() {
    this.isFilterShow = !this.isFilterShow;
  }
  openForEdit(id: number) {

    this.router.navigate(['/asset-user-support/edit/' + id]);
  }
  gotoNew() {
    this.router.navigate(['/add-asset-user-support']);
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  deleteAssetUserSupport(id: number) {

    if (confirm("Are you sure to delete?")) {
      this._apiService.deleteAssetUserSupport(id)
        .subscribe({
          next: (res) => {
            this._snackBar.open("Asset User Support Deleted Successfully", "Delete", {
              horizontalPosition: this.horizontalPosition,
              verticalPosition: this.verticalPosition,
              duration: 1000
            });
            this.getAssetUserSupportList();
          },
          error: () => {
            this._snackBar.open("Delete Failed", "Failed");
          }
        })
    }



  }
  openAssetForView(id: number) {
    this.router.navigate([]).then((result) => {
      window.open('/#/asset-book/detail/' + id, '_blank');
    });
  }

  openAssetEmployeeForView(id: number) {
    this.router.navigate([]).then((result) => {
      window.open('/#/asset-employee/detail/' + id, '_blank');
    });
  }
}


