import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetUserSupportComponent } from './asset-user-support.component';

describe('AssetUserSupportComponent', () => {
  let component: AssetUserSupportComponent;
  let fixture: ComponentFixture<AssetUserSupportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AssetUserSupportComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AssetUserSupportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
