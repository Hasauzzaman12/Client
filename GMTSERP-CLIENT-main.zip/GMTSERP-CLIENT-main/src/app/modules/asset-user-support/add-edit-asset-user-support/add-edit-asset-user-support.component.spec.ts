import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditAssetUserSupportComponent } from './add-edit-asset-user-support.component';

describe('AddEditAssetUserSupportComponent', () => {
  let component: AddEditAssetUserSupportComponent;
  let fixture: ComponentFixture<AddEditAssetUserSupportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddEditAssetUserSupportComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddEditAssetUserSupportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
