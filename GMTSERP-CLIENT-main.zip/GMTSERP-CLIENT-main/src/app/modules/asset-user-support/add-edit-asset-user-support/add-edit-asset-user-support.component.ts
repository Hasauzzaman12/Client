import { HttpClient, HttpEventType, HttpRequest } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable, of,startWith, debounceTime, distinctUntilChanged, switchMap, map } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service.service';
import { AuthService } from 'src/app/shared/auth.service';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-add-edit-asset-user-support',
  templateUrl: './add-edit-asset-user-support.component.html',
  styleUrls: ['./add-edit-asset-user-support.component.scss']
})
export class AddEditAssetUserSupportComponent implements OnInit {

  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';

  myControl = new FormControl();
  myControl2 = new FormControl();
  options = [];
  filteredOptions: Observable<any>;
  filteredOptionsEmp: Observable<any>;

  constructor(public _apiService: ApiServiceService,
    private _snackBar: MatSnackBar,
    public router: Router,
    private authservice: AuthService,
    private currentRoute: ActivatedRoute,
    private datepipe: DatePipe) { 
      this.filteredOptions = this.myControl.valueChanges.pipe(

        startWith(''),
  
        debounceTime(400),
  
        distinctUntilChanged(),
  
        switchMap(val => {
  
          if(val!=''){
            return this.filter(val || '')
          }else{
            return '';
          }
  
         }) 
  
      )

      this.filteredOptionsEmp = this.myControl2.valueChanges.pipe(

        startWith(''),
  
        debounceTime(400),
  
        distinctUntilChanged(),
  
        switchMap(val => {
  
          if(val!=''){
            return this.filter2(val || '')
          }else{
            return '';
          }
  
         }) 
  
      )
    }

    newBlogForm!: FormGroup;
    id: number = 0;
    support_Date : any;
    support_No= '';
    asset_Book_Id: number = 0;
    asset_No= '';
    employee_Id: number = 0;
    employee_Name= '';
    employee_Code= '';
    remarks= '';
    status= 'Requested';
    is_active: boolean = true;
    attachment_Id: number = 0;
    attachment_File_Name= '';

    selectedFile!: File;
    user_Id: number = this.authservice.getUserId;
  
    assetBookList$!:Observable<any[]>;
    employeeList$!:Observable<any[]>;
    supportItemList$!:Observable<any[]>;
  
    support_detail_list: any[] = [];

  ngOnInit(): void {
    let currentDateTime =this.datepipe.transform((new Date), 'MM/dd/yyyy h:mm:ss');
    this.newBlogForm = new FormGroup({
      id: new FormControl(0),
      support_Date: new FormControl(null),
      asset_Book_Id: new FormControl(0),
      support_No: new FormControl(''),
      employee_Id: new FormControl(0),
      remarks: new FormControl(''),
      status: new FormControl('Requested'),
      is_active: new FormControl(true),
      attachment_Id: new FormControl(0),
    });

    let id = this.currentRoute.snapshot.paramMap.get('id');
    if (id != null) {
      this.getAssetUserSupportById(id);
     
    }else{
      this.support_Date=currentDateTime;
      this.getASNO();
    }
  }

  getAssetUserSupportById(id: number | string) {
    this._apiService.getAssetUserSupportById(id).subscribe((data: any) => {
      this.id=data.id;
      this.support_Date=data.support_Date;
      this.support_No=data.support_No;
      this.asset_Book_Id=data.asset_Book_Id;
      this.asset_No=data.asset_No;
      this.employee_Id=data.employee_Id;
      this.employee_Name=data.employee_Name;
      this.employee_Code=data.employee_Code;
      this.remarks=data.remarks;
      this.status=data.status;
      this.is_active=data.is_active;
      this.attachment_Id=data.attachment_Id;
      this.attachment_File_Name=data.attachment_File_Name;

      this.support_detail_list = data.supportDetailList;
      this.supportItemList$=this._apiService.getAssetSupportItemByAssetBookId(data.asset_Book_Id);
    });

    
  }


  onSelectFile(fileInput: any) {
    this.selectedFile = <File>fileInput.target.files[0];
    this.attachment_Id = 0;
  }

  onSubmit(data: any){

    if (data.asset_Book_Id == 0||data.asset_Book_Id == null) {
      alert("Asset is Required")
      return;
    }

    if (data.support_No == ''||data.support_No == null) {
      alert("Support No is Required")
      return;
    }

    if (data.support_Date == ''||data.support_Date == null) {
      alert("Support Date is Required")
      return;
    }

    if (data.employee_Id == 0||data.employee_Id == null) {
      alert("Employee is Required")
      return;
    }
    if (data.status == ''||data.status == null) {
      alert("Status is Required")
      return;
    }

    if (this.support_detail_list.length==0) {
      alert("Support Details is Required")
      return;
    }

    const formData = new FormData();
    data.id=this.id;
    formData.append('id', data.id);
    formData.append('support_Date', data.support_Date);
    formData.append('support_No', data.support_No == null ? '' : data.support_No);
    formData.append('asset_Book_Id', data.asset_Book_Id);
    formData.append('employee_Id', data.employee_Id);
    formData.append('remarks', data.remarks);
    formData.append('status', data.status);
    formData.append('is_active', data.is_active);
    formData.append('attachment_Id', data.attachment_Id);
    formData.append('attachmentFile', this.selectedFile);

    for (let i = 0; i < this.support_detail_list.length; i++) {

      if ((this.support_detail_list[i].asset_Support_Item_Id == 0 || this.support_detail_list[i].asset_Support_Item_Id == null)) {
        alert("Support Item is Required!");
        return;
      }

      if ((this.support_detail_list[i].support_Type == "" || this.support_detail_list[i].support_Type == null)) {
        alert("Support Type is Required!");
        return;
      }
      const keyPrefix = "supportDetailList[" + i.toString() + "].";
      formData.append(keyPrefix + "id", this.support_detail_list[i].id);
      formData.append(keyPrefix + "asset_Support_Item_Id", this.support_detail_list[i].asset_Support_Item_Id);
      formData.append(keyPrefix + "support_Type", this.support_detail_list[i].support_Type == null ? '' : this.support_detail_list[i].support_Type);
      formData.append(keyPrefix + "remarks", this.support_detail_list[i].remarks == null ? '' : this.support_detail_list[i].remarks);
     
    }

    if (this.newBlogForm.valid) {
      if (data.id != 0) {
  
        this._apiService.updateAssetUserSupport(formData).subscribe(res => {
  
          this._snackBar.open("Asset User Support Updated Successfully", "Update", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });
  
          this.router.navigate(['/asset-user-support']);
  
  
        })
      }
      else {
        this._apiService.addAssetUserSupport(formData).subscribe(res => {
  
          this._snackBar.open("Asset User Support Saved Successfully", "Success", {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: 2000
          });
  
          this.router.navigate(['/asset-user-support']);
  
  
        })
      }
    }
  
  }

  filter(val: string): Observable <any>{
    const formData = new FormData();
    formData.append('asset_No', val);
    if (this.user_Id != 0||this.user_Id != null) {
      formData.append('user_Id', this.user_Id.toString());
    }
    formData.append('status', 'STOCKED');

    return this._apiService.getAssetForDdlFiltered(formData)

      .pipe(
 
        map(response => response.filter((option: { asset_No: string; }) => { 
 
          return option.asset_No.toLowerCase().indexOf(val.toLowerCase()) !== -1
 
        }))
 
      )
   }  

   filter2(val: string): Observable <any>{

    const formData = new FormData();
    formData.append('employee_Id', val);
    if (this.user_Id != 0||this.user_Id != null) {
      formData.append('user_Id', this.user_Id.toString());
    }
    formData.append('emp_Status', 'Active');

    return this._apiService.getEmployeesFiltered(formData)

    .pipe(

      map(response => response.filter((option: { employee_Id: string; }) => { 

        return option.employee_Id.toLowerCase().indexOf(val.toLowerCase()) !== -1

      }))

    )

   }  

   onSelFunc(option: any){
    if(option.id>0){
      this.asset_Book_Id=option.id;
      this.supportItemList$=this._apiService.getAssetSupportItemByAssetBookId(this.asset_Book_Id);
    }
  }

  onSelFunc2(option: any){
    if(option.id>0){
      this.employee_Id=option.id;
      this.employee_Name=option.employee_Name;
    }
  }
  addSupportDetailRow() {
    this.support_detail_list.push({ id: 0,asset_User_Support_Id: 0,asset_Support_Item_Id: 0, support_Type: '',  remarks: '' });
  }
  deletedSupportDetailROw(index: any) {
    if (confirm("Are you sure want to delete?")) {
      this.support_detail_list.splice(index, 1);
    }
  }
  gotoBack() {
    this.router.navigate(['/asset-user-support']);
  }
  reset(): void {
    this.ngOnInit();
  }

  getASNO() {
    this._apiService.getASNO()
    .subscribe((data: any) => {
      this.support_No = data;
    })}
}
