import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DefaultModule } from './layouts/default/default.module';
import { FullwidthModule } from './layouts/fullwidth/fullwidth.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { SecureInnerPagesGuard } from './secure-inner-pages.guard';
import { AuthInterceptor } from './shared/authconfig.interceptor';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


//PrimeNG
import { AutoCompleteModule } from 'primeng/autocomplete';
import { Table, TableModule } from 'primeng/table';
import { Button, ButtonModule } from 'primeng/button';
import { PanelModule } from 'primeng/panel';
import { TabViewModule } from 'primeng/tabview';
import { InputTextModule } from 'primeng/inputtext';
import { CalendarModule } from 'primeng/calendar';
import { ChipsModule } from 'primeng/chips';
import { InputMaskModule } from 'primeng/inputmask';
import { InputNumberModule } from 'primeng/inputnumber';
import { DropdownModule } from 'primeng/dropdown';
import { MultiSelectModule } from 'primeng/multiselect';
import { InputTextareaModule } from 'primeng/inputtextarea';
import { CascadeSelectModule } from 'primeng/cascadeselect';
import { PasswordModule } from 'primeng/password';
import { TreeSelectModule } from 'primeng/treeselect';
import { CardModule } from 'primeng/card';
import { MessagesModule } from 'primeng/messages';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { PanelMenuModule } from 'primeng/panelmenu';
import { MenuModule } from 'primeng/menu';
import { ToastModule } from 'primeng/toast';
import { RippleModule } from 'primeng/ripple';

import { MatProgressBarModule } from '@angular/material/progress-bar'
import { MatTabsModule } from '@angular/material/tabs';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatTableModule } from '@angular/material/table';
import { MatTreeModule } from '@angular/material/tree';

import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSortModule } from '@angular/material/sort';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatCardModule } from '@angular/material/card';
import { MatRadioChange, MatRadioModule } from '@angular/material/radio';
import { AdminCompanyComponent } from './modules/admin-company/admin-company.component';
import { CompanydialogComponent } from './modules/admin-company/companydialog/companydialog.component';
import { AdminUsersComponent } from './modules/admin-users/admin-users.component';
import { UserDialogComponent } from './modules/admin-users/user-dialog/user-dialog.component';
import { MatListModule } from '@angular/material/list';
import { StyleMasterComponent } from './modules/style-master/style-master.component';
import { AddEditStylemasterComponent } from './modules/style-master/add-edit-stylemaster/add-edit-stylemaster.component';

import { ConfirmationDialog } from './confirm-dialogue/confirm-dialogue.component';
import { StylemasetrDetailComponent } from './modules/style-master/stylemaster-detail/stylemaster-detail.component';
import { AdminUserRegistrationComponent } from './modules/admin-user-registration/admin-user-registration.component';
import { AddEditAdminUserRegistrationComponent } from './modules/admin-user-registration/add-edit-admin-user-registration/add-edit-admin-user-registration.component';
import { AdminUserRegistrationDetailComponent } from './modules/admin-user-registration/admin-user-registration-detail/admin-user-registration-detail.component';
import { BuyerMasterComponent } from './modules/buyer-master/buyer-master.component';
import { AddEditBuyerMasterComponent } from './modules/buyer-master/add-edit-buyer-master/add-edit-buyer-master.component';
import { DetailsBbuyerMasterDetailComponent } from './modules/buyer-master/details-buyer-master-detail/details-bbuyer-master-detail.component';
import { AddEditAdminCompanyComponent } from './modules/admin-company/add-edit-admin-company/add-edit-admin-company.component';
import { CertificationsComponent } from './modules/certifications/certifications.component';
import { AddEditCertificationsComponent } from './modules/certifications/add-edit-certifications/add-edit-certifications.component';
import { AopRateComponent } from './modules/aop-rate/aop-rate.component';
import { AddEditAopRateComponent } from './modules/aop-rate/add-edit-aop-rate/add-edit-aop-rate.component';
import { DepartmentComponent } from './modules/department/department.component';
import { AddEditDepartmentComponent } from './modules/department/add-edit-department/add-edit-department.component';
import { DesignationComponent } from './modules/designation/designation.component';
import { AddEditDesignationComponent } from './modules/designation/add-edit-designation/add-edit-designation.component';
import { IeAssumptionComponent } from './modules/ie-assumption/ie-assumption.component';
import { AddEditIeAssumptionComponent } from './modules/ie-assumption/add-edit-ie-assumption/add-edit-ie-assumption.component';
import { CostsheetMasterComponent } from './modules/costsheet-master/costsheet-master.component';
import { AddEditCostsheetMasterComponent } from './modules/costsheet-master/add-edit-costsheet-master/add-edit-costsheet-master.component';
import { LookupTypeComponent } from './modules/lookup-type/lookup-type.component';
import { AddEditLookupTypeComponent } from './modules/lookup-type/add-edit-lookup-type/add-edit-lookup-type.component';
import { LookupTypeDetailsComponent } from './modules/lookup-type/lookup-type-details/lookup-type-details.component';
import { FabricDetailsDialogComponent } from './modules/costsheet-master/fabric-details-dialog/fabric-details-dialog.component';
import { TrimsDetailsDialogComponent } from './modules/costsheet-master/trims-details-dialog/trims-details-dialog.component';
import { LookupTypeCompanyComponent } from './modules/lookup-type-company/lookup-type-company.component';
import { AddEditLookupTypeCompanyComponent } from './modules/lookup-type-company/add-edit-lookup-type-company/add-edit-lookup-type-company.component';
import { LookupTypeCompanyDetailsComponent } from './modules/lookup-type-company/lookup-type-company-details/lookup-type-company-details.component';
import { LookupTypeGlobalComponent } from './modules/lookup-type-global/lookup-type-global.component';
import { AddEditLookupTypeGlobalComponent } from './modules/lookup-type-global/add-edit-lookup-type-global/add-edit-lookup-type-global.component';
import { LookupTypeGlobalDetailsComponent } from './modules/lookup-type-global/lookup-type-global-details/lookup-type-global-details.component';
import { CostsheetMasterDetailComponent } from './modules/costsheet-master/costsheet-master-detail/costsheet-master-detail.component';
import { SigninComponent } from './modules/signin/signin.component';
import { HomeLayoutComponent } from './modules/home-layout/home-layout.component';

import { YarnRateComponent } from './modules/yarn-rate/yarn-rate.component';
import { AddEditYarnRateComponent } from './modules/yarn-rate/add-edit-yarn-rate/add-edit-yarn-rate.component';
import { YarnRateDetailComponent } from './modules/yarn-rate/yarn-rate-detail/yarn-rate-detail.component';
import { KnittingRateComponent } from './modules/knitting-rate/knitting-rate.component';
import { AddEditKnittingRateComponent } from './modules/knitting-rate/add-edit-knitting-rate/add-edit-knitting-rate.component';
import { KnittingRateDetailComponent } from './modules/knitting-rate/knitting-rate-detail/knitting-rate-detail.component';
import { AddEditYarnDyeingRateComponent } from './modules/yarn-dyeing-rate/add-edit-yarn-dyeing-rate/add-edit-yarn-dyeing-rate.component';
import { YarnDyeingRateComponent } from './modules/yarn-dyeing-rate/yarn-dyeing-rate.component';
import { YarnDyeingRateDetailComponent } from './modules/yarn-dyeing-rate/yarn-dyeing-rate-detail/yarn-dyeing-rate-detail.component';
import { FabricDyeingRateComponent } from './modules/fabric-dyeing-rate/fabric-dyeing-rate.component';
import { FabricDyeingRateDetailComponent } from './modules/fabric-dyeing-rate/fabric-dyeing-rate-detail/fabric-dyeing-rate-detail.component';
import { AddEditFabricDyeingRateComponent } from './modules/fabric-dyeing-rate/add-edit-fabric-dyeing-rate/add-edit-fabric-dyeing-rate.component';

import { FabricYarnCountComponent } from './modules/fabric-yarn-count/fabric-yarn-count.component';
import { AddEditFabricYarnCountComponent } from './modules/fabric-yarn-count/add-edit-fabric-yarn-count/add-edit-fabric-yarn-count.component';
import { DetailsFabricYarnCountComponent } from './modules/fabric-yarn-count/details-fabric-yarn-count/details-fabric-yarn-count.component';
import { ProcessLossComponent } from './modules/process-loss/process-loss.component';
import { AddEditProcessLossComponent } from './modules/process-loss/add-edit-process-loss/add-edit-process-loss.component';
import { ProcessLossDetailComponent } from './modules/process-loss/process-loss-detail/process-loss-detail.component';
import { TrimsComponent } from './modules/trims/trims.component';
import { AddEditTrimsComponent } from './modules/trims/add-edit-trims/add-edit-trims.component';
import { OcMasterComponent } from './modules/oc-master/oc-master.component';
import { AddEditOcMasterComponent } from './modules/oc-master/add-edit-oc-master/add-edit-oc-master.component';
import { OcMasterDetailComponent } from './modules/oc-master/oc-master-detail/oc-master-detail.component';
import { AddEditEmployeeComponent } from './modules/employee/add-edit-employee/add-edit-employee.component';
import { EmployeeDetailComponent } from './modules/employee/employee-detail/employee-detail.component';
import { EmployeeComponent } from './modules/employee/employee.component';


import { GeoCountryComponent } from './modules/geo-country/geo-country.component';
import { AddEditGeoCountryComponent } from './modules/geo-country/add-edit-geo-country/add-edit-geo-country.component';
import { GeoCountryDetailsComponent } from './modules/geo-country/geo-country-details/geo-country-details.component';
import { GeoRegionComponent } from './modules/geo-region/geo-region.component';
import { AddEditGeoRegionComponent } from './modules/geo-region/add-edit-geo-region/add-edit-geo-region.component';
import { GeoRegionDetailsComponent } from './modules/geo-region/geo-region-details/geo-region-details.component';
import { GeoZoneComponent } from './modules/geo-zone/geo-zone.component';
import { GeoZoneDetailsComponent } from './modules/geo-zone/geo-zone-details/geo-zone-details.component';
import { AddEditGeoZoneComponent } from './modules/geo-zone/add-edit-geo-zone/add-edit-geo-zone.component';
import { GeoTerritoryComponent } from './modules/geo-territory/geo-territory.component';
import { GeoTerritoryDetailsComponent } from './modules/geo-territory/geo-territory-details/geo-territory-details.component';
import { AddEditGeoTerritoryComponent } from './modules/geo-territory/add-edit-geo-territory/add-edit-geo-territory.component';
import { LookupComponent } from './modules/lookup/lookup.component';
import { AddEditLookupComponent } from './modules/lookup/add-edit-lookup/add-edit-lookup.component';
import { LookupDetailsComponent } from './modules/lookup/lookup-details/lookup-details.component';
import { FabricBookingComponent } from './modules/fabric-booking/fabric-booking.component';
import { AddEditFabricBookingComponent } from './modules/fabric-booking/add-edit-fabric-booking/add-edit-fabric-booking.component';
import { DetailFabricBookingComponent } from './modules/fabric-booking/detail-fabric-booking/detail-fabric-booking.component';
import { SupplierComponent } from './modules/supplier/supplier.component';
import { AddEditSupplierComponent } from './modules/supplier/add-edit-supplier/add-edit-supplier.component';
import { FabricBookingColorDialogComponent } from './modules/fabric-booking/fabric-booking-color-dialog/fabric-booking-color-dialog.component';
import { LookupGrpComponent } from './modules/lookupGrp/lookupGrp.component';
import { AddEditLookupGrpComponent } from './modules/lookupGrp/add-edit-lookupGrp/add-edit-lookupGrp.component';
import { LookupGrpDetailsComponent } from './modules/lookupGrp/lookupGrp-details/lookupGrp-details.component';
import { LookupCatComponent } from './modules/lookup-cat/lookup-cat.component';
import { AddEditLookupCatComponent } from './modules/lookup-cat/add-edit-lookup-cat/add-edit-lookup-cat.component';
import { LookupCatDetailsComponent } from './modules/lookup-cat/lookup-cat-details/lookup-cat-details.component';
import { LookupClassComponent } from './modules/lookup-class/lookup-class.component';
import { LookupClassDetailsComponent } from './modules/lookup-class/lookup-class-details/lookup-class-details.component';
import { AddEditLookupClassComponent } from './modules/lookup-class/add-edit-lookup-class/add-edit-lookup-class.component';
import { LookupWarComponent } from './modules/lookup-war/lookup-war.component';
import { LookupWarDetailsComponent } from './modules/lookup-war/lookup-war-details/lookup-war-details.component';
import { AddEditLookupWarComponent } from './modules/lookup-war/add-edit-lookup-war/add-edit-lookup-war.component';
import { CustomerComponent } from './modules/customer/customer.component';
import { AddEditCustomerComponent } from './modules/customer/add-edit-customer/add-edit-customer.component';
import { RuitmentFinalProposalComponent } from './modules/employee/recruitment-final-proposal/recruitment-final-proposal.component';
import { DivisionComponent } from './modules/division/division.component';
import { AddEditDivisionComponent } from './modules/division/add-edit-division/add-edit-division.component';
import { EmployeeApplicationDialogComponent } from './modules/employee/employee-application-dialog/employee-application-dialog.component';
import { SalesOrderComponent } from './modules/sales-order/sales-order.component';
import { AddEditSalesOrderComponent } from './modules/sales-order/add-edit-sales-order/add-edit-sales-order.component';
import { DeliveryChallanComponent } from './modules/delivery-challan/delivery-challan.component';
import { AddEditDeliveryChallanComponent } from './modules/delivery-challan/add-edit-delivery-challan/add-edit-delivery-challan.component';
import { EmployeeDailyAttendanceComponent } from './modules/employee-daily-attendance/employee-daily-attendance.component';
import { EmployeeAttendanceSummaryComponent } from './modules/employee-daily-attendance/employee-attendance-summary/employee-attendance-summary.component';
import { SalesReturnComponent } from './modules/sales-return/sales-return.component';
import { AddEditSalesReturnComponent } from './modules/sales-return/add-edit-sales-return/add-edit-sales-return.component';
import { EmployeeAttendanceDialogueComponent } from './modules/employee-daily-attendance/employee-attendance-dialogue/employee-attendance-dialogue.component';
import { ItemComponent } from './modules/item/item.component';
import { AddEditItemComponent } from './modules/item/add-edit-item/add-edit-item.component';
import { ItemCategoryComponent } from './modules/item-category/item-category.component';
import { AddEditItemCategoryComponent } from './modules/item-category/add-edit-item-category/add-edit-item-category.component';
import { ItemBrandComponent } from './modules/item-brand/item-brand.component';
import { AddEditItemBrandComponent } from './modules/item-brand/add-edit-item-brand/add-edit-item-brand.component';
import { ItemSubCategoryComponent } from './modules/item-sub-category/item-sub-category.component';
import { AddEditItemSubCategoryComponent } from './modules/item-sub-category/add-edit-item-sub-category/add-edit-item-sub-category.component';
import { ItemSubBrandComponent } from './modules/item-sub-brand/item-sub-brand.component';
import { AddEditItemSubBrandComponent } from './modules/item-sub-brand/add-edit-item-sub-brand/add-edit-item-sub-brand.component';
import { UomComponent } from './modules/uom/uom.component';
import { AddEditUomComponent } from './modules/uom/add-edit-uom/add-edit-uom.component';
import { ItemAflComponent } from './modules/item-afl/item-afl.component';
import { AddEditItemAflComponent } from './modules/item-afl/add-edit-item-afl/add-edit-item-afl.component';
import { EmpManualAttndApprovalComponent } from './modules/employee-daily-attendance/emp-manual-attnd-approval/emp-manual-attnd-approval.component';
import { EmployeeLeaveComponent } from './modules/employee-leave/employee-leave.component';
import { LeaveApplicationComponent } from './modules/employee-leave/leave-application/leave-application.component';
import { LeavePolicyComponent } from './modules/employee-leave/leave-policy/leave-policy.component';
import { LeaveAllocationComponent } from './modules/employee-leave/leave-allocation/leave-allocation.component';
import { AddLeaveApplicationComponent } from './modules/employee-leave/leave-application/add-leave-application/add-leave-application.component';
import { DetailLeaveApplicationComponent } from './modules/employee-leave/leave-bulk-approve/detail-leave-application/detail-leave-application.component';
import { AddLeavePolicyComponent } from './modules/employee-leave/leave-policy/add-leave-policy/add-leave-policy.component';
import { DetailLeavePolicyComponent } from './modules/employee-leave/leave-policy/detail-leave-policy/detail-leave-policy.component';
import { AddLeaveAllocationComponent } from './modules/employee-leave/leave-allocation/add-leave-allocation/add-leave-allocation.component';
import { DetailLeaveAllocationComponent } from './modules/employee-leave/leave-allocation/detail-leave-allocation/detail-leave-allocation.component';
import { LeaveAllocProcessListComponent } from './modules/employee-leave/leave-allocation/leave-alloc-process-list/leave-alloc-process-list.component';
import { AssetBookComponent } from './modules/asset-book/asset-book.component';
import { AddEditAssetBookComponent } from './modules/asset-book/add-edit-asset-book/add-edit-asset-book.component';
import { AssetEmployeeComponent } from './modules/asset-employee/asset-employee.component';
import { AddEditAssetEmployeeComponent } from './modules/asset-employee/add-edit-asset-employee/add-edit-asset-employee.component';
import { AddCustodianComponent } from './modules/custodian/add-custodian/add-custodian.component';
import { ViewCustodianComponent } from './modules/custodian/view-custodian/view-custodian.component';
import { SubCustodianComponent } from './modules/sub-custodian/sub-custodian.component';
import { AddSubCustodianComponent } from './modules/sub-custodian/add-sub-custodian/add-sub-custodian.component';
import { ViewSubCustodianComponent } from './modules/sub-custodian/view-sub-custodian/view-sub-custodian.component';
import { CustodianComponent } from './modules/custodian/custodian.component';
import { SharedModule } from './shared/shared.module';
import { AddUserCompanyUnitComponent } from './modules/user-company-unit-mapping/add-user-company-unit/add-user-company-unit.component';
import { AdminCompanyUnitComponent } from './modules/admin-company-unit/admin-company-unit.component';
import { AddAdminCompanyUnitComponent } from './modules/admin-company-unit/add-admin-company-unit/add-admin-company-unit.component';
import { AssetAllocationComponent } from './modules/asset-allocation/asset-allocation.component';
import { AddEditAssetAllocationComponent } from './modules/asset-allocation/add-edit-asset-allocation/add-edit-asset-allocation.component';
import { DetailsUserCompanyUnitComponent } from './modules/user-company-unit-mapping/details-user-company-unit/details-user-company-unit.component';
import { UserCompanyUnitMappingComponent } from './modules/user-company-unit-mapping/user-company-unit-mapping.component';
import { AssetAllocationReturnComponent } from './modules/asset-allocation-return/asset-allocation-return.component';
import { AddEditAssetAllocationReturnComponent } from './modules/asset-allocation-return/add-edit-asset-allocation-return/add-edit-asset-allocation-return.component';
import { UserChangePasswordComponent } from './shared/components/user-change-password/user-change-password.component';
import { AdminChangePasswordComponent } from './shared/components/admin-change-password/admin-change-password.component';
import { NotFoundComponent } from './shared/components/not-found/not-found.component';
import { AuthGuard } from './shared/auth.guard';
import { AdminMenuComponent } from './modules/admin-menu/admin-menu.component';
import { AddAdminMenuComponent } from './modules/admin-menu/add-admin-menu/add-admin-menu.component';
import { MenuPermissionComponent } from './modules/menu-permission/menu-permission.component';
import { AddMenuPermissionComponent } from './modules/menu-permission/add-menu-permission/add-menu-permission.component';
import { JwtModule } from '@auth0/angular-jwt';
import { TokenInterceptorService } from './shared/token-interceptor.service';
import { ApiServiceService } from './api-service.service';
import { AdminRoleComponent } from './modules/admin-role/admin-role.component';
import { AddAdminRoleComponent } from './modules/admin-role/add-admin-role/add-admin-role.component';
import { BnNgIdleService } from 'bn-ng-idle';

import { AssetMaintenanceReceiveComponent } from './modules/asset-maintenance-receive/asset-maintenance-receive.component';
import { AddEditAssetMaintenanceReceiveComponent } from './modules/asset-maintenance-receive/add-edit-asset-maintenance-receive/add-edit-asset-maintenance-receive.component';
import { AssetMaintenanceReturnComponent } from './modules/asset-maintenance-return/asset-maintenance-return.component';
import { AddEditAssetMaintenanceReturnComponent } from './modules/asset-maintenance-return/add-edit-asset-maintenance-return/add-edit-asset-maintenance-return.component';
import { AssetUserSupportComponent } from './modules/asset-user-support/asset-user-support.component';
import { AddEditAssetUserSupportComponent } from './modules/asset-user-support/add-edit-asset-user-support/add-edit-asset-user-support.component';
import { AssetItemComponent } from './modules/asset-item/asset-item.component';
import { AddEditAssetItemComponent } from './modules/asset-item/add-edit-asset-item/add-edit-asset-item.component';

import { ReportViewerModule } from 'ngx-ssrs-reportviewer';

import { AssetItemSoftwareComponent } from './modules/asset-item-software/asset-item-software.component';
import { AddEditSoftwareComponent } from './modules/asset-item-software/add-edit-software/add-edit-software.component';
import { AssetItemEmailComponent } from './modules/asset-item-email/asset-item-email.component';
import { AddEditEmailComponent } from './modules/asset-item-email/add-edit-email/add-edit-email.component';
import { AssetItemMobileComponent } from './modules/asset-item-mobile/asset-item-mobile.component';
import { AddEditMobileComponent } from './modules/asset-item-mobile/add-edit-mobile/add-edit-mobile.component';
import { AssetItemServerComponent } from './modules/asset-item-server/asset-item-server.component';
import { AddEditServerComponent } from './modules/asset-item-server/add-edit-server/add-edit-server.component';
import { AssetItemAssignEmailComponent } from './modules/asset-item-assign-email/asset-item-assign-email.component';
import { AddEditAssetItemAssignEmailComponent } from './modules/asset-item-assign-email/add-edit-asset-item-assign-email/add-edit-asset-item-assign-email.component';
import { AssetItemAssignMobileComponent } from './modules/asset-item-assign-mobile/asset-item-assign-mobile.component';
import { AddEditAssetItemAssignMobileComponent } from './modules/asset-item-assign-mobile/add-edit-asset-item-assign-mobile/add-edit-asset-item-assign-mobile.component';
import { AssetItemAssignSoftwareComponent } from './modules/asset-item-assign-software/asset-item-assign-software.component';
import { AddEditAssetItemAssignSoftwareComponent } from './modules/asset-item-assign-software/add-edit-asset-item-assign-software/add-edit-asset-item-assign-software.component';
import { ShowAssetEmployeeComponent } from './modules/asset-employee/show-asset-employee/show-asset-employee.component';
import { ShowAssetBookComponent } from './modules/asset-book/show-asset-book/show-asset-book.component';

import { AssetReportComponent } from './modules/asset-report/asset-report.component';
import { AssetBookServerComponent } from './modules/asset-book-server/asset-book-server.component';
import { AddEditAssetBookServerComponent } from './modules/asset-book-server/add-edit-asset-book-server/add-edit-asset-book-server.component';
import { ShowAssetBookServerComponent } from './modules/asset-book-server/show-asset-book-server/show-asset-book-server.component';
import { AssetOwnerComponent } from './modules/asset-owner/asset-owner.component';
import { AddEditAssetOwnerComponent } from './modules/asset-owner/add-edit-asset-owner/add-edit-asset-owner.component';
import { AssetBookVehicleComponent } from './modules/asset-book-vehicle/asset-book-vehicle.component';
import { AddEditAssetBookVehicleComponent } from './modules/asset-book-vehicle/add-edit-asset-book-vehicle/add-edit-asset-book-vehicle.component';
import { ShowAssetBookVehicleComponent } from './modules/asset-book-vehicle/show-asset-book-vehicle/show-asset-book-vehicle.component';
import { AssetAllocationVehicleComponent } from './modules/asset-allocation-vehicle/asset-allocation-vehicle.component';
import { AssetAllocationVehicleReturnComponent } from './modules/asset-allocation-vehicle-return/asset-allocation-vehicle-return.component';
import { AddEditAssetAllocationVehicleComponent } from './modules/asset-allocation-vehicle/add-edit-asset-allocation-vehicle/add-edit-asset-allocation-vehicle.component';
import { AddEditAssetAllocationVehicleReturnComponent } from './modules/asset-allocation-vehicle-return/add-edit-asset-allocation-vehicle-return/add-edit-asset-allocation-vehicle-return.component';
import { ShowAssetVehicleDocumentsComponent } from './modules/asset-book-vehicle/show-asset-vehicle-documents/show-asset-vehicle-documents.component';
import { AssetItemListComponent } from './modules/asset-item-list/asset-item-list.component';
import { AddEditAssetItemListComponent } from './modules/asset-item-list/add-edit-asset-item-list/add-edit-asset-item-list.component';
import { AssetBookAdminComponent } from './modules/asset-book-admin/asset-book-admin.component';
import { AddEditAssetBookAdminComponent } from './modules/asset-book-admin/add-edit-asset-book-admin/add-edit-asset-book-admin.component';
import { AssetBookPlantComponent } from './modules/asset-book-plant/asset-book-plant.component';
import { AssetBookLandComponent } from './modules/asset-book-land/asset-book-land.component';
import { AddEditAssetBookPlantComponent } from './modules/asset-book-plant/add-edit-asset-book-plant/add-edit-asset-book-plant.component';
import { AddEditAssetBookLandComponent } from './modules/asset-book-land/add-edit-asset-book-land/add-edit-asset-book-land.component';
import { AssetAllocationAdminComponent } from './modules/asset-allocation-admin/asset-allocation-admin.component';
import { AddEditAssetAllocationAdminComponent } from './modules/asset-allocation-admin/add-edit-asset-allocation-admin/add-edit-asset-allocation-admin.component';
import { AssetAllocationAdminReturnComponent } from './modules/asset-allocation-admin-return/asset-allocation-admin-return.component';
import { AddEditAssetAllocationAdminReturnComponent } from './modules/asset-allocation-admin-return/add-edit-asset-allocation-admin-return/add-edit-asset-allocation-admin-return.component';
import { AssetAllocationLandComponent } from './modules/asset-allocation-land/asset-allocation-land.component';
import { AddEditAssetAllocationLandComponent } from './modules/asset-allocation-land/add-edit-asset-allocation-land/add-edit-asset-allocation-land.component';
import { AssetAllocationPlantComponent } from './modules/asset-allocation-plant/asset-allocation-plant.component';
import { AddEditAssetAllocationPlantComponent } from './modules/asset-allocation-plant/add-edit-asset-allocation-plant/add-edit-asset-allocation-plant.component';
import { AssetAllocationLandReturnComponent } from './modules/asset-allocation-land-return/asset-allocation-land-return.component';
import { AddEditAssetAllocationLandReturnComponent } from './modules/asset-allocation-land-return/add-edit-asset-allocation-land-return/add-edit-asset-allocation-land-return.component';
import { AssetAllocationPlantReturnComponent } from './modules/asset-allocation-plant-return/asset-allocation-plant-return.component';
import { AddEditAssetAllocationPlantReturnComponent } from './modules/asset-allocation-plant-return/add-edit-asset-allocation-plant-return/add-edit-asset-allocation-plant-return.component';
import { EmployeePfComponent } from './modules/employee-pf/employee-pf.component';
import { AddEditEmployeePfComponent } from './modules/employee-pf/add-edit-employee-pf/add-edit-employee-pf.component';
import { AssetSparePartComponent } from './modules/asset-spare-part/asset-spare-part.component';
import { AddEditAssetSparePartComponent } from './modules/asset-spare-part/add-edit-asset-spare-part/add-edit-asset-spare-part.component';
import { AssetGrnMasterComponent } from './modules/asset-grn-master/asset-grn-master.component';
import { AddEditAssetGrnMasterComponent } from './modules/asset-grn-master/add-edit-asset-grn-master/add-edit-asset-grn-master.component';
import { AssetSparePartBookComponent } from './modules/asset-spare-part-book/asset-spare-part-book.component';
import { AddEditAssetSparePartBookComponent } from './modules/asset-spare-part-book/add-edit-asset-spare-part-book/add-edit-asset-spare-part-book.component';
import { AssetSparePartCsComponent } from './modules/asset-spare-part-cs/asset-spare-part-cs.component';
import { HrLeaveTypeComponent } from './modules/hr-leave-type/hr-leave-type.component';
import { AddEditHrLeaveTypeComponent } from './modules/hr-leave-type/add-edit-hr-leave-type/add-edit-hr-leave-type.component';
import { LeaveReasonComponent } from './modules/employee-leave/leave-reason/leave-reason.component';
import { AddEditLeaveReasonComponent } from './modules/employee-leave/leave-reason/add-edit-leave-reason/add-edit-leave-reason.component';

import { HR_SectionComponent } from './modules/hr_section/hr_section.component';
import { AddEditHR_SectionComponent } from './modules/hr_section/add-edit-hr_section/add-edit-hr_section.component';
import { MyLeaveApplicationComponent } from './modules/employee-leave/my-leave-application/my-leave-application.component';
import { LeaveBulkApproveComponent } from './modules/employee-leave/leave-bulk-approve/leave-bulk-approve.component';
import { AddEditLeaveBulkApproveComponent } from './modules/employee-leave/leave-bulk-approve/add-edit-leave-bulk-approve/add-edit-leave-bulk-approve.component';
import { LeaveAuthorizationComponent } from './modules/employee-leave/leave-authorization/leave-authorization.component';
import { AddEditLeaveAuthorizationComponent } from './modules/employee-leave/leave-authorization/add-edit-leave-authorization/add-edit-leave-authorization.component';
import { EmployeesDocComponent } from './modules/employee/employees-doc/employees-doc.component';

import { MonthlyAttendanceProcessComponent } from './modules/employee-daily-attendance/monthly-attendance-process/monthly-attendance-process.component';
import { AddMonthlyAttendanceProcessComponent } from './modules/employee-daily-attendance/add-monthly-attendance-process/add-monthly-attendance-process.component';
import { AddEditEmpManualDailyAatendanceComponent } from './modules/employee-daily-attendance/emp-manual-attnd-approval/add-edit-emp-manual-daily-aatendance/add-edit-emp-manual-daily-aatendance.component';
import { AddEditGmtsDocumentsComponent } from './modules/gmts-domcuments/add-edit-gmts-documents/add-edit-gmts-documents.component';
import { GmtsDomcumentsComponent } from './modules/gmts-domcuments/gmts-domcuments.component';
import { GmtsDocSearchComponent } from './modules/gmts-domcuments/gmts-doc-search/gmts-doc-search.component';
import { RecycleDocComponent } from './modules/gmts-domcuments/recycle-doc/recycle-doc.component';
import { GmtsDocReminderComponent } from './modules/gmts-domcuments/gmts-doc-reminder/gmts-doc-reminder.component';
import { GmtsDocLookupComponent } from './modules/gmts-domcuments/gmts-doc-lookup/gmts-doc-lookup.component';
import { AddEditGmtsDocLookupComponent } from './modules/gmts-domcuments/gmts-doc-lookup/add-edit-gmts-doc-lookup/add-edit-gmts-doc-lookup.component';
import { DdmsCommercialComponent } from './modules/ddms-commercial/ddms-commercial.component';
import { AddEditDdmsCommercialComponent } from './modules/ddms-commercial/add-edit-ddms-commercial/add-edit-ddms-commercial.component';
import { DepartmentCompanyComponent } from './modules/department-company/department-company.component';
import { AddDepartmentCompanyComponent } from './modules/department-company/add-department-company/add-department-company.component';
import { HrHolidayComponent } from './modules/employee-leave/hr-holiday/hr-holiday.component';
import { AddEditHrHolidayComponent } from './modules/employee-leave/hr-holiday/add-edit-hr-holiday/add-edit-hr-holiday.component';
import { AdminUserPasswordResetDialogComponent } from './modules/admin-user-registration/admin-user-password-reset-dialog/admin-user-password-reset-dialog.component';
import { MonthlyAttendaceSummaryReportComponent } from './modules/employee-daily-attendance/report/monthly-attendace-summary-report/monthly-attendace-summary-report.component';
import { LeaveReportComponent } from './modules/employee-leave/report/leave-report/leave-report.component';
import { EmployeeCountSummaryComponent } from './modules/employee/employee-count-summary/employee-count-summary.component';
import { EmployeeCountSummaryDialogComponent } from './modules/employee/employee-count-summary/employee-count-summary-dialog/employee-count-summary-dialog.component';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatMenuModule } from '@angular/material/menu';
import { LayoutModule } from '@angular/cdk/layout';
import { ItemDiscountPolicyComponent } from './modules/item-discount-policy/item-discount-policy.component';
import { AddEditItemDiscountPolicyComponent } from './modules/item-discount-policy/add-edit-item-discount-policy/add-edit-item-discount-policy.component';
import { WarehouseComponent } from './modules/warehouse/warehouse.component';
import { AddEditWarehouseComponent } from './modules/warehouse/add-edit-warehouse/add-edit-warehouse.component';
import { VehicleLocationComponent } from './modules/asset-book-vehicle/vehicle-location/vehicle-location.component';
import { AddEditVehicleLocationComponent } from './modules/asset-book-vehicle/vehicle-location/add-edit-vehicle-location/add-edit-vehicle-location.component';
import { TransportTpComponent } from './modules/transport-tp/transport-tp.component';
import { AddEditTransportTpComponent } from './modules/transport-tp/add-edit-transport-tp/add-edit-transport-tp.component';
import { CfFarmerComponent } from './modules/cf/cf-farmer/cf-farmer.component';
import { AddEditCfFarmerComponent } from './modules/cf/cf-farmer/add-edit-cf-farmer/add-edit-cf-farmer.component';
import { CfFlockInfoComponent } from './modules/cf/cf-flock-info/cf-flock-info.component';
import { AddEditCfFlockInfoComponent } from './modules/cf/cf-flock-info/add-edit-cf-flock-info/add-edit-cf-flock-info.component';
import { CfGrnComponent } from './modules/cf/cf-grn/cf-grn.component';
import { AddEditCfGrnComponent } from './modules/cf/cf-grn/add-edit-cf-grn/add-edit-cf-grn.component';
import { CfIssueComponent } from './modules/cf/cf-issue/cf-issue.component';
import { AddEditCfIssueComponent } from './modules/cf/cf-issue/add-edit-cf-issue/add-edit-cf-issue.component';
import { CfItemStockComponent } from './modules/cf/cf-item-stock/cf-item-stock.component';
import { AccCoaComponent } from './modules/finance/acc-coa/acc-coa.component';
import { AddEditAccCoaComponent } from './modules/finance/acc-coa/add-edit-acc-coa/add-edit-acc-coa.component';
import { FiberCompositionComponent } from './modules/merchandising/fiber-composition/fiber-composition.component';
import { YarnItemRegistrationComponent } from './modules/merchandising/yarn-item-registration/yarn-item-registration.component';
import { AddEditYarnItemRegistrationComponent } from './modules/merchandising/yarn-item-registration/add-edit-yarn-item-registration/add-edit-yarn-item-registration.component';
import { AddEditFiberCompositionComponent } from './modules/merchandising/fiber-composition/add-edit-fiber-composition/add-edit-fiber-composition.component';
import { YarnCountLookupComponent } from './modules/merchandising/yarn-count-lookup/yarn-count-lookup.component';
import { YarnCountLookupDetailsComponent } from './modules/merchandising/yarn-count-lookup/yarn-count-lookup-details/yarn-count-lookup-details.component';
import { AddEditYarnCountLookupComponent } from './modules/merchandising/yarn-count-lookup/add-edit-yarn-count-lookup/add-edit-yarn-count-lookup.component';
import { CfIssueReturnComponent } from './modules/cf/cf-issue-return/cf-issue-return.component';
import { AddEditCfIssueReturnComponent } from './modules/cf/cf-issue-return/add-edit-cf-issue-return/add-edit-cf-issue-return.component';
import { VoucherComponent } from './modules/finance/voucher/voucher.component';
import { UploadVoucherComponent } from './modules/finance/voucher/upload-voucher/upload-voucher.component';
import { AddEditVoucherComponent } from './modules/finance/voucher/add-edit-voucher/add-edit-voucher.component';
import { CfRegionComponent } from './modules/cf/cf-region/cf-region.component';
import { AddEditCfRegionComponent } from './modules/cf/cf-region/add-edit-cf-region/add-edit-cf-region.component';
import { CfBranchComponent } from './modules/cf/cf-branch/cf-branch.component';
import { AddEditCfBranchComponent } from './modules/cf/cf-branch/add-edit-cf-branch/add-edit-cf-branch.component';
import { CfClusterComponent } from './modules/cf/cf-cluster/cf-cluster.component';
import { AddEditCfClusterComponent } from './modules/cf/cf-cluster/add-edit-cf-cluster/add-edit-cf-cluster.component';
import { CfWarehouseComponent } from './modules/cf/cf-warehouse/cf-warehouse.component';
import { AddEditCfWarehouseComponent } from './modules/cf/cf-warehouse/add-edit-cf-warehouse/add-edit-cf-warehouse.component';
import { CfSupplierComponent } from './modules/cf/cf-supplier/cf-supplier.component';
import { AddEditCfSupplierComponent } from './modules/cf/cf-supplier/add-edit-cf-supplier/add-edit-cf-supplier.component';
import { DetailCfIssueComponent } from './modules/cf/cf-issue/detail-cf-issue/detail-cf-issue.component';
import { DetailCfIssueReturnComponent } from './modules/cf/cf-issue-return/detail-cf-issue-return/detail-cf-issue-return.component';
import { DetailCfGrnComponent } from './modules/cf/cf-grn/detail-cf-grn/detail-cf-grn.component';
import { FinanceReportComponent } from './modules/finance/report/finance-report/finance-report.component';
import { EmployeeAttendanceApplicationComponent } from './modules/employee-daily-attendance/employee-attendance-application/employee-attendance-application.component';
import { CfFgSaleComponent } from './modules/cf/cf-fg-sale/cf-fg-sale.component';
import { AddEditCfFgSaleComponent } from './modules/cf/cf-fg-sale/add-edit-cf-fg-sale/add-edit-cf-fg-sale.component';
import { DetailCfFgSaleComponent } from './modules/cf/cf-fg-sale/detail-cf-fg-sale/detail-cf-fg-sale.component';
import { CfApprovalProcessComponent } from './modules/cf/cf-approval-process/cf-approval-process.component';
import { AddEditCfApprovalProcessComponent } from './modules/cf/cf-approval-process/add-edit-cf-approval-process/add-edit-cf-approval-process.component';
import { CfIssueApprovalComponent } from './modules/cf/cf-issue/cf-issue-approval/cf-issue-approval.component';
import { CfCustomerComponent } from './modules/cf/cf-customer/cf-customer.component';
import { AddEditCfCustomerComponent } from './modules/cf/cf-customer/add-edit-cf-customer/add-edit-cf-customer.component';
import { CfRatePolicyComponent } from './modules/cf/cf-rate-policy/cf-rate-policy.component';
import { AddEditCfRatePolicyComponent } from './modules/cf/cf-rate-policy/add-edit-cf-rate-policy/add-edit-cf-rate-policy.component';
import { CfDailyFlockActivityComponent } from './modules/cf/cf-daily-flock-activity/cf-daily-flock-activity.component';
import { AddEditCfDailyFlockActivityComponent } from './modules/cf/cf-daily-flock-activity/add-edit-cf-daily-flock-activity/add-edit-cf-daily-flock-activity.component';
import { CfReportComponent } from './modules/cf/cf-report/cf-report.component';
import { CfDeadReasonComponent } from './modules/cf/cf_lookup/cf-dead-reason/cf-dead-reason.component';
import { AddEditCfDeadReasonComponent } from './modules/cf/cf_lookup/cf-dead-reason/add-edit-cf-dead-reason/add-edit-cf-dead-reason.component';
import { CfDeadActionComponent } from './modules/cf/cf_lookup/cf-dead-action/cf-dead-action.component';
import { AddEditCfDeadActionComponent } from './modules/cf/cf_lookup/cf-dead-action/add-edit-cf-dead-action/add-edit-cf-dead-action.component';
import { CfDashboardComponent } from './modules/cf/cf-dashboard/cf-dashboard.component';
import { AjflPurchaseComponent } from './modules/ajfl/ajfl-purchase/ajfl-purchase.component';
import { AddEditAjflPurchaseComponent } from './modules/ajfl/ajfl-purchase/add-edit-ajfl-purchase/add-edit-ajfl-purchase.component';
import { AjflReportComponent } from './modules/ajfl/ajfl-report/ajfl-report.component';
import { AjflSupplierComponent } from './modules/ajfl/ajfl-lookup/ajfl-supplier/ajfl-supplier.component';
import { AddEditAjflSupplierComponent } from './modules/ajfl/ajfl-lookup/ajfl-supplier/add-edit-ajfl-supplier/add-edit-ajfl-supplier.component';
import { AjflItemGradeComponent } from './modules/ajfl/ajfl-item-grade/ajfl-item-grade.component';
import { AddEditAjflItemGradeComponent } from './modules/ajfl/ajfl-item-grade/add-edit-ajfl-item-grade/add-edit-ajfl-item-grade.component';
import { ComplianceDocumentComponent } from './modules/compliance/compliance-document/compliance-document.component';
import { AddEditComplianceDocumentComponent } from './modules/compliance/compliance-document/add-edit-compliance-document/add-edit-compliance-document.component';
import { ComplianceItemTypeComponent } from './modules/compliance/compliance-item-type/compliance-item-type.component';
import { AddEditComplianceItemTypeComponent } from './modules/compliance/compliance-item-type/add-edit-compliance-item-type/add-edit-compliance-item-type.component';
import { SalaryHeadComponent } from './modules/employee/employee-salary/salary-head/salary-head.component';
import { SalaryRuleComponent } from './modules/employee/employee-salary/salary-rule/salary-rule.component';
import { EmpSalaryInfoComponent } from './modules/employee/employee-salary/emp-salary-info/emp-salary-info.component';
import { EmpMonthwiseSalaryProcessComponent } from './modules/employee/employee-salary/emp-monthwise-salary-process/emp-monthwise-salary-process.component';
import { EmpMonthwiseAttnProcSalaryComponent } from './modules/employee/employee-salary/emp-monthwise-attn-proc-salary/emp-monthwise-attn-proc-salary.component';
import { EmpAttendancePayRuleComponent } from './modules/employee/employee-salary/emp-attendance-pay-rule/emp-attendance-pay-rule.component';
import { AddEditSalaryheadComponent } from './modules/employee/employee-salary/salary-head/add-edit-salaryhead/add-edit-salaryhead.component';
import { AddEditSalaryruleComponent } from './modules/employee/employee-salary/salary-rule/add-edit-salaryrule/add-edit-salaryrule.component';
import { AddEditAttnpayruleComponent } from './modules/employee/employee-salary/emp-attendance-pay-rule/add-edit-attnpayrule/add-edit-attnpayrule.component';
import { AddAttnprocSalaryComponent } from './modules/employee/employee-salary/emp-monthwise-attn-proc-salary/add-attnproc-salary/add-attnproc-salary.component';
import { AddMonthlySalaryProcessComponent } from './modules/employee/employee-salary/emp-monthwise-salary-process/add-monthly-salary-process/add-monthly-salary-process.component';
import { AddEmpSalaryInfoComponent } from './modules/employee/employee-salary/emp-salary-info/add-emp-salary-info/add-emp-salary-info.component';
import { EmpSalaryManipulationInfoComponent } from './modules/employee/employee-salary/emp-salary-manipulation-info/emp-salary-manipulation-info.component';
import { AddSalaryManipulationInfoComponent } from './modules/employee/employee-salary/emp-salary-manipulation-info/add-salary-manipulation-info/add-salary-manipulation-info.component';
import { AjflBasisSetupComponent } from './modules/ajfl/ajfl-basis-setup/ajfl-basis-setup.component';
import { AddEditAjflBasisSetupComponent } from './modules/ajfl/ajfl-basis-setup/add-edit-ajfl-basis-setup/add-edit-ajfl-basis-setup.component';
import { CstCustomerComponent } from './modules/cst/cst-customer/cst-customer.component';
import { AddEditCstCustomerComponent } from './modules/cst/cst-customer/add-edit-cst-customer/add-edit-cst-customer.component';
import { CstBookingComponent } from './modules/cst/cst-booking/cst-booking.component';
import { AddEditCstBookingComponent } from './modules/cst/cst-booking/add-edit-cst-booking/add-edit-cst-booking.component';
import { CstSroComponent } from './modules/cst/cst-sro/cst-sro.component';
import { AddEditCstSroComponent } from './modules/cst/cst-sro/add-edit-cst-sro/add-edit-cst-sro.component';
import { MonthwiseSalaryProcessRollbackComponent } from './modules/employee/employee-salary/emp-monthwise-salary-process/monthwise-salary-process-rollback/monthwise-salary-process-rollback.component';
import { CstSroPendingListComponent } from './modules/cst/cst-sro/cst-sro-pending-list/cst-sro-pending-list.component';
import { AjflProductionIssueComponent } from './modules/ajfl/ajfl-production-issue/ajfl-production-issue.component';
import { AddEditProductionIssueComponent } from './modules/ajfl/ajfl-production-issue/add-edit-production-issue/add-edit-production-issue.component';
import { AjflProductionRequisitionComponent } from './modules/ajfl/ajfl-production-requisition/ajfl-production-requisition.component';
import { AddEditProductionRequisitionComponent } from './modules/ajfl/ajfl-production-requisition/add-edit-production-requisition/add-edit-production-requisition.component';

import { CstSeasonComponent } from './modules/cst/cst-season/cst-season.component';
import { AddEditCstSeasonComponent } from './modules/cst/cst-season/add-edit-cst-season/add-edit-cst-season.component';
import { CfUserMappingComponent } from './modules/cf/cf-user-mapping/cf-user-mapping.component';
import { AddEditCfUserMappingComponent } from './modules/cf/cf-user-mapping/add-edit-cf-user-mapping/add-edit-cf-user-mapping.component';
import { CstDoComponent } from './modules/cst/cst-do/cst-do.component';
import { AddEditCstDoComponent } from './modules/cst/cst-do/add-edit-cst-do/add-edit-cst-do.component';
import { CstBookingRateComponent } from './modules/cst/cst-booking-rate/cst-booking-rate.component';
import { AddEditCstNormalBookingComponent } from './modules/cst/cst-normal-booking/add-edit-cst-normal-booking/add-edit-cst-normal-booking.component';
import { AddEditCstBookingRateComponent } from './modules/cst/cst-booking-rate/add-edit-cst-booking-rate/add-edit-cst-booking-rate.component';
import { CstNormalBookingComponent } from './modules/cst/cst-normal-booking/cst-normal-booking.component';
import { ModifyAttnPrcSalaryComponent } from './modules/employee/employee-salary/emp-monthwise-attn-proc-salary/modify-attn-prc-salary/modify-attn-prc-salary.component';
import { AccPettyCashComponent } from './modules/finance/acc-petty-cash/acc-petty-cash.component';
import { AddEditAccPettyCashComponent } from './modules/finance/acc-petty-cash/add-edit-acc-petty-cash/add-edit-acc-petty-cash.component';
import { CfPlDashboardComponent } from './modules/cf/cf-pl-dashboard/cf-pl-dashboard.component';
import { AccAccountsTypeComponent } from './modules/finance/acc-accounts-type/acc-accounts-type.component';
import { AddEditAccAccountsTypeComponent } from './modules/finance/acc-accounts-type/add-edit-acc-accounts-type/add-edit-acc-accounts-type.component';
import { AddEditCstSrLoanPaymentComponent } from './modules/cst/cst-sr-loan-payment/add-edit-cst-sr-loan-payment/add-edit-cst-sr-loan-payment.component';
import { CstSrLoanComponent } from './modules/cst/cst-sr-loan/cst-sr-loan.component';
import { AddEditCstSrLoanComponent } from './modules/cst/cst-sr-loan/add-edit-cst-sr-loan/add-edit-cst-sr-loan.component';
import { CstSrLoanPaymentComponent } from './modules/cst/cst-sr-loan-payment/cst-sr-loan-payment.component';
import { ComplianceAllDocumentComponent } from './modules/compliance/compliance-all-document/compliance-all-document.component';
import { AddEditCstSrLoanReturnComponent } from './modules/cst/cst-sr-loan-return/add-edit-cst-sr-loan-return/add-edit-cst-sr-loan-return.component';
import { CstSrLoanReturnComponent } from './modules/cst/cst-sr-loan-return/cst-sr-loan-return.component';
import { ComplianceAssignedDocumentComponent } from './modules/compliance/compliance-assigned-document/compliance-assigned-document.component';
import { EmployeeSalaryReportComponent } from './modules/employee/employee-salary/report/employee-salary-report/employee-salary-report.component';
import { AddEditComplainceAssignedDocumentComponent } from './modules/compliance/compliance-assigned-document/add-edit-complaince-assigned-document/add-edit-complaince-assigned-document.component';
import { CfFeedConsumptionDetailComponent } from './modules/cf/cf-feed-consumption-report/cf-feed-consumption-detail/cf-feed-consumption-detail.component';
import { CfFeedConsumptionReportComponent } from './modules/cf/cf-feed-consumption-report/cf-feed-consumption-report.component';
import { ComplianceApprovalProcessComponent } from './modules/compliance/compliance-approval-process/compliance-approval-process.component';
import { AddEditComplianceApprovalProcessComponent } from './modules/compliance/compliance-approval-process/add-edit-compliance-approval-process/add-edit-compliance-approval-process.component';
import { ComplianceDocumentApprovalComponent } from './modules/compliance/compliance-document-approval/compliance-document-approval.component';
import { EmpMonthwiseAttnProcSalaryManipulationComponent } from './modules/employee/employee-salary/emp-monthwise-attn-proc-salary-manipulation/emp-monthwise-attn-proc-salary-manipulation.component';
import { ModifyAttnProcSalaryManipulationComponent } from './modules/employee/employee-salary/emp-monthwise-attn-proc-salary-manipulation/modify-attn-proc-salary-manipulation/modify-attn-proc-salary-manipulation.component';
import { CfFlockCostingComponent } from './modules/cf/cf-flock-info/cf-flock-costing/cf-flock-costing.component';
import { CfDaSummaryComponent } from './modules/cf/cf-daily-flock-activity/cf-da-summary/cf-da-summary.component';
import { CfDaSummaryDialogComponent } from './modules/cf/cf-daily-flock-activity/cf-da-summary/cf-da-summary-dialog/cf-da-summary-dialog.component';
import { InvRawMaterialComponent } from './modules/inventory/inv-raw-material/inv-raw-material.component';
import { AddEditInvRawMaterialComponent } from './modules/inventory/inv-raw-material/add-edit-inv-raw-material/add-edit-inv-raw-material.component';
import { AddEditCstDeliveryComponent } from './modules/cst/cst-do/add-edit-cst-delivery/add-edit-cst-delivery.component';
import { CstPaidBookngInfoComponent } from './modules/cst/cst-paid-bookng-info/cst-paid-bookng-info.component';
import { AddEditCstPaidBookngComponent } from './modules/cst/cst-paid-bookng-info/add-edit-cst-paid-bookng/add-edit-cst-paid-bookng.component';
import { CfPaymentInfoComponent } from './modules/cf/cf-payment-info/cf-payment-info.component';
import { AddEditCfPaymentInfoComponent } from './modules/cf/cf-payment-info/add-edit-cf-payment-info/add-edit-cf-payment-info.component';
import { ComplianceDocSummaryDialogComponent } from './modules/compliance/compliance-doc-summary-dialog/compliance-doc-summary-dialog.component';
import { CstSrInfoListComponent } from './modules/cst/cst-sro/cst-sr-info-list/cst-sr-info-list.component';
import { CfItemMarketRateComponent } from './modules/cf/cf-item-market-rate/cf-item-market-rate.component';
import { AddEditCfItemMarketRateComponent } from './modules/cf/cf-item-market-rate/add-edit-cf-item-market-rate/add-edit-cf-item-market-rate.component';
import { CfFarmManagementCostComponent } from './modules/cf/cf-farm-management-cost/cf-farm-management-cost.component';
import { AddEditCfFarmManagementCostComponent } from './modules/cf/cf-farm-management-cost/add-edit-cf-farm-management-cost/add-edit-cf-farm-management-cost.component';
import { CstReportComponent } from './modules/cst/cst-report/cst-report.component';
import { CfGrnStockTransferComponent } from './modules/cf/cf-grn-stock-transfer/cf-grn-stock-transfer.component';
import { AddEditCfGrnStockTransferComponent } from './modules/cf/cf-grn-stock-transfer/add-edit-cf-grn-stock-transfer/add-edit-cf-grn-stock-transfer.component';
import { CfGrnStockRecieveComponent } from './modules/cf/cf-grn-stock-recieve/cf-grn-stock-recieve/cf-grn-stock-recieve.component';
import { AddEditCfGrnStockRecvComponent } from './modules/cf/cf-grn-stock-recieve/add-edit-cf-grn-stock-recv/add-edit-cf-grn-stock-recv/add-edit-cf-grn-stock-recv.component';

export function tokenGetter() {
  return localStorage.getItem("jwt");
}


@NgModule({
  declarations: [
    AppComponent,
    AppComponent,
    AdminCompanyComponent,
    CompanydialogComponent,
    AdminUsersComponent,
    UserDialogComponent,
    StyleMasterComponent,
    AddEditStylemasterComponent,
    ConfirmationDialog,
    StylemasetrDetailComponent,
    AdminUserRegistrationComponent,
    AddEditAdminUserRegistrationComponent,
    AdminUserRegistrationDetailComponent,
    LookupTypeComponent,
    AddEditLookupTypeComponent,
    LookupTypeDetailsComponent,
    BuyerMasterComponent,
    AddEditBuyerMasterComponent,
    DetailsBbuyerMasterDetailComponent,
    AddEditAdminCompanyComponent,
    CertificationsComponent,
    AddEditCertificationsComponent,
    AopRateComponent,
    AddEditAopRateComponent,
    DepartmentComponent,
    AddEditDepartmentComponent,
    HR_SectionComponent,
    AddEditHR_SectionComponent,
    DesignationComponent,
    AddEditDesignationComponent,
    IeAssumptionComponent,
    AddEditIeAssumptionComponent,
    CostsheetMasterComponent,
    CostsheetMasterDetailComponent,
    AddEditCostsheetMasterComponent,
    FabricDetailsDialogComponent,
    TrimsDetailsDialogComponent,

    LookupTypeComponent,
    AddEditLookupTypeComponent,
    LookupTypeDetailsComponent,

    LookupTypeCompanyComponent,
    AddEditLookupTypeCompanyComponent,
    LookupTypeCompanyDetailsComponent,

    LookupTypeGlobalComponent,
    AddEditLookupTypeGlobalComponent,
    LookupTypeGlobalDetailsComponent,

    SigninComponent,
    HomeLayoutComponent,

    FabricYarnCountComponent,
    AddEditFabricYarnCountComponent,
    DetailsFabricYarnCountComponent,

    YarnRateComponent,
    AddEditYarnRateComponent,
    YarnRateDetailComponent,


    KnittingRateComponent,
    AddEditKnittingRateComponent,
    KnittingRateDetailComponent,

    YarnDyeingRateComponent,
    AddEditYarnDyeingRateComponent,
    YarnDyeingRateDetailComponent,

    FabricDyeingRateComponent,
    FabricDyeingRateDetailComponent,
    AddEditFabricDyeingRateComponent,
    ProcessLossComponent,
    AddEditProcessLossComponent,
    ProcessLossDetailComponent,

    TrimsComponent,
    AddEditTrimsComponent,
    TrimsDetailsDialogComponent,
    OcMasterComponent,
    AddEditOcMasterComponent,
    OcMasterDetailComponent,
    AddEditEmployeeComponent,
    EmployeeDetailComponent,
    EmployeeComponent,

    GeoCountryComponent,
    AddEditGeoCountryComponent,
    GeoCountryDetailsComponent,
    GeoRegionComponent,
    AddEditGeoRegionComponent,
    GeoRegionDetailsComponent,
    AddEditGeoRegionComponent,
    GeoZoneComponent,
    GeoZoneDetailsComponent,
    AddEditGeoZoneComponent,
    GeoTerritoryComponent,
    GeoTerritoryDetailsComponent,
    AddEditGeoTerritoryComponent,
    LookupComponent,
    AddEditLookupComponent,
    LookupDetailsComponent,
    FabricBookingComponent,
    AddEditFabricBookingComponent,
    DetailFabricBookingComponent,
    SupplierComponent,
    AddEditSupplierComponent,
    FabricBookingColorDialogComponent,
    LookupGrpComponent,
    AddEditLookupGrpComponent,
    LookupGrpDetailsComponent,
    LookupCatComponent,
    AddEditLookupCatComponent,
    LookupCatDetailsComponent,
    LookupClassComponent,
    LookupClassDetailsComponent,
    AddEditLookupClassComponent,
    LookupWarComponent,
    LookupWarDetailsComponent,
    AddEditLookupWarComponent,
    CustomerComponent,
    AddEditCustomerComponent,
    RuitmentFinalProposalComponent,
    DivisionComponent,
    AddEditDivisionComponent,
    EmployeeApplicationDialogComponent,
    SalesOrderComponent,
    AddEditSalesOrderComponent,
    EmployeeDailyAttendanceComponent,
    EmployeeAttendanceSummaryComponent,
    DeliveryChallanComponent,
    AddEditDeliveryChallanComponent,
    EmployeeAttendanceSummaryComponent,
    SalesReturnComponent,
    AddEditSalesReturnComponent,
    EmployeeApplicationDialogComponent,
    EmployeeAttendanceDialogueComponent,
    ItemComponent,
    AddEditItemComponent,
    ItemCategoryComponent,
    AddEditItemCategoryComponent,
    ItemBrandComponent,
    AddEditItemBrandComponent,
    ItemSubCategoryComponent,
    AddEditItemSubCategoryComponent,
    ItemSubBrandComponent,
    AddEditItemSubBrandComponent,
    UomComponent,
    AddEditUomComponent,
    ItemAflComponent,
    AddEditItemAflComponent,
    EmpManualAttndApprovalComponent,
    EmployeeLeaveComponent,
    LeaveApplicationComponent,
    LeavePolicyComponent,
    LeaveAllocationComponent,
    AddLeaveApplicationComponent,
    DetailLeaveApplicationComponent,
    AddLeavePolicyComponent,
    DetailLeavePolicyComponent,
    AddLeaveAllocationComponent,
    DetailLeaveAllocationComponent,
    LeaveAllocProcessListComponent,
    AssetBookComponent,
    AddEditAssetBookComponent,
    AddEditAssetBookComponent,
    AssetEmployeeComponent,
    AddEditAssetEmployeeComponent,
    CustodianComponent,
    AddCustodianComponent,
    ViewCustodianComponent,
    SubCustodianComponent,
    AddSubCustodianComponent,
    ViewSubCustodianComponent,
    YarnRateComponent,
    AddEditYarnRateComponent,
    YarnRateDetailComponent,
    AddUserCompanyUnitComponent,
    AdminCompanyUnitComponent,
    AddAdminCompanyUnitComponent,
    AssetAllocationComponent,
    AddEditAssetAllocationComponent,
    DetailsUserCompanyUnitComponent,
    AddUserCompanyUnitComponent,
    UserCompanyUnitMappingComponent,
    AssetAllocationReturnComponent,
    AddEditAssetAllocationReturnComponent,
    UserChangePasswordComponent,
    AdminChangePasswordComponent,
    NotFoundComponent,

    AdminMenuComponent,
    AddAdminMenuComponent,
    MenuPermissionComponent,
    AddMenuPermissionComponent,
    AdminRoleComponent,
    AddAdminRoleComponent,

    AssetMaintenanceReceiveComponent,
    AddEditAssetMaintenanceReceiveComponent,
    AssetMaintenanceReturnComponent,
    AddEditAssetMaintenanceReturnComponent,
    AssetUserSupportComponent,
    AddEditAssetUserSupportComponent,
    AssetItemComponent,
    AddEditAssetItemComponent,
    AssetItemSoftwareComponent,
    AddEditSoftwareComponent,
    AssetItemEmailComponent,
    AddEditEmailComponent,
    AssetItemMobileComponent,
    AddEditMobileComponent,
    AssetItemServerComponent,
    AddEditServerComponent,
    AssetItemAssignEmailComponent,
    AddEditAssetItemAssignEmailComponent,
    AssetItemAssignMobileComponent,
    AddEditAssetItemAssignMobileComponent,
    AssetItemAssignSoftwareComponent,
    AddEditAssetItemAssignSoftwareComponent,
    ShowAssetEmployeeComponent,
    ShowAssetBookComponent,
    AssetReportComponent,
    AssetBookServerComponent,
    AddEditAssetBookServerComponent,
    ShowAssetBookServerComponent,
    AssetOwnerComponent,
    AddEditAssetOwnerComponent,
    AssetBookVehicleComponent,
    AddEditAssetBookVehicleComponent,
    ShowAssetBookVehicleComponent,
    AssetAllocationVehicleComponent,
    AssetAllocationVehicleReturnComponent,
    AddEditAssetAllocationVehicleComponent,
    AddEditAssetAllocationVehicleReturnComponent,
    ShowAssetVehicleDocumentsComponent,
    AssetItemListComponent,
    AddEditAssetItemListComponent,
    AssetBookAdminComponent,
    AddEditAssetBookAdminComponent,
    AssetBookPlantComponent,
    AssetBookLandComponent,
    AddEditAssetBookPlantComponent,
    AddEditAssetBookLandComponent,
    AssetAllocationAdminComponent,
    AddEditAssetAllocationAdminComponent,
    AssetAllocationAdminReturnComponent,
    AddEditAssetAllocationAdminReturnComponent,
    AssetAllocationLandComponent,
    AddEditAssetAllocationLandComponent,
    AssetAllocationPlantComponent,
    AddEditAssetAllocationPlantComponent,
    AssetAllocationLandReturnComponent,
    AddEditAssetAllocationLandReturnComponent,
    AssetAllocationPlantReturnComponent,
    AddEditAssetAllocationPlantReturnComponent,
    EmployeePfComponent,
    AddEditEmployeePfComponent,
    AssetSparePartComponent,
    AddEditAssetSparePartComponent,
    AssetGrnMasterComponent,
    AddEditAssetGrnMasterComponent,
    AssetSparePartBookComponent,
    AddEditAssetSparePartBookComponent,
    AssetSparePartCsComponent,
    HrLeaveTypeComponent,
    AddEditHrLeaveTypeComponent,
    LeaveReasonComponent,
    AddEditLeaveReasonComponent,
    MyLeaveApplicationComponent,
    LeaveBulkApproveComponent,
    AddEditLeaveBulkApproveComponent,
    LeaveAuthorizationComponent,
    AddEditLeaveAuthorizationComponent,
    EmployeesDocComponent,
    MonthlyAttendanceProcessComponent,
    AddMonthlyAttendanceProcessComponent,
    AddEditEmpManualDailyAatendanceComponent,
    GmtsDomcumentsComponent,
    AddEditGmtsDocumentsComponent,
    GmtsDocSearchComponent,
    RecycleDocComponent,
    GmtsDocReminderComponent,
    GmtsDocLookupComponent,
    AddEditGmtsDocLookupComponent,
    DdmsCommercialComponent,
    AddEditDdmsCommercialComponent,
    DepartmentCompanyComponent,
    AddDepartmentCompanyComponent,
    HrHolidayComponent,
    AddEditHrHolidayComponent,
    AdminUserPasswordResetDialogComponent,
    MonthlyAttendaceSummaryReportComponent,
    LeaveReportComponent,
    EmployeeCountSummaryComponent,
    EmployeeCountSummaryDialogComponent,
    ItemDiscountPolicyComponent,
    AddEditItemDiscountPolicyComponent,
    WarehouseComponent,
    AddEditWarehouseComponent,
    VehicleLocationComponent,
    AddEditVehicleLocationComponent,
    TransportTpComponent,
    AddEditTransportTpComponent,
    CfFarmerComponent,
    AddEditCfFarmerComponent,
    CfFlockInfoComponent,
    AddEditCfFlockInfoComponent,
    CfGrnComponent,
    AddEditCfGrnComponent,
    CfIssueComponent,
    AddEditCfIssueComponent,
    CfItemStockComponent,
    AccCoaComponent,
    AddEditAccCoaComponent,
    FiberCompositionComponent,
    YarnItemRegistrationComponent,
    AddEditYarnItemRegistrationComponent,
    AddEditFiberCompositionComponent,
    YarnCountLookupComponent,
    YarnCountLookupDetailsComponent,
    AddEditYarnCountLookupComponent,
    CfIssueReturnComponent,
    AddEditCfIssueReturnComponent,
    VoucherComponent,
    AddEditVoucherComponent,
    UploadVoucherComponent,
    CfRegionComponent,
    AddEditCfRegionComponent,
    CfBranchComponent,
    AddEditCfBranchComponent,
    CfClusterComponent,
    AddEditCfClusterComponent,
    CfWarehouseComponent,
    AddEditCfWarehouseComponent,
    CfSupplierComponent,
    AddEditCfSupplierComponent,
    DetailCfIssueComponent,
    DetailCfIssueReturnComponent,
    DetailCfGrnComponent,
    FinanceReportComponent,
    EmployeeAttendanceApplicationComponent,
    CfFgSaleComponent,
    AddEditCfFgSaleComponent,
    DetailCfFgSaleComponent,
    CfApprovalProcessComponent,
    AddEditCfApprovalProcessComponent,
    CfIssueApprovalComponent,
    CfCustomerComponent,
    AddEditCfCustomerComponent,
    CfRatePolicyComponent,
    AddEditCfRatePolicyComponent,
    CfDailyFlockActivityComponent,
    AddEditCfDailyFlockActivityComponent,
    CfReportComponent,
    CfDeadReasonComponent,
    AddEditCfDeadReasonComponent,
    CfDeadActionComponent,
    AddEditCfDeadActionComponent,
    CfDashboardComponent,
    AjflPurchaseComponent,
    AddEditAjflPurchaseComponent,
    AjflReportComponent,
    AjflSupplierComponent,
    AddEditAjflSupplierComponent,
    AjflItemGradeComponent,
    AddEditAjflItemGradeComponent,
    ComplianceDocumentComponent,
    AddEditComplianceDocumentComponent,
    ComplianceItemTypeComponent,
    AddEditComplianceItemTypeComponent,
    SalaryHeadComponent,
    SalaryRuleComponent,
    EmpSalaryInfoComponent,
    EmpMonthwiseSalaryProcessComponent,
    EmpMonthwiseAttnProcSalaryComponent,
    EmpAttendancePayRuleComponent,
    AddEditSalaryheadComponent,
    AddEditSalaryruleComponent,
    AddEditAttnpayruleComponent,
    AddAttnprocSalaryComponent,
    AddMonthlySalaryProcessComponent,
    AddEmpSalaryInfoComponent,
    EmpSalaryManipulationInfoComponent,
    AddSalaryManipulationInfoComponent,
    AjflBasisSetupComponent,
    AddEditAjflBasisSetupComponent,
    CstCustomerComponent,
    AddEditCstCustomerComponent,
    CstBookingComponent,
    AddEditCstBookingComponent,
    CstSroComponent,
    CstSeasonComponent,
    AddEditCstSeasonComponent,
    AddEditCstSroComponent,
    MonthwiseSalaryProcessRollbackComponent,
    CstSroPendingListComponent,
    CstDoComponent,
    AddEditCstDoComponent,
    AjflProductionIssueComponent,
    AddEditProductionIssueComponent,
    AjflProductionRequisitionComponent,
    AddEditProductionRequisitionComponent,
    CfUserMappingComponent,
    AddEditCfUserMappingComponent,
    CstBookingRateComponent,
    AddEditCstBookingRateComponent,
    CstNormalBookingComponent,
    AddEditCstNormalBookingComponent,
    ModifyAttnPrcSalaryComponent,
    AccPettyCashComponent,
    AddEditAccPettyCashComponent,
    CfPlDashboardComponent,
    AccAccountsTypeComponent,
    AddEditAccAccountsTypeComponent,
    CstSrLoanComponent,
    AddEditCstSrLoanComponent,
    CstSrLoanPaymentComponent,
    AddEditCstSrLoanPaymentComponent,
    ComplianceAllDocumentComponent,
    CstSrLoanReturnComponent,
    AddEditCstSrLoanReturnComponent,
    ComplianceAssignedDocumentComponent,
    EmployeeSalaryReportComponent,
    AddEditComplainceAssignedDocumentComponent,
    CfFeedConsumptionReportComponent,
    CfFeedConsumptionDetailComponent,
    ComplianceApprovalProcessComponent,
    AddEditComplianceApprovalProcessComponent,
    ComplianceDocumentApprovalComponent,
    EmpMonthwiseAttnProcSalaryManipulationComponent,
    ModifyAttnProcSalaryManipulationComponent,
    CfFlockCostingComponent,
    CfDaSummaryComponent,
    CfDaSummaryDialogComponent,
    InvRawMaterialComponent,
    AddEditInvRawMaterialComponent,
    AddEditCstDeliveryComponent,
    CstPaidBookngInfoComponent,
    AddEditCstPaidBookngComponent,
    CfPaymentInfoComponent,
    AddEditCfPaymentInfoComponent,
    ComplianceDocSummaryDialogComponent,
    CstSrInfoListComponent,
    CfItemMarketRateComponent,
    AddEditCfItemMarketRateComponent,
    CfFarmManagementCostComponent,
    AddEditCfFarmManagementCostComponent,
    CstReportComponent,
    CfGrnStockTransferComponent,
    AddEditCfGrnStockTransferComponent,
    CfGrnStockRecieveComponent,
    AddEditCfGrnStockRecvComponent

  ],
  imports: [
    BrowserModule,
    ReportViewerModule,
    FormsModule,
    BrowserAnimationsModule,
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
    DefaultModule,
    FullwidthModule,
    MatAutocompleteModule,
    MatToolbarModule,
    MatIconModule,
    MatButtonModule,
    MatDialogModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatTableModule,
    MatPaginatorModule,
    MatProgressSpinnerModule,
    MatSortModule,
    MatSnackBarModule,
    MatCheckboxModule,
    MatCardModule,
    MatRadioModule,
    MatTabsModule,
    MatListModule,
    MatTreeModule,
    MatProgressBarModule,


    AutoCompleteModule,
    TableModule,
    ButtonModule,
    CascadeSelectModule,
    PanelModule,
    TabViewModule,
    InputTextModule,
    AutoCompleteModule,
    CalendarModule,
    ChipsModule,
    InputMaskModule,
    InputNumberModule,
    DropdownModule,
    MultiSelectModule,
    InputTextareaModule,
    PasswordModule,
    TreeSelectModule,
    CardModule,
    ConfirmDialogModule,
    MessagesModule,
    PanelMenuModule,
    MenuModule,
    ToastModule,
    RippleModule,

    MatGridListModule,
    MatMenuModule,
    LayoutModule,

    JwtModule.forRoot({
      config: {
        tokenGetter: tokenGetter,
        allowedDomains: ["localhost:5001"],
        disallowedRoutes: []
      }
    }),


  ],
  providers: [
    DatePipe, BnNgIdleService,
    AuthGuard, SecureInnerPagesGuard, ApiServiceService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: TokenInterceptorService,
      multi: true
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }

//providers: [AuthGuard,{provide:HTTP_INTERCEPTORS,useClass:TokenInterceptorService,multi:true}],
