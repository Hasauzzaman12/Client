import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BnNgIdleService } from 'bn-ng-idle';
import { AuthService } from './shared/auth.service';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})

export class AppComponent implements OnInit {
  title = 'GMTS Cloud ERP';
  loader = true;



  constructor(private auth: AuthService, private router: Router, private bnIdle: BnNgIdleService) {

  }


  ngOnInit() {
    this.bnIdle.startWatching(60).subscribe((isTimedOut: boolean) => {
      if (isTimedOut) {
        // this.auth.SessionLogout();
      }
    });
  }


}


