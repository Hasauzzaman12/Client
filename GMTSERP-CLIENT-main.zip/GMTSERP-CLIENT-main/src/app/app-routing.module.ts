import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DefaultComponent } from './layouts/default/default.component';
import { FullwidthComponent } from './layouts/fullwidth/fullwidth.component';
import { LoginComponent } from './modules/login/login.component';


import { ItemComponent } from './modules/item/item.component';
import { AddEditItemComponent } from './modules/item/add-edit-item/add-edit-item.component';
import { SalesReturnComponent } from './modules/sales-return/sales-return.component';
import { AddEditSalesReturnComponent } from './modules/sales-return/add-edit-sales-return/add-edit-sales-return.component';
import { DeliveryChallanComponent } from './modules/delivery-challan/delivery-challan.component';
import { AddEditDeliveryChallanComponent } from './modules/delivery-challan/add-edit-delivery-challan/add-edit-delivery-challan.component';
import { SalesOrderComponent } from './modules/sales-order/sales-order.component';
import { AddEditSalesOrderComponent } from './modules/sales-order/add-edit-sales-order/add-edit-sales-order.component';
import { SupplierComponent } from './modules/supplier/supplier.component';
import { AddEditSupplierComponent } from './modules/supplier/add-edit-supplier/add-edit-supplier.component';
import { EmployeeDetailComponent } from './modules/employee/employee-detail/employee-detail.component';
import { AddEditEmployeeComponent } from './modules/employee/add-edit-employee/add-edit-employee.component';
import { ProcessLossDetailComponent } from './modules/process-loss/process-loss-detail/process-loss-detail.component';
import { ProcessLossComponent } from './modules/process-loss/process-loss.component';
import { AddEditProcessLossComponent } from './modules/process-loss/add-edit-process-loss/add-edit-process-loss.component';
import { IeAssumptionComponent } from './modules/ie-assumption/ie-assumption.component';
import { AddEditIeAssumptionComponent } from './modules/ie-assumption/add-edit-ie-assumption/add-edit-ie-assumption.component';
import { AddEditDesignationComponent } from './modules/designation/add-edit-designation/add-edit-designation.component';
import { DepartmentComponent } from './modules/department/department.component';
import { AddEditDepartmentComponent } from './modules/department/add-edit-department/add-edit-department.component';
import { AddEditCertificationsComponent } from './modules/certifications/add-edit-certifications/add-edit-certifications.component';
import { CertificationsComponent } from './modules/certifications/certifications.component';

import { AdminCompanyComponent } from './modules/admin-company/admin-company.component';
import { AdminUsersComponent } from './modules/admin-users/admin-users.component';
import { SigninComponent } from './modules/signin/signin.component';
import { StyleMasterComponent } from './modules/style-master/style-master.component';
import { AddEditStylemasterComponent } from './modules/style-master/add-edit-stylemaster/add-edit-stylemaster.component';
import { CompanydialogComponent } from './modules/admin-company/companydialog/companydialog.component';
import { StylemasetrDetailComponent } from './modules/style-master/stylemaster-detail/stylemaster-detail.component';
import { AdminUserRegistrationComponent } from './modules/admin-user-registration/admin-user-registration.component';
import { AddEditAdminUserRegistrationComponent } from './modules/admin-user-registration/add-edit-admin-user-registration/add-edit-admin-user-registration.component';
import { BuyerMasterComponent } from './modules/buyer-master/buyer-master.component';
import { AddEditBuyerMasterComponent } from './modules/buyer-master/add-edit-buyer-master/add-edit-buyer-master.component';
import { DetailsBbuyerMasterDetailComponent } from './modules/buyer-master/details-buyer-master-detail/details-bbuyer-master-detail.component';
import { AddEditAdminCompanyComponent } from './modules/admin-company/add-edit-admin-company/add-edit-admin-company.component';
import { AddEditAopRateComponent } from './modules/aop-rate/add-edit-aop-rate/add-edit-aop-rate.component';
import { AopRateComponent } from './modules/aop-rate/aop-rate.component';
import { DesignationComponent } from './modules/designation/designation.component';
import { AddEditCostsheetMasterComponent } from './modules/costsheet-master/add-edit-costsheet-master/add-edit-costsheet-master.component';
import { CostsheetMasterComponent } from './modules/costsheet-master/costsheet-master.component';
import { LookupTypeDetailsComponent } from './modules/lookup-type/lookup-type-details/lookup-type-details.component';
import { AddEditLookupTypeComponent } from './modules/lookup-type/add-edit-lookup-type/add-edit-lookup-type.component';
import { LookupTypeComponent } from './modules/lookup-type/lookup-type.component';
import { AddEditLookupTypeCompanyComponent } from './modules/lookup-type-company/add-edit-lookup-type-company/add-edit-lookup-type-company.component';
import { LookupTypeCompanyComponent } from './modules/lookup-type-company/lookup-type-company.component';
import { LookupTypeCompanyDetailsComponent } from './modules/lookup-type-company/lookup-type-company-details/lookup-type-company-details.component';
import { AddEditLookupTypeGlobalComponent } from './modules/lookup-type-global/add-edit-lookup-type-global/add-edit-lookup-type-global.component';
import { LookupTypeGlobalComponent } from './modules/lookup-type-global/lookup-type-global.component';
import { LookupTypeGlobalDetailsComponent } from './modules/lookup-type-global/lookup-type-global-details/lookup-type-global-details.component';
import { CostsheetMasterDetailComponent } from './modules/costsheet-master/costsheet-master-detail/costsheet-master-detail.component';
import { AddEditYarnRateComponent } from './modules/yarn-rate/add-edit-yarn-rate/add-edit-yarn-rate.component';
import { YarnRateDetailComponent } from './modules/yarn-rate/yarn-rate-detail/yarn-rate-detail.component';
import { YarnRateComponent } from './modules/yarn-rate/yarn-rate.component';
import { AddEditKnittingRateComponent } from './modules/knitting-rate/add-edit-knitting-rate/add-edit-knitting-rate.component';
import { KnittingRateComponent } from './modules/knitting-rate/knitting-rate.component';
import { KnittingRateDetailComponent } from './modules/knitting-rate/knitting-rate-detail/knitting-rate-detail.component';
import { AddEditFabricDyeingRateComponent } from './modules/fabric-dyeing-rate/add-edit-fabric-dyeing-rate/add-edit-fabric-dyeing-rate.component';
import { FabricDyeingRateComponent } from './modules/fabric-dyeing-rate/fabric-dyeing-rate.component';
import { FabricDyeingRateDetailComponent } from './modules/fabric-dyeing-rate/fabric-dyeing-rate-detail/fabric-dyeing-rate-detail.component';
import { AddEditYarnDyeingRateComponent } from './modules/yarn-dyeing-rate/add-edit-yarn-dyeing-rate/add-edit-yarn-dyeing-rate.component';
import { YarnDyeingRateComponent } from './modules/yarn-dyeing-rate/yarn-dyeing-rate.component';
import { YarnDyeingRateDetailComponent } from './modules/yarn-dyeing-rate/yarn-dyeing-rate-detail/yarn-dyeing-rate-detail.component';
import { AddEditFabricYarnCountComponent } from './modules/fabric-yarn-count/add-edit-fabric-yarn-count/add-edit-fabric-yarn-count.component';
import { FabricYarnCountComponent } from './modules/fabric-yarn-count/fabric-yarn-count.component';
import { DetailsFabricYarnCountComponent } from './modules/fabric-yarn-count/details-fabric-yarn-count/details-fabric-yarn-count.component';
import { AddEditTrimsComponent } from './modules/trims/add-edit-trims/add-edit-trims.component';
import { TrimsComponent } from './modules/trims/trims.component';
import { TrimsDetailComponent } from './modules/trims/trims-detail/trims-detail.component';
import { AddEditOcMasterComponent } from './modules/oc-master/add-edit-oc-master/add-edit-oc-master.component';
import { OcMasterComponent } from './modules/oc-master/oc-master.component';
import { OcMasterDetailComponent } from './modules/oc-master/oc-master-detail/oc-master-detail.component';
import { EmployeeComponent } from './modules/employee/employee.component';
import { AddEditGeoCountryComponent } from './modules/geo-country/add-edit-geo-country/add-edit-geo-country.component';
import { GeoCountryComponent } from './modules/geo-country/geo-country.component';
import { AddEditGeoRegionComponent } from './modules/geo-region/add-edit-geo-region/add-edit-geo-region.component';
import { GeoCountryDetailsComponent } from './modules/geo-country/geo-country-details/geo-country-details.component';
import { GeoRegionComponent } from './modules/geo-region/geo-region.component';
import { GeoRegionDetailsComponent } from './modules/geo-region/geo-region-details/geo-region-details.component';
import { AddEditGeoZoneComponent } from './modules/geo-zone/add-edit-geo-zone/add-edit-geo-zone.component';
import { GeoZoneComponent } from './modules/geo-zone/geo-zone.component';
import { GeoZoneDetailsComponent } from './modules/geo-zone/geo-zone-details/geo-zone-details.component';
import { AddEditGeoTerritoryComponent } from './modules/geo-territory/add-edit-geo-territory/add-edit-geo-territory.component';
import { GeoTerritoryComponent } from './modules/geo-territory/geo-territory.component';
import { GeoTerritoryDetailsComponent } from './modules/geo-territory/geo-territory-details/geo-territory-details.component';
import { FabricBookingComponent } from './modules/fabric-booking/fabric-booking.component';
import { AddEditFabricBookingComponent } from './modules/fabric-booking/add-edit-fabric-booking/add-edit-fabric-booking.component';
import { DetailFabricBookingComponent } from './modules/fabric-booking/detail-fabric-booking/detail-fabric-booking.component';
//anis
import { LookupComponent } from './modules/lookup/lookup.component';
import { AddEditLookupComponent } from './modules/lookup/add-edit-lookup/add-edit-lookup.component';
import { LookupDetailsComponent } from './modules/lookup/lookup-details/lookup-details.component';

import { LookupGrpComponent } from './modules/lookupGrp/lookupGrp.component';
import { AddEditLookupGrpComponent } from './modules/lookupGrp/add-edit-lookupGrp/add-edit-lookupGrp.component';
import { LookupGrpDetailsComponent } from './modules/lookupGrp/lookupGrp-details/lookupGrp-details.component';

import { LookupCatComponent } from './modules/lookup-cat/lookup-cat.component';
import { AddEditLookupCatComponent } from './modules/lookup-cat/add-edit-lookup-cat/add-edit-lookup-cat.component';
import { LookupCatDetailsComponent } from './modules/lookup-cat/lookup-cat-details/lookup-cat-details.component';

import { LookupClassComponent } from './modules/lookup-class/lookup-class.component';
import { LookupClassDetailsComponent } from './modules/lookup-class/lookup-class-details/lookup-class-details.component';
import { AddEditLookupClassComponent } from './modules/lookup-class/add-edit-lookup-class/add-edit-lookup-class.component';

import { LookupWarComponent } from './modules/lookup-war/lookup-war.component';
import { LookupWarDetailsComponent } from './modules/lookup-war/lookup-war-details/lookup-war-details.component';
import { AddEditLookupWarComponent } from './modules/lookup-war/add-edit-lookup-war/add-edit-lookup-war.component';
import { CustomerComponent } from './modules/customer/customer.component';
import { AddEditCustomerComponent } from './modules/customer/add-edit-customer/add-edit-customer.component';
import { RuitmentFinalProposalComponent } from './modules/employee/recruitment-final-proposal/recruitment-final-proposal.component';
import { DivisionComponent } from './modules/division/division.component';
import { AddEditDivisionComponent } from './modules/division/add-edit-division/add-edit-division.component';
import { EmployeeDailyAttendanceComponent } from './modules/employee-daily-attendance/employee-daily-attendance.component';
import { EmployeeAttendanceSummaryComponent } from './modules/employee-daily-attendance/employee-attendance-summary/employee-attendance-summary.component';
import { AddEditItemCategoryComponent } from './modules/item-category/add-edit-item-category/add-edit-item-category.component';
import { ItemCategoryComponent } from './modules/item-category/item-category.component';
import { AddEditItemSubCategoryComponent } from './modules/item-sub-category/add-edit-item-sub-category/add-edit-item-sub-category.component';
import { ItemSubCategoryComponent } from './modules/item-sub-category/item-sub-category.component';
import { AddEditItemBrandComponent } from './modules/item-brand/add-edit-item-brand/add-edit-item-brand.component';
import { ItemBrandComponent } from './modules/item-brand/item-brand.component';
import { AddEditItemSubBrandComponent } from './modules/item-sub-brand/add-edit-item-sub-brand/add-edit-item-sub-brand.component';
import { ItemSubBrandComponent } from './modules/item-sub-brand/item-sub-brand.component';
import { AddEditUomComponent } from './modules/uom/add-edit-uom/add-edit-uom.component';
import { UomComponent } from './modules/uom/uom.component';
import { AddEditItemAflComponent } from './modules/item-afl/add-edit-item-afl/add-edit-item-afl.component';
import { ItemAflComponent } from './modules/item-afl/item-afl.component';
import { EmpManualAttndApprovalComponent } from './modules/employee-daily-attendance/emp-manual-attnd-approval/emp-manual-attnd-approval.component';
import { LeaveApplicationComponent } from './modules/employee-leave/leave-application/leave-application.component';
import { AddLeaveApplicationComponent } from './modules/employee-leave/leave-application/add-leave-application/add-leave-application.component';
import { AddLeavePolicyComponent } from './modules/employee-leave/leave-policy/add-leave-policy/add-leave-policy.component';
import { AddLeaveAllocationComponent } from './modules/employee-leave/leave-allocation/add-leave-allocation/add-leave-allocation.component';
import { AddEditAssetBookComponent } from './modules/asset-book/add-edit-asset-book/add-edit-asset-book.component';
import { AssetBookComponent } from './modules/asset-book/asset-book.component';
import { AddEditAssetEmployeeComponent } from './modules/asset-employee/add-edit-asset-employee/add-edit-asset-employee.component';
import { AssetEmployeeComponent } from './modules/asset-employee/asset-employee.component';
import { CustodianComponent } from './modules/custodian/custodian.component';
import { AddSubCustodianComponent } from './modules/sub-custodian/add-sub-custodian/add-sub-custodian.component';
import { SubCustodianComponent } from './modules/sub-custodian/sub-custodian.component';
import { AddCustodianComponent } from './modules/custodian/add-custodian/add-custodian.component';
import { AddUserCompanyUnitComponent } from './modules/user-company-unit-mapping/add-user-company-unit/add-user-company-unit.component';
import { AddAdminCompanyUnitComponent } from './modules/admin-company-unit/add-admin-company-unit/add-admin-company-unit.component';
import { AssetAllocationComponent } from './modules/asset-allocation/asset-allocation.component';
import { AddEditAssetAllocationComponent } from './modules/asset-allocation/add-edit-asset-allocation/add-edit-asset-allocation.component';
import { AdminCompanyUnitComponent } from './modules/admin-company-unit/admin-company-unit.component';
import { UserCompanyUnitMappingComponent } from './modules/user-company-unit-mapping/user-company-unit-mapping.component';
import { AddEditAssetAllocationReturnComponent } from './modules/asset-allocation-return/add-edit-asset-allocation-return/add-edit-asset-allocation-return.component';
import { AssetAllocationReturnComponent } from './modules/asset-allocation-return/asset-allocation-return.component';
import { UserChangePasswordComponent } from './shared/components/user-change-password/user-change-password.component';
import { AdminChangePasswordComponent } from './shared/components/admin-change-password/admin-change-password.component';
import { UserProfileComponent } from './shared/components/user-profile/user-profile.component';
import { NotFoundComponent } from './shared/components/not-found/not-found.component';
import { AuthGuard } from './shared/auth.guard';
import { SecureInnerPagesGuard } from './secure-inner-pages.guard';
import { AdminMenuComponent } from './modules/admin-menu/admin-menu.component';
import { AddAdminMenuComponent } from './modules/admin-menu/add-admin-menu/add-admin-menu.component';
import { MenuPermissionComponent } from './modules/menu-permission/menu-permission.component';
import { AddMenuPermissionComponent } from './modules/menu-permission/add-menu-permission/add-menu-permission.component';
import { RoleGuard } from './shared/role.guard';
import { AddAdminRoleComponent } from './modules/admin-role/add-admin-role/add-admin-role.component';
import { AdminRoleComponent } from './modules/admin-role/admin-role.component';
import { AddEditAssetMaintenanceReceiveComponent } from './modules/asset-maintenance-receive/add-edit-asset-maintenance-receive/add-edit-asset-maintenance-receive.component';
import { AssetMaintenanceReceiveComponent } from './modules/asset-maintenance-receive/asset-maintenance-receive.component';
import { AddEditAssetMaintenanceReturnComponent } from './modules/asset-maintenance-return/add-edit-asset-maintenance-return/add-edit-asset-maintenance-return.component';
import { AssetMaintenanceReturnComponent } from './modules/asset-maintenance-return/asset-maintenance-return.component';

import { AddEditAssetUserSupportComponent } from './modules/asset-user-support/add-edit-asset-user-support/add-edit-asset-user-support.component';
import { AssetUserSupportComponent } from './modules/asset-user-support/asset-user-support.component';
import { AddEditAssetItemComponent } from './modules/asset-item/add-edit-asset-item/add-edit-asset-item.component';
import { AssetItemComponent } from './modules/asset-item/asset-item.component';

import { AddEditSoftwareComponent } from './modules/asset-item-software/add-edit-software/add-edit-software.component';
import { AssetItemSoftwareComponent } from './modules/asset-item-software/asset-item-software.component';
import { AddEditEmailComponent } from './modules/asset-item-email/add-edit-email/add-edit-email.component';
import { AssetItemEmailComponent } from './modules/asset-item-email/asset-item-email.component';
import { AddEditMobileComponent } from './modules/asset-item-mobile/add-edit-mobile/add-edit-mobile.component';
import { AssetItemMobileComponent } from './modules/asset-item-mobile/asset-item-mobile.component';
import { AddEditAssetItemAssignSoftwareComponent } from './modules/asset-item-assign-software/add-edit-asset-item-assign-software/add-edit-asset-item-assign-software.component';
import { AssetItemAssignSoftwareComponent } from './modules/asset-item-assign-software/asset-item-assign-software.component';
import { AddEditAssetItemAssignEmailComponent } from './modules/asset-item-assign-email/add-edit-asset-item-assign-email/add-edit-asset-item-assign-email.component';
import { AssetItemAssignEmailComponent } from './modules/asset-item-assign-email/asset-item-assign-email.component';
import { AddEditAssetItemAssignMobileComponent } from './modules/asset-item-assign-mobile/add-edit-asset-item-assign-mobile/add-edit-asset-item-assign-mobile.component';
import { AssetItemAssignMobileComponent } from './modules/asset-item-assign-mobile/asset-item-assign-mobile.component';
import { ShowAssetBookComponent } from './modules/asset-book/show-asset-book/show-asset-book.component';
import { AddEditAssetBookServerComponent } from './modules/asset-book-server/add-edit-asset-book-server/add-edit-asset-book-server.component';
import { AssetBookServerComponent } from './modules/asset-book-server/asset-book-server.component';
import { ShowAssetBookServerComponent } from './modules/asset-book-server/show-asset-book-server/show-asset-book-server.component';
import { ShowAssetEmployeeComponent } from './modules/asset-employee/show-asset-employee/show-asset-employee.component';
import { AssetReportComponent } from './modules/asset-report/asset-report.component';
import { AddEditAssetOwnerComponent } from './modules/asset-owner/add-edit-asset-owner/add-edit-asset-owner.component';
import { AssetOwnerComponent } from './modules/asset-owner/asset-owner.component';
import { AddEditAssetBookVehicleComponent } from './modules/asset-book-vehicle/add-edit-asset-book-vehicle/add-edit-asset-book-vehicle.component';
import { AssetBookVehicleComponent } from './modules/asset-book-vehicle/asset-book-vehicle.component';
import { ShowAssetBookVehicleComponent } from './modules/asset-book-vehicle/show-asset-book-vehicle/show-asset-book-vehicle.component';
import { AddEditAssetAllocationVehicleComponent } from './modules/asset-allocation-vehicle/add-edit-asset-allocation-vehicle/add-edit-asset-allocation-vehicle.component';
import { AssetAllocationVehicleComponent } from './modules/asset-allocation-vehicle/asset-allocation-vehicle.component';
import { AddEditAssetAllocationVehicleReturnComponent } from './modules/asset-allocation-vehicle-return/add-edit-asset-allocation-vehicle-return/add-edit-asset-allocation-vehicle-return.component';
import { AssetAllocationVehicleReturnComponent } from './modules/asset-allocation-vehicle-return/asset-allocation-vehicle-return.component';
import { ShowAssetVehicleDocumentsComponent } from './modules/asset-book-vehicle/show-asset-vehicle-documents/show-asset-vehicle-documents.component';
import { AssetItemListComponent } from './modules/asset-item-list/asset-item-list.component';
import { AddEditAssetItemListComponent } from './modules/asset-item-list/add-edit-asset-item-list/add-edit-asset-item-list.component';
import { AddEditAssetBookAdminComponent } from './modules/asset-book-admin/add-edit-asset-book-admin/add-edit-asset-book-admin.component';
import { AssetBookAdminComponent } from './modules/asset-book-admin/asset-book-admin.component';
import { AddEditAssetBookLandComponent } from './modules/asset-book-land/add-edit-asset-book-land/add-edit-asset-book-land.component';
import { AssetBookLandComponent } from './modules/asset-book-land/asset-book-land.component';
import { AddEditAssetBookPlantComponent } from './modules/asset-book-plant/add-edit-asset-book-plant/add-edit-asset-book-plant.component';
import { AssetBookPlantComponent } from './modules/asset-book-plant/asset-book-plant.component';
import { AddEditAssetAllocationAdminComponent } from './modules/asset-allocation-admin/add-edit-asset-allocation-admin/add-edit-asset-allocation-admin.component';
import { AssetAllocationAdminComponent } from './modules/asset-allocation-admin/asset-allocation-admin.component';
import { AddEditAssetAllocationAdminReturnComponent } from './modules/asset-allocation-admin-return/add-edit-asset-allocation-admin-return/add-edit-asset-allocation-admin-return.component';
import { AssetAllocationAdminReturnComponent } from './modules/asset-allocation-admin-return/asset-allocation-admin-return.component';
import { AddEditAssetAllocationLandComponent } from './modules/asset-allocation-land/add-edit-asset-allocation-land/add-edit-asset-allocation-land.component';
import { AssetAllocationLandComponent } from './modules/asset-allocation-land/asset-allocation-land.component';
import { AddEditAssetAllocationLandReturnComponent } from './modules/asset-allocation-land-return/add-edit-asset-allocation-land-return/add-edit-asset-allocation-land-return.component';
import { AssetAllocationLandReturnComponent } from './modules/asset-allocation-land-return/asset-allocation-land-return.component';
import { AddEditAssetAllocationPlantComponent } from './modules/asset-allocation-plant/add-edit-asset-allocation-plant/add-edit-asset-allocation-plant.component';
import { AssetAllocationPlantComponent } from './modules/asset-allocation-plant/asset-allocation-plant.component';
import { AddEditAssetAllocationPlantReturnComponent } from './modules/asset-allocation-plant-return/add-edit-asset-allocation-plant-return/add-edit-asset-allocation-plant-return.component';
import { AssetAllocationPlantReturnComponent } from './modules/asset-allocation-plant-return/asset-allocation-plant-return.component';
import { AddEditEmployeePfComponent } from './modules/employee-pf/add-edit-employee-pf/add-edit-employee-pf.component';
import { EmployeePfComponent } from './modules/employee-pf/employee-pf.component';
import { AssetSparePartComponent } from './modules/asset-spare-part/asset-spare-part.component';
import { AddEditAssetSparePartComponent } from './modules/asset-spare-part/add-edit-asset-spare-part/add-edit-asset-spare-part.component';
import { AssetGrnMasterComponent } from './modules/asset-grn-master/asset-grn-master.component';
import { AddEditAssetGrnMasterComponent } from './modules/asset-grn-master/add-edit-asset-grn-master/add-edit-asset-grn-master.component';
import { AddEditAssetSparePartBookComponent } from './modules/asset-spare-part-book/add-edit-asset-spare-part-book/add-edit-asset-spare-part-book.component';
import { AssetSparePartBookComponent } from './modules/asset-spare-part-book/asset-spare-part-book.component';
import { AssetSparePartCsComponent } from './modules/asset-spare-part-cs/asset-spare-part-cs.component';
import { HrLeaveTypeComponent } from './modules/hr-leave-type/hr-leave-type.component';
import { AddEditHrLeaveTypeComponent } from './modules/hr-leave-type/add-edit-hr-leave-type/add-edit-hr-leave-type.component';
import { LeavePolicyComponent } from './modules/employee-leave/leave-policy/leave-policy.component';
import { AddEditLeaveReasonComponent } from './modules/employee-leave/leave-reason/add-edit-leave-reason/add-edit-leave-reason.component';
import { LeaveReasonComponent } from './modules/employee-leave/leave-reason/leave-reason.component';
import { LeaveAllocationComponent } from './modules/employee-leave/leave-allocation/leave-allocation.component';
import { MyLeaveApplicationComponent } from './modules/employee-leave/my-leave-application/my-leave-application.component';
import { AddEditLeaveAuthorizationComponent } from './modules/employee-leave/leave-authorization/add-edit-leave-authorization/add-edit-leave-authorization.component';
import { LeaveAuthorizationComponent } from './modules/employee-leave/leave-authorization/leave-authorization.component';
import { AddEditLeaveBulkApproveComponent } from './modules/employee-leave/leave-bulk-approve/add-edit-leave-bulk-approve/add-edit-leave-bulk-approve.component';
import { LeaveBulkApproveComponent } from './modules/employee-leave/leave-bulk-approve/leave-bulk-approve.component';
import { EmployeesDocComponent } from './modules/employee/employees-doc/employees-doc.component';
import { AddMonthlyAttendanceProcessComponent } from './modules/employee-daily-attendance/add-monthly-attendance-process/add-monthly-attendance-process.component';
import { MonthlyAttendanceProcessComponent } from './modules/employee-daily-attendance/monthly-attendance-process/monthly-attendance-process.component';
import { GmtsDomcumentsComponent } from './modules/gmts-domcuments/gmts-domcuments.component';
import { AddEditGmtsDocumentsComponent } from './modules/gmts-domcuments/add-edit-gmts-documents/add-edit-gmts-documents.component';
import { AddEditEmpManualDailyAatendanceComponent } from './modules/employee-daily-attendance/emp-manual-attnd-approval/add-edit-emp-manual-daily-aatendance/add-edit-emp-manual-daily-aatendance.component';
import { GmtsDocSearchComponent } from './modules/gmts-domcuments/gmts-doc-search/gmts-doc-search.component';
import { RecycleDocComponent } from './modules/gmts-domcuments/recycle-doc/recycle-doc.component';
import { GmtsDocReminderComponent } from './modules/gmts-domcuments/gmts-doc-reminder/gmts-doc-reminder.component';
import { GmtsDocLookupComponent } from './modules/gmts-domcuments/gmts-doc-lookup/gmts-doc-lookup.component';
import { AddEditGmtsDocLookupComponent } from './modules/gmts-domcuments/gmts-doc-lookup/add-edit-gmts-doc-lookup/add-edit-gmts-doc-lookup.component';
import { AddEditHR_SectionComponent } from './modules/hr_section/add-edit-hr_section/add-edit-hr_section.component';
import { HR_SectionComponent } from './modules/hr_section/hr_section.component';
import { DdmsCommercialComponent } from './modules/ddms-commercial/ddms-commercial.component';
import { AddEditDdmsCommercialComponent } from './modules/ddms-commercial/add-edit-ddms-commercial/add-edit-ddms-commercial.component';
import { AddDepartmentCompanyComponent } from './modules/department-company/add-department-company/add-department-company.component';
import { DepartmentCompanyComponent } from './modules/department-company/department-company.component';
import { HrHolidayComponent } from './modules/employee-leave/hr-holiday/hr-holiday.component';
import { AddEditHrHolidayComponent } from './modules/employee-leave/hr-holiday/add-edit-hr-holiday/add-edit-hr-holiday.component';
import { MonthlyAttendaceSummaryReportComponent } from './modules/employee-daily-attendance/report/monthly-attendace-summary-report/monthly-attendace-summary-report.component';
import { LeaveReportComponent } from './modules/employee-leave/report/leave-report/leave-report.component';
import { EmployeeCountSummaryComponent } from './modules/employee/employee-count-summary/employee-count-summary.component';
import { HomeComponent } from './modules/home/home.component';
import { ItemDiscountPolicyComponent } from './modules/item-discount-policy/item-discount-policy.component';
import { AddEditItemDiscountPolicyComponent } from './modules/item-discount-policy/add-edit-item-discount-policy/add-edit-item-discount-policy.component';
import { WarehouseComponent } from './modules/warehouse/warehouse.component';
import { AddEditWarehouseComponent } from './modules/warehouse/add-edit-warehouse/add-edit-warehouse.component';
import { VehicleLocationComponent } from './modules/asset-book-vehicle/vehicle-location/vehicle-location.component';
import { AddEditVehicleLocationComponent } from './modules/asset-book-vehicle/vehicle-location/add-edit-vehicle-location/add-edit-vehicle-location.component';
import { TransportTpComponent } from './modules/transport-tp/transport-tp.component';
import { AddEditTransportTpComponent } from './modules/transport-tp/add-edit-transport-tp/add-edit-transport-tp.component';
import { CfFarmerComponent } from './modules/cf/cf-farmer/cf-farmer.component';
import { AddEditCfFarmerComponent } from './modules/cf/cf-farmer/add-edit-cf-farmer/add-edit-cf-farmer.component';
import { CfFlockInfoComponent } from './modules/cf/cf-flock-info/cf-flock-info.component';
import { AddEditCfFlockInfoComponent } from './modules/cf/cf-flock-info/add-edit-cf-flock-info/add-edit-cf-flock-info.component';
import { CfGrnComponent } from './modules/cf/cf-grn/cf-grn.component';
import { AddEditCfGrnComponent } from './modules/cf/cf-grn/add-edit-cf-grn/add-edit-cf-grn.component';
import { CfIssueComponent } from './modules/cf/cf-issue/cf-issue.component';
import { AddEditCfIssueComponent } from './modules/cf/cf-issue/add-edit-cf-issue/add-edit-cf-issue.component';
import { CfItemStockComponent } from './modules/cf/cf-item-stock/cf-item-stock.component';
import { AccCoaComponent } from './modules/finance/acc-coa/acc-coa.component';
import { AddEditAccCoaComponent } from './modules/finance/acc-coa/add-edit-acc-coa/add-edit-acc-coa.component';
import { FiberCompositionComponent } from './modules/merchandising/fiber-composition/fiber-composition.component';
import { YarnItemRegistrationComponent } from './modules/merchandising/yarn-item-registration/yarn-item-registration.component';
import { AddEditYarnItemRegistrationComponent } from './modules/merchandising/yarn-item-registration/add-edit-yarn-item-registration/add-edit-yarn-item-registration.component';
import { AddEditFiberCompositionComponent } from './modules/merchandising/fiber-composition/add-edit-fiber-composition/add-edit-fiber-composition.component';
import { AddEditYarnCountLookupComponent } from './modules/merchandising/yarn-count-lookup/add-edit-yarn-count-lookup/add-edit-yarn-count-lookup.component';
import { YarnCountLookupDetailsComponent } from './modules/merchandising/yarn-count-lookup/yarn-count-lookup-details/yarn-count-lookup-details.component';
import { YarnCountLookupComponent } from './modules/merchandising/yarn-count-lookup/yarn-count-lookup.component';
import { AddEditCfIssueReturnComponent } from './modules/cf/cf-issue-return/add-edit-cf-issue-return/add-edit-cf-issue-return.component';
import { CfIssueReturnComponent } from './modules/cf/cf-issue-return/cf-issue-return.component';
import { AddEditVoucherComponent } from './modules/finance/voucher/add-edit-voucher/add-edit-voucher.component';
import { VoucherComponent } from './modules/finance/voucher/voucher.component';
import { CfRegionComponent } from './modules/cf/cf-region/cf-region.component';
import { AddEditCfRegionComponent } from './modules/cf/cf-region/add-edit-cf-region/add-edit-cf-region.component';
import { CfBranchComponent } from './modules/cf/cf-branch/cf-branch.component';
import { AddEditCfBranchComponent } from './modules/cf/cf-branch/add-edit-cf-branch/add-edit-cf-branch.component';
import { CfClusterComponent } from './modules/cf/cf-cluster/cf-cluster.component';
import { AddEditCfClusterComponent } from './modules/cf/cf-cluster/add-edit-cf-cluster/add-edit-cf-cluster.component';
import { CfWarehouseComponent } from './modules/cf/cf-warehouse/cf-warehouse.component';
import { AddEditCfWarehouseComponent } from './modules/cf/cf-warehouse/add-edit-cf-warehouse/add-edit-cf-warehouse.component';
import { AddEditCfSupplierComponent } from './modules/cf/cf-supplier/add-edit-cf-supplier/add-edit-cf-supplier.component';
import { CfSupplierComponent } from './modules/cf/cf-supplier/cf-supplier.component';
import { DetailCfIssueComponent } from './modules/cf/cf-issue/detail-cf-issue/detail-cf-issue.component';
import { DetailCfIssueReturnComponent } from './modules/cf/cf-issue-return/detail-cf-issue-return/detail-cf-issue-return.component';
import { DetailCfGrnComponent } from './modules/cf/cf-grn/detail-cf-grn/detail-cf-grn.component';
import { FinanceReportComponent } from './modules/finance/report/finance-report/finance-report.component';
import { EmployeeAttendanceApplicationComponent } from './modules/employee-daily-attendance/employee-attendance-application/employee-attendance-application.component';
import { CfFgSaleComponent } from './modules/cf/cf-fg-sale/cf-fg-sale.component';
import { AddEditCfFgSaleComponent } from './modules/cf/cf-fg-sale/add-edit-cf-fg-sale/add-edit-cf-fg-sale.component';
import { DetailCfFgSaleComponent } from './modules/cf/cf-fg-sale/detail-cf-fg-sale/detail-cf-fg-sale.component';
import { CfApprovalProcessComponent } from './modules/cf/cf-approval-process/cf-approval-process.component';
import { AddEditCfApprovalProcessComponent } from './modules/cf/cf-approval-process/add-edit-cf-approval-process/add-edit-cf-approval-process.component';
import { CfIssueApprovalComponent } from './modules/cf/cf-issue/cf-issue-approval/cf-issue-approval.component';
import { AddEditCfCustomerComponent } from './modules/cf/cf-customer/add-edit-cf-customer/add-edit-cf-customer.component';
import { CfCustomerComponent } from './modules/cf/cf-customer/cf-customer.component';
import { CfRatePolicyComponent } from './modules/cf/cf-rate-policy/cf-rate-policy.component';
import { AddEditCfRatePolicyComponent } from './modules/cf/cf-rate-policy/add-edit-cf-rate-policy/add-edit-cf-rate-policy.component';
import { CfDailyFlockActivityComponent } from './modules/cf/cf-daily-flock-activity/cf-daily-flock-activity.component';
import { AddEditCfDailyFlockActivityComponent } from './modules/cf/cf-daily-flock-activity/add-edit-cf-daily-flock-activity/add-edit-cf-daily-flock-activity.component';
import { CfReportComponent } from './modules/cf/cf-report/cf-report.component';
import { AddEditCfDeadActionComponent } from './modules/cf/cf_lookup/cf-dead-action/add-edit-cf-dead-action/add-edit-cf-dead-action.component';
import { CfDeadActionComponent } from './modules/cf/cf_lookup/cf-dead-action/cf-dead-action.component';
import { AddEditCfDeadReasonComponent } from './modules/cf/cf_lookup/cf-dead-reason/add-edit-cf-dead-reason/add-edit-cf-dead-reason.component';
import { CfDeadReasonComponent } from './modules/cf/cf_lookup/cf-dead-reason/cf-dead-reason.component';
import { CfDashboardComponent } from './modules/cf/cf-dashboard/cf-dashboard.component';
import { UploadVoucherComponent } from './modules/finance/voucher/upload-voucher/upload-voucher.component';
import { AddEditAjflPurchaseComponent } from './modules/ajfl/ajfl-purchase/add-edit-ajfl-purchase/add-edit-ajfl-purchase.component';
import { AjflPurchaseComponent } from './modules/ajfl/ajfl-purchase/ajfl-purchase.component';
import { AjflReportComponent } from './modules/ajfl/ajfl-report/ajfl-report.component';
import { AddEditAjflSupplierComponent } from './modules/ajfl/ajfl-lookup/ajfl-supplier/add-edit-ajfl-supplier/add-edit-ajfl-supplier.component';
import { AjflSupplierComponent } from './modules/ajfl/ajfl-lookup/ajfl-supplier/ajfl-supplier.component';
import { AjflItemGradeComponent } from './modules/ajfl/ajfl-item-grade/ajfl-item-grade.component';
import { AddEditAjflItemGradeComponent } from './modules/ajfl/ajfl-item-grade/add-edit-ajfl-item-grade/add-edit-ajfl-item-grade.component';
import { ComplianceDocumentComponent } from './modules/compliance/compliance-document/compliance-document.component';
import { AddEditComplianceDocumentComponent } from './modules/compliance/compliance-document/add-edit-compliance-document/add-edit-compliance-document.component';
import { ComplianceItemTypeComponent } from './modules/compliance/compliance-item-type/compliance-item-type.component';
import { AddEditComplianceItemTypeComponent } from './modules/compliance/compliance-item-type/add-edit-compliance-item-type/add-edit-compliance-item-type.component';
import { AddEditSalaryheadComponent } from './modules/employee/employee-salary/salary-head/add-edit-salaryhead/add-edit-salaryhead.component';
import { SalaryHeadComponent } from './modules/employee/employee-salary/salary-head/salary-head.component';
import { AddEditSalaryruleComponent } from './modules/employee/employee-salary/salary-rule/add-edit-salaryrule/add-edit-salaryrule.component';
import { SalaryRuleComponent } from './modules/employee/employee-salary/salary-rule/salary-rule.component';
import { AddEditAttnpayruleComponent } from './modules/employee/employee-salary/emp-attendance-pay-rule/add-edit-attnpayrule/add-edit-attnpayrule.component';
import { EmpAttendancePayRuleComponent } from './modules/employee/employee-salary/emp-attendance-pay-rule/emp-attendance-pay-rule.component';
import { AddAttnprocSalaryComponent } from './modules/employee/employee-salary/emp-monthwise-attn-proc-salary/add-attnproc-salary/add-attnproc-salary.component';
import { EmpMonthwiseAttnProcSalaryComponent } from './modules/employee/employee-salary/emp-monthwise-attn-proc-salary/emp-monthwise-attn-proc-salary.component';
import { AddMonthlySalaryProcessComponent } from './modules/employee/employee-salary/emp-monthwise-salary-process/add-monthly-salary-process/add-monthly-salary-process.component';
import { EmpMonthwiseSalaryProcessComponent } from './modules/employee/employee-salary/emp-monthwise-salary-process/emp-monthwise-salary-process.component';
import { AddEmpSalaryInfoComponent } from './modules/employee/employee-salary/emp-salary-info/add-emp-salary-info/add-emp-salary-info.component';
import { EmpSalaryInfoComponent } from './modules/employee/employee-salary/emp-salary-info/emp-salary-info.component';
import { AddSalaryManipulationInfoComponent } from './modules/employee/employee-salary/emp-salary-manipulation-info/add-salary-manipulation-info/add-salary-manipulation-info.component';
import { EmpSalaryManipulationInfoComponent } from './modules/employee/employee-salary/emp-salary-manipulation-info/emp-salary-manipulation-info.component';
import { AjflBasisSetupComponent } from './modules/ajfl/ajfl-basis-setup/ajfl-basis-setup.component';
import { AddEditAjflBasisSetupComponent } from './modules/ajfl/ajfl-basis-setup/add-edit-ajfl-basis-setup/add-edit-ajfl-basis-setup.component';
import { CstCustomerComponent } from './modules/cst/cst-customer/cst-customer.component';
import { AddEditCstCustomerComponent } from './modules/cst/cst-customer/add-edit-cst-customer/add-edit-cst-customer.component';
import { AddEditCstBookingComponent } from './modules/cst/cst-booking/add-edit-cst-booking/add-edit-cst-booking.component';
import { CstBookingComponent } from './modules/cst/cst-booking/cst-booking.component';
import { CstSroComponent } from './modules/cst/cst-sro/cst-sro.component';
import { AddEditCstSroComponent } from './modules/cst/cst-sro/add-edit-cst-sro/add-edit-cst-sro.component';
import { CstSroPendingListComponent } from './modules/cst/cst-sro/cst-sro-pending-list/cst-sro-pending-list.component';
import { MonthwiseSalaryProcessRollbackComponent } from './modules/employee/employee-salary/emp-monthwise-salary-process/monthwise-salary-process-rollback/monthwise-salary-process-rollback.component';
import { AjflProductionIssueComponent } from './modules/ajfl/ajfl-production-issue/ajfl-production-issue.component';
import { AddEditProductionIssueComponent } from './modules/ajfl/ajfl-production-issue/add-edit-production-issue/add-edit-production-issue.component';
import { AjflProductionRequisitionComponent } from './modules/ajfl/ajfl-production-requisition/ajfl-production-requisition.component';
import { AddEditProductionRequisitionComponent } from './modules/ajfl/ajfl-production-requisition/add-edit-production-requisition/add-edit-production-requisition.component';
import { CstSeasonComponent } from './modules/cst/cst-season/cst-season.component';
import { AddEditCstSeasonComponent } from './modules/cst/cst-season/add-edit-cst-season/add-edit-cst-season.component';
import { CfUserMappingComponent } from './modules/cf/cf-user-mapping/cf-user-mapping.component';
import { AddEditCfUserMappingComponent } from './modules/cf/cf-user-mapping/add-edit-cf-user-mapping/add-edit-cf-user-mapping.component';
import { CstDoComponent } from './modules/cst/cst-do/cst-do.component';
import { AddEditCstDoComponent } from './modules/cst/cst-do/add-edit-cst-do/add-edit-cst-do.component';
import { AddEditCstNormalBookingComponent } from './modules/cst/cst-normal-booking/add-edit-cst-normal-booking/add-edit-cst-normal-booking.component';
import { CstNormalBookingComponent } from './modules/cst/cst-normal-booking/cst-normal-booking.component';
import { CstBookingRateComponent } from './modules/cst/cst-booking-rate/cst-booking-rate.component';
import { AddEditCstBookingRateComponent } from './modules/cst/cst-booking-rate/add-edit-cst-booking-rate/add-edit-cst-booking-rate.component';
import { ModifyAttnPrcSalaryComponent } from './modules/employee/employee-salary/emp-monthwise-attn-proc-salary/modify-attn-prc-salary/modify-attn-prc-salary.component';
import { AccPettyCashComponent } from './modules/finance/acc-petty-cash/acc-petty-cash.component';
import { AddEditAccPettyCashComponent } from './modules/finance/acc-petty-cash/add-edit-acc-petty-cash/add-edit-acc-petty-cash.component';
import { CfPlDashboardComponent } from './modules/cf/cf-pl-dashboard/cf-pl-dashboard.component';
import { AccAccountsTypeComponent } from './modules/finance/acc-accounts-type/acc-accounts-type.component';
import { AddEditAccAccountsTypeComponent } from './modules/finance/acc-accounts-type/add-edit-acc-accounts-type/add-edit-acc-accounts-type.component';
import { AddEditCstSrLoanComponent } from './modules/cst/cst-sr-loan/add-edit-cst-sr-loan/add-edit-cst-sr-loan.component';
import { CstSrLoanComponent } from './modules/cst/cst-sr-loan/cst-sr-loan.component';
import { CstSrLoanPaymentComponent } from './modules/cst/cst-sr-loan-payment/cst-sr-loan-payment.component';
import { AddEditCstSrLoanPaymentComponent } from './modules/cst/cst-sr-loan-payment/add-edit-cst-sr-loan-payment/add-edit-cst-sr-loan-payment.component';
import { ComplianceAllDocumentComponent } from './modules/compliance/compliance-all-document/compliance-all-document.component';
import { AddEditCstSrLoanReturnComponent } from './modules/cst/cst-sr-loan-return/add-edit-cst-sr-loan-return/add-edit-cst-sr-loan-return.component';
import { CstSrLoanReturnComponent } from './modules/cst/cst-sr-loan-return/cst-sr-loan-return.component';
import { ComplianceAssignedDocumentComponent } from './modules/compliance/compliance-assigned-document/compliance-assigned-document.component';
import { EmployeeSalaryReportComponent } from './modules/employee/employee-salary/report/employee-salary-report/employee-salary-report.component';
import { AddEditComplainceAssignedDocumentComponent } from './modules/compliance/compliance-assigned-document/add-edit-complaince-assigned-document/add-edit-complaince-assigned-document.component';
import { CfFeedConsumptionReportComponent } from './modules/cf/cf-feed-consumption-report/cf-feed-consumption-report.component';
import { AddEditComplianceApprovalProcessComponent } from './modules/compliance/compliance-approval-process/add-edit-compliance-approval-process/add-edit-compliance-approval-process.component';
import { ComplianceApprovalProcessComponent } from './modules/compliance/compliance-approval-process/compliance-approval-process.component';
import { ComplianceDocumentApprovalComponent } from './modules/compliance/compliance-document-approval/compliance-document-approval.component';
import { EmpMonthwiseAttnProcSalaryManipulationComponent } from './modules/employee/employee-salary/emp-monthwise-attn-proc-salary-manipulation/emp-monthwise-attn-proc-salary-manipulation.component';
import { ModifyAttnProcSalaryManipulationComponent } from './modules/employee/employee-salary/emp-monthwise-attn-proc-salary-manipulation/modify-attn-proc-salary-manipulation/modify-attn-proc-salary-manipulation.component';
import { CfFlockCostingComponent } from './modules/cf/cf-flock-info/cf-flock-costing/cf-flock-costing.component';
import { CfDaSummaryComponent } from './modules/cf/cf-daily-flock-activity/cf-da-summary/cf-da-summary.component';
import { InvRawMaterialComponent } from './modules/inventory/inv-raw-material/inv-raw-material.component';
import { AddEditInvRawMaterialComponent } from './modules/inventory/inv-raw-material/add-edit-inv-raw-material/add-edit-inv-raw-material.component';
import { AddEditCstPaidBookngComponent } from './modules/cst/cst-paid-bookng-info/add-edit-cst-paid-bookng/add-edit-cst-paid-bookng.component';
import { CstPaidBookngInfoComponent } from './modules/cst/cst-paid-bookng-info/cst-paid-bookng-info.component';
import { CfPaymentInfoComponent } from './modules/cf/cf-payment-info/cf-payment-info.component';
import { AddEditCfPaymentInfoComponent } from './modules/cf/cf-payment-info/add-edit-cf-payment-info/add-edit-cf-payment-info.component';
import { CstSrInfoListComponent } from './modules/cst/cst-sro/cst-sr-info-list/cst-sr-info-list.component';
import { CfItemMarketRateComponent } from './modules/cf/cf-item-market-rate/cf-item-market-rate.component';
import { AddEditCfItemMarketRateComponent } from './modules/cf/cf-item-market-rate/add-edit-cf-item-market-rate/add-edit-cf-item-market-rate.component';
import { CfFarmManagementCostComponent } from './modules/cf/cf-farm-management-cost/cf-farm-management-cost.component';
import { AddEditCfFarmManagementCostComponent } from './modules/cf/cf-farm-management-cost/add-edit-cf-farm-management-cost/add-edit-cf-farm-management-cost.component';
import { CstReportComponent } from './modules/cst/cst-report/cst-report.component';
import { CfGrnStockTransferComponent } from './modules/cf/cf-grn-stock-transfer/cf-grn-stock-transfer.component';
import { AddEditCfGrnStockTransferComponent } from './modules/cf/cf-grn-stock-transfer/add-edit-cf-grn-stock-transfer/add-edit-cf-grn-stock-transfer.component';
import { CfGrnStockRecieveComponent } from './modules/cf/cf-grn-stock-recieve/cf-grn-stock-recieve/cf-grn-stock-recieve.component';
import { AddEditCfGrnStockRecvComponent } from './modules/cf/cf-grn-stock-recieve/add-edit-cf-grn-stock-recv/add-edit-cf-grn-stock-recv/add-edit-cf-grn-stock-recv.component';


const routes: Routes = [

  { path: '', redirectTo: 'login', pathMatch: 'full' },

  {
    path: '', component: DefaultComponent,
    children: [
      { path: 'home', component: HomeComponent, canActivate: [SecureInnerPagesGuard] },


      { path: 'add-menu', component: AddAdminMenuComponent },
      {
        path: 'menu', children: [
          { path: '', component: AdminMenuComponent },
          { path: 'edit/:id', component: AddAdminMenuComponent }
        ]
      },


      { path: 'addrole', component: AddAdminRoleComponent },
      {
        path: 'role', children: [
          { path: '', component: AdminRoleComponent },
          { path: 'edit/:id', component: AddAdminRoleComponent }
        ]
      },

      { path: 'addmenupermission', component: AddMenuPermissionComponent, canActivate: [SecureInnerPagesGuard] },
      {
        path: 'menu-permission', canActivate: [SecureInnerPagesGuard], children: [
          { path: '', component: MenuPermissionComponent },
          { path: 'edit/:id', component: AddMenuPermissionComponent }
        ]
      },


      { path: 'addcostsheetmaster', component: AddEditCostsheetMasterComponent },

      {
        path: 'costsheet-master', children: [
          { path: '', component: CostsheetMasterComponent },
          { path: 'edit/:id', component: AddEditCostsheetMasterComponent },
          { path: 'detail/:id', component: CostsheetMasterDetailComponent }
        ]
      },
      { path: 'addcostsheetmaster', component: AddEditCostsheetMasterComponent },

      {
        path: 'costsheet-master', children: [
          { path: '', component: CostsheetMasterComponent },
          { path: 'edit/:id', component: AddEditCostsheetMasterComponent },
          { path: 'detail/:id', component: CostsheetMasterDetailComponent }
        ]
      },


      { path: 'addcompany', component: AddEditAdminCompanyComponent },
      {
        path: 'admin-company', children: [
          { path: '', component: AdminCompanyComponent },
          { path: 'edit/:id', component: AddEditAdminCompanyComponent }
        ]
      },


      { path: 'addcompanyunit', component: AddAdminCompanyUnitComponent },
      {
        path: 'company-unit', children: [
          { path: '', component: AdminCompanyUnitComponent },
          { path: 'edit/:id', component: AddAdminCompanyUnitComponent }
        ]
      },

      { path: 'myprofile', component: UserProfileComponent },
      { path: 'change-password', component: UserChangePasswordComponent },
      { path: 'admin-change-password', component: AdminChangePasswordComponent },


      { path: 'admin-users', component: AdminUsersComponent },


      { path: 'addusercompanymapping', component: AddUserCompanyUnitComponent },
      {
        path: 'usercompanymapping', children: [
          { path: '', component: UserCompanyUnitMappingComponent },
          { path: 'edit/:id', component: AddUserCompanyUnitComponent }

        ]
      },



      { path: 'addstylemaster', component: AddEditStylemasterComponent },
      {
        path: 'style-master', children: [
          { path: '', component: StyleMasterComponent },
          { path: 'edit/:id', component: AddEditStylemasterComponent },
          { path: 'detail/:id', component: StylemasetrDetailComponent }

        ]
      },
      { path: 'addcertification', component: AddEditCertificationsComponent },
      {
        path: 'certification', children: [
          { path: '', component: CertificationsComponent },
          { path: 'edit/:id', component: AddEditCertificationsComponent }


        ]
      },

      { path: 'addaoprate', component: AddEditAopRateComponent },
      {
        path: 'aop-rate', children: [
          { path: '', component: AopRateComponent },
          { path: 'edit/:id', component: AddEditAopRateComponent }


        ]
      },
      { path: 'adddepartment', component: AddEditDepartmentComponent },
      {
        path: 'department', children: [
          { path: '', component: DepartmentComponent },
          { path: 'edit/:id', component: AddEditDepartmentComponent }


        ]
      },

      { path: 'add-dept-company', component: AddDepartmentCompanyComponent, canActivate: [SecureInnerPagesGuard] },
      {
        path: 'dept-company', canActivate: [SecureInnerPagesGuard], children: [
          { path: '', component: DepartmentCompanyComponent },
          { path: 'edit/:id', component: AddDepartmentCompanyComponent }
        ]
      },



      { path: 'adddesignation', component: AddEditDesignationComponent },
      {
        path: 'designation', children: [
          { path: '', component: DesignationComponent },
          { path: 'edit/:id', component: AddEditDesignationComponent }


        ]
      },
      { path: 'adddivision', component: AddEditDivisionComponent },
      {
        path: 'division', children: [
          { path: '', component: DivisionComponent },
          { path: 'edit/:id', component: AddEditDivisionComponent }


        ]
      },


      { path: 'addsection', component: AddEditHR_SectionComponent },
      {
        path: 'section', children: [
          { path: '', component: HR_SectionComponent },
          { path: 'edit/:id', component: AddEditHR_SectionComponent }


        ]
      },



      { path: 'addbuyermaster', component: AddEditBuyerMasterComponent },
      {
        path: 'buyer-master', children: [
          { path: '', component: BuyerMasterComponent },
          { path: 'edit/:id', component: AddEditBuyerMasterComponent },
          { path: 'detail/:id', component: DetailsBbuyerMasterDetailComponent }

        ]
      },

      { path: 'addadminUser', component: AddEditAdminUserRegistrationComponent },

      {
        path: 'admin-user-registration', children: [
          { path: '', component: AdminUserRegistrationComponent },
          { path: 'edit/:id', component: AddEditAdminUserRegistrationComponent },

        ]
      },


      {
        path: 'ieassumption', children: [
          { path: '', component: IeAssumptionComponent },
          { path: 'edit/:id', component: AddEditIeAssumptionComponent }
        ]
      },



      { path: 'addyarnrate', component: AddEditYarnRateComponent },
      {
        path: 'yarn-rate', children: [
          { path: '', component: YarnRateComponent },
          { path: 'edit/:id', component: AddEditYarnRateComponent },
          { path: 'detail/:id', component: YarnRateDetailComponent }

        ]
      },


      { path: 'addknittingrate', component: AddEditKnittingRateComponent },
      {
        path: 'knitting-rate', children: [
          { path: '', component: KnittingRateComponent },
          { path: 'edit/:id', component: AddEditKnittingRateComponent },
          { path: 'detail/:id', component: KnittingRateDetailComponent }

        ]
      },

      { path: 'addfabricdyeingrate', component: AddEditFabricDyeingRateComponent },
      {
        path: 'fabric-dyeing-rate', children: [
          { path: '', component: FabricDyeingRateComponent },
          { path: 'edit/:id', component: AddEditFabricDyeingRateComponent },
          { path: 'detail/:id', component: FabricDyeingRateDetailComponent }

        ]
      },
      { path: 'add-process-loss', component: AddEditProcessLossComponent },
      {
        path: 'process-loss', children: [
          { path: '', component: ProcessLossComponent },
          { path: 'edit/:id', component: AddEditProcessLossComponent },
          { path: 'detail/:id', component: ProcessLossDetailComponent }

        ]
      },

      { path: 'add-trims', component: AddEditTrimsComponent },
      {
        path: 'trimsmaster', children: [
          { path: '', component: TrimsComponent },
          { path: 'edit/:id', component: AddEditTrimsComponent },
          { path: 'detail/:id', component: TrimsDetailComponent }

        ]
      },

      { path: 'addyarndyeingrate', component: AddEditYarnDyeingRateComponent },
      {
        path: 'yarn-dyeing-rate', children: [
          { path: '', component: YarnDyeingRateComponent },
          { path: 'edit/:id', component: AddEditYarnDyeingRateComponent },
          { path: 'detail/:id', component: YarnDyeingRateDetailComponent }

        ]
      },
      { path: 'add-ordermaster', component: AddEditOcMasterComponent },
      {
        path: 'order-master', children: [
          { path: '', component: OcMasterComponent },
          { path: 'edit/:id', component: AddEditOcMasterComponent },
          { path: 'detail/:id', component: OcMasterDetailComponent }

        ]
      },
      { path: 'gmts-doc-search', component: GmtsDocSearchComponent },
      { path: 'recycle-doc', component: RecycleDocComponent },
      { path: 'gmts-doc-reminder', component: GmtsDocReminderComponent },
      { path: 'add-gmts-documents', component: AddEditGmtsDocumentsComponent },
      {
        path: 'gmts-domcuments', children: [
          { path: '', component: GmtsDomcumentsComponent },
          { path: 'edit/:id', component: AddEditGmtsDocumentsComponent },

        ]
      },
      { path: 'add-ddms-commercial', component: AddEditDdmsCommercialComponent },
      {
        path: 'ddms-commercial', children: [
          { path: '', component: DdmsCommercialComponent },
          { path: 'edit/:id', component: AddEditDdmsCommercialComponent },

        ]
      },
      { path: 'add-gmts-doc-lookup', component: AddEditGmtsDocLookupComponent },
      {
        path: 'gmts-doc-lookup', children: [
          { path: '', component: GmtsDocLookupComponent },
          { path: 'edit/:id', component: AddEditGmtsDocLookupComponent },

        ]
      },

      { path: 'addfabricyarncount', component: AddEditFabricYarnCountComponent },
      {
        path: 'fabric-yarn-count', children: [
          { path: '', component: FabricYarnCountComponent },
          { path: 'edit/:id', component: AddEditFabricYarnCountComponent },
          { path: 'detail/:id', component: DetailsFabricYarnCountComponent }

        ]
      },

      { path: 'addlookupType', component: AddEditLookupTypeComponent },
      {
        path: 'lookup-type', children: [
          { path: '', component: LookupTypeComponent },
          { path: 'edit/:id', component: AddEditLookupTypeComponent },
          { path: 'detail/:id', component: LookupTypeDetailsComponent }

        ]
      },
      { path: 'addcompanylookupType', component: AddEditLookupTypeCompanyComponent },
      {
        path: 'companylookup-type', children: [
          { path: '', component: LookupTypeCompanyComponent },
          { path: 'edit/:id', component: AddEditLookupTypeCompanyComponent },
          { path: 'detail/:id', component: LookupTypeCompanyDetailsComponent }

        ]
      },

      { path: 'addgloballookupType', component: AddEditLookupTypeGlobalComponent },
      {
        path: 'globallookup-type', children: [
          { path: '', component: LookupTypeGlobalComponent },
          { path: 'edit/:id', component: AddEditLookupTypeGlobalComponent },
          { path: 'detail/:id', component: LookupTypeGlobalDetailsComponent }

        ]
      },
      { path: 'add-employee', component: AddEditEmployeeComponent },
      {
        path: 'employees', children: [
          { path: '', component: EmployeeComponent, canActivate: [AuthGuard], },
          { path: 'edit/:id', component: AddEditEmployeeComponent },
          { path: 'recruitproposal/:id', component: RuitmentFinalProposalComponent },
          { path: 'detail/:id', component: EmployeeDetailComponent }

        ]
      },

      { path: 'employees-doc', component: EmployeesDocComponent },
      { path: 'employee-count-summary', component: EmployeeCountSummaryComponent },
      { path: 'add-employeepf', component: AddEditEmployeePfComponent },
      {
        path: 'employee-pf', children: [
          { path: '', component: EmployeePfComponent },
          { path: 'edit/:id', component: AddEditEmployeePfComponent },
        ]
      },





      { path: 'addgeocountry', component: AddEditGeoCountryComponent },
      {
        path: 'geo-country', children: [
          { path: '', component: GeoCountryComponent },
          { path: 'edit/:id', component: AddEditGeoCountryComponent },
          { path: 'detail/:id', component: GeoCountryDetailsComponent }

        ]
      },
      { path: 'addgeoregion', component: AddEditGeoRegionComponent },
      {
        path: 'geo-region', children: [
          { path: '', component: GeoRegionComponent },
          { path: 'edit/:id', component: AddEditGeoRegionComponent },
          { path: 'detail/:id', component: GeoRegionDetailsComponent }

        ]
      },
      { path: 'addgeozone', component: AddEditGeoZoneComponent },
      {
        path: 'geo-zone', children: [
          { path: '', component: GeoZoneComponent },
          { path: 'edit/:id', component: AddEditGeoZoneComponent },
          { path: 'detail/:id', component: GeoZoneDetailsComponent }

        ]
      },
      { path: 'addgeoterritory', component: AddEditGeoTerritoryComponent },
      {
        path: 'geo-territory', children: [
          { path: '', component: GeoTerritoryComponent },
          { path: 'edit/:id', component: AddEditGeoTerritoryComponent },
          { path: 'detail/:id', component: GeoTerritoryDetailsComponent }

        ]
      },

      { path: 'add-fabricbooking', component: AddEditFabricBookingComponent },
      {
        path: 'fabric-booking', children: [
          { path: '', component: FabricBookingComponent },
          { path: 'edit/:id', component: AddEditFabricBookingComponent },
          { path: 'detail/:id', component: DetailFabricBookingComponent }

        ]
      },
      { path: 'addsupplier', component: AddEditSupplierComponent },

      {
        path: 'supplier', children: [
          { path: '', component: SupplierComponent },
          { path: 'edit/:id', component: AddEditSupplierComponent }
        ]
      },
      { path: 'addlookupvalue', component: AddEditLookupComponent },
      {
        path: 'lookupvalue', children: [
          { path: '', component: LookupComponent },
          { path: 'edit/:id', component: AddEditLookupComponent },
          { path: 'detail/:id', component: LookupDetailsComponent }

        ]
      },

      { path: 'addlookupGrpvalue', component: AddEditLookupGrpComponent },
      {
        path: 'lookupGrpvalue', children: [
          { path: '', component: LookupGrpComponent },
          { path: 'edit/:id', component: AddEditLookupGrpComponent },
          { path: 'detail/:id', component: LookupGrpDetailsComponent }

        ]
      },

      { path: 'addlookupCatvalue', component: AddEditLookupCatComponent },
      {
        path: 'lookupCatvalue', children: [
          { path: '', component: LookupCatComponent },
          { path: 'edit/:id', component: AddEditLookupCatComponent },
          { path: 'detail/:id', component: LookupCatDetailsComponent }

        ]
      },

      { path: 'addlookupClassvalue', component: AddEditLookupClassComponent },
      {
        path: 'lookupClassvalue', children: [
          { path: '', component: LookupClassComponent },
          { path: 'edit/:id', component: AddEditLookupClassComponent },
          { path: 'detail/:id', component: LookupClassDetailsComponent }

        ]
      },

      { path: 'addlookupWarvalue', component: AddEditLookupWarComponent },
      {
        path: 'lookupWarvalue', children: [
          { path: '', component: LookupWarComponent },
          { path: 'edit/:id', component: AddEditLookupWarComponent },
          { path: 'detail/:id', component: LookupWarDetailsComponent }

        ]
      },

      { path: 'addcustomer', component: AddEditCustomerComponent },

      {
        path: 'customer', children: [
          { path: '', component: CustomerComponent },
          { path: 'edit/:id', component: AddEditCustomerComponent }
        ]
      },
      { path: 'add-warehouse', component: AddEditWarehouseComponent },

      {
        path: 'warehouse', children: [
          { path: '', component: WarehouseComponent },
          { path: 'edit/:id', component: AddEditWarehouseComponent }
        ]
      },
      { path: 'addsalesorder', component: AddEditSalesOrderComponent },

      {
        path: 'salesorder', children: [
          { path: '', component: SalesOrderComponent },
          { path: 'edit/:id', component: AddEditSalesOrderComponent }
        ]
      },
      { path: 'add-sales-return', component: AddEditSalesReturnComponent },

      {
        path: 'sales-return', children: [
          { path: '', component: SalesReturnComponent },
          { path: 'edit/:id', component: AddEditSalesReturnComponent }
        ]
      },
      { path: 'add-delivery-challan', component: AddEditDeliveryChallanComponent },

      {
        path: 'delivery-challan', children: [
          { path: '', component: DeliveryChallanComponent },
          { path: 'edit/:id', component: AddEditDeliveryChallanComponent }
        ]
      }
      ,
      { path: 'add-item', component: AddEditItemComponent },

      {
        path: 'item', children: [
          { path: '', component: ItemComponent },
          { path: 'edit/:id', component: AddEditItemComponent }
        ]
      }
      ,
      { path: 'add-item-afl', component: AddEditItemAflComponent },

      {
        path: 'item-afl', children: [
          { path: '', component: ItemAflComponent },
          { path: 'edit/:id', component: AddEditItemAflComponent }
        ]
      }
      ,
      { path: 'add-item-discount-policy', component: AddEditItemDiscountPolicyComponent },

      {
        path: 'item-discount-policy', children: [
          { path: '', component: ItemDiscountPolicyComponent },
          { path: 'edit/:id', component: AddEditItemDiscountPolicyComponent }
        ]
      }
      ,
      { path: 'add-item-category', component: AddEditItemCategoryComponent },

      {
        path: 'item-category', children: [
          { path: '', component: ItemCategoryComponent },
          { path: 'edit/:id', component: AddEditItemCategoryComponent }
        ]
      }
      ,
      { path: 'add-item-sub-category', component: AddEditItemSubCategoryComponent },

      {
        path: 'item-sub-category', children: [
          { path: '', component: ItemSubCategoryComponent },
          { path: 'edit/:id', component: AddEditItemSubCategoryComponent }
        ]
      },
      { path: 'add-item-brand', component: AddEditItemBrandComponent },

      {
        path: 'item-brand', children: [
          { path: '', component: ItemBrandComponent },
          { path: 'edit/:id', component: AddEditItemBrandComponent }
        ]
      }
      ,
      { path: 'add-item-sub-brand', component: AddEditItemSubBrandComponent },

      {
        path: 'item-sub-brand', children: [
          { path: '', component: ItemSubBrandComponent },
          { path: 'edit/:id', component: AddEditItemSubBrandComponent }
        ]
      }
      ,
      { path: 'add-inv-raw-material', component: AddEditInvRawMaterialComponent },

      {
        path: 'inv-raw-material', children: [
          { path: '', component: InvRawMaterialComponent },
          { path: 'edit/:id', component: AddEditInvRawMaterialComponent }
        ]
      }
      ,
      { path: 'add-asset-owner', component: AddEditAssetOwnerComponent },

      {
        path: 'asset-owner', children: [
          { path: '', component: AssetOwnerComponent },
          { path: 'edit/:id', component: AddEditAssetOwnerComponent }
        ]
      }
      ,
      { path: 'add-asset-book', component: AddEditAssetBookComponent },

      {
        path: 'asset-book', children: [
          { path: '', component: AssetBookComponent },
          { path: 'edit/:id', component: AddEditAssetBookComponent },
          { path: 'detail/:id', component: ShowAssetBookComponent }
        ]
      }
      ,
      { path: 'add-asset-book-server', component: AddEditAssetBookServerComponent },

      {
        path: 'asset-book-server', children: [
          { path: '', component: AssetBookServerComponent },
          { path: 'edit/:id', component: AddEditAssetBookServerComponent },
          { path: 'detail/:id', component: ShowAssetBookServerComponent }
        ]
      }
      ,
      { path: 'add-asset-book-admin', component: AddEditAssetBookAdminComponent },

      {
        path: 'asset-book-admin', children: [
          { path: '', component: AssetBookAdminComponent },
          { path: 'edit/:id', component: AddEditAssetBookAdminComponent },
          // { path: 'detail/:id', component: ShowAssetBookServerComponent }
        ]
      }
      ,
      { path: 'add-asset-book-land', component: AddEditAssetBookLandComponent },

      {
        path: 'asset-book-land', children: [
          { path: '', component: AssetBookLandComponent },
          { path: 'edit/:id', component: AddEditAssetBookLandComponent },
          // { path: 'detail/:id', component: ShowAssetBookServerComponent }
        ]
      }
      ,
      { path: 'add-asset-book-plant', component: AddEditAssetBookPlantComponent },

      {
        path: 'asset-book-plant', children: [
          { path: '', component: AssetBookPlantComponent },
          { path: 'edit/:id', component: AddEditAssetBookPlantComponent },
          // { path: 'detail/:id', component: ShowAssetBookServerComponent }
        ]
      }
      ,
      { path: 'add-asset-book-vehicle', component: AddEditAssetBookVehicleComponent },

      {
        path: 'asset-book-vehicle', children: [
          { path: '', component: AssetBookVehicleComponent },
          { path: 'edit/:id', component: AddEditAssetBookVehicleComponent },
          { path: 'detail/:id', component: ShowAssetBookVehicleComponent }
        ]
      }
      ,
      { path: 'add-vehicle-location', component: AddEditVehicleLocationComponent },

      {
        path: 'vehicle-location', children: [
          { path: '', component: VehicleLocationComponent },
          { path: 'edit/:id', component: AddEditVehicleLocationComponent }
        ]
      }
      ,
      { path: 'add-custodian', component: AddCustodianComponent },

      {
        path: 'custodian', children: [
          { path: '', component: CustodianComponent },
          { path: 'edit/:id', component: AddCustodianComponent }
        ]
      }
      ,
      { path: 'add-sub-custodian', component: AddSubCustodianComponent },

      {
        path: 'sub-custodian', children: [
          { path: '', component: SubCustodianComponent },
          { path: 'edit/:id', component: AddSubCustodianComponent }
        ]
      }
      ,
      { path: 'add-asset-employee', component: AddEditAssetEmployeeComponent },

      {
        path: 'asset-employee', children: [
          { path: '', component: AssetEmployeeComponent },
          { path: 'edit/:id', component: AddEditAssetEmployeeComponent },
          { path: 'detail/:id', component: ShowAssetEmployeeComponent }
        ]
      }
      ,
      { path: 'add-uom', component: AddEditUomComponent },

      {
        path: 'uom', children: [
          { path: '', component: UomComponent },
          { path: 'edit/:id', component: AddEditUomComponent }
        ]
      },
      { path: 'my-leave-application', component: MyLeaveApplicationComponent },
      { path: 'users-leave-application', component: LeaveApplicationComponent },
      {
        path: 'leave-application', children: [
          { path: '', component: AddLeaveApplicationComponent },
          { path: 'edit/:id', component: AddLeaveApplicationComponent }
        ]
      },
      { path: 'add-leave-policy', component: AddLeavePolicyComponent },
      {
        path: 'leave-policy', children: [
          { path: '', component: LeavePolicyComponent },
          { path: 'edit/:id', component: AddLeavePolicyComponent }
        ]
      },
      { path: 'leave-allocation', component: LeaveAllocationComponent },
      {
        path: 'add-leave-allocation', children: [
          { path: '', component: AddLeaveAllocationComponent },
          { path: 'edit/:id', component: AddLeaveAllocationComponent }
        ]
      },

      { path: 'add-asset-allocation', component: AddEditAssetAllocationComponent },

      {
        path: 'asset-allocation', children: [
          { path: '', component: AssetAllocationComponent },
          { path: 'edit/:id', component: AddEditAssetAllocationComponent }
        ]
      },
      { path: 'add-hr-holiday', component: AddEditHrHolidayComponent },

      {
        path: 'hr-holiday', children: [
          { path: '', component: HrHolidayComponent },
          { path: 'edit/:id', component: AddEditHrHolidayComponent }
        ]
      },


      //Attendance Report
      { path: 'monthly-attendance-summary-report', component: MonthlyAttendaceSummaryReportComponent },




      //Attendance

      { path: 'daily-attendance', component: EmployeeDailyAttendanceComponent, canActivate: [AuthGuard] },
      { path: 'emp-attendance-summary', component: EmployeeAttendanceSummaryComponent, canActivate: [AuthGuard] },
      { path: 'emp-attendance-approval', component: EmpManualAttndApprovalComponent, canActivate: [AuthGuard] },
      { path: 'employee-attendance-application', component: EmployeeAttendanceApplicationComponent, canActivate: [AuthGuard] },


      { path: 'add-emp-manual-attendance-approval', component: AddEditEmpManualDailyAatendanceComponent, canActivate: [AuthGuard] },
      {
        path: 'emp-manual-attendance-approval', children: [
          { path: '', component: EmpManualAttndApprovalComponent, canActivate: [AuthGuard] },
          { path: 'edit/:id', component: AddEditEmpManualDailyAatendanceComponent, canActivate: [AuthGuard] }
        ]
      },



      { path: 'add-monthly-attn-process', component: AddMonthlyAttendanceProcessComponent },
      {
        path: 'monthly-attn-process', children: [
          { path: '', component: MonthlyAttendanceProcessComponent },
          { path: 'edit/:id', component: AddMonthlyAttendanceProcessComponent }
        ]
      }
      ,
      { path: 'add-asset-allocation-return', component: AddEditAssetAllocationReturnComponent },

      {
        path: 'asset-allocation-return', children: [
          { path: '', component: AssetAllocationReturnComponent },
          { path: 'edit/:id', component: AddEditAssetAllocationReturnComponent }
        ]
      }
      ,
      { path: 'add-asset-allocation-vehicle', component: AddEditAssetAllocationVehicleComponent },

      {
        path: 'asset-allocation-vehicle', children: [
          { path: '', component: AssetAllocationVehicleComponent },
          { path: 'edit/:id', component: AddEditAssetAllocationVehicleComponent }
        ]
      }
      ,
      { path: 'add-asset-allocation-vehicle-return', component: AddEditAssetAllocationVehicleReturnComponent },

      {
        path: 'asset-allocation-vehicle-return', children: [
          { path: '', component: AssetAllocationVehicleReturnComponent },
          { path: 'edit/:id', component: AddEditAssetAllocationVehicleReturnComponent }
        ]
      }
      ,
      { path: 'add-asset-allocation-admin', component: AddEditAssetAllocationAdminComponent },

      {
        path: 'asset-allocation-admin', children: [
          { path: '', component: AssetAllocationAdminComponent },
          { path: 'edit/:id', component: AddEditAssetAllocationAdminComponent }
        ]
      }
      ,
      { path: 'add-asset-allocation-admin-return', component: AddEditAssetAllocationAdminReturnComponent },

      {
        path: 'asset-allocation-admin-return', children: [
          { path: '', component: AssetAllocationAdminReturnComponent },
          { path: 'edit/:id', component: AddEditAssetAllocationAdminReturnComponent }
        ]
      }
      ,
      { path: 'add-asset-allocation-land', component: AddEditAssetAllocationLandComponent },

      {
        path: 'asset-allocation-land', children: [
          { path: '', component: AssetAllocationLandComponent },
          { path: 'edit/:id', component: AddEditAssetAllocationLandComponent }
        ]
      }
      ,
      { path: 'add-asset-allocation-land-return', component: AddEditAssetAllocationLandReturnComponent },

      {
        path: 'asset-allocation-land-return', children: [
          { path: '', component: AssetAllocationLandReturnComponent },
          { path: 'edit/:id', component: AddEditAssetAllocationLandReturnComponent }
        ]
      }
      ,
      { path: 'add-asset-allocation-plant', component: AddEditAssetAllocationPlantComponent },

      {
        path: 'asset-allocation-plant', children: [
          { path: '', component: AssetAllocationPlantComponent },
          { path: 'edit/:id', component: AddEditAssetAllocationPlantComponent }
        ]
      }
      ,
      { path: 'add-asset-allocation-plant-return', component: AddEditAssetAllocationPlantReturnComponent },

      {
        path: 'asset-allocation-plant-return', children: [
          { path: '', component: AssetAllocationPlantReturnComponent },
          { path: 'edit/:id', component: AddEditAssetAllocationPlantReturnComponent }
        ]
      }
      ,
      { path: 'asset-vehicle-documnets', component: ShowAssetVehicleDocumentsComponent },
      { path: 'add-asset-maintenance-receive', component: AddEditAssetMaintenanceReceiveComponent },

      { path: 'add-asset-allocation', component: AddEditAssetAllocationComponent },

      {
        path: 'asset-allocation', children: [
          { path: '', component: AssetAllocationComponent },
          { path: 'edit/:id', component: AddEditAssetAllocationComponent }
        ]
      }
      ,
      { path: 'add-asset-allocation-return', component: AddEditAssetAllocationReturnComponent },

      {
        path: 'asset-allocation-return', children: [
          { path: '', component: AssetAllocationReturnComponent },
          { path: 'edit/:id', component: AddEditAssetAllocationReturnComponent }
        ]
      }
      ,
      { path: 'add-asset-maintenance-receive', component: AddEditAssetMaintenanceReceiveComponent },

      {
        path: 'asset-maintenance-receive', children: [
          { path: '', component: AssetMaintenanceReceiveComponent },
          { path: 'edit/:id', component: AddEditAssetMaintenanceReceiveComponent }
        ]
      }
      ,
      { path: 'add-asset-maintenance-return', component: AddEditAssetMaintenanceReturnComponent },

      {
        path: 'asset-maintenance-return', children: [
          { path: '', component: AssetMaintenanceReturnComponent },
          { path: 'edit/:id', component: AddEditAssetMaintenanceReturnComponent }
        ]
      }
      ,
      { path: 'add-asset-user-support', component: AddEditAssetUserSupportComponent },

      {
        path: 'asset-user-support', children: [
          { path: '', component: AssetUserSupportComponent },
          { path: 'edit/:id', component: AddEditAssetUserSupportComponent }
        ]
      }
      ,
      { path: 'add-asset-item-software', component: AddEditSoftwareComponent },

      {
        path: 'asset-item-software', children: [
          { path: '', component: AssetItemSoftwareComponent },
          { path: 'edit/:id', component: AddEditSoftwareComponent }
        ]
      }
      ,
      { path: 'add-asset-item-email', component: AddEditEmailComponent },

      {
        path: 'asset-item-email', children: [
          { path: '', component: AssetItemEmailComponent },
          { path: 'edit/:id', component: AddEditEmailComponent }
        ]
      }
      ,
      { path: 'add-asset-item-list', component: AddEditAssetItemListComponent },

      {
        path: 'asset-item-list', children: [
          { path: '', component: AssetItemListComponent },
          { path: 'edit/:id', component: AddEditAssetItemListComponent }
        ]
      }
      ,
      { path: 'add-asset-item-mobile', component: AddEditMobileComponent },

      {
        path: 'asset-item-mobile', children: [
          { path: '', component: AssetItemMobileComponent },
          { path: 'edit/:id', component: AddEditMobileComponent }
        ]
      }
      ,
      { path: 'add-asset-item-assign-software', component: AddEditAssetItemAssignSoftwareComponent },

      {
        path: 'asset-item-assign-software', children: [
          { path: '', component: AssetItemAssignSoftwareComponent },
          { path: 'edit/:id', component: AddEditAssetItemAssignSoftwareComponent }
        ]
      }
      ,
      { path: 'add-asset-item-assign-email', component: AddEditAssetItemAssignEmailComponent },

      {
        path: 'asset-item-assign-email', children: [
          { path: '', component: AssetItemAssignEmailComponent },
          { path: 'edit/:id', component: AddEditAssetItemAssignEmailComponent }
        ]
      }
      ,
      { path: 'add-asset-item-assign-mobile', component: AddEditAssetItemAssignMobileComponent },

      {
        path: 'asset-item-assign-mobile', children: [
          { path: '', component: AssetItemAssignMobileComponent },
          { path: 'edit/:id', component: AddEditAssetItemAssignMobileComponent }
        ]
      }
      ,
      { path: 'add-asset-spare-part', component: AddEditAssetSparePartComponent },
      { path: 'asset-spare-part-cs', component: AssetSparePartCsComponent },
      {
        path: 'asset-spare-part', children: [
          { path: '', component: AssetSparePartComponent },
          { path: 'edit/:id', component: AddEditAssetSparePartComponent }
        ]
      }
      ,
      { path: 'add-asset-grn-master', component: AddEditAssetGrnMasterComponent },

      {
        path: 'asset-grn-master', children: [
          { path: '', component: AssetGrnMasterComponent },
          { path: 'edit/:id', component: AddEditAssetGrnMasterComponent }
        ]
      }
      ,
      { path: 'add-asset-spare-part-book', component: AddEditAssetSparePartBookComponent },

      {
        path: 'asset-spare-part-book', children: [
          { path: '', component: AssetSparePartBookComponent },
          { path: 'edit/:id', component: AddEditAssetSparePartBookComponent }
        ]
      },
      //Leave

      //Leave Report
      { path: 'leave-report', component: LeaveReportComponent },




      //LeaveType

      { path: 'add-hr-leave-type', component: AddEditHrLeaveTypeComponent },

      {
        path: 'hr-leave-type', children: [
          { path: '', component: HrLeaveTypeComponent },
          { path: 'edit/:id', component: AddEditHrLeaveTypeComponent }
        ]
      }
      //LeaveReason
      ,
      { path: 'add-leave-reason', component: AddEditLeaveReasonComponent },

      {
        path: 'leave-reason', children: [
          { path: '', component: LeaveReasonComponent },
          { path: 'edit/:id', component: AddEditLeaveReasonComponent }
        ]
      }

      //LeaveBulkApproval
      ,
      { path: 'add-leave-bulk-approval', component: AddEditLeaveBulkApproveComponent },

      {
        path: 'leave-bulk-approval', children: [
          { path: '', component: LeaveBulkApproveComponent },
          { path: 'edit/:id', component: AddEditLeaveBulkApproveComponent }
        ]
      }



      //LeaveAuthorization
      ,
      { path: 'add-leave-authorization', component: AddEditLeaveAuthorizationComponent },

      {
        path: 'leave-authorization', children: [
          { path: '', component: LeaveAuthorizationComponent },
          { path: 'edit/:id', component: AddEditLeaveAuthorizationComponent }
        ]
      }

      //TripPlan
      ,
      { path: 'add-transport-tp', component: AddEditTransportTpComponent },

      {
        path: 'transport-tp', children: [
          { path: '', component: TransportTpComponent },
          { path: 'edit/:id', component: AddEditTransportTpComponent }
        ]
      }
      //TripPlan
      ,
      { path: 'add-cf-farmer', component: AddEditCfFarmerComponent },

      {
        path: 'cf-farmer', children: [
          { path: '', component: CfFarmerComponent },
          { path: 'edit/:id', component: AddEditCfFarmerComponent }
        ]
      }
      ,
      { path: 'add-flock-info', component: AddEditCfFlockInfoComponent },

      {
        path: 'cf-flock-info', children: [
          { path: '', component: CfFlockInfoComponent },
          { path: 'edit/:id', component: AddEditCfFlockInfoComponent }
        ]
      }
      ,
      { path: 'cf-flock-costing', component: CfFlockCostingComponent },
      { path: 'add-cf-grn', component: AddEditCfGrnComponent },

      {
        path: 'cf-grn', children: [
          { path: '', component: CfGrnComponent },
          { path: 'edit/:id', component: AddEditCfGrnComponent },
          { path: 'detail/:id', component: DetailCfGrnComponent }
        ]
      }
      ,
      { path: 'add-cf-grn-recv', component: AddEditCfGrnStockRecvComponent },
      {
        path: 'cf-grn-recv', children: [
          { path: '', component: CfGrnStockRecieveComponent },
          { path: 'edit/:id', component: AddEditCfGrnStockRecvComponent },
          { path: 'detail/:id', component: DetailCfGrnComponent }
        ]
      },
      { path: 'add-cf-grn-transfer', component: AddEditCfGrnStockTransferComponent },
      {
        path: 'cf-grn-transfer', children: [
          { path: '', component: CfGrnStockTransferComponent },
          { path: 'edit/:id', component: AddEditCfGrnStockTransferComponent },
          { path: 'detail/:id', component: DetailCfGrnComponent }
        ]
      },
      { path: 'add-cf-issue', component: AddEditCfIssueComponent },
      { path: 'cf-issue-approval', component: CfIssueApprovalComponent },
      {
        path: 'cf-issue', children: [
          { path: '', component: CfIssueComponent },
          { path: 'edit/:id', component: AddEditCfIssueComponent },
          { path: 'detail/:id', component: DetailCfIssueComponent }
        ]
      },
      { path: 'add-cf-issue-return', component: AddEditCfIssueReturnComponent },

      {
        path: 'cf-issue-return', children: [
          { path: '', component: CfIssueReturnComponent },
          { path: 'edit/:id', component: AddEditCfIssueReturnComponent },
          { path: 'detail/:id', component: DetailCfIssueReturnComponent }
        ]
      },
      { path: 'add-cf-fg-sale', component: AddEditCfFgSaleComponent },

      {
        path: 'cf-fg-sale', children: [
          { path: '', component: CfFgSaleComponent },
          { path: 'edit/:id', component: AddEditCfFgSaleComponent },
          { path: 'detail/:id', component: DetailCfFgSaleComponent }
        ]
      },
      { path: 'cf-item-stock', component: CfItemStockComponent },

      { path: 'add-cf-region', component: AddEditCfRegionComponent },

      {
        path: 'cf-region', children: [
          { path: '', component: CfRegionComponent },
          { path: 'edit/:id', component: AddEditCfRegionComponent }
        ]
      },

      { path: 'add-cf-branch', component: AddEditCfBranchComponent },

      {
        path: 'cf-branch', children: [
          { path: '', component: CfBranchComponent },
          { path: 'edit/:id', component: AddEditCfBranchComponent }
        ]
      },
      { path: 'add-cf-cluster', component: AddEditCfClusterComponent },

      {
        path: 'cf-cluster', children: [
          { path: '', component: CfClusterComponent },
          { path: 'edit/:id', component: AddEditCfClusterComponent }
        ]
      },
      { path: 'add-cf-warehouse', component: AddEditCfWarehouseComponent },

      {
        path: 'cf-warehouse', children: [
          { path: '', component: CfWarehouseComponent },
          { path: 'edit/:id', component: AddEditCfWarehouseComponent }
        ]
      },
      { path: 'add-cf-supplier', component: AddEditCfSupplierComponent },

      {
        path: 'cf-supplier', children: [
          { path: '', component: CfSupplierComponent },
          { path: 'edit/:id', component: AddEditCfSupplierComponent }
        ]
      },
      { path: 'add-cf-approval-process', component: AddEditCfApprovalProcessComponent },

      {
        path: 'cf-approval-process', children: [
          { path: '', component: CfApprovalProcessComponent },
          { path: 'edit/:id', component: AddEditCfApprovalProcessComponent }
        ]
      },
      { path: 'add-cf-customer', component: AddEditCfCustomerComponent },

      {
        path: 'cf-customer', children: [
          { path: '', component: CfCustomerComponent },
          { path: 'edit/:id', component: AddEditCfCustomerComponent }
        ]
      },
      { path: 'add-cf-rate-policy', component: AddEditCfRatePolicyComponent },

      {
        path: 'cf-rate-policy', children: [
          { path: '', component: CfRatePolicyComponent },
          { path: 'edit/:id', component: AddEditCfRatePolicyComponent }
        ]
      },
      { path: 'add-cf-daily-flock-activity', component: AddEditCfDailyFlockActivityComponent },

      {
        path: 'cf-daily-flock-activity', children: [
          { path: '', component: CfDailyFlockActivityComponent },
          { path: 'edit/:id', component: AddEditCfDailyFlockActivityComponent }
        ]
      },
      { path: 'cf-da-summary', component: CfDaSummaryComponent },
      { path: 'add-cf-dead-reason', component: AddEditCfDeadReasonComponent },

      {
        path: 'cf-dead-reason', children: [
          { path: '', component: CfDeadReasonComponent },
          { path: 'edit/:id', component: AddEditCfDeadReasonComponent }
        ]
      },
      { path: 'add-cf-dead-action', component: AddEditCfDeadActionComponent },

      {
        path: 'cf-dead-action', children: [
          { path: '', component: CfDeadActionComponent },
          { path: 'edit/:id', component: AddEditCfDeadActionComponent }
        ]
      },
      { path: 'add-cf-user-mapping', component: AddEditCfUserMappingComponent },

      {
        path: 'cf-user-mapping', children: [
          { path: '', component: CfUserMappingComponent },
          { path: 'edit/:id', component: AddEditCfUserMappingComponent }
        ]
      },
      { path: 'add-cf-payment-info', component: AddEditCfPaymentInfoComponent },

      {
        path: 'cf-payment-info', children: [
          { path: '', component: CfPaymentInfoComponent },
          { path: 'edit/:id', component: AddEditCfPaymentInfoComponent }
        ]
      },      
      { path: 'add-cf-item-market-rate', component: CfItemMarketRateComponent },
      {
        path: 'cf-item-market-rate', children: [
          { path: '', component: CfItemMarketRateComponent },
          { path: 'edit/:id', component: AddEditCfItemMarketRateComponent }
        ]
      },
      { path: 'add-cf-farm-mngt-cost', component: CfFarmManagementCostComponent },
      {
        path: 'cf-farm-mngt-cost', children: [
          { path: '', component: CfFarmManagementCostComponent },
          { path: 'edit/:id', component: AddEditCfFarmManagementCostComponent }
        ]
      },
      { path: 'cf-dashboard', component: CfDashboardComponent },
      { path: 'cf-pl-dashboard', component: CfPlDashboardComponent },
      { path: 'cf-report', component: CfReportComponent },
      { path: 'cf-feed-consumption-report', component: CfFeedConsumptionReportComponent },


      //Finance
      { path: 'addcoa', component: AddEditAccCoaComponent },

      {
        path: 'coa', children: [
          { path: '', component: AccCoaComponent },
          { path: 'edit/:id', component: AddEditAccCoaComponent }

        ]
      },

      { path: 'addvoucher', component: AddEditVoucherComponent },

      {
        path: 'voucher', children: [
          { path: '', component: VoucherComponent },
          { path: 'edit/:id', component: AddEditVoucherComponent },
          { path: 'voucher-upload', component: UploadVoucherComponent }
        ]
      },
      { path: 'add-acc-petty-cash', component: AddEditAccPettyCashComponent },

      {
        path: 'acc-petty-cash', children: [
          { path: '', component: AccPettyCashComponent },
          { path: 'edit/:id', component: AddEditAccPettyCashComponent }
        ]
      },
      { path: 'add-acc-accounts-type', component: AddEditAccAccountsTypeComponent},

      {
        path: 'acc-accounts-type', children: [
          { path: '', component: AccAccountsTypeComponent },
          { path: 'edit/:id', component: AddEditAccAccountsTypeComponent }
        ]
      },
      { path: 'finance-report', component: FinanceReportComponent },


      //Ajfl
      { path: 'add-ajfl-purchase', component: AddEditAjflPurchaseComponent },

      {
        path: 'ajfl-purchase', children: [
          { path: '', component: AjflPurchaseComponent },
          { path: 'edit/:id', component: AddEditAjflPurchaseComponent }
        ]
      },
      { path: 'add-ajfl-supplier', component: AddEditAjflSupplierComponent },

      {
        path: 'ajfl-supplier', children: [
          { path: '', component: AjflSupplierComponent },
          { path: 'edit/:id', component: AddEditAjflSupplierComponent }
        ]
      },
      { path: 'add-ajfl-item-grade', component: AddEditAjflItemGradeComponent },
      {
        path: 'ajfl-item-grade', children: [
          { path: '', component: AjflItemGradeComponent },
          { path: 'edit/:id', component: AddEditAjflItemGradeComponent }
        ]
      },
      { path: 'add-ajfl-basis-setup', component: AddEditAjflBasisSetupComponent },
      {
        path: 'ajfl-basis-setup', children: [
          { path: '', component: AjflBasisSetupComponent },
          { path: 'edit/:id', component: AddEditAjflBasisSetupComponent }
        ]
      },
      { path: 'add-ajfl-production-requisition', component: AddEditProductionRequisitionComponent },
      {
        path: 'ajfl-production-requisition', children: [
          { path: '', component: AjflProductionRequisitionComponent },
          { path: 'edit/:id', component: AddEditProductionRequisitionComponent }
        ]
      },
      { path: 'add-ajfl-production-issue', component: AddEditProductionIssueComponent },
      {
        path: 'ajfl-production-issue', children: [
          { path: '', component: AjflProductionIssueComponent },
          { path: 'edit/:id', component: AddEditProductionIssueComponent }
        ]
      },
      { path: 'ajfl-report', component: AjflReportComponent },


      //Compliance
      { path: 'add-compliance-document', component: AddEditComplianceDocumentComponent },
      {
        path: 'compliance-document', children: [
          { path: '', component: ComplianceDocumentComponent },
          { path: 'edit/:id', component: AddEditComplianceDocumentComponent }
        ]
      },
      { path: 'add-compliance-item-type', component: AddEditComplianceItemTypeComponent },
      {
        path: 'compliance-item-type', children: [
          { path: '', component: ComplianceItemTypeComponent },
          { path: 'edit/:id', component: AddEditComplianceItemTypeComponent }
        ]
      }, 
      { path: 'compliance-all-document', component: ComplianceAllDocumentComponent },
      {
        path: 'compliance-assigned-document', children: [
          { path: '', component: ComplianceAssignedDocumentComponent },
          { path: 'edit/:id', component: AddEditComplainceAssignedDocumentComponent }
        ]
      }, 
      { path: 'add-compliance-approval-process', component: AddEditComplianceApprovalProcessComponent },
      {
        path: 'compliance-approval-process', children: [
          { path: '', component: ComplianceApprovalProcessComponent },
          { path: 'edit/:id', component: AddEditComplianceApprovalProcessComponent }
        ]
      }, 
      { path: 'compliance-document-approval', component: ComplianceDocumentApprovalComponent },
      //CST
      { path: 'add-cst-customer-info', component: AddEditCstCustomerComponent },

      {
        path: 'cst-customer-info', children: [
          { path: '', component: CstCustomerComponent },
          { path: 'edit/:id', component: AddEditCstCustomerComponent }
        ]
      },
      { path: 'add-cst-booking-info', component: AddEditCstBookingComponent },

      {
        path: 'cst-booking-info', children: [
          { path: '', component: CstBookingComponent },
          { path: 'edit/:id', component: AddEditCstBookingComponent }
        ]
      },
      { path: 'add-cst-sro-info', component: AddEditCstSroComponent },

      {
        path: 'cst-sro-info', children: [
          { path: '', component: CstSroComponent },
          { path: 'edit/:id', component: AddEditCstSroComponent }
        ]
      },
      { path: 'add-cst-do-info', component: AddEditCstDoComponent },

      {
        path: 'cst-do-info', children: [
          { path: '', component: CstDoComponent },
          { path: 'edit/:id', component: AddEditCstDoComponent }
        ]
      },
      {
        path: 'cst-sro-pending-list', children: [
          { path: '', component: CstSroPendingListComponent },
        ]
      },
      {
        path: 'cst-poketing-info', children: [
          { path: '', component: CstSrInfoListComponent },
        ]
      },
      { path: 'add-cst-season-info', component: AddEditCstSeasonComponent },

      {
        path: 'cst-season-info', children: [
          { path: '', component: CstSeasonComponent },
          { path: 'edit/:id', component: AddEditCstSeasonComponent }
        ]
      },
      { path: 'add-cst-target-booking-info', component: AddEditCstNormalBookingComponent },

      {
        path: 'cst-target-booking-info', children: [
          { path: '', component: CstNormalBookingComponent },
          { path: 'edit/:id', component: AddEditCstNormalBookingComponent }
        ]
      },
      { path: 'add-cst-booking-rate-info', component: AddEditCstBookingRateComponent },

      {
        path: 'cst-booking-rate-info', children: [
          { path: '', component: CstBookingRateComponent },
          { path: 'edit/:id', component: AddEditCstBookingRateComponent }
        ]
      },
      { path: 'add-cst-sr-loan-info', component: AddEditCstSrLoanComponent },

      {
        path: 'cst-sr-loan-info', children: [
          { path: '', component: CstSrLoanComponent },
          { path: 'edit/:id', component: AddEditCstSrLoanComponent }
        ]
      },
      { path: 'add-cst-sr-loan-payment-info', component: AddEditCstSrLoanPaymentComponent },

      {
        path: 'cst-sr-loan-payment-info', children: [
          { path: '', component: CstSrLoanPaymentComponent },
          { path: 'edit/:id', component: AddEditCstSrLoanPaymentComponent }
        ]
      },
      { path: 'add-cst-sr-loan-return-info', component: AddEditCstSrLoanReturnComponent },

      {
        path: 'cst-sr-loan-return-info', children: [
          { path: '', component: CstSrLoanReturnComponent },
          { path: 'edit/:id', component: AddEditCstSrLoanReturnComponent }
        ]
      },
      { path: 'add-cst-paid-booking-info', component: AddEditCstPaidBookngComponent },

      {
        path: 'cst-paid-booking-info', children: [
          { path: '', component: CstPaidBookngInfoComponent },
          { path: 'edit/:id', component: AddEditCstPaidBookngComponent }
        ]
      },
      { path: 'cst-report', component: CstReportComponent },

      //Merchandising
      { path: 'add-fiber-composition', component: AddEditFiberCompositionComponent },

      {
        path: 'fiber-composition', children: [
          { path: '', component: FiberCompositionComponent },
          { path: 'edit/:id', component: AddEditFiberCompositionComponent }
        ]
      },
      { path: 'add-yarn-item-registration', component: AddEditYarnItemRegistrationComponent },

      {
        path: 'yarn-item-registration', children: [
          { path: '', component: YarnItemRegistrationComponent },
          { path: 'edit/:id', component: AddEditYarnItemRegistrationComponent }
        ]
      }

      //yarn-count-lookup      
      , { path: 'add-yarn-count-lookup', component: AddEditYarnCountLookupComponent },

      {
        path: 'yarn-count-lookup', children: [
          { path: '', component: YarnCountLookupComponent },
          { path: 'edit/:id', component: AddEditYarnCountLookupComponent },
          { path: 'detail/:id', component: YarnCountLookupDetailsComponent }
        ]
      }
      //reporting

      , { path: 'asset-report', component: AssetReportComponent }


      //Employee Salary Process

      , { path: 'add-salary-head', component: AddEditSalaryheadComponent },

      {
        path: 'salary-head', children: [
          { path: '', component: SalaryHeadComponent },
          { path: 'edit/:id', component: AddEditSalaryheadComponent }
        ]
      }

      , { path: 'add-salary-rule', component: AddEditSalaryruleComponent },

      {
        path: 'salary-rule', children: [
          { path: '', component: SalaryRuleComponent },
          { path: 'edit/:id', component: AddEditSalaryruleComponent }
        ]
      }


      , { path: 'add-attendance-pay-rule', component: AddEditAttnpayruleComponent },

      {
        path: 'attendance-pay-rule', children: [
          { path: '', component: EmpAttendancePayRuleComponent },
          { path: 'edit/:id', component: AddEditAttnpayruleComponent }
        ]
      }
      , { path: 'add-attendance-proc-salary', component: AddAttnprocSalaryComponent },
      {
        path: 'attendance-proc-salary', children: [
          { path: '', component: EmpMonthwiseAttnProcSalaryComponent },
          { path: 'edit/:id', component: ModifyAttnPrcSalaryComponent }
        ]
      }
      ,
      { path: 'modify-attn-salary-manipulation', component: ModifyAttnProcSalaryManipulationComponent },
      {
        path: 'attendance-salary-manipulation', children: [
          { path: '', component: EmpMonthwiseAttnProcSalaryManipulationComponent },
          { path: 'edit/:id', component: ModifyAttnProcSalaryManipulationComponent }
        ]
      },
      { path: 'rollback-monthwise-salary-process', component: MonthwiseSalaryProcessRollbackComponent }
      , { path: 'add-monthwise-salary-process', component: AddMonthlySalaryProcessComponent },
      {
        path: 'monthwise-salary-process', children: [
          { path: '', component: EmpMonthwiseSalaryProcessComponent },
          { path: 'edit/:id', component: AddMonthlySalaryProcessComponent }
        ]
      }

      , { path: 'add-emp-salary-info', component: AddEmpSalaryInfoComponent },

      {
        path: 'emp-salary-info', children: [
          { path: '', component: EmpSalaryInfoComponent },
          { path: 'edit/:id', component: AddEmpSalaryInfoComponent }
        ]
      }

      , { path: 'add-salary-manipulation-info', component: AddSalaryManipulationInfoComponent },

      {
        path: 'salary-manipulation-info', children: [
          { path: '', component: EmpSalaryManipulationInfoComponent },
          { path: 'edit/:id', component: AddSalaryManipulationInfoComponent }
        ]
      },
      { path: 'employee-salary-report', component: EmployeeSalaryReportComponent }


    ]
  },





  {
    path: '', component: FullwidthComponent,
    children: [
      {
        path: 'login',
        component: LoginComponent
      }
    ]
  },

  { path: '**', component: NotFoundComponent }

];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const RoutingComponents = [HomeComponent];
