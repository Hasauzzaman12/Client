import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, of, Subject, Subscription, throwError } from 'rxjs';
import { catchError, delay, finalize, map, tap } from 'rxjs/operators';
import {
  HttpClient,
  HttpHeaders,
  HttpErrorResponse,
} from '@angular/common/http';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { MatSnackBar } from '@angular/material/snack-bar';
import { AuthService } from './shared/auth.service';

@Injectable({
  providedIn: 'root'
})
export class ApiServiceService {

  //endpoint: string = '${environment.apiUrl}api/';
  endpoint: string = `${environment.apiUrl}api/`;
  acces_token: string | null = this._authService.getToken();


  constructor(private http: HttpClient,
    public router: Router,
    private _snackBar: MatSnackBar,
    private _authService: AuthService) { }


  //admin-menu

  getmenuList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'adminmenu');
  }

  getmoduleList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'adminmenu/getmodulelist');
  }

  addAdminMenu(data: any) {
    return this.http.post(`${this.endpoint}adminmenu`, data);
  }
  updateAdminMenu(data: any) {
    return this.http.put(this.endpoint + `adminmenu`, data);
  }

  getAdminMenuById(id: number | string) {
    return this.http.get<any>(this.endpoint + `adminmenu/${id}`);
  }


  checkduplicateMenuName(Name: any): Observable<any> {
    return this.http.get<any>(this.endpoint + `AdminMenu/isManuNameExist?Name=${Name}`);
  }


  //menu-permission

  getmenupermissionList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'AdminMenu/menupermissionlist');
  }
  getMenuPermissionByRoleId(id: number | string) {
    return this.http.get<any>(this.endpoint + `adminmenu/getMenuPermissionByRoleId?id=${id}`);
  }


  addAdminMenuPermission(data: any) {
    return this.http.post(`${this.endpoint}adminmenu/saveMenuPermission`, data);
  }

  updateMenuPermission(data: any) {
    return this.http.put(this.endpoint + `adminmenu/UpdateMenuPermission`, data);
  }

  checkduplicateRoleInMenuPermission(Id: any): Observable<any> {
    return this.http.get<any>(this.endpoint + `AdminMenu/isMenuPermissionRoleExist?Id=${Id}`);
  }



  //order-master
  addOrder(data: any) {
    return this.http.post(`${this.endpoint}order`, data);
  }
  updateOrder(data: any) {
    return this.http.put(this.endpoint + `order`, data);
  }
  getOrderList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'order');
  }

  getOrderMasterById(id: number | string) {
    return this.http.get<any>(this.endpoint + `order/${id}`);
  }

  getOrderListByOrderId(id: number | string) {
    return this.http.get<any>(this.endpoint + `order/getOrderListBookingByOrderId?id=${id}`);
  }


  deleteOrder(id: number | string) {
    return this.http.delete(this.endpoint + `order/${id}`);
  }

  getLatestOrderSLNO() {
    return this.http.get<any>(this.endpoint + 'order/getLatestOMSLNo');
  }


  // Company Service
  addCompany(data: any) {
    return this.http.post(`${this.endpoint}company`, data);
  }
  updateCompany(data: any) {
    return this.http.put(this.endpoint + `company`, data);
  }
  getCompanyList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'company');
  }

  getCompanyActiveList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'company/GetActiveCopanyList');
  }

  getCompanyListByUser(userId: number | string) {
    return this.http.get<any>(this.endpoint + `Company/getCompanyListByUser?userId=${userId}`);
  }

  deleteCompany(id: number | string) {
    return this.http.delete(this.endpoint + `company/${id}`);
  }

  getAdminCompanyById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `company/${id}`);
  }

  //Admin User Company Unit Role

  getAdminUserCompanyUnitRoleList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'AdminUserCompanyUnitRole');
  }

  getAdminUserCompanyUnitRoleByUser(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'AdminUserCompanyUnitRole/adminusercompanyunitrolebyuser');
  }

  getAdminUserCompanyUnitRoleById(id: number | string) {
    return this.http.get<any>(this.endpoint + `AdminUserCompanyUnitRole/${id}`);
  }

  getAdminUserCompanyUnitRoleByUserId(id: number | string) {
    return this.http.get<any>(this.endpoint + `AdminUserCompanyUnitRole/adminusercompanyunitrolebyuserid?id=${id}`);
  }

  checkduplicateAdminUserCompanyUnitRole(id: number | string): Observable<any> {
    return this.http.get<any>(this.endpoint + `AdminUserCompanyUnitRole/isCompanyUserCompanyUnitRoleExist?id=${id}`);
  }


  addAdminUserCompanyUnitRole(data: any) {
    return this.http.post(`${this.endpoint}AdminUserCompanyUnitRole`, data);
  }
  updateAdminUserCompanyUnitRole(data: any) {
    return this.http.put(this.endpoint + `AdminUserCompanyUnitRole`, data);
  }


  deleteAdminUserCompanyUnitRole(id: number | string) {
    return this.http.delete(this.endpoint + `AdminUserCompanyUnitRole/${id}`);
  }


  // Admin Unit
  addUnit(data: any) {
    return this.http.post(`${this.endpoint}adminunit`, data);
  }
  updateUnit(data: any) {
    return this.http.put(this.endpoint + `adminunit`, data);
  }
  getUnitList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'adminunit');
  }


  getAdminCompanyUnitById(id: number | string) {
    return this.http.get<any>(this.endpoint + `adminunit/${id}`);
  }

  getActiveUnitList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'adminunit/GetActiveAdminUnitList');
  }

  getUnitListByCompanyId(id: number | string) {
    return this.http.get<any>(this.endpoint + `AdminUnit/unitByComID?id=${id}`);
  }
  getUnitListByUserId(userId: number | string) {
    return this.http.get<any>(this.endpoint + `AdminUnit/unitByUserID?userId=${userId}`);
  }

  getUnitListByComUserId(userId: number | string, companyId: number | string) {
    return this.http.get<any>(this.endpoint + `AdminUnit/unitByComUserID?userId=${userId}&companyId=${companyId}`);

  }

  getAdminUnitsByUserId(companyId: number | string) {
    return this.http.get<any>(this.endpoint + `Auth/getAdminUnitsByUserId?companyId=${companyId}`);
  }

  checkduplicateCompanyUnit(Name: any, CompanyId: any): Observable<any> {
    return this.http.get<any>(this.endpoint + `adminunit/isCompanyUnitExist?Name=${Name} &CompanyId=${CompanyId}`);
  }


  deleteUnit(id: number | string) {
    return this.http.delete(this.endpoint + `adminunit/${id}`);
  }

  //Style Master service 

  addStyleMaster(data: any) {
    return this.http.post(`${this.endpoint}stylemaster`, data);
  }
  updateStyleMaster(data: any) {
    return this.http.put(this.endpoint + `stylemaster`, data);
  }
  getStyleMasterList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'stylemaster');
  }



  getStyleMasterById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `stylemaster/${id}`);
  }

  deleteStyleMaster(id: number | string) {
    return this.http.delete(this.endpoint + `stylemaster/${id}`);
  }

  getStyleMasterDetails(id: number | string) {
    return this.http.get<any>(this.endpoint + `stylemaster/${id}`);
  }
  sendStyleMasterToIe(id: number | string) {
    return this.http.get<any>(this.endpoint + `StyleMaster/sentToIe?id=${id}`);
  }
  getProductList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'StyleMaster/productList');
  }

  getstyleMasterByBuyerId(id: number | string) {
    return this.http.get<any>(this.endpoint + `StyleMaster/styleMasterByBuyerId?id=${id}`);
  }

  //Buyer Master service 

  getBuyerList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `buyer`);
  }

  //Get Active Buyer List
  getActiveBuyerList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `buyer/GetActiveBuyerList`);
  }

  addBuyerList(data: any) {
    return this.http.post(`${this.endpoint}buyer`, data);
  }

  updateBuyerMaster(data: any) {
    return this.http.put(this.endpoint + `buyer`, data);
  }

  getBuyerMasterById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `buyer/${id}`);
  }

  //season service 

  getSeasonList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `season`);
  }


  //Get Active Season List
  getActiveSeasonList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `season/GetActiveSeasonList`);
  }


  //Department

  // getDepartmentList(): Observable<any[]> {
  //   const headers = new HttpHeaders().set('Authorization', `Bearer ${this.acces_token}`);
  //   return this.http.get<any>(this.endpoint + 'department', { headers: headers });
  // }

  getDepartmentList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'department');
  }

  getActiveDepartmentList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'department/GetActiveDepartmentList');
  }

  addDepartment(data: any) {
    return this.http.post(`${this.endpoint}department`, data);
  }
  updateDepartment(data: any) {
    return this.http.put(this.endpoint + `department`, data);
  }

  getDepartmentById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `department/${id}`);
  }

  deleteDepartment(id: number | string) {
    return this.http.delete(this.endpoint + `department/${id}`);
  }

  getDepartmentForDdlFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `department/getDepartmentForDdlFiltered`, data);
  }
  getDepartmentsByCompany(companyID: number | string) {
    return this.http.get<any>(this.endpoint + `Department/getDepartmentsByCompany?companyID=${companyID}`);
  }

  //department-comapny

  getOnlyDepartmentList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'DepartmentCompany/GetActiveDepartmentList');
  }

  getDepartmentCompanyList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'DepartmentCompany/departmentCompanylist');
  }


  getDepartmenCompanyNewtList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'DepartmentCompany');
  }

  getdepartmentListByCompanyId(id: number | string) {
    return this.http.get<any>(this.endpoint + `DepartmentCompany/getDepartmentCompanyListByCompanyId?id=${id}`);
  }



  getdepartmentCompanyId(id: number | string) {
    return this.http.get<any>(this.endpoint + `DepartmentCompany/${id}`);
  }


  adddepartmentCompany(data: any) {
    return this.http.post(`${this.endpoint}DepartmentCompany`, data);
  }

  updatedepartmentCompany(data: any) {
    return this.http.put(this.endpoint + `DepartmentCompany`, data);
  }

  checkduplicatedepartmentCompany(Id: any): Observable<any> {
    return this.http.get<any>(this.endpoint + `DepartmentCompany/isDepartmentCompanyIdExist?Id=${Id}`);
  }

  deleteDepartmentCompany(id: number | string) {
    return this.http.delete(this.endpoint + `DepartmentCompany/${id}`);
  }



  //Section
  getSectionList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'HRSection');
  }


  addSection(data: any) {
    return this.http.post(`${this.endpoint}HRSection`, data);
  }
  updateSection(data: any) {
    return this.http.put(this.endpoint + `HRSection`, data);
  }

  getSectionById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `HRSection/${id}`);
  }
  getSectionByDepartmentId(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `HRSection/GetSectiontListByDepartment?Department_Id=${id}`);
  }


  deleteSection(id: number | string) {
    return this.http.delete(this.endpoint + `HRSection/${id}`);
  }


  //Designation

  getDesignationList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'designation');
  }


  getActiveDesignationList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'designation/GetActiveDesignationList');
  }

  addDesignation(data: any) {
    return this.http.post(`${this.endpoint}designation`, data);
  }
  updateDesignation(data: any) {
    return this.http.put(this.endpoint + `designation`, data);
  }

  getDesignationById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `designation/${id}`);
  }

  deleteDesignation(id: number | string) {
    return this.http.delete(this.endpoint + `designation/${id}`);
  }

  getDesignationListForDdlFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `designation/getDesignationForDdlFiltered`, data);
  }


  //employee pf


  getemployeepfList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'HRPFMaster');
  }

  addemployeepf(data: any) {
    return this.http.post(`${this.endpoint}HRPFMaster`, data);
  }
  updateemployeepf(data: any) {
    return this.http.put(this.endpoint + `HRPFMaster`, data);
  }

  getemployeepfById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `HRPFMaster/${id}`);
  }

  deleteemployeepf(id: number | string) {
    return this.http.delete(this.endpoint + `HRPFMaster/${id}`);
  }

  //Division

  getDivisionList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'Division');
  }

  addDivision(data: any) {
    return this.http.post(`${this.endpoint}Division`, data);
  }
  updateDivision(data: any) {
    return this.http.put(this.endpoint + `Division`, data);
  }

  getDivisionById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `Division/${id}`);
  }

  deleteDivision(id: number | string) {
    return this.http.delete(this.endpoint + `Division/${id}`);
  }
  //Country
  getCountryList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'country');
  }

  //Currency
  getCurrencyList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'CompanyLookupType/currencyList');
  }

  //payment Term List
  getPaymentTermList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'LookupType/paymentTermList');
  }

  //delivery Term List
  getDeliveryTermList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'LookupType/deliveryTermList');
  }

  //Certification


  addCertification(data: any) {
    return this.http.post(`${this.endpoint}certificationRateChart`, data);
  }
  updateCertification(data: any) {
    return this.http.put(this.endpoint + `certificationRateChart`, data);
  }
  getCertificationList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'certificationRateChart');
  }

  getCertificationById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `certificationRateChart/${id}`);
  }

  deleteCertification(id: number | string) {
    return this.http.delete(this.endpoint + `certificationRateChart/${id}`);
  }


  //AOP_Rate


  addAOPRate(data: any) {
    return this.http.post(`${this.endpoint}AopRateChart`, data);
  }
  updateAOPRate(data: any) {
    return this.http.put(this.endpoint + `AopRateChart`, data);
  }
  getAOPRateList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'AopRateChart');
  }

  getAOPRateById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `AopRateChart/${id}`);
  }

  deleteAOPRate(id: number | string) {
    return this.http.delete(this.endpoint + `AopRateChart/${id}`);
  }

  //IE Assumption

  addIEAssumption(data: any) {
    return this.http.post(`${this.endpoint}IEAssumption`, data);
  }
  updateIEAssumption(data: any) {
    return this.http.put(this.endpoint + `IEAssumption`, data);
  }
  getIEAssumptionList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'IEAssumption');
  }

  getAIEAssumptionById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `IEAssumption/${id}`);
  }

  deleteIEAssumption(id: number | string) {
    return this.http.delete(this.endpoint + `IEAssumption/${id}`);
  }
  sendIEAssumptionToCs(id: number | string) {
    return this.http.get<any>(this.endpoint + `IEAssumption/sentToCS?id=${id}`);
  }

  //Costsheet


  getCostSheetFabricYarnRateCalculation(data: any) {
    //return this.http.get<any>(this.endpoint + `Costsheet/getFabricSelectCalculation?id=${dT_Lookup_Id}`); 
    return this.http.post(`${this.endpoint}Costsheet/getFabricSelectCalculation`, data);
  }


  getFabricProcessLossByShadeandCompositionId(data: any) {
    //return this.http.get<any>(this.endpoint + `Costsheet/getFabricSelectCalculation?id=${dT_Lookup_Id}`); 
    return this.http.post(`${this.endpoint}Costsheet/getFabricProcessLossByShadeandCompositionId`, data);
  }



  addCostsheet(data: any) {
    return this.http.post(`${this.endpoint}Costsheet`, data);
  }
  updateCostsheet(data: any) {
    return this.http.put(this.endpoint + `Costsheet`, data);
  }
  getCostsheetList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'Costsheet');
  }

  getCostsheetById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `Costsheet/${id}`);
  }

  deleteCostsheet(id: number | string) {
    return this.http.delete(this.endpoint + `Costsheet/${id}`);
  }

  approveCostsheet(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `Costsheet/approveCostsheet?id=${id}`);
  }

  reviseCostSheet(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `Costsheet/reviseCostsheet?id=${id}`);
  }
  getDyeingList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'Costsheet/dyeingList');
  }
  getFabricTypeList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'Costsheet/fabricTypeList');
  }
  getCompositionList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'Costsheet/compositionList');
  }


  getGsmByFabricYarnId(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `Costsheet/getGsmByFabricYarnId?id=${id}`);
  }
  getKnittiingFabricByYarnId(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `Costsheet/getKnittingFabricDetailByFabricYarnId?id=${id}`);
  }

  getFabricYarnCountByYarnId(id: number | string, gsm: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `Costsheet/getFabricYarnCountByFabricYarnId?id=${id}&gsm=${gsm}`);
  }

  getYarnTypeList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'Costsheet/yarnTypeList');
  }


  getFabricByCostSheetId(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `Costsheet/getFabricByCostSheetId?id=${id}`);
  }




  //FabricShade
  getFabricShadeList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'FabricShade');
  }
  //GMTSDocuments
  getDocNo() {

    return this.http.get(this.endpoint + 'GMTSDocuments/getDocNo', { responseType: 'text' })
  }
  getGMTSDocumentsFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `GMTSDocuments/getGMTSDocumentsFiltered`, data);
  }
  getGmtsDocumentsAllDocumentList(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `GMTSDocuments/getGmtsDocumentsAllDocumentList`, data);
  }
  getGmtsDocumentsRecycleDocumentList(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `GMTSDocuments/getGmtsDocumentsRecycleDocumentList`, data);
  }
  addGMTSDocuments(data: any) {
    return this.http.post(`${this.endpoint}GMTSDocuments`, data);
  }

  updateGMTSDocuments(data: any) {
    return this.http.put(this.endpoint + `GMTSDocuments`, data);
  }

  getGMTSDocumentsList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'GMTSDocuments');
  }


  getGMTSDocumentsById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `GMTSDocuments/${id}`);
  }

  deletGMTSDocuments(id: number | string) {
    return this.http.delete(this.endpoint + `GMTSDocuments/${id}`);
  }

  deleteGMTSDocumentsDetails(doc_detail_Id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `GMTSDocuments/deleteGMTSDocumentsDetails?id=${doc_detail_Id}`);
  }
  recycleGMTSDocumentsDetails(doc_detail_Id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `GMTSDocuments/recycleGMTSDocumentsDetails?id=${doc_detail_Id}`);
  }
  postGMTSDocumentsType(data: any) {
    return this.http.post(`${this.endpoint}GMTSDocuments/postGMTSDocumentsType`, data);
  }
  putGMTSDocumentsType(data: any) {
    return this.http.put(this.endpoint + `GMTSDocuments/putGMTSDocumentsType`, data);
  }
  getGMTSDocumentsTypeById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `GMTSDocuments/getGMTSDocumentsTypeById?id=${id}`);
  }

  getGMTSDocumentTypeListByCompany(companyID: number | string, departmentId: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `GMTSDocuments/getGMTSDocumentTypeListByCompany?companyId=${companyID}&departmentId=${departmentId}`);
  }
  //UOM
  getUOMList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'Uom');
  }
  getUomsByType(type: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `Uom/getUomsByType?type=${type}`);
  }
  addUOM(data: any) {
    return this.http.post(`${this.endpoint}Uom`, data);
  }
  updateUOm(data: any) {
    return this.http.put(this.endpoint + `Uom`, data);
  }

  getUOMById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `Uom/${id}`);
  }

  deleteUOM(id: number | string) {
    return this.http.delete(this.endpoint + `Uom/${id}`);
  }
  //Embl Type
  getEmblList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'EmblType');
  }

  checkduplicatelookup(Name: any): Observable<any> {
    return this.http.get<any>(this.endpoint + `LookupType/isLookupTypeExist?Name=${Name}`);
  }






  addLookup(data: any) {
    return this.http.post(`${this.endpoint}LookupType`, data);
  }

  updateLookupType(data: any) {
    return this.http.put(this.endpoint + `LookupType`, data);
  }

  getLookupTypeList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'LookupType');
  }

  getLookupTypeListcompanywise(companyid: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `LookupType/GetLookupTypesCompanyWise?companyid=${companyid}`);
  }

  getLookupTypeById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `LookupType/${id}`);
  }

  deletelookup(id: number | string) {
    return this.http.delete(this.endpoint + `LookupType/${id}`);
  }

  //Company Lookup data

  checkduplicatecompanylookupType(id: number | string): Observable<any> {
    //return this.http.get<any>(this.endpoint + `LookupType/isLookupTypeExist?Name=${Name}`);
    return this.http.get<any>(this.endpoint + `CompanyLookupType/isCompanyLookupTypeExist?id=${id}`);
  }

  addCompanyLookupType(data: any) {
    return this.http.post(`${this.endpoint}CompanyLookupType`, data);
  }

  updateCompanyLookupType(data: any) {
    return this.http.put(this.endpoint + `CompanyLookupType`, data);
  }

  getLookupTypeListCompany(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'CompanyLookupType');
  }

  getLookupTypCompanyeById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CompanyLookupType/${id}`);
  }

  deleteCompanylookup(id: number | string) {
    return this.http.delete(this.endpoint + `CompanyLookupType/${id}`);
  }

  //LookUpDetails
  GetCompanyLookupDeailListById(lookupId: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CompanyLookupType/GetCompanyLookupDeailListById?lookupId=${lookupId}`);
  }
  getCompanyLookUpDetailsById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CompanyLookupType/getCompanyLookUpDetailsById?id=${id}`);
  }
  postCompanyLookUpDetails(data: any) {
    return this.http.post(`${this.endpoint}CompanyLookupType/postCompanyLookUpDetails`, data);
  }
  putCompanyLookUpDetails(data: any) {
    return this.http.put(this.endpoint + `CompanyLookupType/putCompanyLookUpDetails`, data);
  }

  //global Lookup data

  checkduplicategloballookup(id: number | string): Observable<any> {
    return this.http.get<any>(this.endpoint + `GlobalLookupType/isCompanyLookupTypeExist?id=${id}`);
  }

  addGlobalLookup(data: any) {
    return this.http.post(`${this.endpoint}GlobalLookupType`, data);
  }

  updateGlobalLookupType(data: any) {
    return this.http.put(this.endpoint + `GlobalLookupType`, data);
  }

  getLookupTypeListGlobal(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'GlobalLookupType');
  }

  getLookupTypeGlobalById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `GlobalLookupType/${id}`);
  }

  deleteGloballookup(id: number | string) {
    return this.http.delete(this.endpoint + `GlobalLookupType/${id}`);
  }

  //fabric Yarn count data
  addfabricyarncount(data: any) {
    return this.http.post(`${this.endpoint}FabricYarnCount`, data);
  }

  updatefabricyarncount(data: any) {
    return this.http.put(this.endpoint + `FabricYarnCount`, data);
  }

  getfabricyarncountList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'FabricYarnCount');
  }

  getfabricyarncountById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `FabricYarnCount/${id}`);
  }

  deletefabricyarncount(id: number | string) {
    return this.http.delete(this.endpoint + `FabricYarnCount/${id}`);
  }

  checkduplicatefabricyarncount(id: number | string): Observable<any> {
    //return this.http.get<any>(this.endpoint + `LookupType/isLookupTypeExist?Name=${Name}`);
    return this.http.get<any>(this.endpoint + `FabricYarnCount/isFabricYarnCountExist?id=${id}`);
  }

  GetCompanyLookupTypefabricWise(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CompanyLookupType/GetLookupListfabricWise?id=${id}`);
  }

  GetCompanyLookupTypeyarnWise(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CompanyLookupType/GetLookupListfabricWise?id=${id}`);
  }


  //yarn rate data
  addYarnRate(data: any) {
    return this.http.post(`${this.endpoint}YarnRate`, data);
  }

  updateYarnRate(data: any) {
    return this.http.put(this.endpoint + `YarnRate`, data);
  }

  getYarnRateList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'YarnRate');
  }


  getYarnRateById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `YarnRate/${id}`);
  }

  deleteYarnRate(id: number | string) {
    return this.http.delete(this.endpoint + `YarnRate/${id}`);
  }

  checkduplicateYarnRate(id: number | string): Observable<any> {
    return this.http.get<any>(this.endpoint + `YarnRate/isYarnRateExist?id=${id}`);
  }

  //Knitting _rate

  addknittingrate(data: any) {
    return this.http.post(`${this.endpoint}KnittingRate`, data);
  }

  updateknittingrate(data: any) {
    return this.http.put(this.endpoint + `KnittingRate`, data);
  }

  getknittinrateList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'KnittingRate');
  }


  getknittingrateById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `KnittingRate/${id}`);
  }

  deleteknittingrate(id: number | string) {
    return this.http.delete(this.endpoint + `KnittingRate/${id}`);
  }

  checkduplicateknittingrate(id: number | string): Observable<any> {
    return this.http.get<any>(this.endpoint + `KnittingRate/isKnittingRateExist?id=${id}`);
  }


  //Yarn-dyeing-rate

  addyarndyeingrate(data: any) {
    return this.http.post(`${this.endpoint}YarnDyeingRate`, data);
  }

  updateyarndyeingrate(data: any) {
    return this.http.put(this.endpoint + `YarnDyeingRate`, data);
  }

  getyarndyeingrateList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'YarnDyeingRate');
  }


  getyarndyeingrateById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `YarnDyeingRate/${id}`);
  }

  deleteyarndyeingrate(id: number | string) {
    return this.http.delete(this.endpoint + `YarnDyeingRate/${id}`);
  }


  checkduplicateyarndyeingrate(id: number | string): Observable<any> {
    return this.http.get<any>(this.endpoint + `YarnDyeingRate/isYarnDyeingRateExist?id=${id}`);
  }

  //fabric-dyeing-rate

  addfabricdyeingrate(data: any) {
    return this.http.post(`${this.endpoint}FabricDyeingRate`, data);
  }

  updatefabricdyeingrate(data: any) {
    return this.http.put(this.endpoint + `FabricDyeingRate`, data);
  }

  getfabricdyeingrateList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'FabricDyeingRate');
  }


  getfabricdyeingrateById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `FabricDyeingRate/${id}`);
  }

  deletefabricdyeingrate(id: number | string) {
    return this.http.delete(this.endpoint + `FabricDyeingRate/${id}`);
  }

  checkduplicatefabricdyeingrate(id: number | string, buyerId: number | string): Observable<any> {
    return this.http.get<any>(this.endpoint + `FabricDyeingRate/isFabricDyeingRateExist?id=${id}&buyerId=${buyerId}`);
  }


  //fabric-shade
  getfabricshadeList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'FabricShade');
  }


  //Dyeing Technique
  getDyeingTechniqueList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'DyeingTechnique');
  }

  getDyeingTechniqueById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `DyeingTechnique/${id}`);
  }

  //Dyeing Rate Calculation


  GetYarnDyeingRateDetailByFabricShadeAndYarnDyeingId(FabricShadeId: number | string, CompositionId: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `YarnDyeingRate/getYarnDyeingRateDetailByFabricShadeAndYarnDyeingId?FabricShadeId=${FabricShadeId} &CompositionId=${CompositionId}`);
  }


  getFabricDyeingRateDetailByFabricShadeAndCompositionId(FabricShadeId: number | string, CompositionId: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `FabricDyeingRate/getFabricDyeingRateDetailByFabricShadeAndCompositionId?FabricShadeId=${FabricShadeId} &CompositionId=${CompositionId}`);
  }

  // getFabricDyeingRateDetailByFabricShadeAndCompositionId(FabricShadeId:number|string, CompositionId:number|string, Quantity:number|string):Observable<any[]>{
  //   return this.http.get<any>(this.endpoint + `FabricDyeingRate/getFabricDyeingRateDetailByFabricShadeAndCompositionId?FabricShadeId=${FabricShadeId} &CompositionId=${CompositionId} &Quantity=${Quantity}`);
  // }

  //Yarn Rate Calculation

  getYarnRateDetailByYarnCountIdAndYarnTypeId(YarnCountId: number | string, YarnTypeId: number | string): Observable<any[]> {
    //return this.http.get<any>(this.endpoint + `YarnRate/getYarnRateDetailByYarnCountIdAndYarnTypeId?YarnCountId=${YarnCountId} && YarnTypeId=${YarnTypeId}`);
    return this.http.get<any>(this.endpoint + `YarnRate/getYarnRateDetailByYarnCountIdAndYarnTypeId?YarnCountId=${YarnCountId}&YarnTypeId=${YarnTypeId}`);
  }

  getOthersRateById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `OthersRate/${id}`);
  }


  getKnittingRateDetailByFabricTypeIdAndFabricDetailsId(FabricTypeId: number | string, FabricDetailsId: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `KnittingRate/getKnittingRateDetailByFabricTypeIdAndFabricDetailsId?FabricTypeId=${FabricTypeId}&FabricDetailsId=${FabricDetailsId}`);
  }



  //Trims Master


  addTrims(data: any) {
    return this.http.post(`${this.endpoint}TrimsMaster`, data);
  }
  updateTrims(data: any) {
    return this.http.put(this.endpoint + `TrimsMaster`, data);
  }
  getTrimList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'TrimsMaster');
  }

  getTrimById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `TrimsMaster/${id}`);
  }

  deleteTrimById(id: number | string) {
    return this.http.delete(this.endpoint + `TrimsMaster/${id}`);
  }
  getTrimMasterByQuantitity(id: number | string, quantity: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `TrimsMaster/getTrimMasterByQuantitity?id=${id}&quantity=${quantity}`);
  }

  //ProcessLoss

  addProcessloss(data: any) {
    return this.http.post(`${this.endpoint}Processloss`, data);
  }

  updateProcessloss(data: any) {
    return this.http.put(this.endpoint + `Processloss`, data);
  }

  getProcesslosseList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'Processloss');
  }


  getProcesslossById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `Processloss/${id}`);
  }

  deleteProcessloss(id: number | string) {
    return this.http.delete(this.endpoint + `Processloss/${id}`);
  }

  //Employee
  getEmployeeList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'Employee');
  }
  getEmployeeShiftList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'Employee/getEmployeeShiftList');
  }


  getActiveEmployeeList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'Employee/getActiveEmployees');
  }

  getEmployeeListIndexFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `Employee/getEmployeeListIndexFiltered`, data);
  }
  getEmployeeByCompanyID(comId: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `Employee/getEmployeeByCompanyID?ComID=${comId}`);
  }
  getEmployeeListIndex(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'Employee/getEmployeeList');
  }

  getEmployeeListFilterData(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `Employee/getEmployeeListFiltered`, data);
  }

  getEmployeesFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `Employee/getEmployeesFiltered`, data);
  }
  getEmployeesFilteredForAc(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `Employee/getEmployeesFilteredForAc`, data);
  }
  getEmployeesFilteredForLeave(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `Employee/getEmployeesFilteredForLeave`, data);
  }


  getEmployeeById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `Employee/${id}`);
  }


  addEmployee(data: any) {
    return this.http.post(`${this.endpoint}Employee`, data);
  }


  addAssetEmployee(data: any) {
    return this.http.post(`${this.endpoint}Employee/addEmployeeList`, data);
  }


  updateEmployee(data: any) {
    return this.http.put(this.endpoint + `Employee`, data);
  }

  updateAssetEmployee(data: any) {
    return this.http.put(this.endpoint + `Employee/updateEmployeeList`, data);
  }

  getEmployeeAllDocumentList(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `Employee/getEmployeeAllDocumentList`, data);
  }
  getEmployeeCountSummary(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `Employee/getEmployeeCountSummary`, data);
  }

  deleteEmployee(id: number | string) {
    return this.http.delete(this.endpoint + `Employee/${id}`);
  }
  getJobLocationList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'LookupType/jobLocationList');
  }
  getEmpGroupList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'LookupType/empGroupList');
  }

  getDocumentTypeList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'companylookuptype/Document_Type_List');
  }


  getReligionList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'LookupType/religionList');
  }
  getNationalityList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'LookupType/nationalityList');
  }
  getLanguageList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'LookupType/languageList');
  }
  getResidentListt(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'LookupType/residentList');
  }
  getDistrictList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'LookupType/districtList');
  }
  getBloodGroupList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'LookupType/bloodGroupList');
  }
  getGenderList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'LookupType/genderList');
  }
  getResultTypeList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'LookupType/resultTypeList');
  }
  getCustomerGroupList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'LookupType/customerGroupList');
  }
  getCustomerTypeList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'LookupType/customerType');
  }
  getCreditLimitTypeList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'LookupType/getCreditLimitTypeList');
  }
  getVehicleLocationList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'LookupType/getVehicleLocationList');
  }
  getCustodianByCompanyId(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `Custodian/getCustodianListByCompany?CompanyId=${id}`);
  }



  getApplicationTypeList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'LookupType/applicationTypeList');
  }
  getApplicationReasonReplacementList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'LookupType/applicationReasonReplaceList');
  }

  getHRDocumentList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'LookupType/getHRDocumentList');
  }

  getGMTSDocumentTypeList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'LookupType/getGMTSDocumentTypeList');
  }
  getIsEmployeeIdExist(id: number | string): Observable<any> {
    return this.http.get<any>(this.endpoint + `Employee/isEmployeeIdExist?EmployeeId=${id}`);
  }


  getCarList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'companylookuptype/carList');
  }

  getComputerList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'companylookuptype/computerList');
  }

  getRecruitmenttypeList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'companylookuptype/Recruitment_type_List');
  }

  getRecruitmentmodeList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'companylookuptype/Recruitment_mode_List');
  }


  //custodian

  getEmployeeCustodian(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'Custodian');
  }
  getCustodianListFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `Custodian/getCustodianListFiltered`, data);
  }
  getCustodianListByUser(userId: number | string) {
    return this.http.get<any>(this.endpoint + `Custodian/getCustodianListByUser?userId=${userId}`);
  }
  addCustodian(data: any) {
    return this.http.post(`${this.endpoint}Custodian`, data);
  }

  updateCustodian(data: any) {
    return this.http.put(this.endpoint + `Custodian`, data);
  }

  getCustodianById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `Custodian/${id}`);
  }

  deleteCustodian(id: number | string) {
    return this.http.delete(this.endpoint + `Custodian/${id}`);
  }


  // sub-custodian
  getEmployeeSubCustodian(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'SubCustodian');
  }
  getSubCustodianListFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `SubCustodian/getSubCustodianListFiltered`, data);
  }
  getSubCustodianByCustodian(custodianId: number | string) {
    return this.http.get<any>(this.endpoint + `SubCustodian/getSubCustodianByCustodian?custodianId=${custodianId}`);
  }
  addSubCustodian(data: any) {
    return this.http.post(`${this.endpoint}SubCustodian`, data);
  }
  updateSubCustodian(data: any) {
    return this.http.put(this.endpoint + `SubCustodian`, data);
  }


  getSubCustodianById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `SubCustodian/${id}`);
  }

  deleteSubCustodian(id: number | string) {
    return this.http.delete(this.endpoint + `SubCustodian/${id}`);
  }


  //employee-appication-requisition

  addEmployeeApplication(data: any) {
    return this.http.post(`${this.endpoint}EmployeeApplication`, data);
  }
  updateEmployeeApplication(data: any) {
    return this.http.put(this.endpoint + `EmployeeApplication`, data);
  }
  getEmployeeApplicationList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'EmployeeApplication');
  }

  deleteEmployeeApplication(id: number | string) {
    return this.http.delete(this.endpoint + `EmployeeApplication/${id}`);
  }

  getEmployeeApplicationById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `EmployeeApplication/${id}`);
  }


  //employee_daily_attendance

  addEmployeeAttendance(data: any) {
    return this.http.post(`${this.endpoint}DailyAttendance`, data);
  }
  updateEmployeeAttendance(data: any) {
    return this.http.put(this.endpoint + `DailyAttendance`, data);
  }
  getEmployeeAttendanceList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'DailyAttendance');
  }

  deleteEmployeeAttendance(id: number | string) {
    return this.http.delete(this.endpoint + `DailyAttendance/${id}`);
  }

  getEmployeeAttendanceById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `DailyAttendance/${id}`);
  }

  updateEmployeeAttendanceManual(data: any) {
    return this.http.put(this.endpoint + `MonthlyAttendance/DailyManulaAttendanceRequestUpdate`, data);
  }
  getMonthlyAttendanceById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `MonthlyAttendance/${id}`);
  }
  updateMonthlyManualAttendanceRequest(data: any) {
    return this.http.post(`${this.endpoint}DailyAttendance/updateMonthlyManualAttendanceRequest`, data);
  }

  manulaAttendanceTimeUpdate(data: any) {
    return this.http.put(this.endpoint + `MonthlyAttendance/manulaAttendanceTimeUpdate`, data);
  }
  getAttendanceApplicationFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `MonthlyAttendance/getAttendanceApplicationFiltered`, data);
  }
  // getEmployeeAttendanceSummary(data: any) {
  //   return this.http.put(this.endpoint + `DailyAttendance/getattendancesummary`, data);
  // }
  getAttnRequestTypeList() {
    return this.http.get<any>(this.endpoint + 'CompanyLookupType/getAttnRequestTypeList');
  }


  getEmployeeAttendanceSummary(EmployeeCode: string, Year: any, Month: any): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `DailyAttendance/searchAttendances?EmployeeCode=${EmployeeCode} &Year=${Year}&Month=${Month}`);
  }

  getMonthlyAttendancePendingSummary(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `DailyAttendance/searchAttendancesPending`, data);
  }

  addHRMonthlyAttendanceProcess(data: any) {
    return this.http.post(`${this.endpoint}DailyAttendance/SaveMonthlyAttendanceProcess`, data);
  }

  getEmployeeMonthlyAttendanceListFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `DailyAttendance/getMonthlyAttendanceListFiltered`, data);
  }


  getDailyManualAttendancePendingdListFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `DailyAttendance/getDailyManualAttendancePendingdListFiltered`, data);
  }
  getDailyManualAttendanceApprovedListFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `DailyAttendance/getDailyManualAttendanceApprovedListFiltered`, data);
  }

  resetManualAttendanceRequest(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `DailyAttendance/resetManualAttendanceRequest?id=${id}`);
  }

  // Geo Country Service

  checkduplicategeocountry(id: number | string): Observable<any> {
    return this.http.get<any>(this.endpoint + `GeoCountry/isGeoCountryExist?txt=${id}`);
  }

  addGeoCountry(data: any) {
    return this.http.post(`${this.endpoint}GeoCountry`, data);
  }
  updateGeoCountry(data: any) {
    return this.http.put(this.endpoint + `GeoCountry`, data);
  }
  getGeoCountryList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'GeoCountry');
  }

  deleteGeoCountry(id: number | string) {
    return this.http.delete(this.endpoint + `GeoCountry/${id}`);
  }

  getGeoCountryById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `GeoCountry/${id}`);
  }

  // Geo Region Service

  checkduplicategeoregion(id: number | string): Observable<any> {
    return this.http.get<any>(this.endpoint + `GeoRegion/isGeoRegionExist?txt=${id}`);
  }
  //GetGeoRegionisExist

  addGeoRegion(data: any) {
    return this.http.post(`${this.endpoint}GeoRegion`, data);
  }
  updateGeoRegion(data: any) {
    return this.http.put(this.endpoint + `GeoRegion`, data);
  }
  getGeoRegionList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'GeoRegion');
  }

  deleteGeoRegion(id: number | string) {
    return this.http.delete(this.endpoint + `GeoRegion/${id}`);
  }

  getGeoRegionById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `GeoRegion/${id}`);
  }

  // Geo Zone Service

  isGeoZoneExist(id: number | string): Observable<any> {
    return this.http.get<any>(this.endpoint + `GeoZone/isGeoZoneExist?txt=${id}`);
  }

  addGeoZone(data: any) {
    return this.http.post(`${this.endpoint}GeoZone`, data);
  }
  updateGeoZone(data: any) {
    return this.http.put(this.endpoint + `GeoZone`, data);
  }
  getGeoZoneList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'GeoZone');
  }

  deleteGeoZone(id: number | string) {
    return this.http.delete(this.endpoint + `GeoZone/${id}`);
  }

  getGeoZoneById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `GeoZone/${id}`);
  }

  // Geo Territory Service

  isGeoTerritoryExist(id: number | string): Observable<any> {
    return this.http.get<any>(this.endpoint + `GeoTerritory/isGeoTerritoryExist?txt=${id}`);
  }

  addGeoTerritory(data: any) {
    return this.http.post(`${this.endpoint}GeoTerritory`, data);
  }
  updateGeoTerritory(data: any) {
    return this.http.put(this.endpoint + `GeoTerritory`, data);
  }
  getGeoTerritoryList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'GeoTerritory');
  }

  deleteGeoTerritory(id: number | string) {
    return this.http.delete(this.endpoint + `GeoTerritory/${id}`);
  }

  getGeoTerritoryById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `GeoTerritory/${id}`);
  }


  //fabric-booking


  isFabricBookingExist(id: number | string): Observable<any> {
    return this.http.get<any>(this.endpoint + `Booking/isGeoTerritoryExist?txt=${id}`);
  }

  addFabricbooking(data: any) {
    return this.http.post(`${this.endpoint}Booking`, data);
  }
  updateFabricbooking(data: any) {
    return this.http.put(this.endpoint + `Booking`, data);
  }
  getFabricbookingList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'Booking');
  }

  deleteFabricbooking(id: number | string) {
    return this.http.delete(this.endpoint + `Booking/${id}`);
  }

  getFabricbookingById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `Booking/${id}`);
  }

  getLatestFabricBookingSLNO(): any {
    return this.http.get<any>(this.endpoint + 'Booking/getlastbookingno');
  }


  GetCostSheetListByBuyerIdandStyleId(BuyerId: number | string, StyleMasterId: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `Booking/getcostsheetbybuyerandstyle?BuyerId=${BuyerId} &StyleMasterId=${StyleMasterId}`);
  }

  GetOrderListByBuyerIdandStyleId(BuyerId: number | string, StyleMasterId: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `Booking/getbuyerorderbybuyerandstyle?BuyerId=${BuyerId} &StyleMasterId=${StyleMasterId}`);
  }


  Getbookingcolordetailsbyid(id: number | string): Observable<any> {
    return this.http.get<any>(this.endpoint + `Booking/getbookingcolordetailsbyid?id=${id}`);
  }

  //supplier

  getSuulierList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'Supplier');
  }
  getSuppliersFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `Supplier/getSuppliersFiltered`, data);
  }
  getAjflSupplierList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'Supplier/getAjflSuppliers');
  }
  addSupplier(data: any) {
    return this.http.post(`${this.endpoint}Supplier`, data);
  }
  updateSupplier(data: any) {
    return this.http.put(this.endpoint + `Supplier`, data);
  }
  getSupplierList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'Supplier');
  }

  getSupplierById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `Supplier/${id}`);
  }

  deleteSupplier(id: number | string) {
    return this.http.delete(this.endpoint + `Supplier/${id}`);
  }
  getSupplierGroupList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'CompanyLookupType/supplierGroupList');
  }

  // Lookup value Service

  // isInvlookupvalueExist(id:number|string):Observable<any>{
  //   return this.http.get<any>(this.endpoint + `Invlookupvalue/isInvlookupvalueExist?txt=${id}`);
  // }

  addInvlookupvalue(data: any) {
    return this.http.post(`${this.endpoint}Invlookupvalue`, data);
  }
  updateInvlookupvalue(data: any) {
    return this.http.put(this.endpoint + `Invlookupvalue`, data);
  }
  getInvlookupvalueList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'Invlookupvalue');
  }

  getInvlookupList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'Invlookup');
  }

  deleteInvlookupvalue(id: number | string) {
    return this.http.delete(this.endpoint + `Invlookupvalue/${id}`);
  }

  getInvlookupvalueById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `Invlookupvalue/${id}`);
  }
  //Customer
  getCustomerNo() {
    // return this.http.get<any>(this.endpoint + 'Customer/getCustomerNo');
    return this.http.get(this.endpoint + 'Customer/getCustomerNo', { responseType: 'text' })
  }

  getCustomerList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'Customer');
  }
  getCfCustomerList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'Customer/getCfCustomers');
  }
  addCustomer(data: any) {
    return this.http.post(`${this.endpoint}Customer`, data);
  }
  updateCustomer(data: any) {
    return this.http.put(this.endpoint + `Customer`, data);
  }


  getCustomerById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `Customer/${id}`);
  }

  deleteCustomer(id: number | string) {
    return this.http.delete(this.endpoint + `Customer/${id}`);
  }

  //SalesOrder
  getSONO() {
    return this.http.get<any>(this.endpoint + 'SalesOrder/getSONo');
  }
  getSalesOrderList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'SalesOrder');
  }
  getSalesOrdersFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `SalesOrder/getSalesOrdersFiltered`, data);
  }
  addSalesOrder(data: any) {
    return this.http.post(`${this.endpoint}SalesOrder`, data);
  }
  updateSalesOrder(data: any) {
    return this.http.put(this.endpoint + `SalesOrder`, data);
  }


  getSalesOrderById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `SalesOrder/${id}`);
  }
  getSOByCustomerId(customerId: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `SalesOrder/getSOByCustomerId?CustomerId=${customerId}`);
  }

  deleteSalesOrder(id: number | string) {
    return this.http.delete(this.endpoint + `SalesOrder/${id}`);
  }
  //DeliveryChallan
  getDCNO() {
    return this.http.get<any>(this.endpoint + 'DeliveryChallan/getChallanNo');
  }
  getDeliveryChallanList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'DeliveryChallan');
  }
  addDeliveryChallan(data: any) {
    return this.http.post(`${this.endpoint}DeliveryChallan`, data);
  }
  updateDeliveryChallan(data: any) {
    return this.http.put(this.endpoint + `DeliveryChallan`, data);
  }


  getDeliveryChallanById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `DeliveryChallan/${id}`);
  }

  deleteDeliveryChallan(id: number | string) {
    return this.http.delete(this.endpoint + `DeliveryChallan/${id}`);
  }
  getSoWiseDeliveryChallan(soId: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `DeliveryChallan/getSoWiseDeliveryChallan?SoID=${soId}`);
  }
  getDCByCustomerId(customerId: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `DeliveryChallan/getDCByCustomerId?CustomerId=${customerId}`);
  }

  //Sales Return
  getSRENO() {
    return this.http.get<any>(this.endpoint + 'SalesReturn/getSRENo');
  }
  getSalesReturnList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'SalesReturn');
  }
  addSalesReturn(data: any) {
    return this.http.post(`${this.endpoint}SalesReturn`, data);
  }
  updateSalesReturnn(data: any) {
    return this.http.put(this.endpoint + `SalesReturn`, data);
  }

  getSalesReturnById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `SalesReturn/${id}`);
  }

  deleteSalesReturn(id: number | string) {
    return this.http.delete(this.endpoint + `SalesReturn/${id}`);
  }
  getDCWiseSalesReturn(dcId: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `SalesReturn/getDCWiseSalesReturn?DcID=${dcId}`);
  }
  //Item
  getItemList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'Item');
  }
  getItemsListByUnitID(unitID: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `Item/getItemsListByUnitID?UnitID=${unitID}`);
  }
  getCfItemsListByUnitID(unitID: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `Item/getCfItemsListByUnitID?UnitID=${unitID}`);
  }
  getCfItemsListBySubCategory(subCategoryId: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `Item/getCfItemsListBySubCategory?subCategoryId=${subCategoryId}`);
  }
  getCfItemsListByCategory(categoryId: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `Item/getCfItemsListByCategory?categoryId=${categoryId}`);
  }
  addItem(data: any) {
    return this.http.post(`${this.endpoint}Item`, data);
  }
  updateItem(data: any) {
    return this.http.put(this.endpoint + `Item`, data);
  }

  getItemById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `Item/${id}`);
  }

  deleteItem(id: number | string) {
    return this.http.delete(this.endpoint + `Item/${id}`);
  }
  getItemByZone(zoneID: number | string, itemID: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `Item/getItemByZone?ZoneId=${zoneID}&ItemId=${itemID}`);
  }

  getItemDataForSo(zoneID: number | string, itemID: number | string, customerId: number | string, warehouseId: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `Item/getItemDataForSo?ZoneId=${zoneID}&ItemId=${itemID}&customerId=${customerId}&warehouseId=${warehouseId}`);
  }
  //ItemDiscountPolicy
  getItemDiscountPolicyList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'ItemDiscountPolicy');
  }
  addItemDiscountPolicy(data: any) {
    return this.http.post(`${this.endpoint}ItemDiscountPolicy`, data);
  }
  updateItemDiscountPolicy(data: any) {
    return this.http.put(this.endpoint + `ItemDiscountPolicy`, data);
  }

  getItemDiscountPolicyById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `ItemDiscountPolicy/${id}`);
  }
  //Category
  getCategoryList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'InvCategory');
  }
  getCfInvCategoriesList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'InvCategory/getCfInvCategoriesList');
  }
  getSubCategoryByCatID(catID: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `InvCategory/getSubCategoryByCatID?CatID=${catID}`);
  }
  addCategory(data: any) {
    return this.http.post(`${this.endpoint}InvCategory`, data);
  }
  updatCategory(data: any) {
    return this.http.put(this.endpoint + `InvCategory`, data);
  }

  getCategoryById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `InvCategory/${id}`);
  }

  deleteCategory(id: number | string) {
    return this.http.delete(this.endpoint + `InvCategory/${id}`);
  }
  //SubCategory
  getSubCategoryList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'InvSubCategory');
  }
  getCfSubCategoryList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'InvSubCategory/getCfSubCategoryList');
  }
  addSubCategory(data: any) {
    return this.http.post(`${this.endpoint}InvSubCategory`, data);
  }
  updatSubCategory(data: any) {
    return this.http.put(this.endpoint + `InvSubCategory`, data);
  }

  getSubCategoryById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `InvSubCategory/${id}`);
  }

  deleteSubCategory(id: number | string) {
    return this.http.delete(this.endpoint + `InvSubCategory/${id}`);
  }
  //Brand
  getBrandList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'InvBrand');
  }
  getSubBrandByBrandID(brandID: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `InvBrand/getSubBrandByBrandID?BrandID=${brandID}`);
  }
  addBrand(data: any) {
    return this.http.post(`${this.endpoint}InvBrand`, data);
  }
  updatBrand(data: any) {
    return this.http.put(this.endpoint + `InvBrand`, data);
  }

  getBrandById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `InvBrand/${id}`);
  }

  deleteBrand(id: number | string) {
    return this.http.delete(this.endpoint + `InvBrand/${id}`);
  }
  //SubBrand
  getSubBrandList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'InvSubBrand');
  }
  addSubBrand(data: any) {
    return this.http.post(`${this.endpoint}InvSubBrand`, data);
  }
  updateSubBrand(data: any) {
    return this.http.put(this.endpoint + `InvSubBrand`, data);
  }

  getSubBrandById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `InvSubBrand/${id}`);
  }

  deleteSubBrand(id: number | string) {
    return this.http.delete(this.endpoint + `InvSubBrand/${id}`);
  }
  //InvItemGroup
  getInvItemGroupList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'InvItemGroup');
  }
  //InvRawMaterial
  getInvRawMaterialList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'InvRawMaterial');
  }
  addInvRawMaterial(data: any) {
    return this.http.post(`${this.endpoint}InvRawMaterial`, data);
  }
  updateInvRawMaterial(data: any) {
    return this.http.put(this.endpoint + `InvRawMaterial`, data);
  }

  getInvRawMaterialById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `InvRawMaterial/${id}`);
  }
  //WareHouse
  getWarehouseList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'Warehouse');
  }
  addWarehouse(data: any) {
    return this.http.post(`${this.endpoint}Warehouse`, data);
  }
  updateWarehouse(data: any) {
    return this.http.put(this.endpoint + `Warehouse`, data);
  }


  getWarehouseById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `Warehouse/${id}`);
  }


  getYearList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'companylookuptype/yearList');
  }

  getMonthList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'companylookuptype/monthList');
  }

  getAttendanceStatusList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'companylookuptype/attendanceStatustypelist');
  }

  getLeaveTypeList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'companylookuptype/leavetypelist');
  }


  getLeaveTypeFromLeaveList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'HRLeaveType');
  }



  getLeaveReasonList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'companylookuptype/leavereasonlist');
  }
  getHRLeaveReasoneByLeaveType(leaveTypeId: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `HRLeaveReason/getHRLeaveReasoneByLeaveType?leaveTypeId=${leaveTypeId}`);
  }
  getLeaveUOMList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'companylookuptype/leaveuomlist');
  }

  opts: any = [];
  getAutoCompleteCustomerData() {
    return this.opts.length ?
      of(this.opts) :
      this.http.get(this.endpoint + 'Customer').pipe(tap(data => this.opts = data))
  }

  getAutoCompleteEmployeeNameData() {
    return this.opts.length ?
      of(this.opts) :
      this.http.get(this.endpoint + 'Employee/getActiveEmployees').pipe(tap(data => this.opts = data))
  }
  //AssetOwner
  getAssetOwnerList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'AssetOwner');
  }
  addAssetOwner(data: any) {
    return this.http.post(`${this.endpoint}AssetOwner`, data);
  }
  updateAssetOwner(data: any) {
    return this.http.put(this.endpoint + `AssetOwner`, data);
  }
  getAssetOwnerById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `AssetOwner/${id}`);
  }
  // AssetItemCategory
  getAssetItemCategoryList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'AssetItemCategory');
  }
  // AssetItemGroup
  getAssetItemGroupList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'AssetItemGroup');
  }
  //AssetBook
  getAssetBookList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'AssetBook');
  }
  getAssetBookingFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `AssetBook/getAssetBookingFiltered`, data);
  }
  getAssetForDdlFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `AssetBook/getAssetForDdlFiltered`, data);
  }
  getAvilableAssetBooking(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'AssetBook/getAvilableAssetBooking');
  }
  getAssetVehicleDocFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `AssetBook/getAssetVehicleDocFiltered`, data);
  }
  getAssetForMaintenance(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'AssetBook/getAssetForMaintenance');
  }
  getAvilableAssetBookingEdit(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `AssetBook/getAvilableAssetBookingEdit?id=${id}`);
  }
  getInstalledAsset(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'AssetBook/getInstalledAsset');
  }
  getInstalledAssetEdit(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `AssetBook/getInstalledAssetEdit?id=${id}`);
  }
  getMaintenanceReceiveAsset(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'AssetBook/getMaintenanceReceiveAsset');
  }
  getMaintenanceReceiveAssetEdit(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `AssetBook/getMaintenanceReceiveAssetEdit?id=${id}`);
  }
  addAssetBook(data: any) {
    return this.http.post(`${this.endpoint}AssetBook`, data);
  }
  updateAssetBook(data: any) {
    return this.http.put(this.endpoint + `AssetBook`, data);
  }

  getAssetBookById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `AssetBook/${id}`);
  }

  deleteAssetBook(id: number | string) {
    return this.http.delete(this.endpoint + `AssetBook/${id}`);
  }
  //Compliance
  getComplianceCode() {
    return this.http.get(this.endpoint + `AssetBook/getComplianceCode`, { responseType: 'text' });
  }
  getComplianceDocType(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'AssetItemType/getComplianceDocType');
  }
  getComplianceDocTypeChild(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'AssetItemType/getComplianceDocTypeChild');
  }
  getComplianceDocTypeById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `AssetItemType/getComplianceDocTypeById?id=${id}`);
  }
  getComplianceRenewTypeList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'companylookuptype/getComplianceRenewTypeList');
  }
  getComplianceDocByID(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `AssetBook/getComplianceDocByID?id=${id}`);
  }
  putComplianceDoument(data: any) {
    return this.http.put(this.endpoint + `AssetBook/putComplianceDoument`, data);
  }
  getAssetVehicleDocById(docId: number | string,companyId: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `AssetBook/getAssetVehicleDocById?docId=${docId}&companyId=${companyId}`);
  }
  getAssetApprovalStageLevelList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'AssetApprovalStageLevel');
  }
  //AssetDocumentApprovalProcess
  getDocumentApprovalProcessListFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `AssetDocumentApprovalProcess/getDocumentApprovalProcessListFiltered`, data);
  }
  addAssetDocumentApprovalProcess(data: any) {
    return this.http.post(`${this.endpoint}AssetDocumentApprovalProcess`, data);
  }
  updateAssetDocumentApprovalProcess(data: any) {
    return this.http.put(this.endpoint + `AssetDocumentApprovalProcess`, data);
  }
  getAssetDocumentApprovalProcessById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `AssetDocumentApprovalProcess/${id}`);
  }
  getAssetVehicleDocForApproval(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `AssetBook/getAssetVehicleDocForApproval`, data);
  }
  saveAssetVehicleDocApproval(data: any) {
    return this.http.post(`${this.endpoint}AssetBook/saveAssetVehicleDocApproval`, data);
  }
  //AssetItem
  getAssetItemList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'AssetItem');
  }
  getAssetItemListN(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'AssetItem/getAssetItemList');
  }
  getAssetSoftwareItemList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'AssetItem/getAssetSoftwareItemList');
  }
  getAssetItemListFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `AssetItem/getAssetItemListFiltered`, data);
  }
  getAvailableAssetItemListFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `AssetItem/getAvailableAssetItemListFiltered`, data);
  }
  getAssetEmailItemList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'AssetItem/getAssetEmailItemList');
  }
  getAssetMobileSimItemList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'AssetItem/getAssetMobileSimItemList');
  }
  getAssetItemById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `AssetItem/${id}`);
  }
  getAssetItemByOwner(ownerID: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `AssetItem/getAssetItemByOwner?OwnerID=${ownerID}`);
  }
  getAssetSNItemByOwner(ownerID: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `AssetItem/getAssetSNItemByOwner?OwnerID=${ownerID}`);
  }
  getAssetVehicleItemByOwner(ownerID: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `AssetItem/getAssetVehicleItemByOwner?OwnerID=${ownerID}`);
  }
  getAssetAdminItemByOwner(ownerID: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `AssetItem/getAssetAdminItemByOwner?OwnerID=${ownerID}`);
  }
  getAssetPlantItemByOwner(ownerID: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `AssetItem/getAssetPlantItemByOwner?OwnerID=${ownerID}`);
  }
  getAssetLandItemByOwner(ownerID: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `AssetItem/getAssetLandItemByOwner?OwnerID=${ownerID}`);
  }
  addAssetItem(data: any) {
    return this.http.post(`${this.endpoint}AssetItem`, data);
  }
  updateAssetItem(data: any) {
    return this.http.put(this.endpoint + `AssetItem`, data);
  }

  getAssetItemnById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `AssetItem/${id}`);
  }

  deleteAssetItem(id: number | string) {
    return this.http.delete(this.endpoint + `AssetItem/${id}`);
  }

  getAvailableAssetItemList(categoryID: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `AssetItem/getAvailableAssetItemList?categoryID=${categoryID}`);
  }
  getAvailableAssetItemListEdit(categoryID: number | string, itemID: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `AssetItem/getAvailableAssetItemListEdit?categoryID=${categoryID}&itemID=${itemID}`);
  }

  getAssetRamTypeList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'AssetBook/getRamType');
  }
  getAssetMonitorTypeList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'AssetBook/getMonitorType');
  }
  getAssetMouseTypeList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'AssetBook/getMouseType');
  }
  getAssetKeyboardTypeList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'AssetBook/getKeyboardType');
  }
  getVehicleType(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'AssetBook/getVehicleType');
  }
  getVehicleDocType(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'AssetBook/getVehicleDocType');
  }
  // getAssetItemDescription(data: any) {
  //   return this.http.post(`${this.endpoint}AssetBook/getAssetItemDescription`, data);
  // }
  getAssetItemDescription(data: any) {
    return this.http.post(`${this.endpoint}AssetBook/getAssetItemDescription`, data);
  }
  //AssetItemType

  addAssetItemType(data: any) {
    return this.http.post(`${this.endpoint}AssetItemType`, data);
  }
  updateAssetItemType(data: any) {
    return this.http.put(this.endpoint + `AssetItemType`, data);
  }
  getAssetItemTypeById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `AssetItemType/${id}`);
  }

  //AssetAllocation
  getAssetAllocationList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'AssetAllocation');
  }
  getAssetAllocationsFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `AssetAllocation/getAssetAllocationsFiltered`, data);
  }
  getAssetAllocationByAssetId(assetId: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `AssetAllocation/getAssetAllocationByAssetId?assetId=${assetId}`);
  }
  getAssetByEmployeeID(employeeID: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `AssetAllocation/getAssetByEmployeeID?employeeID=${employeeID}`);
  }
  addAssetAllocation(data: any) {
    return this.http.post(`${this.endpoint}AssetAllocation`, data);
  }
  updateAssetAllocation(data: any) {
    return this.http.put(this.endpoint + `AssetAllocation`, data);
  }

  getAssetAllocationkById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `AssetAllocation/${id}`);
  }

  deleteAssetAllocation(id: number | string) {
    return this.http.delete(this.endpoint + `AssetAllocation/${id}`);
  }
  //AssetAllocationReturn
  getAssetAllocationReturnList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'AssetAllocationReturn');
  }
  getAssetAllocationReturnsFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `AssetAllocationReturn/getAssetAllocationReturnsFiltered`, data);
  }
  addAssetAllocationReturn(data: any) {
    return this.http.post(`${this.endpoint}AssetAllocationReturn`, data);
  }
  updateAssetAllocationReturn(data: any) {
    return this.http.put(this.endpoint + `AssetAllocationReturn`, data);
  }

  getAssetAllocationReturnById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `AssetAllocationReturn/${id}`);
  }

  deleteAssetAllocationReturn(id: number | string) {
    return this.http.delete(this.endpoint + `AssetAllocationReturn/${id}`);
  }

  //AssetMaintenance

  getAMNO() {

    return this.http.get(this.endpoint + 'AssetMaintenance/getAssetMaintenanceNo', { responseType: 'text' })
  }
  getAssetMaintenanceList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'AssetMaintenance');
  }
  getAssetMaintenancesFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `AssetMaintenance/getAssetMaintenancesFiltered`, data);
  }
  getAssetMaintenanceReceiveList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'AssetMaintenance/getAssetMaintenancesReceive');
  }
  getAssetMaintenanceReturnList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'AssetMaintenance/getAssetMaintenancesReturn');
  }
  addAssetMaintenance(data: any) {
    return this.http.post(`${this.endpoint}AssetMaintenance`, data);
  }
  updateAssetMaintenance(data: any) {
    return this.http.put(this.endpoint + `AssetMaintenance`, data);
  }
  updateAssetMaintenanceForReturn(data: any) {
    return this.http.put(this.endpoint + `AssetMaintenance/putAssetMaintenanceForRetutn`, data);
  }

  getAssetMaintenanceById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `AssetMaintenance/${id}`);
  }
  getAssetMaintenanceByAssetId(assetId: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `AssetMaintenance/getAssetMaintenanceByAssetId?assetId=${assetId}`);
  }
  deleteAssetMaintenance(id: number | string) {
    return this.http.delete(this.endpoint + `AssetMaintenance/${id}`);
  }

  //AssetUserSupport
  getASNO() {
    return this.http.get(this.endpoint + 'AssetUserSupport/getAssetUserSupportNo', { responseType: 'text' })
  }
  getAssetUserSupportFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `AssetUserSupport/getAssetUserSupportFiltered`, data);
  }
  getAssetUserSupportById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `AssetUserSupport/${id}`);
  }
  getAssetUserSupportList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'AssetUserSupport');
  }
  addAssetUserSupport(data: any) {
    return this.http.post(`${this.endpoint}AssetUserSupport`, data);
  }
  updateAssetUserSupport(data: any) {
    return this.http.put(this.endpoint + `AssetUserSupport`, data);
  }

  deleteAssetUserSupport(id: number | string) {
    return this.http.delete(this.endpoint + `AssetUserSupport/${id}`);
  }
  getAssetSupportItemByAssetBookId(assetId: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `AssetSupportItem/getAssetSupportItemByAssetBookId?assetBookId=${assetId}`);
  }

  //AssetItemAssign
  getAssetItemAssignList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'AssetItemAssign');
  }
  getAssetItemAssignsFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `AssetItemAssign/getAssetItemAssignsFiltered`, data);
  }
  getAssetItemAssignsByCategory(categoryID: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `AssetItemAssign/getAssetItemAssignsByCategory?categoryID=${categoryID}`);
  }
  addAssetItemAssign(data: any) {
    return this.http.post(`${this.endpoint}AssetItemAssign`, data);
  }
  updateAssetItemAssign(data: any) {
    return this.http.put(this.endpoint + `AssetItemAssign`, data);
  }

  getAssetItemAssignById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `AssetItemAssign/${id}`);
  }

  deleteAssetItemAssign(id: number | string) {
    return this.http.delete(this.endpoint + `AssetItemAssign/${id}`);
  }
  //AssetSparePart
  getAssetSparePartList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'AssetSpareParts');
  }
  getAssetSparePartsFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `AssetSpareParts/getAssetSparePartsFiltered`, data);
  }
  // getAssetSparePartsStock(): Observable<any[]> {
  //   return this.http.get<any>(this.endpoint + 'AssetSpareParts/getAssetSparePartsStock');
  // }
  getAssetSparePartsStock(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `AssetSpareParts/getAssetSparePartsStock`, data);
  }
  getAssetSparePartsByOwner(ownerId: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `AssetSpareParts/getAssetSparePartsByOwner?owner_Id=${ownerId}`);
  }
  addSparePart(data: any) {
    return this.http.post(`${this.endpoint}AssetSpareParts`, data);
  }
  updateSparePart(data: any) {
    return this.http.put(this.endpoint + `AssetSpareParts`, data);
  }
  getSparePartById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `AssetSpareParts/${id}`);
  }
  getAvailableSparePartQty(sparePartID: number | string, companyID: number | string) {
    return this.http.get(this.endpoint + `AssetSpareParts/getAvailableSparePartQty?sparePartID=${sparePartID}&companyID=${companyID}`, { responseType: 'text' });
  }
  //AssetGrnMaster
  getGrnNo() {

    return this.http.get(this.endpoint + 'AssetGrnMaster/getGrnNo', { responseType: 'text' })
  }
  getAssetGrnMasterList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'AssetGrnMaster');
  }
  getAssetGrnMastersFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `AssetGrnMaster/getAssetGrnMastersFiltered`, data);
  }
  addAssetGrnMaster(data: any) {
    return this.http.post(`${this.endpoint}AssetGrnMaster`, data);
  }
  updateAssetGrnMaster(data: any) {
    return this.http.put(this.endpoint + `AssetGrnMaster`, data);
  }
  getAssetGrnMasterById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `AssetGrnMaster/${id}`);
  }
  //AssetSparePartBook

  getAssetSparePartBookList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'AssetSparePartBook');
  }
  getAssetSparePartBookFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `AssetSparePartBook/getAssetSparePartBookFiltered`, data);
  }
  addAssetSparePartBook(data: any) {
    return this.http.post(`${this.endpoint}AssetSparePartBook`, data);
  }
  updateAssetSparePartBook(data: any) {
    return this.http.put(this.endpoint + `AssetSparePartBook`, data);
  }
  getAssetSparePartBookById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `AssetSparePartBook/${id}`);
  }

  //HRLeaveType

  getHRLeaveTypeList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'HRLeaveType');
  }
  getLeaveTypeWithBalanceByEmp(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `HRLeaveType/getLeaveTypeWithBalanceByEmp`, data);
  }
  getHRLeaveTypeById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `HRLeaveType/${id}`);
  }
  addHRLeaveType(data: any) {
    return this.http.post(`${this.endpoint}HRLeaveType`, data);
  }
  updateHRLeaveType(data: any) {
    return this.http.put(this.endpoint + `HRLeaveType`, data);
  }

  deleteHRLeaveType(id: number | string) {
    return this.http.delete(this.endpoint + `HRLeaveType/${id}`);
  }

  // HRLeavePolicy

  getHRLeavePolicyList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'HRLeavePolicy');
  }
  getHRLeavePolicyById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `HRLeavePolicy/${id}`);
  }
  addHRLeavePolicy(data: any) {
    return this.http.post(`${this.endpoint}HRLeavePolicy`, data);
  }
  updateHRLeavePolicy(data: any) {
    return this.http.put(this.endpoint + `HRLeavePolicy`, data);
  }

  deleteHRLeavePolicy(id: number | string) {
    return this.http.delete(this.endpoint + `HRLeavePolicy/${id}`);
  }

  //HRLeaveReason

  getHRLeaveReasonList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'HRLeaveReason');
  }
  getHRLeaveReasonById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `HRLeaveReason/${id}`);
  }
  addHRLeaveReason(data: any) {
    return this.http.post(`${this.endpoint}HRLeaveReason`, data);
  }
  updateHRLeaveReason(data: any) {
    return this.http.put(this.endpoint + `HRLeaveReason`, data);
  }

  deleteHRLeaveReason(id: number | string) {
    return this.http.delete(this.endpoint + `HRLeaveReason/${id}`);
  }
  //HRLeaveProcessLevel
  getHRLeaveProcessLevelList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'HRLeaveProcessLevel');
  }
  // HRLeaveAllocation
  getLeaveAllocationFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `HRLeaveAllocation/getLeaveAllocationFiltered`, data);
  }
  getLeaveAllocationPreProcessView(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `HRLeaveAllocation/getLeaveAllocationPreProcessView`, data);
  }
  addHRLeaveAllocation(data: any) {
    return this.http.post(`${this.endpoint}HRLeaveAllocation`, data);
  }

  // HRLeaveApplication
  getLeaveApplicationFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `HRLeaveApplication/getLeaveApplicationFiltered`, data);
  }

  getHRLeaveApplicationById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `HRLeaveApplication/${id}`);
  }
  addHRLeaveApplication(data: any) {
    return this.http.post(`${this.endpoint}HRLeaveApplication`, data);
  }
  updateHRLeaveApplication(data: any) {
    return this.http.put(this.endpoint + `HRLeaveApplication`, data);
  }


  getLPFBulkPendingViewList(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `HRLeaveApplication/getLeaveApplicationForBulkPendingViewList`, data);
  }

  getLPFBulkApprovedViewList(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `HRLeaveApplication/getLeaveApplicationForBulkApprovedViewList`, data);
  }

  saveLeaveBulkAprroval(data: any) {
    return this.http.post(`${this.endpoint}HRLeaveApplication/saveBulkLeaveApproval`, data);
  }

  isValidLeaveApplication(data: any) {
    return this.http.post(`${this.endpoint}HRLeaveApplication/isValidLeaveApplication`, data, { responseType: 'text' });
  }
  cancelLeaveApplication(data: any) {
    return this.http.post(`${this.endpoint}HRLeaveApplication/cancelLeaveApplication`, data);
  }
  getLeaveStatusList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'companylookuptype/leaveStatusList');
  }
  getCFDeadReasonList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'companylookuptype/getCFDeadReasonList');
  }
  getCFDeadActionList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'companylookuptype/getCFDeadActionList');
  }

  //Leave Approval Process User
  getLAPUList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'HRLAPU');
  }


  addLAPU(data: any) {
    return this.http.post(`${this.endpoint}HRLAPU`, data);
  }
  updateLAPU(data: any) {
    return this.http.put(this.endpoint + `HRLAPU`, data);
  }

  getLAPUById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `HRLAPU/${id}`);
  }

  getLeaveAuthFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `HRLAPU/getLeaveAuthFiltered`, data);
  }


  getLAPUByAuthEmployeeId(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `HRLAPU/GetSectiontListByDepartment?Department_Id=${id}`);
  }

  deleteLAPU(id: number | string) {
    return this.http.delete(this.endpoint + `HRLAPU/${id}`);
  }


  getLAPLList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'HRLAPU/getlaplList');
  }

  getLAPList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'HRLAPU/getlapList');
  }
  isOnBehalfEntry(userId: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `HRLAPU/isOnBehalfEntry?userId=${userId}`);
  }
  // Holiday
  getHolidaysFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `Holiday/getHolidaysFiltered`, data);
  }

  getHolidayById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `Holiday/${id}`);
  }
  addHoliday(data: any) {
    return this.http.post(`${this.endpoint}Holiday`, data);
  }
  updateHoliday(data: any) {
    return this.http.put(this.endpoint + `Holiday`, data);
  }
  getWeekendList(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `Holiday/getWeekendList`, data);
  }

  getHolidayTypeList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'LookupType/getHolidayTypeList');
  }

  //Bank
  getBankist(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'Bank');
  }

  //TripPlan
  getTripPlansFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `TripPlan/getTripPlansFiltered`, data);
  }
  addTripPlan(data: any) {
    return this.http.post(`${this.endpoint}TripPlan`, data);
  }
  updateTripPlan(data: any) {
    return this.http.put(this.endpoint + `TripPlan`, data);
  }
  getTripPlanById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `TripPlan/${id}`);
  }
  //CfFarmer
  getFarmerCode() {
    // return this.http.get<any>(this.endpoint + 'CfFarmer/getFarmerCode');
    return this.http.get(this.endpoint + `CfFarmer/getFarmerCode`, { responseType: 'text' });
  }
  getCfFarmerList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'CfFarmer');
  }
  getCfFarmersFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `CfFarmer/getCFFarmerListFiltered`, data);
  }
  addCfFarmer(data: any) {
    return this.http.post(`${this.endpoint}CfFarmer`, data);
  }
  updateCfFarmer(data: any) {
    return this.http.put(this.endpoint + `CfFarmer`, data);
  }
  getCfFarmerById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CfFarmer/${id}`);
  }
  //CfBranch
  getCfBranchList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'CfBranch');
  }
  addCfBranch(data: any) {
    return this.http.post(`${this.endpoint}CfBranch`, data);
  }
  updateCfBranch(data: any) {
    return this.http.put(this.endpoint + `CfBranch`, data);
  }
  getCfBranchById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CfBranch/${id}`);
  }
  getBranchByRegion(regionID: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CfBranch/getBranchByRegion?regionID=${regionID}`);
  }
  //CfRegion
  getCfRegionList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'CfRegion');
  }
  addCfRegion(data: any) {
    return this.http.post(`${this.endpoint}CfRegion`, data);
  }
  updateCfRegion(data: any) {
    return this.http.put(this.endpoint + `CfRegion`, data);
  }
  getCfRegionById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CfRegion/${id}`);
  }
  //CfCluster
  getCfClusterList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'CfCluster');
  }
  addCfCluster(data: any) {
    return this.http.post(`${this.endpoint}CfCluster`, data);
  }
  updateCfCluster(data: any) {
    return this.http.put(this.endpoint + `CfCluster`, data);
  }
  getCfClusterById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CfCluster/${id}`);
  }
  getClusterByBranch(branchID: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CfCluster/getClusterByBranch?branchID=${branchID}`);
  }
  //CfWarehouse
  getWarehouseByBranch(branchID: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CfWarehouse/getWarehouseByBranch?branchID=${branchID}`);
  }
  getCfWarehouseList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'CfWarehouse');
  }
  addCfWarehouse(data: any) {
    return this.http.post(`${this.endpoint}CfWarehouse`, data);
  }
  updateCfWarehouse(data: any) {
    return this.http.put(this.endpoint + `CfWarehouse`, data);
  }
  getCfWarehouseById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CfWarehouse/${id}`);
  }
  // CfSupplier
  getCfSupplierList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'CfSupplier');
  }
  addCfSupplier(data: any) {
    return this.http.post(`${this.endpoint}CfSupplier`, data);
  }
  updatCfSupplier(data: any) {
    return this.http.put(this.endpoint + `CfSupplier`, data);
  }
  getCfSupplierById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CfSupplier/${id}`);
  }
  //FlockInfo
  getFlockNo() {
    return this.http.get<any>(this.endpoint + 'FlockInfo/getFlockNo');
  }
  getFlockRatePolicy(broiler_Type_Id : number | string) {
    return this.http.get<any>(this.endpoint + `FlockInfo/getFlockRatePolicy?broiler_Type_Id=${broiler_Type_Id}`);
  }
  getFlockNoByFarmer(farmerID: number | string) {
    return this.http.get(this.endpoint + `FlockInfo/getFlockNoByFarmer?farmerID=${farmerID}`, { responseType: 'text' });
  }
  isExistOpenFlock(farmerId: number | string): Observable<any> {
    return this.http.get<any>(this.endpoint + `FlockInfo/isExistOpenFlock?farmerId=${farmerId}`);
  }

  getFlockInfoListFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `FlockInfo/getFlockInfoListFiltered`, data);
  }
  addFlockInfo(data: any) {
    return this.http.post(`${this.endpoint}FlockInfo`, data);
  }
  updateFlockInfo(data: any) {
    return this.http.put(this.endpoint + `FlockInfo`, data);
  }
  getFlockInfoById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `FlockInfo/${id}`);
  }
  getFlockByFarmer(farmerID: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `FlockInfo/getFlockByFarmer?farmerID=${farmerID}`);
  }
  getOpenFlockByFarmer(farmerID: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `FlockInfo/getOpenFlockByFarmer?farmerID=${farmerID}`);
  }
  getFlockAvailabaleQty(flockId: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `FlockInfo/getFlockAvailabaleQty?flockId=${flockId}`);
  }
  getFlockCosting(Branch_Id: number, Cluster_Id: number, Farmer_Id: number, Flock_Id: number): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `FlockInfo/getFlockCosting?Branch_Id=${Branch_Id}&Cluster_Id=${Cluster_Id}&Farmer_Id=${Farmer_Id}&Flock_Id=${Flock_Id}`);
  }
  //CFGrn
  getCFGrnkNo() {
    return this.http.get(this.endpoint + `CFGrn/getCfGrnCode`, { responseType: 'text' });
  }
  getCFGrnListFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `CFGrn/getCFGrnListFiltered`, data);
  }
  addCFGrn(data: any) {
    return this.http.post(`${this.endpoint}CFGrn`, data);
  }
  updateCFGrn(data: any) {
    return this.http.put(this.endpoint + `CFGrn`, data);
  }
  getCFGrnById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CFGrn/${id}`);
  }
  //CF GRN Transfer
  getCFGrnTransferNo() {
    return this.http.get(this.endpoint + `CFGrnTransfer/GetCode`, { responseType: 'text' });
  }
  getCFGrnTransferedListFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `CFGrnTransfer/getCFGrnTransferedListFiltered`, data);
  }
  addCFGrnTransfer(data: any) {
    return this.http.post(`${this.endpoint}CFGrnTransfer`, data);
  }
  updateCFGrnTransfer(data: any) {
    return this.http.put(this.endpoint + `CFGrnTransfer`, data);
  }
  getCFGrnTransferById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CFGrnTransfer/${id}`);
  }
  updateCFGrnRecv(data: any) {
    return this.http.post(`${this.endpoint}CFGrnTransfer/CFGRNStockRecieved`, data);
  }
  // updateCFGrnRecv(data: any): Observable<any[]> {
  //   return this.http.post<any>(this.endpoint + `CFGrnTransfer/CFGRNStockRecieved`, data);
  // }
  //CfIssue
  getCfIssueNo() {
    return this.http.get(this.endpoint + `CfIssue/getCfIssueCode`, { responseType: 'text' });
  }
  getCFIssueListFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `CfIssue/getCFIssueListFiltered`, data);
  }
  getCFIssueListForApproval(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `CfIssue/getCFIssueListForApproval`, data);
  }
  addCfIssue(data: any) {
    return this.http.post(`${this.endpoint}CfIssue`, data);
  }
  updateCfIssue(data: any) {
    return this.http.put(this.endpoint + `CfIssue`, data);
  }
  getCfIssueById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CfIssue/${id}`);
  }
  getAvailableItemQty(itemID: number | string, warehouseID: number | string) {
    return this.http.get(this.endpoint + `CfIssue/getAvailableItemQty?itemID=${itemID}&warehouseID=${warehouseID}`, { responseType: 'text' });
  }
  getAvailableItemQtyForReturn(itemID: number | string, warehouseID: number | string, flockId: number | string) {
    return this.http.get(this.endpoint + `CfIssue/getAvailableItemQtyForReturn?itemID=${itemID}&warehouseID=${warehouseID}&flockId=${flockId}`, { responseType: 'text' });
  }
  getCFItemCurrentStock(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `CfIssue/getCFItemCurrentStock`, data);
  }
  saveBulkCFIssueApproval(data: any) {
    return this.http.post(`${this.endpoint}CfIssue/saveBulkCFIssueApproval`, data);
  }
  //CfIssueReturn
  getCfIssueReturnCode() {
    return this.http.get(this.endpoint + `CfIssueReturn/getCfIssueReturnCode`, { responseType: 'text' });
  }
  getCfIssueReturnListFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `CfIssueReturn/getCFIssueReturnListFiltered`, data);
  }
  addCfIssueReturn(data: any) {
    return this.http.post(`${this.endpoint}CfIssueReturn`, data);
  }
  updateCfIssueReturn(data: any) {
    return this.http.put(this.endpoint + `CfIssueReturn`, data);
  }
  getCfIssueReturnById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CfIssueReturn/${id}`);
  }
  //CFFGSale
  getCFFGSaleCode() {
    return this.http.get(this.endpoint + `CFFGSale/getCFFGSaleCode`, { responseType: 'text' });
  }
  getCFFGSaleListFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `CFFGSale/GetCFFGSaleListFiltered`, data);
  }
  addCFFGSale(data: any) {
    return this.http.post(`${this.endpoint}CFFGSale`, data);
  }
  updateCFFGSale(data: any) {
    return this.http.put(this.endpoint + `CFFGSale`, data);
  }
  getCFFGSaleById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CFFGSale/${id}`);
  }
  //CfApprovalProcess

  getCfApprovalProcessListFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `CfApprovalProcess/getCFApprovalProcessListFiltered`, data);
  }
  addCfApprovalProcess(data: any) {
    return this.http.post(`${this.endpoint}CfApprovalProcess`, data);
  }
  updateCfApprovalProcess(data: any) {
    return this.http.put(this.endpoint + `CfApprovalProcess`, data);
  }
  getCfApprovalProcessById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CfApprovalProcess/${id}`);
  }
  //CFStageLevel
  getCFStageLevelList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'CFStageLevel');
  }
  //CfRatePolicy
  GetCfBroilerTypes(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'CfRatePolicy/GetCfBroilerTypes');
  }
  getCfRatePolicyList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'CfRatePolicy');
  }
  updatCfRatePolicy(data: any) {
    return this.http.put(this.endpoint + `CfRatePolicy`, data);
  }
  getCfRatePolicyById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CfRatePolicy/${id}`);
  }
  //CFDailyFlockActivity

  getCFDailyFlockActivityListFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `CFDailyFlockActivity/getCFDailyFlockActivityListFiltered`, data);
  }
  addCFDailyFlockActivity(data: any) {
    return this.http.post(`${this.endpoint}CFDailyFlockActivity`, data);
  }
  updateCFDailyFlockActivity(data: any) {
    return this.http.put(this.endpoint + `CFDailyFlockActivity`, data);
  }
  getCFDailyFlockActivityById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CFDailyFlockActivity/${id}`);
  }
  getDailyFlockData(flockId: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CFDailyFlockActivity/getDailyFlockData?flockId=${flockId}`);
  }
  isExistActivity(flockId: number | string, activity_Date: any): Observable<any> {
    return this.http.get<any>(this.endpoint + `CFDailyFlockActivity/isExistActivity?flockeId=${flockId}&activityDate=${activity_Date}`);
  }
  getFlockDASummaryData(Branch_Id: number, Cluster_Id: number, Farmer_Id: number, Flock_Id: number): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `FlockInfo/getFlockDASummaryData?Branch_Id=${Branch_Id}&Cluster_Id=${Cluster_Id}&Farmer_Id=${Farmer_Id}&Flock_Id=${Flock_Id}`);
  }
  //CfUserMapping
  getCfUserMappingList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'CfUserMapping');
  }
  getCfUserMappingById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CfUserMapping/${id}`);
  }
  getMappingDetailByMappingId(mappingId: number | string) {
    return this.http.get<any>(this.endpoint + `CfUserMapping/getMappingDetailByMappingId?mappingId=${mappingId}`);
  }
  addCfUserMapping(data: any) {
    return this.http.post(`${this.endpoint}CfUserMapping`, data);
  }
  updatCfUserMapping(data: any) {
    return this.http.put(this.endpoint + `CfUserMapping`, data);
  }
  getCFMappingTypeList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'companylookuptype/getCFMappingTypeList');
  }
 //CfPaymentInfo
 getCFDPaymentInfoListFiltered(data: any): Observable<any[]> {
  return this.http.post<any>(this.endpoint + `CfPaymentInfo/getCFDPaymentInfoListFiltered`, data);
}
addCfPaymentInfo(data: any) {
  return this.http.post(`${this.endpoint}CfPaymentInfo`, data);
}
updateCfPaymentInfo(data: any) {
  return this.http.put(this.endpoint + `CfPaymentInfo`, data);
}
getCfPaymentInfoById(id: number | string): Observable<any[]> {
  return this.http.get<any>(this.endpoint + `CfPaymentInfo/${id}`);
}
getCFPaymentModeTypeList() {
  return this.http.get<any>(this.endpoint + 'CompanyLookupType/getCFPaymentModeTypeList');
}
postForFlockPayment(flockId: number | string,userId: number | string): Observable<any[]> {
  return this.http.get<any>(this.endpoint + `CfPaymentInfo/postForFlockPayment?flockId=${flockId}&userId=${userId}`);
}
//cf market rate
SaveCfItemMarketRate(data: any) {
  return this.http.post(this.endpoint + `CFItemMarketRate`, data);
}
getMarketRatesByItemId(inv_item_id: number | string): Observable<any[]> {
  return this.http.get<any>(this.endpoint + `CFItemMarketRate/${inv_item_id}`);
}
//cf farm managemtn cost
getCffarmMngtCost(data: any): Observable<any[]> {
  // return this.http.get<any>(this.endpoint + `CFFarmManagement/${branch_Id}`);
  return this.http.post<any>(this.endpoint + `CFFarmManagement/Get`, data);

}
SaveCffarmMngtCost(data: any) {
  return this.http.post(this.endpoint + `CFFarmManagement`, data);
}
UpdateCffarmMngtCost(data: any) {
  return this.http.put(this.endpoint + `CFFarmManagement`, data);
}
  //Ajfl
  //AJflArea
  getAJflAreaList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'AJflArea');
  }
  //AjflBasisSetup
  getAjflBasisSetupCode() {
    return this.http.get(this.endpoint + `AjflBasisSetup/getBasisSetupCode`, { responseType: 'text' });
  }
  getAJflBasisSetupList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'AjflBasisSetup');
  }
  getBasisSetupListFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `AjflBasisSetup/getBasisSetupListFiltered`, data);
  }
  addAjflBasisSetup(data: any) {
    return this.http.post(`${this.endpoint}AjflBasisSetup`, data);
  }
  updatAjflBasisSetup(data: any) {
    return this.http.put(this.endpoint + `AjflBasisSetup`, data);
  }
  getAjflBasisSetupById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `AjflBasisSetup/${id}`);
  }
  getItemRateByBs(itemGradeId: number | string, basisId: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `AjflBasisSetup/getItemRateByBs?itemGradeId=${itemGradeId}&basisId=${basisId}`);
  }
  //AjflPurchase
  getPurchaseCode() {
    return this.http.get(this.endpoint + `AjflPurchase/getPurchaseCode`, { responseType: 'text' });
  }
  getPurchaseListFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `AjflPurchase/getPurchaseListFiltered`, data);
  }
  addAjflPurchase(data: any) {
    return this.http.post(`${this.endpoint}AjflPurchase`, data);
  }
  updateAjflPurchase(data: any) {
    return this.http.put(this.endpoint + `AjflPurchase`, data);
  }
  getCAjflPurchaseById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `AjflPurchase/${id}`);
  }
  //AjflItem
  getAjflItemList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'AjflItem');
  }
  //AjflItemGrade
  getAjflItemGradeList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'AjflItemGrade');
  }
  getItemGradesByItem(itemId: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `AjflItemGrade/getItemGradesByItem?itemId=${itemId}`);
  }
  getAjflItemGradeById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `AjflItemGrade/${id}`);
  }
  addAjflItemGrade(data: any) {
    return this.http.post(`${this.endpoint}AjflItemGrade`, data);
  }
  updateAjflItemGrade(data: any) {
    return this.http.put(this.endpoint + `AjflItemGrade`, data);
  }
  //AjflProductionRequisition
  getProductionRequisitionCode() {
    return this.http.get(this.endpoint + `AjflProductionRequisition/getProductionRequisitionCode`, { responseType: 'text' });
  }
  getProductionRequisitionListFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `AjflProductionRequisition/getProductionRequisitionListFiltered`, data);
  }
  getPrDetailForIssue(prId: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `AjflProductionRequisition/getPrDetailForIssue?prId=${prId}`);
  }
  addAjflProductionRequisition(data: any) {
    return this.http.post(`${this.endpoint}AjflProductionRequisition`, data);
  }
  updateAjflProductionRequisition(data: any) {
    return this.http.put(this.endpoint + `AjflProductionRequisition`, data);
  }
  getAjflProductionRequisitionById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `AjflProductionRequisition/${id}`);
  }
  //AjflProductionIssue
  getProductionIssueCode() {
    return this.http.get(this.endpoint + `AjflProductionIssue/getProductionIssueCode`, { responseType: 'text' });
  }
  getProductionIssueListFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `AjflProductionIssue/getProductionIssueListFiltered`, data);
  }
  addAjflProductionIssue(data: any) {
    return this.http.post(`${this.endpoint}AjflProductionIssue`, data);
  }
  updateAjflProductionIssue(data: any) {
    return this.http.put(this.endpoint + `AjflProductionIssue`, data);
  }
  getAjflProductionIssueById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `AjflProductionIssue/${id}`);
  }
  //finance

  //acc_coa
  getCOAList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'acccoa');
  }

  getActiveCOAList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'acccoa/GetActiveCOAList');
  }

  getActiveCOAHeadList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'acccoa/GetActiveCOAHeadList');
  }

  addCOA(data: any) {
    return this.http.post(`${this.endpoint}acccoa`, data);
  }
  updateCOA(data: any) {
    return this.http.put(this.endpoint + `acccoa`, data);
  }

  getCOAById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `acccoa/${id}`);
  }

  deleteCOA(id: number | string) {
    return this.http.delete(this.endpoint + `acccoa/${id}`);
  }

  getCOAFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `acccoa/getcoaFiltered`, data);
  }
  getCoasByCompany(companyID: number | string) {
    return this.http.get<any>(this.endpoint + `acccoa/getcoasByCompany?companyID=${companyID}`);
  }

  getcoaMasterListByCompany(companyID: number | string) {
    return this.http.get<any>(this.endpoint + `acccoa/getcoaMasterListByCompany?companyID=${companyID}`);
  }

  //acc_voucher
  getVoucherList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'accvoucher');
  }

  getActiveVoucherList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'accvoucher/GetActiveVoucherList');
  }

  getVoucherTypeList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'companylookuptype/voucherTypeList');
  }

  addVoucher(data: any) {
    return this.http.post(`${this.endpoint}accvoucher`, data);
  }
  updateVoucher(data: any) {
    return this.http.put(this.endpoint + `accvoucher`, data);
  }

  updateVoucherPostStatus(data: any) {
    return this.http.put<any>(this.endpoint + `accvoucher/UpdateVoucherPostUnpost`, data);

  }

  getVoucherById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `accvoucher/${id}`);
  }

  getVoucherFirstId() {
    return this.http.get<any>(this.endpoint + 'accvoucher/getvoucherFrstId');
  }

  getVoucherLastId() {
    return this.http.get<any>(this.endpoint + 'accvoucher/getvoucherLastId');

  }

  deleteVoucher(id: number | string) {
    return this.http.delete(this.endpoint + `accvoucher/${id}`);
  }

  getVoucherFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `accvoucher/getvoucherFiltered`, data);
  }
  getVouchersByCompany(companyID: number | string) {
    return this.http.get<any>(this.endpoint + `accvoucher/getcoasByCompany?companyID=${companyID}`);
  }

  //AccPettyCash
  getPettyCashCode() {
    return this.http.get(this.endpoint + `AccPettyCash/getPettyCashCode`, { responseType: 'text' });
  }
  getPettyCashListFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `AccPettyCash/getPettyCashListFiltered`, data);
  }
  addAccPettyCash(data: any) {
    return this.http.post(`${this.endpoint}AccPettyCash`, data);
  }
  updateAccPettyCash(data: any) {
    return this.http.put(this.endpoint + `AccPettyCash`, data);
  }
  getAccPettyCashById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `AccPettyCash/${id}`);
  }
  //AccParticularType
  getAccParticularTypeList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'AccParticularType');
  }
  getParticularTypeDetailById(particularTypeId: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `AccParticularType/getParticularTypeDetailById?particularTypeId=${particularTypeId}`);
  }
  getAccParticularTypeById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `AccParticularType/${id}`);
  }
  isExistParticularType(particularType: number | string): Observable<any> {
    return this.http.get<any>(this.endpoint + `AccParticularType/isExistParticularType?particularType=${particularType}`);
  }
  addAccParticularType(data: any) {
    return this.http.post(`${this.endpoint}AccParticularType`, data);
  }
  updateAccParticularType(data: any) {
    return this.http.put(this.endpoint + `AccParticularType`, data);
  }

  //YarnItemRegistration
  getYarnItemRegistrationist(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'YarnItemRegistration');
  }
  addYarnItemRegistration(data: any) {
    return this.http.post(`${this.endpoint}YarnItemRegistration`, data);
  }
  updateYarnItemRegistration(data: any) {
    return this.http.put(this.endpoint + `YarnItemRegistration`, data);
  }
  getYarnItemRegistrationById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `YarnItemRegistration/${id}`);
  }
  spinningProcessList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'companylookuptype/spinningProcessList');
  }
  cottonTypeList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'companylookuptype/cottonTypeList');
  }
  yarnItemList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'companylookuptype/yarnItemList');
  }
  //FiberComposition
  getFiberCompositionist(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'FiberComposition');
  }
  addFiberComposition(data: any) {
    return this.http.post(`${this.endpoint}FiberComposition`, data);
  }
  updateFiberComposition(data: any) {
    return this.http.put(this.endpoint + `FiberComposition`, data);
  }
  getFiberCompositionById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `FiberComposition/${id}`);
  }
  fiberTypeList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'companylookuptype/fiberTypeList');
  }

  //CFDashboard
  GetCFFlockAgeSummaryDashbordData(RegionId: number, BranchId: number,broilerTypeId:number): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CFDashboard/GetCFFlockAgeSummaryDashbordData?RegionId=${RegionId}&BranchId=${BranchId}&BroilerTypeId=${broilerTypeId}`);
  }
  GetCFProductionCostDetailsDashbordData(Year: any, Month: any, RegionId: number, BranchId: number,broilerTypeId:number): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CFDashboard/GetCFProductionCostDetailsDashbordData?Year=${Year}&Month=${Month}&RegionId=${RegionId}&BranchId=${BranchId}&BroilerTypeId=${broilerTypeId}`);
  }
  GetCFBroilerSalesDetailsDashbordData(Year: any, Month: any, RegionId: number, BranchId: number,broilerTypeId:number): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CFDashboard/GetCFBroilerSalesDetailsDashbordData?Year=${Year}&Month=${Month}&RegionId=${RegionId}&BranchId=${BranchId}&BroilerTypeId=${broilerTypeId}`);
  }
  GetCFGRNDetailsDashbordData(Year: any, Month: any, RegionId: number, BranchId: number): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CFDashboard/GetCFGRNDetailsDashbordData?Year=${Year}&Month=${Month}&RegionId=${RegionId}&BranchId=${BranchId}`);
  }
  GetFarmerWiseFlockSummaryCountDashboardData(RegionId: any, BranchId: any): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CFDashboard/GetFarmerWiseFlockSummaryCountDashboardData?RegionId=${RegionId}&BranchId=${BranchId}`);
  }
  GetCFProfitLossDashboardData(Year: number, Month: string, RegionId: number, BranchId: number): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CFDashboard/GetCFProfitLossDashboardData?Year=${Year}&Month=${Month}&Region_Id=${RegionId}&Branch_Id=${BranchId}`);
  }
  GetCFFeedSalesDashbordData(Year: number, Month: string, RegionId: number, BranchId: number): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CFDashboard/GetCFFeedSalesDashbordData?Year=${Year}&Month=${Month}&Region_Id=${RegionId}&Branch_Id=${BranchId}`);
  }
  GetCFFeedConsumptionData(From_Date: any, To_Date: any, Branch_Id: number, Cluster_Id: number, Flock_Id: number): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CFDashboard/GetCFFeedConsumptionData?From_Date=${From_Date}&To_Date=${To_Date}&Branch_Id=${Branch_Id}&Cluster_Id=${Cluster_Id}&Flock_Id=${Flock_Id}`);
  }
  GetCFFeedConsumptionDataByFlock(Flock_Id: number): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CFDashboard/GetCFFeedConsumptionDataByFlock?Flock_Id=${Flock_Id}`);
  }

  //Employee Salary

  getsearchEmpMonthwiseSalaryProcessedList(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `EmployeeSalary/searchEmpMonthwiseSalaryProcessedList`, data);
  }

  getEmpMonthwiseSalaryProcessedRollBackPendingList(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `EmployeeSalary/searchEmpMonthwiseSalaryRollBackPendingList`, data);
  }

  addHRMonthlyEmpSalaryProcess(data: any) {
    return this.http.post(`${this.endpoint}EmployeeSalary/SaveMonthlyEmpSalaryProcess`, data);
  }

  deleteRMonthlyEmpSalaryProcessRollback(data: any) {
    return this.http.post(`${this.endpoint}EmployeeSalary/DeleteMonthlyEmpSalaryRollback`, data);
  }

  getsearchMonthwiseSalaryProcessPendingList(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `EmployeeSalary/searchMonthwiseSalaryProcessPendingList`, data);
  }




  //Monthly Attendance Process for salary
  GetEmpAttnsalaryManipulationDataById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `EmployeeSalary/GetEmpAttnsalaryManipulationDataById?Id=${id}`);
  }

  saveEmpAttnSummaryManipulationData(data: any) {
    return this.http.post(this.endpoint + `EmployeeSalary/saveEmployeeAttnsalaryprocessdata`, data);
  }
  GetMonthlyAttnSalaryManipulationListFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `EmployeeSalary/GetMonthlyAttnSalaryManipulationListFiltered`, data);
  }
  GetEmployeeAttnsalaryprocessdataById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `EmployeeSalary/GetEmployeeAttnsalaryprocessdataById?Id=${id}`);
  }


  updateEmpAttnSummaryManipulationData(data: any) {
    return this.http.put(this.endpoint + `EmployeeSalary/updateEmployeeAttnsalaryprocessdata`, data);
  }



  IsAttendanceProcessExists(year_Id: number | string, month_Id: number | string, company_Id: number | string): Observable<boolean> {
    //return this.http.post<any>(this.endpoint + `EmployeeSalary/IsAttendanceProcessExists`, data);
    return this.http.get<any>(this.endpoint + `EmployeeSalary/IsAttendanceProcessExists?year_Id=${year_Id}&month_Id=${month_Id}&company_Id=${company_Id}`);
  }

  // IsExistSalaryInfoByEmpId(emp_id: number | string): Observable<boolean> {
  //   return this.http.get<any>(this.endpoint + `EmployeeSalary/IsExistSalaryInfoByEmpId?emp_id=${emp_id}`);
  // }

  deleteMonthlyEmpAttnProcessRollback(data: any) {
    return this.http.post(`${this.endpoint}EmployeeSalary/DeleteMonthlyAttendanceSalaryProcessRollback`, data);
  }


  getMonthlyAttendanceProcessSalaryData(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `EmployeeSalary/getMonthlyAttendanceSalaryProcessedListFiltered`, data);
  }

  getMonthlyAttendanceProcessSalaryPendingData(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `EmployeeSalary/searchEmployeeAttnsalaryprocessdata`, data);
  }

  addHRMonthlyAttendanceProcessSalaryData(data: any) {
    return this.http.post(`${this.endpoint}EmployeeSalary/SaveMonthlyAttendanceSalaryProcess`, data);
  }
  DeleteAttnSalaryManipuationById(id: number | string) {
    return this.http.delete(this.endpoint + `EmployeeSalary/DeleteAttnSalaryManipuationById?Id=${id}`);
  }
  //end


  GetHRSalaryHeadBySalaryRuleCode(salary_Rule_Code: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `EmployeeSalary/GetHRSalaryHeadBySalaryRuleCode?salary_Rule_Code=${salary_Rule_Code}`);
  }

  GetAllHRSalaryRuleListByCompanyEmplId(company_Id: number | string, employee_Id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `EmployeeSalary/GetAllHRSalaryRuleListByCompanyEmployeeId?company_Id=${company_Id}&employee_Id=${employee_Id}`);
  }


  // GetAllHRSalaryHeadsByCompanyId(company_Id: number | string): Observable<any[]> {
  //   return this.http.get<any>(this.endpoint + `EmployeeSalary/GetAllHRSalaryHeadsByCompanyId?Company_Id=${company_Id}`);
  // }

  GetAllHRSalaryHeadsForManipulationByCompanyId(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `EmployeeSalary/GetAllHRSalaryHeadsForManipulationByCompanyId`, data);
  }


  GetAllHRSalaryHeadNameListByRule(employee_Id: number | string, salary_Rule_ID: number, amnt: number, isEditActoion: boolean): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `EmployeeSalary/GetAllHRSalaryHeadNameListByRule?employee_Id=${employee_Id}&salary_Rule_ID=${salary_Rule_ID}&amnt=${amnt}&isEditActoion=${isEditActoion}`);
  }


  GetAllHRSalaryHeads(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'EmployeeSalary/GetAllHRSalaryHeads');
  }
  GetHRSalaryHeadById(head_Id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `EmployeeSalary/GetHRSalaryHeadById?head_Id=${head_Id}`);
  }
  SaveHRSalaryHead(data: any) {
    return this.http.post(`${this.endpoint}EmployeeSalary/SaveHRSalaryHead`, data);
  }
  UpdateHRSalaryHead(data: any) {
    return this.http.put(this.endpoint + `EmployeeSalary/UpdateHRSalaryHead`, data);
  }
  GetAllHRSalaryRules(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'EmployeeSalary/GetAllHRSalaryRules');
  }
  GetHRSalaryRuleById(rule_Id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `EmployeeSalary/GetHRSalaryRuleById?rule_Id=${rule_Id}`);
  }

  GetAllHRSalaryRuleListByCompanyId(company_Id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `EmployeeSalary/GetAllHRSalaryRuleListByCompanyId?Company_Id=${company_Id}`);
  }

  SaveHRSalaryRule(data: any) {
    return this.http.post(`${this.endpoint}EmployeeSalary/SaveHRSalaryRule`, data);
  }
  UpdateHRSalaryRule(data: any) {
    return this.http.put(this.endpoint + `EmployeeSalary/UpdateHRSalaryRule`, data);
  }

  GetAllHRAttendancePaymentRules(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'EmployeeSalary/GetAllHRAttendancePaymentRules');
  }
  GetHRAttendancePaymentRuleById(rule_Id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `EmployeeSalary/GetHRAttendancePaymentRuleById?att_pay_rule_Id=${rule_Id}`);
  }
  SaveHRAttendancePaymentRule(data: any) {
    return this.http.post(`${this.endpoint}EmployeeSalary/SaveHRAttendancePaymentRule`, data);
  }
  UpdateHRAttendancePaymentRule(data: any) {
    return this.http.put(this.endpoint + `EmployeeSalary/UpdateHRAttendancePaymentRule`, data);
  }

  //Salary Info

  GetAllHREmpSalaryInfoes(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'EmployeeSalary/GetAllHREmpSalaryInfoes');
  }
  SaveHREmpSalaryInfo(data: any) {
    return this.http.post(`${this.endpoint}EmployeeSalary/SaveHREmpSalaryInfo`, data);
  }
  GetHREmpSalaryInfoById(info_Id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `EmployeeSalary/GetHREmpSalaryInfoById?info_Id=${info_Id}`);
  }

  UpdateHREmpSalaryInfo(data: any) {
    return this.http.put(this.endpoint + `EmployeeSalary/UpdateHREmpSalaryInfo`, data);
  }
  IsExistSalaryInfoByEmpId(emp_id: number | string): Observable<boolean> {
    return this.http.get<any>(this.endpoint + `EmployeeSalary/IsExistSalaryInfoByEmpId?emp_id=${emp_id}`);
  }
  // Salary Manipulation Info

  GetAllHRMonthlySalaryManipulationInfoes(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'EmployeeSalary/GetAllHREmpSalaryManipulations');
  }

  addHRMonthlySalaryManipulationInfo(data: any) {
    return this.http.post(`${this.endpoint}EmployeeSalary/SaveMonthlySalaryManipulationInfo`, data);
  }

  UpdateHRMonthlySalaryManipulationInfo(data: any) {
    return this.http.put(this.endpoint + `EmployeeSalary/UpdateHREmpSalaryManipulation`, data);
  }


  GetHRMonthlySalaryManipulationInfoById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `EmployeeSalary/GetHREmpSalaryManipulationById?id=${id}`);
  }

  //#region CST
  //CST
  GetCSTDistricts(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'CSTCustomer/GetCSTDistricts');
  }
  GetAllCSTCustomers(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'CSTCustomer');
  }
  SaveCSTCustomer(data: any) {
    return this.http.post(`${this.endpoint}CSTCustomer`, data);
  }
  GetCSTCustomerById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CSTCustomer/${id}`);
  }
  UpdateCSTCustomer(data: any){
    return this.http.put(this.endpoint + `CSTCustomer`, data);
  }
  GetCSTCustomerCode(company_Id : number | string) {
    return this.http.get(this.endpoint + `CSTCustomer/GetCSTCustomerCode?company_Id=${company_Id}`, { responseType: 'text' });
  }
  GetAllCSTBookings(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'CSTBooking');
  }
  
  SaveCSTBooking(data: any) {
    return this.http.post(`${this.endpoint}CSTBooking`, data);
  }
  GetCSTBookingById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CSTBooking/${id}`);
  }
  UpdateCSTBooking(data: any){
    return this.http.put(this.endpoint + `CSTBooking`, data);
  }
  UpdateCSTTargetBooking(data: any){
    return this.http.put(this.endpoint + `CSTTargetBooking`, data);
  }
  GetCSTTargetBookingForSRO(booking_Id: number | string,booking_Type_Id: number | string,season_Id : number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CSTTargetBooking/GetCSTTargetBookingForSRO?booking_Id=${booking_Id}&booking_Type_Id=${booking_Type_Id}&season_Id=${season_Id}`);
  }
  getCstBookingTypeList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'CompanyLookupType/getCstBookingTypeList');
  }
  getCstLoanTypeList(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'CompanyLookupType/getCstLoanTypeList');
  }
  GetAllCSTTargetBookings(booking_id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CSTTargetBooking/${booking_id}`);
  }
  GetAllCSTTargetBookingsBySeason(season_Id : number | string,booking_Type_Id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CSTTargetBooking?season_Id=${season_Id}&booking_Type_Id=${booking_Type_Id}`);
  }
  GetCSTRatesBytargetBookings(target_booking_Id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CSTTargetBooking/GetCSTRatesBytargetBookings?target_booking_Id=${target_booking_Id}`);
  }
  GetCSTBookingTypeListBySeason(season_Id : number | string,booking_Id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CSTTargetBooking/GetCSTBookingTypeListBySeason?season_Id=${season_Id}&booking_Id=${booking_Id}`);
  }
  GetAllCSTSeasons(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'CSTSeason');
  }
  GetCSTSeasonById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CSTSeason/${id}`);
  }
  GetBookingRateByMaxTargetBag(company_Id: number | string,max_Target_Bag : number,season_Id : number | string,booking_Type_Id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CSTBooking/GetBookingRateByMaxTargetBag?company_Id=${company_Id}&max_Target_Bag=${max_Target_Bag}&season_Id=${season_Id}&booking_Type_Id=${booking_Type_Id}`);
  }
  IsExistBookingNo(booking_No: number | string,booking_Type_Id : number | string,season_Id : number | string,company_Id : number | string): Observable<boolean> {
    return this.http.get<any>(this.endpoint + `CSTBooking/IsExistBookingNo?booking_No=${booking_No}&booking_Type_Id=${booking_Type_Id}&season_Id=${season_Id}&company_Id=${company_Id}`);
  }
  getCSTCustomersFiltered(filterValue: any): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CSTBooking/getCSTCustomersFiltered?filterValue=${filterValue}`);
  }
  GetCSTCustomersByBookingNo(booking_No: string,user_Id : number,booking_Id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CSTBooking/GetCSTCustomersByBookingNo?booking_No=${booking_No}&user_Id=${user_Id}&booking_Id=${booking_Id}`);
  }
  GetCSTMaxTargetBag(booking_Id: number | string,booking_Type_Id : number | string,season_Id : number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CSTBooking/GetCSTMaxTargetBag?booking_Id=${booking_Id}&booking_Type_Id=${booking_Type_Id}&season_Id=${season_Id}`);
  }
  GetCSTSROCode(company_Id : number | string) {
    return this.http.get(this.endpoint + `CSTSRO/GetCSTSROCode?company_Id=${company_Id}`, { responseType: 'text' });
  }
  GetCSTBookingsFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `CSTBooking/GetCSTBookingsFiltered`, data);
  }
  GetCSTBookingListFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `CSTBooking/GetCSTBookingListFiltered`, data);
  }
  GetCSTBookingsRatesFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `CSTBookingRate/GetCSTBookingsRatesFiltered`, data);
  }
  GetAllCSTSRLoansFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `CSTSRLoan/GetAllCSTSRLoansFiltered`, data);
  }
  GetAllCSTDOListFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `CSTDO/GetAllCSTDOListFiltered`, data);
  }
  GetAllCSTSRListFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `CSTSRO/GetAllCSTSRListFiltered`, data);
  }
  GetAllCSTCustomersListFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `CSTCustomer/GetAllCSTCustomersListFiltered`, data);
  }
  
  GetAllCSTSROs(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'CSTSRO');
  }
  SaveCSTSRO(data: any) {
    return this.http.post(`${this.endpoint}CSTSRO`, data);
  }
  GetCSTSROById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CSTSRO/${id}`);
  }
  GetCSTSROByBookingId(booking_id: number | string,customer_id: number | string,booking_Type_Id : number | string,season_Id : number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CSTSRO/GetCSTSROByBookingId?booking_id=${booking_id}&customer_id=${customer_id}&booking_Type_Id=${booking_Type_Id}&season_Id=${season_Id}`);
  }
  UpdateCSTSRO(data: any){
    return this.http.put(this.endpoint + `CSTSRO`, data);
  }
  IsExistSROManualCode(sro_manual_Code: number | string): Observable<boolean> {
    return this.http.get<any>(this.endpoint + `CSTSRO/IsExistSROManualCode?code=${sro_manual_Code}`);
  }
  GetCSTBagBalanceQty(booking_Id: number | string,booking_Type_Id : number | string,season_Id : number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CSTSRO/GetCSTBagBalanceQty?booking_Id=${booking_Id}&booking_Type_Id=${booking_Type_Id}&season_Id=${season_Id}`);
  }
  GetTTlSRQtyByTBookingId(target_Booking_Id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CSTSRO/GetTTlSRQtyByTBookingId?target_Booking_Id=${target_Booking_Id}`);
  }
  GetCSTBagBalanceQtyByCustomer(customer_Id: number | string,booking_Type_Id : number | string,season_Id : number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CSTDO/GetCSTBagBalanceQtyByCustomer?customer_Id=${customer_Id}&booking_Type_Id=${booking_Type_Id}&season_Id=${season_Id}`);
  }
  IsExistCSTCustomerCode(customer_Code: number | string): Observable<boolean> {
    return this.http.get<any>(this.endpoint + `CSTCustomer/IsExistCSTCustomerCode?customer_Code=${customer_Code}`);
  }
  IsExistCSTCustomerMobile(mobile_No: string): Observable<boolean> {
    return this.http.get<any>(this.endpoint + `CSTCustomer/IsExistCSTCustomerMobile?mobile_No=${mobile_No}`);
  }
  SaveCSTSeason(data: any) {
    return this.http.post(`${this.endpoint}CSTSeason`, data);
  }
  UpdateCSTSeason(data: any){
    return this.http.put(this.endpoint + `CSTSeason`, data);
  }
  IsExistSeasonYear(year: number | string): Observable<boolean> {
    return this.http.get<any>(this.endpoint + `CSTSeason/IsExistSeasonYear?year=${year}`);
  }
  GetCSTDOCode(company_Id : number | string) {
    return this.http.get(this.endpoint + `CSTDO/GetCSTDOCode?company_Id=${company_Id}`, { responseType: 'text' });
  }
  GetAllCSTDOs(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'CSTDO');
  }
  SaveCSTDO(data: any) {
    return this.http.post(`${this.endpoint}CSTDO`, data);
  }
  GetCSTDOById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CSTDO/${id}`);
  }
  UpdateCSTDO(data: any){
    return this.http.put(this.endpoint + `CSTDO`, data);
  }
  IsExistCSTDOManualCode(do_manual_Code: number | string): Observable<boolean> {
    return this.http.get<any>(this.endpoint + `CSTDO/IsExistCSTDOManualCode?code=${do_manual_Code}`);
  }
  
  GetAllCSTBookingRates(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'CSTBookingRate');
  }
  SaveCSTBookingRate(data: any) {
    return this.http.post(`${this.endpoint}CSTBookingRate`, data);
  }
  GetCSTBookingRateById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CSTBookingRate/${id}`);
  }
  GetCSTBookingRateDetailByCompany(season_Id: number | string,company_Id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CSTBookingRate/GetCSTBookingRateDetailByCompany?season_Id=${season_Id}&company_Id=${company_Id}`);
  }
  UpdateCSTBookingRate(data: any){
    return this.http.put(this.endpoint + `CSTBookingRate`, data);
  }
  IsExistBookingRateByCompany(season_Id: number | string,company_Id: number | string): Observable<boolean> {
    return this.http.get<any>(this.endpoint + `CSTBookingRate/IsExistBookingRateByCompany?season_Id=${season_Id}&company_Id=${company_Id}`);
  }
  GetAllCSTSRLaons(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'CSTSRLoan');
  }
  SaveCSTSRLoan(data: any) {
    return this.http.post(`${this.endpoint}CSTSRLoan`, data);
  }
  GetCSTSRLoanById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CSTSRLoan/${id}`);
  }
  UpdateCSTSRLoan(data: any){
    return this.http.put(this.endpoint + `CSTSRLoan`, data);
  }
  GetCSTSRLoanCode(company_Id : number | string) {
    return this.http.get(this.endpoint + `CSTSRLoan/GetCSTSRLoanCode?company_Id=${company_Id}`, { responseType: 'text' });
  }
  GetAllCSTSROsForLoanPayment(booking_Id: number | string){
    return this.http.get<any>(this.endpoint + `CSTLoanPayment/GetAllCSTSROsForLoanPayment?booking_Id=${booking_Id}`);
  }
  GetCSTSRLoanPaymentCode(company_Id : number | string) {
    return this.http.get(this.endpoint + `CSTLoanPayment/GetCSTSRLoanPaymentCode?company_Id=${company_Id}`, { responseType: 'text' });
  }
  GetAllCSTSRLoansBySRO(target_Booking_Id: number | string,sro_Id : number | string){
    return this.http.get<any>(this.endpoint + `CSTLoanPayment/GetAllCSTSRLoansBySRO?target_Booking_Id=${target_Booking_Id}&sro_Id=${sro_Id}`);
  }
  GetAllCSTSRLoansByBookingId(booking_Id: number | string,target_Booking_Id : number | string){
    return this.http.get<any>(this.endpoint + `CSTLoanPayment/GetAllCSTSRLoansByBookingId?booking_Id=${booking_Id}&target_Booking_Id=${target_Booking_Id}`);
  }
  GetAllCSTSRLaonPayments(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'CSTLoanPayment');
  }
  SaveCSTSRLoanPayment(data: any) {
    return this.http.post(`${this.endpoint}CSTLoanPayment`, data);
  }
  GetCSTSRLoanPaymentById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CSTLoanPayment/${id}`);
  }
  UpdateCSTSRLoanPayment(data: any){
    return this.http.put(this.endpoint + `CSTLoanPayment`, data);
  }
  GetAlreadyPaidAmntBySRLoan(sr_Loan_Id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CSTLoanPayment/GetAlreadyPaidAmntBySRLoan?sr_Loan_Id=${sr_Loan_Id}`);
  }
  GetAllCSTSRLaonReturns(): Observable<any[]> {
    return this.http.get<any>(this.endpoint + 'CSTSRLoanReturn');
  }
  SaveCSTSRLoanReturn(data: any) {
    return this.http.post(`${this.endpoint}CSTSRLoanReturn`, data);
  }
  GetCSTSRLoanReturnById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CSTSRLoanReturn/${id}`);
  }
  UpdateCSTSRLoanReturn(data: any){
    return this.http.put(this.endpoint + `CSTSRLoanReturn`, data);
  }
  GetCSTSRLoanReturnCode(company_Id : number | string) {
    return this.http.get(this.endpoint + `CSTSRLoanReturn/GetCSTSRLoanReturnCode?company_Id=${company_Id}`, { responseType: 'text' });
  }
  GetCSTDOByBookingId(booking_Id : number | string){
    return this.http.get(this.endpoint + `CSTDO/GetCSTDOByBookingId?booking_Id=${booking_Id}`);
  }
  GetAlreadyReturnedAmntBySRLoan(sr_Loan_Id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CSTSRLoanReturn/GetAlreadyReturnedAmntBySRLoan?sr_Loan_Id=${sr_Loan_Id}`);
  }
  GetAllCSTDeliveries(dO_Id : number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CSTDelivery/${dO_Id}`);
  }
  SaveCSTDelivery(data: any) {
    return this.http.post(this.endpoint + `CSTDelivery`, data);
  }
  GetAllPaidBookings(data: any): Observable<any> {
    return this.http.post<any>(this.endpoint + `CSTPaidBookingInfo/GetAllPaidBookings`,data);
  }
  
  GetCSTPaidBookingCode(company_Id : number | string) {
    return this.http.get(this.endpoint + `CSTPaidBookingInfo/GetCSTPaidBookingCode?company_Id=${company_Id}`, { responseType: 'text' });
  }
  getCSTModeCollectionTypeList() {
    return this.http.get<any>(this.endpoint + 'CompanyLookupType/getCSTModeCollectionTypeList');
  }
  SaveCSTPaidBookingInfo(data: any) {
    return this.http.post(`${this.endpoint}CSTPaidBookingInfo`, data);
  }
  GetCSTPaidBookingInfoById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CSTPaidBookingInfo/${id}`);
  }
  UpdateCSTPaidBookingInfo(data: any){
    return this.http.put(this.endpoint + `CSTPaidBookingInfo`, data);
  }
  GetPaidBookingSummaryByTBId(target_booking_Id : number): Observable<any>{
    return this.http.get<any>(this.endpoint + `CSTPaidBookingInfo/GetPaidBookingSummaryByTBId?target_booking_Id=${target_booking_Id}`);
  }
  GetSackQtyBalanceBySR(sr_Id : number): Observable<any>{
    return this.http.get<any>(this.endpoint + `CSTDO/GetSackQtyBalanceBySR?sr_Id=${sr_Id}`);
  }
  GetDOQtyBySRId(sr_Id : number,dO_Id: number): Observable<any>{
    return this.http.get<any>(this.endpoint + `CSTDO/GetDOQtyBySRId?sr_Id=${sr_Id}&dO_Id=${dO_Id}`);
  }
  SaveCSTProjectLoanPayment(data: any) {
    return this.http.post(`${this.endpoint}CSTProjectLoan`, data);
  }
  GetCSTProjectLoanPaymentById(id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CSTProjectLoan/${id}`);
  }
  UpdateCSTProjectLoanPayment(data: any){
    return this.http.put(this.endpoint + `CSTProjectLoan`, data);
  }
  GetCSTProjectLoanCode(company_Id : number | string) {
    return this.http.get(this.endpoint + `CSTProjectLoan/GetCSTProjectLoanCode?company_Id=${company_Id}`, { responseType: 'text' });
  }
  GetAllCSTProjectLoans(data: any): Observable<any> {
    return this.http.post<any>(this.endpoint + `CSTProjectLoan/GetAllCSTProjectLoans`,data);
  }
  GetAllCSTProjectLoansFiltered(data: any): Observable<any[]> {
    return this.http.post<any>(this.endpoint + `CSTProjectLoan/GetAllCSTProjectLoansFiltered`, data);
  }
  GetAlreadyPaidPLAmntBySRLoan(sr_Loan_Id: number | string): Observable<any[]> {
    return this.http.get<any>(this.endpoint + `CSTProjectLoan/GetAlreadyPaidPLAmntBySRLoan?sr_Loan_Id=${sr_Loan_Id}`);
  }
  GetAllCSTProjectLoansBySRO(target_Booking_Id: number | string,sro_Id : number | string){
    return this.http.get<any>(this.endpoint + `CSTProjectLoan/GetAllCSTProjectLoansBySRO?target_Booking_Id=${target_Booking_Id}&sro_Id=${sro_Id}`);
  }
  //#endregion cst
}